package lol.folium.unstable.blackjack;

import java.util.ArrayList;
import java.util.List;

public final class Hand {

    private final List<Card> cards = new ArrayList<>();

    public void add(Card card) {
        cards.add(card);
    }

    public List<Card> cards() {
        return cards;
    }

    public int value() {
        int total = 0;
        int aces = 0;
        for (Card card : cards) {
            total += card.value();
            if (card.rank() == Card.Rank.ACE) aces++;
        }
        while (total > 21 && aces > 0) {
            total -= 10;
            aces--;
        }
        return total;
    }

    public boolean isBust() {
        return value() > 21;
    }

    public boolean isBlackjack() {
        return cards.size() == 2 && value() == 21;
    }

    public boolean isSoft() {
        int total = 0;
        int aces = 0;
        for (Card card : cards) {
            total += card.value();
            if (card.rank() == Card.Rank.ACE) aces++;
        }
        while (total > 21 && aces > 0) {
            total -= 10;
            aces--;
        }
        return aces > 0 && total <= 21;
    }

    public void clear() {
        cards.clear();
    }

    public int size() {
        return cards.size();
    }
}
