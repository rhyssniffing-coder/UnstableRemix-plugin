package lol.folium.unstable.command;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;

import java.util.List;

public final class TrashCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;

    public TrashCommand(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    protected void execute(Player player, String[] args) {
        openGui(player);
    }

    public void openGui(Player player) {
        String title = plugin.getConfig().getString("trash.title", "<gradient:#FF4444:#FF8800:#FFD700><bold>TRASH CAN</bold></gradient>");
        TrashHolder holder = new TrashHolder(plugin);
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.parse(title));
        holder.bind(inv);

        for (int i = 0; i < 54; i++) {
            if (i == 49) {
                inv.setItem(i, ItemBuilder.of(Material.BARRIER)
                        .name(TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700><bold>\u2718 CONFIRM CLEAR</bold></gradient>"))
                        .lore(List.of(
                                TextUtil.parse(""),
                                TextUtil.parse("<gray>Click to destroy all items</gray>"),
                                TextUtil.parse("<gray>in this inventory.</gray>")
                        ))
                        .build());
            } else if (i >= 45) {
                inv.setItem(i, ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE).name(net.kyori.adventure.text.Component.empty()).build());
            } else {
                inv.setItem(i, ItemBuilder.of(Material.GRAY_STAINED_GLASS_PANE).name(net.kyori.adventure.text.Component.empty()).build());
            }
        }

        player.openInventory(inv);
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
    }

    public static final class TrashHolder extends GuiHolder {
        private final UnstableRemixPlugin plugin;

        TrashHolder(UnstableRemixPlugin plugin) {
            this.plugin = plugin;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            if (slot < 0 || slot >= 54) return;
            if (event.getCurrentItem() == null || event.getCurrentItem().getType() == Material.AIR) return;

            if (slot == 49) {
                int cleared = 0;
                Inventory inv = getInventory();
                for (int i = 0; i < 45; i++) {
                    if (inv.getItem(i) != null && inv.getItem(i).getType() != Material.AIR
                            && inv.getItem(i).getType() != Material.GRAY_STAINED_GLASS_PANE) {
                        cleared++;
                    }
                    inv.setItem(i, null);
                }
                event.getWhoClicked().closeInventory();
                if (cleared > 0) {
                    String msg = plugin.getConfig().getString("trash.destroyed-message",
                            "<red>Destroyed <white>{count}</white> item(s).</red>");
                    event.getWhoClicked().sendMessage(TextUtil.parse(msg.replace("{count}", String.valueOf(cleared))));
                } else {
                    String msg = plugin.getConfig().getString("trash.empty-message", "<gray>Nothing to destroy.</gray>");
                    event.getWhoClicked().sendMessage(TextUtil.parse(msg));
                }
                return;
            }

            if (slot >= 45) return;
            event.setCancelled(false);
        }

        @Override
        public void handleClose(InventoryCloseEvent event) {
        }
    }

    public Listener createListener() {
        return new Listener() {
            @EventHandler
            public void onInventoryClick(InventoryClickEvent event) {
                if (event.getInventory().getHolder() instanceof TrashHolder holder) {
                    holder.handleClick(event);
                }
            }

            @EventHandler
            public void onInventoryClose(InventoryCloseEvent event) {
                if (event.getInventory().getHolder() instanceof TrashHolder holder) {
                    holder.handleClose(event);
                }
            }

            @EventHandler
            public void onInventoryDrag(InventoryDragEvent event) {
                if (event.getInventory().getHolder() instanceof TrashHolder) {
                    event.setCancelled(true);
                }
            }
        };
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        return List.of();
    }

    @Override
    protected String permission() {
        return null;
    }
}
