package lol.folium.unstable.quest;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class QuestCommand extends SubCommand {

    private final QuestService quests;

    public QuestCommand(QuestService quests) {
        this.quests = quests;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length == 0) {
            quests.openGui(player);
            return;
        }
        QuestTier tier = parseTier(args[0]);
        if (tier != null) {
            quests.openTierGui(player, tier, 0);
            return;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            if (!player.hasPermission("unstable.admin")) {
                player.sendMessage(TextUtil.parse("<red>No permission."));
                return;
            }
            UnstableRemixPlugin.getInstance().getConfigManager().reloadAll();
            quests.reload();
            UnstableRemixPlugin.getInstance().refreshPlaceholderExpansions();
            player.sendMessage(TextUtil.parse("<green>Quests reloaded."));
            return;
        }
        if (args[0].equalsIgnoreCase("admin")) {
            handleAdmin(player, args);
            return;
        }
        quests.openGui(player);
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            List<String> options = new ArrayList<>(List.of("daily", "weekly", "monthly", "achievements"));
            if (player.hasPermission("unstable.admin")) {
                options.add("admin");
                options.add("reload");
            }
            return options;
        }
        if (!player.hasPermission("unstable.admin") || !args[0].equalsIgnoreCase("admin")) {
            return List.of();
        }
        if (args.length == 2) {
            return List.of("complete", "reset", "setreward");
        }
        if (args.length == 3) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        }
        if (args.length == 4 && args[1].equalsIgnoreCase("complete")) {
            return quests.questIdSuggestions();
        }
        if (args.length == 4 && args[1].equalsIgnoreCase("reset")) {
            return List.of("daily", "weekly", "monthly");
        }
        if (args.length == 3 && args[1].equalsIgnoreCase("setreward")) {
            return quests.questIdSuggestions();
        }
        if (args.length == 4 && args[1].equalsIgnoreCase("setreward")) {
            return List.of("10", "25", "50", "75", "100");
        }
        return List.of();
    }

    @Override
    protected String permission() {
        return null;
    }

    private void handleAdmin(Player sender, String[] args) {
        if (!sender.hasPermission("unstable.admin")) {
            sender.sendMessage(TextUtil.parse("<red>No permission."));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(TextUtil.parse("<yellow>/quests admin complete <player> <quest_id>"));
            sender.sendMessage(TextUtil.parse("<yellow>/quests admin reset <player> <daily|weekly|monthly>"));
            sender.sendMessage(TextUtil.parse("<yellow>/quests admin setreward <quest_id> <amount>"));
            return;
        }
        if (args[1].equalsIgnoreCase("setreward")) {
            if (args.length < 4) {
                sender.sendMessage(TextUtil.parse("<yellow>/quests admin setreward <quest_id> <amount>"));
                return;
            }
            try {
                long amount = Long.parseLong(args[3]);
                if (!quests.setReward(args[2], amount)) {
                    sender.sendMessage(TextUtil.parse("<red>Unknown quest id."));
                    return;
                }
                sender.sendMessage(TextUtil.parse("<green>Set reward of <white>" + args[2] + "</white> to <light_purple>" + Math.min(100L, amount) + " Shards</light_purple>."));
            } catch (NumberFormatException ex) {
                sender.sendMessage(TextUtil.parse("<red>Invalid number."));
            }
            return;
        }
        Player target = Bukkit.getPlayerExact(args[2]);
        if (target == null) {
            sender.sendMessage(TextUtil.parse("<red>Player not found."));
            return;
        }
        if (args[1].equalsIgnoreCase("complete")) {
            if (!quests.forceComplete(target, args[3])) {
                sender.sendMessage(TextUtil.parse("<red>Unknown quest id."));
                return;
            }
            sender.sendMessage(TextUtil.parse("<green>Quest completed for " + target.getName() + "."));
            return;
        }
        if (args[1].equalsIgnoreCase("reset")) {
            QuestTier tier = parseTier(args[3]);
            if (tier == null || tier == QuestTier.MILESTONE || !quests.reset(target, tier)) {
                sender.sendMessage(TextUtil.parse("<red>Use daily, weekly, or monthly."));
                return;
            }
            sender.sendMessage(TextUtil.parse("<green>Reset " + tier.id() + " quest for " + target.getName() + "."));
            return;
        }
        sender.sendMessage(TextUtil.parse("<yellow>/quests admin complete <player> <quest_id>"));
        sender.sendMessage(TextUtil.parse("<yellow>/quests admin reset <player> <daily|weekly|monthly>"));
        sender.sendMessage(TextUtil.parse("<yellow>/quests admin setreward <quest_id> <amount>"));
    }

    private QuestTier parseTier(String raw) {
        String normalized = raw.toLowerCase(Locale.ROOT);
        if (normalized.equals("achievements") || normalized.equals("achievement") || normalized.equals("milestones")) {
            return QuestTier.MILESTONE;
        }
        return QuestTier.from(raw);
    }
}
