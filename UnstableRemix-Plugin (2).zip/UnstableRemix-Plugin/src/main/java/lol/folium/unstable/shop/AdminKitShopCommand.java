package lol.folium.unstable.shop;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.kit.KitManager;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class AdminKitShopCommand implements CommandExecutor, TabCompleter {

    private final UnstableRemixPlugin plugin;
    private final KitManager kits;

    public AdminKitShopCommand(UnstableRemixPlugin plugin, KitManager kits) {
        this.plugin = plugin;
        this.kits = kits;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (!player.hasPermission("unstable.coreadmin")) {
            player.sendMessage(TextUtil.parse("<red>No permission.</red>"));
            return true;
        }
        if (args.length >= 1) {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "delete" -> handleDelete(player, args);
                case "import" -> handleImport(player);
                default -> player.sendMessage(TextUtil.parse("<red>Usage: /adminkitshop [delete <id> | import]</red>"));
            }
            return true;
        }
        openGui(player);
        return true;
    }

    private void handleDelete(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /adminkitshop delete <id></red>"));
            return;
        }
        String id = args[1].toLowerCase(Locale.ROOT);
        if (kits.deleteKit(id)) {
            player.sendMessage(TextUtil.parse("<green>Deleted kit <white>" + id + "</white>.</green>"));
        } else {
            player.sendMessage(TextUtil.parse("<red>Kit <white>" + id + "</white> not found.</red>"));
        }
    }

    private void handleImport(Player player) {
        File dir = new File(plugin.getDataFolder(), "kits-import");
        if (!dir.exists() || !dir.isDirectory()) {
            player.sendMessage(TextUtil.parse("<red>Import directory not found at <white>plugins/UnstableRemix/kits-import/</white>.</red>"));
            return;
        }
        kits.importKitsFromFiles(dir);
        player.sendMessage(TextUtil.parse("<green>Imported kits from <white>" + dir.getAbsolutePath() + "</white>.</green>"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(List.of("delete", "import"), args[0]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("delete")) {
            return filter(kits.kitIds(), args[1]);
        }
        return Collections.emptyList();
    }

    private List<String> filter(List<String> options, String prefix) {
        List<String> result = new ArrayList<>();
        for (String opt : options) {
            if (opt.startsWith(prefix.toLowerCase(Locale.ROOT))) result.add(opt);
        }
        return result;
    }

    private void openGui(Player player) {
        List<String> ids = kits.kitIds();
        FileConfiguration config = plugin.getConfigManager().get("kits.yml");
        if (config == null) {
            player.sendMessage(TextUtil.parse("<red>kits.yml not loaded.</red>"));
            return;
        }
        int rows = Math.max(4, (int) Math.ceil(Math.min(ids.size() + 2, 54) / 9.0));
        if (rows > 6) rows = 6;

        AdminKitShopHolder holder = new AdminKitShopHolder(player);
        Inventory inventory = Bukkit.createInventory(holder, rows * 9, TextUtil.parse("<gradient:#FF4444:#FF8800>Kit Shop Admin</gradient>"));
        holder.bind(inventory);

        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE).name(Component.text("")).build());
        }

        int slot = 10;
        for (String kitId : ids) {
            if (slot >= inventory.getSize() - 9) break;
            if ((slot + 1) % 9 == 0 || slot % 9 == 8) {
                slot += 2;
                if (slot >= inventory.getSize() - 9) break;
            }

            long price = config.getLong("kits." + kitId + ".price", 0);
            boolean inShop = price > 0;
            String matName = config.getString("kits." + kitId + ".material", "BOOK");
            Material mat = Material.matchMaterial(matName);
            if (mat == null) mat = Material.BOOK;

            List<Component> lore = new ArrayList<>();
            lore.add(TextUtil.parse("<gray>ID: <white>" + kitId + "</white></gray>"));
            lore.add(TextUtil.parse("<gray>Price: <light_purple>" + price + " Shards</light_purple></gray>"));
            lore.add(TextUtil.parse(inShop ? "<green>In Shop</green>" : "<red>Not in Shop</red>"));
            lore.add(Component.empty());
            lore.add(TextUtil.parse("<yellow>Click to manage this kit</yellow>"));

            inventory.setItem(slot, ItemBuilder.of(mat)
                    .name(TextUtil.parse("<gold>" + kitId + "</gold>"))
                    .lore(lore)
                    .build());
            holder.kitSlots.put(slot, kitId);
            slot++;
        }

        int bottomRow = rows * 9 - 9;
        int createSlot = bottomRow + 4;
        int closeSlot = bottomRow + 7;
        holder.createSlot = createSlot;
        holder.closeSlot = closeSlot;

        inventory.setItem(createSlot, ItemBuilder.of(Material.GREEN_TERRACOTTA)
                .name(TextUtil.parse("<green><bold>Create Kit from Inventory</bold></green>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Creates a new kit with your current</gray>"),
                        TextUtil.parse("<gray>inventory, armor, and offhand.</gray>"),
                        Component.empty(),
                        TextUtil.parse("<yellow>Click to name it in chat</yellow>")))
                .build());
        inventory.setItem(closeSlot, ItemBuilder.of(Material.BARRIER)
                .name(TextUtil.parse("<red><bold>Close</bold></red>"))
                .build());

        player.openInventory(inventory);
    }

    private void openKitActions(Player player, String kitId) {
        FileConfiguration config = plugin.getConfigManager().get("kits.yml");
        long price = config.getLong("kits." + kitId + ".price", 0);
        boolean inShop = price > 0;
        int cooldown = config.getInt("kits." + kitId + ".cooldown-seconds", 0);
        String matName = config.getString("kits." + kitId + ".material", "BOOK");
        String reqGroup = config.getString("kits." + kitId + ".required-group", "");

        KitActionsHolder holder = new KitActionsHolder(player, kitId);
        Inventory inventory = Bukkit.createInventory(holder, 3 * 9,
                TextUtil.parse("<gradient:#FF4444:#FF8800>" + kitId + "</gradient>"));
        holder.bind(inventory);

        for (int i = 0; i < 27; i++) {
            inventory.setItem(i, ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE).name(Component.text("")).build());
        }

        inventory.setItem(10, ItemBuilder.of(Material.CHEST)
                .name(TextUtil.parse("<aqua><bold>Edit Kit Contents</bold></aqua>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Open the layout editor to</gray>"),
                        TextUtil.parse("<gray>modify this kit's items.</gray>")
                ))
                .build());

        inventory.setItem(12, ItemBuilder.of(inShop ? Material.LIME_DYE : Material.RED_DYE)
                .name(TextUtil.parse((inShop ? "<green>" : "<red>") + "<bold>" + (inShop ? "In Shop" : "Not in Shop") + "</bold></" + (inShop ? "green" : "red") + ">"))
                .lore(List.of(
                        TextUtil.parse("<gray>Current: " + (inShop ? "<green>Enabled</green>" : "<red>Disabled</red>") + "</gray>"),
                        TextUtil.parse("<gray>Price: <light_purple>" + price + " Shards</light_purple></gray>"),
                        Component.empty(),
                        TextUtil.parse("<yellow>Click to toggle</yellow>")
                ))
                .build());

        inventory.setItem(14, ItemBuilder.of(Material.EMERALD)
                .name(TextUtil.parse("<light_purple><bold>Set Price</bold></light_purple>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Current: <light_purple>" + price + " Shards</light_purple></gray>"),
                        Component.empty(),
                        TextUtil.parse("<yellow>Click to set via chat</yellow>")
                ))
                .build());

        inventory.setItem(16, ItemBuilder.of(Material.CLOCK)
                .name(TextUtil.parse("<gold><bold>Set Cooldown</bold></gold>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Current: <white>" + cooldown + "s</white></gray>"),
                        Component.empty(),
                        TextUtil.parse("<yellow>Click to set via chat</yellow>")
                ))
                .build());

        inventory.setItem(20, ItemBuilder.of(Material.BOOK)
                .name(TextUtil.parse("<blue><bold>Set Display Material</bold></blue>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Current: <white>" + matName + "</white></gray>"),
                        Component.empty(),
                        TextUtil.parse("<yellow>Click to set via chat</yellow>")
                ))
                .build());

        inventory.setItem(22, ItemBuilder.of(Material.NAME_TAG)
                .name(TextUtil.parse("<green><bold>Set Required Group</bold></green>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Current: <white>" + (reqGroup.isBlank() ? "None" : reqGroup) + "</white></gray>"),
                        Component.empty(),
                        TextUtil.parse("<yellow>Click to set via chat</yellow>")
                ))
                .build());

        inventory.setItem(24, ItemBuilder.of(Material.RED_DYE)
                .name(TextUtil.parse("<red><bold>Set LuckPerms Rank</bold></red>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Sets the LuckPerms group</gray>"),
                        TextUtil.parse("<gray>assigned when this kit is selected.</gray>"),
                        Component.empty(),
                        TextUtil.parse("<yellow>Click to set via chat</yellow>")
                ))
                .build());

        inventory.setItem(26, ItemBuilder.of(Material.BARRIER)
                .name(TextUtil.parse("<red><bold>Delete Kit</bold></red>"))
                .lore(List.of(
                        TextUtil.parse("<red>Permanently delete this kit.</red>"),
                        Component.empty(),
                        TextUtil.parse("<yellow>Click to confirm</yellow>")
                ))
                .build());

        inventory.setItem(18, ItemBuilder.of(Material.ARROW)
                .name(TextUtil.parse("<yellow><bold>Back</bold></yellow>"))
                .build());
        holder.backSlot = 18;

        player.openInventory(inventory);
    }

    private final Map<UUID, String> pendingInput = new HashMap<>();

    private final class AdminKitShopHolder extends GuiHolder {
        private final Player player;
        private final Map<Integer, String> kitSlots = new HashMap<>();
        private int createSlot = -1;
        private int closeSlot = -1;

        AdminKitShopHolder(Player player) {
            this.player = player;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();

            if (slot == closeSlot) {
                player.closeInventory();
                return;
            }

            if (slot == createSlot) {
                player.closeInventory();
                player.sendMessage(TextUtil.parse("<yellow>Type a kit ID in chat to create from your inventory:</yellow>"));
                player.sendMessage(TextUtil.parse("<gray>(or type <white>cancel</white> to cancel)</gray>"));
                pendingInput.put(player.getUniqueId(), "create:");
                listenChat(player, message -> {
                    String pending = pendingInput.remove(player.getUniqueId());
                    if (pending == null || !pending.startsWith("create:")) return;
                    if (message.equalsIgnoreCase("cancel")) {
                        player.sendMessage(TextUtil.parse("<red>Cancelled.</red>"));
                        openGui(player);
                        return;
                    }
                    if (message.contains(" ")) {
                        player.sendMessage(TextUtil.parse("<red>Kit ID must not contain spaces.</red>"));
                        openGui(player);
                        return;
                    }
                    String id = message.toLowerCase();
                    ItemStack held = player.getInventory().getItemInMainHand();
                    Material displayMat = held.getType().isAir() ? Material.IRON_SWORD : held.getType();
                    kits.createKit(player, id, displayMat);
                    player.sendMessage(TextUtil.parse("<green>Created kit <white>" + id + "</white> from your inventory.</green>"));
                    openGui(player);
                });
                return;
            }

            String kitId = kitSlots.get(slot);
            if (kitId != null) {
                openKitActions(player, kitId);
            }
        }

        private void listenChat(Player player, ChatCallback callback) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                org.bukkit.event.Listener listener = new org.bukkit.event.Listener() {
                    @org.bukkit.event.EventHandler
                    public void onChat(org.bukkit.event.player.PlayerChatEvent e) {
                        if (!e.getPlayer().equals(player)) return;
                        e.setCancelled(true);
                        callback.accept(e.getMessage().trim());
                        org.bukkit.event.HandlerList.unregisterAll(this);
                    }
                };
                Bukkit.getPluginManager().registerEvents(listener, plugin);
            }, 1L);
        }
    }

    private final class KitActionsHolder extends GuiHolder {
        private final Player player;
        private final String kitId;
        private int backSlot = -1;

        KitActionsHolder(Player player, String kitId) {
            this.player = player;
            this.kitId = kitId;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();

            if (slot == backSlot) {
                openGui(player);
                return;
            }

            switch (slot) {
                case 10 -> {
                    player.closeInventory();
                    kits.openLayoutEditor(player, kitId);
                }
                case 12 -> {
                    long current = plugin.getConfigManager().get("kits.yml").getLong("kits." + kitId + ".price", 0);
                    if (current > 0) {
                        kits.removeKitFromShop(kitId);
                        player.sendMessage(TextUtil.parse("<green>Removed <white>" + kitId + "</white> from shop.</green>"));
                    } else {
                        String mat = plugin.getConfigManager().get("kits.yml").getString("kits." + kitId + ".material", "BOOK");
                        kits.addKitToShop(kitId, 0, 5000, mat);
                        player.sendMessage(TextUtil.parse("<green>Added <white>" + kitId + "</white> to shop for 5000 Shards.</green>"));
                    }
                    openKitActions(player, kitId);
                }
                case 14 -> {
                    player.closeInventory();
                    player.sendMessage(TextUtil.parse("<yellow>Type a price in chat for kit <white>" + kitId + "</white>:</yellow>"));
                    player.sendMessage(TextUtil.parse("<gray>(or type <white>cancel</white> to cancel)</gray>"));
                    pendingInput.put(player.getUniqueId(), "price:" + kitId);
                    listenChat(player, message -> {
                        String pending = pendingInput.remove(player.getUniqueId());
                        if (pending == null || !pending.startsWith("price:")) return;
                        if (message.equalsIgnoreCase("cancel")) {
                            player.sendMessage(TextUtil.parse("<red>Cancelled.</red>"));
                            openKitActions(player, kitId);
                            return;
                        }
                        try {
                            long price = Long.parseLong(message);
                            if (price <= 0) {
                                player.sendMessage(TextUtil.parse("<red>Price must be positive.</red>"));
                            } else {
                                kits.setKitShopPrice(kitId, price);
                                player.sendMessage(TextUtil.parse("<green>Set price of <white>" + kitId + "</white> to " + price + " Shards.</green>"));
                            }
                        } catch (NumberFormatException ex) {
                            player.sendMessage(TextUtil.parse("<red>Invalid number.</red>"));
                        }
                        openKitActions(player, kitId);
                    });
                }
                case 16 -> {
                    player.closeInventory();
                    player.sendMessage(TextUtil.parse("<yellow>Type cooldown in seconds for kit <white>" + kitId + "</white> (0 to disable):</yellow>"));
                    player.sendMessage(TextUtil.parse("<gray>(or type <white>cancel</white> to cancel)</gray>"));
                    pendingInput.put(player.getUniqueId(), "cooldown:" + kitId);
                    listenChat(player, message -> {
                        String pending = pendingInput.remove(player.getUniqueId());
                        if (pending == null || !pending.startsWith("cooldown:")) return;
                        if (message.equalsIgnoreCase("cancel")) {
                            player.sendMessage(TextUtil.parse("<red>Cancelled.</red>"));
                            openKitActions(player, kitId);
                            return;
                        }
                        try {
                            int cd = Integer.parseInt(message);
                            if (cd < 0) {
                                player.sendMessage(TextUtil.parse("<red>Cooldown must be 0 or positive.</red>"));
                            } else {
                                kits.editKit(kitId, "cooldown-seconds", String.valueOf(cd));
                                player.sendMessage(TextUtil.parse("<green>Set cooldown of <white>" + kitId + "</white> to " + cd + " seconds.</green>"));
                            }
                        } catch (NumberFormatException ex) {
                            player.sendMessage(TextUtil.parse("<red>Invalid number.</red>"));
                        }
                        openKitActions(player, kitId);
                    });
                }
                case 20 -> {
                    player.closeInventory();
                    player.sendMessage(TextUtil.parse("<yellow>Type a material name for <white>" + kitId + "</white>:</yellow>"));
                    player.sendMessage(TextUtil.parse("<gray>(e.g. DIAMOND_SWORD, or hold the item and type <white>hand</white>)</gray>"));
                    player.sendMessage(TextUtil.parse("<gray>(or type <white>cancel</white> to cancel)</gray>"));
                    pendingInput.put(player.getUniqueId(), "material:" + kitId);
                    listenChat(player, message -> {
                        String pending = pendingInput.remove(player.getUniqueId());
                        if (pending == null || !pending.startsWith("material:")) return;
                        if (message.equalsIgnoreCase("cancel")) {
                            player.sendMessage(TextUtil.parse("<red>Cancelled.</red>"));
                            openKitActions(player, kitId);
                            return;
                        }
                        String matInput = message.equalsIgnoreCase("hand")
                                ? player.getInventory().getItemInMainHand().getType().name()
                                : message;
                        Material mat = Material.matchMaterial(matInput);
                        if (mat == null || mat.isAir()) {
                            player.sendMessage(TextUtil.parse("<red>Unknown material: " + matInput + "</red>"));
                        } else {
                            kits.editKit(kitId, "material", mat.name());
                            player.sendMessage(TextUtil.parse("<green>Set display material of <white>" + kitId + "</white> to " + mat.name() + ".</green>"));
                        }
                        openKitActions(player, kitId);
                    });
                }
                case 22 -> {
                    player.closeInventory();
                    player.sendMessage(TextUtil.parse("<yellow>Type a LuckPerms group name for <white>" + kitId + "</white>:</yellow>"));
                    player.sendMessage(TextUtil.parse("<gray>(type <white>none</white> to clear the requirement)</gray>"));
                    player.sendMessage(TextUtil.parse("<gray>(or type <white>cancel</white> to cancel)</gray>"));
                    pendingInput.put(player.getUniqueId(), "group:" + kitId);
                    listenChat(player, message -> {
                        String pending = pendingInput.remove(player.getUniqueId());
                        if (pending == null || !pending.startsWith("group:")) return;
                        if (message.equalsIgnoreCase("cancel")) {
                            player.sendMessage(TextUtil.parse("<red>Cancelled.</red>"));
                            openKitActions(player, kitId);
                            return;
                        }
                        if (message.equalsIgnoreCase("none")) {
                            kits.editKit(kitId, "required-group", "");
                            player.sendMessage(TextUtil.parse("<green>Cleared required group for <white>" + kitId + "</white>.</green>"));
                        } else {
                            kits.editKit(kitId, "required-group", message.toLowerCase());
                            player.sendMessage(TextUtil.parse("<green>Set required group of <white>" + kitId + "</white> to <white>" + message.toLowerCase() + "</white>.</green>"));
                        }
                        openKitActions(player, kitId);
                    });
                }
                case 24 -> {
                    player.closeInventory();
                    player.sendMessage(TextUtil.parse("<yellow>Type a LuckPerms rank name for <white>" + kitId + "</white>:</yellow>"));
                    player.sendMessage(TextUtil.parse("<gray>(type <white>none</white> to clear the rank)</gray>"));
                    player.sendMessage(TextUtil.parse("<gray>(or type <white>cancel</white> to cancel)</gray>"));
                    pendingInput.put(player.getUniqueId(), "rank:" + kitId);
                    listenChat(player, message -> {
                        String pending = pendingInput.remove(player.getUniqueId());
                        if (pending == null || !pending.startsWith("rank:")) return;
                        if (message.equalsIgnoreCase("cancel")) {
                            player.sendMessage(TextUtil.parse("<red>Cancelled.</red>"));
                            openKitActions(player, kitId);
                            return;
                        }
                        if (message.equalsIgnoreCase("none")) {
                            kits.editKit(kitId, "luckperms-rank", "");
                            player.sendMessage(TextUtil.parse("<green>Cleared LuckPerms rank for <white>" + kitId + "</white>.</green>"));
                        } else {
                            kits.editKit(kitId, "luckperms-rank", message.toLowerCase());
                            player.sendMessage(TextUtil.parse("<green>Set LuckPerms rank of <white>" + kitId + "</white> to <white>" + message.toLowerCase() + "</white>.</green>"));
                        }
                        openKitActions(player, kitId);
                    });
                }
                case 26 -> {
                    player.closeInventory();
                    player.sendMessage(TextUtil.parse("<red>Type <white>delete</white> in chat to confirm deleting kit <white>" + kitId + "</white>:</red>"));
                    player.sendMessage(TextUtil.parse("<gray>(or type anything else to cancel)</gray>"));
                    pendingInput.put(player.getUniqueId(), "delete:" + kitId);
                    listenChat(player, message -> {
                        String pending = pendingInput.remove(player.getUniqueId());
                        if (pending == null || !pending.startsWith("delete:")) return;
                        if (message.equalsIgnoreCase("delete")) {
                            kits.deleteKit(kitId);
                            player.sendMessage(TextUtil.parse("<green>Deleted kit <white>" + kitId + "</white>.</green>"));
                            openGui(player);
                        } else {
                            player.sendMessage(TextUtil.parse("<red>Cancelled.</red>"));
                            openKitActions(player, kitId);
                        }
                    });
                }
            }
        }

        private void listenChat(Player player, ChatCallback callback) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                org.bukkit.event.Listener listener = new org.bukkit.event.Listener() {
                    @org.bukkit.event.EventHandler
                    public void onChat(org.bukkit.event.player.PlayerChatEvent e) {
                        if (!e.getPlayer().equals(player)) return;
                        e.setCancelled(true);
                        callback.accept(e.getMessage().trim());
                        org.bukkit.event.HandlerList.unregisterAll(this);
                    }
                };
                Bukkit.getPluginManager().registerEvents(listener, plugin);
            }, 1L);
        }
    }

    private interface ChatCallback {
        void accept(String message);
    }
}
