package lol.folium.unstable.ffa;

import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public final class FFAWeaponCommand extends SubCommand {

    private final FFAWeaponManager weaponManager;

    public FFAWeaponCommand(FFAWeaponManager weaponManager) {
        this.weaponManager = weaponManager;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("weapons")) {
            openMainGui(player);
        } else if (args[0].equalsIgnoreCase("help")) {
            showHelp(player);
        } else {
            openMainGui(player);
        }
    }

    private void showHelp(Player player) {
        player.sendMessage(TextUtil.parse("<gradient:#7D3BCC:#F186F3><bold>FFA WEAPONS</bold></gradient>"));
        player.sendMessage(TextUtil.parse("<gray>/ffa weapons</gray> <dark_gray>–</dark_gray> <gray>Opens a GUI with the weapons</gray>"));
    }

    private void openMainGui(Player player) {
        WeaponGui holder = new WeaponGui(player);
        Inventory inv = Bukkit.createInventory(holder, 27,
                TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700><bold>FFA WEAPONS</bold></gradient>"));
        holder.bind(inv);

        ItemStack filler = ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE)
                .name(TextUtil.parse(" ")).build();
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        inv.setItem(10, ItemBuilder.of(Material.NETHERITE_SWORD)
                .name(TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700><bold>\u2694 SWORDS</bold></gradient>"))
                .lore(List.of(
                        TextUtil.parse("<dark_gray><strikethrough>                         </strikethrough></dark_gray>"),
                        TextUtil.parse("<gray>Click to browse</gray>")
                ))
                .build());
        inv.setItem(13, ItemBuilder.of(Material.MACE)
                .name(TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700><bold>\uD83D\uDD28 MACES</bold></gradient>"))
                .lore(List.of(
                        TextUtil.parse("<dark_gray><strikethrough>                         </strikethrough></dark_gray>"),
                        TextUtil.parse("<gray>Click to browse</gray>")
                ))
                .build());
        inv.setItem(16, ItemBuilder.of(Material.NETHERITE_AXE)
                .name(TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700><bold>\u26CF AXES</bold></gradient>"))
                .lore(List.of(
                        TextUtil.parse("<dark_gray><strikethrough>                         </strikethrough></dark_gray>"),
                        TextUtil.parse("<gray>Click to browse</gray>")
                ))
                .build());
        inv.setItem(22, ItemBuilder.of(Material.BOW)
                .name(TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700><bold>\uD83C\uDFF9 BOWS</bold></gradient>"))
                .lore(List.of(
                        TextUtil.parse("<dark_gray><strikethrough>                         </strikethrough></dark_gray>"),
                        TextUtil.parse("<gray>Click to browse</gray>")
                ))
                .build());

        player.openInventory(inv);
    }

    private void openCategoryGui(Player player, String category) {
        List<FFAWeaponManager.FFAWeapon> weapons = weaponManager.getWeaponsByCategory(category);
        WeaponCategoryGui holder = new WeaponCategoryGui(player, category);
        Inventory inv = Bukkit.createInventory(holder, 45,
                TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700><bold>" + capitalize(category).toUpperCase() + "</bold></gradient>"));
        holder.bind(inv);

        for (int i = 0; i < 45; i++)
            inv.setItem(i, ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE).name(TextUtil.parse(" ")).build());

        for (int i = 0; i < weapons.size() && i < 9; i++)
            inv.setItem(i, weaponManager.createWeapon(weapons.get(i).id()));

        inv.setItem(40, ItemBuilder.of(Material.BARRIER)
                .name(TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700><bold>\u2190 RETURN</bold></gradient>"))
                .lore(List.of(TextUtil.parse("<dark_gray>Back</dark_gray>")))
                .build());

        player.openInventory(inv);
    }

    private String capitalize(String s) { return s.isEmpty() ? s : s.substring(0, 1).toUpperCase() + s.substring(1); }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) return filter(literals("weapons", "help"), args[0]);
        return List.of();
    }

    @Override
    protected String permission() {
        return null;
    }

    private final class WeaponGui extends GuiHolder {
        private final Player player;
        WeaponGui(Player player) { this.player = player; }
        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            if (slot == 10) openCategoryGui(player, "swords");
            else if (slot == 13) openCategoryGui(player, "maces");
            else if (slot == 16) openCategoryGui(player, "axes");
            else if (slot == 22) openCategoryGui(player, "bows");
        }
    }

    private final class WeaponCategoryGui extends GuiHolder {
        private final Player player;
        WeaponCategoryGui(Player player, String category) { this.player = player; }
        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            if (slot == 40) { openMainGui(player); return; }
            if (slot < 0 || slot >= event.getInventory().getSize()) return;
            ItemStack item = event.getInventory().getItem(slot);
            if (item == null || item.getType() == Material.AIR || item.getType() == Material.BARRIER) return;
            String weaponId = weaponManager.getWeaponId(item);
            if (weaponId != null) {
                player.getInventory().addItem(weaponManager.createWeapon(weaponId));
                player.closeInventory();
                FFAWeaponManager.FFAWeapon w = weaponManager.getWeapon(weaponId);
                if (w != null) player.sendMessage(TextUtil.parse("<green><bold>FFA</bold></green> <dark_gray>»</dark_gray> <gray>Received " + w.name() + "</gray>"));
            }
        }
    }
}
