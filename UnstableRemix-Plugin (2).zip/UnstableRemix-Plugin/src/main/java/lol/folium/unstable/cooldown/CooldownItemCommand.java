package lol.folium.unstable.cooldown;

import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class CooldownItemCommand extends SubCommand {

    private final CooldownItemManager itemManager;

    public CooldownItemCommand(CooldownItemManager itemManager) {
        this.itemManager = itemManager;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length == 0) {
            showHelp(player);
            return;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "give" -> handleGive(player, args);
            case "giveall" -> handleGiveAll(player, args);
            case "list" -> handleList(player);
            case "reload" -> handleReload(player);
            case "shop" -> handleShop(player);
            default -> showHelp(player);
        }
    }

    private void showHelp(Player player) {
        player.sendMessage(TextUtil.parse("<gradient:#FF4444:#FF8800><bold>Cooldown Items</bold></gradient>"));
        player.sendMessage(TextUtil.parse("<yellow>/cooldownitem give <player> <item> [amount]</yellow> <dark_gray>-</dark_gray> <gray>Give cooldown item</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/cooldownitem giveall <player></yellow> <dark_gray>-</dark_gray> <gray>Give one of each item</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/cooldownitem list</yellow> <dark_gray>-</dark_gray> <gray>List all items</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/cooldownitem shop</yellow> <dark_gray>-</dark_gray> <gray>Open cooldown item shop</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/cooldownitem reload</yellow> <dark_gray>-</dark_gray> <gray>Reload items</gray>"));
    }

    private void handleGive(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(TextUtil.parse("<red>Usage: /cooldownitem give <player> <item_id> [amount]</red>"));
            return;
        }

        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            player.sendMessage(TextUtil.parse("<red>Player not found.</red>"));
            return;
        }

        CooldownItem item = itemManager.getItem(args[2]);
        if (item == null) {
            player.sendMessage(TextUtil.parse("<red>Item not found: <white>" + args[2] + "</white></red>"));
            player.sendMessage(TextUtil.parse("<gray>Available items: <white>" + String.join(", ", itemManager.getIds()) + "</white></gray>"));
            return;
        }

        int amount = 1;
        if (args.length >= 4) {
            try {
                amount = Integer.parseInt(args[3]);
                if (amount < 1 || amount > 64) {
                    player.sendMessage(TextUtil.parse("<red>Amount must be 1-64.</red>"));
                    return;
                }
            } catch (NumberFormatException ex) {
                player.sendMessage(TextUtil.parse("<red>Invalid amount.</red>"));
                return;
            }
        }

        itemManager.giveItem(target, item, amount);
        player.sendMessage(TextUtil.parse("<green>Gave <white>" + amount + "x " + item.displayName() + "</white> to <white>" + target.getName() + "</white>.</green>"));
        if (!player.equals(target)) {
            target.sendMessage(TextUtil.parse("<green>You received <white>" + amount + "x " + item.displayName() + "</white>!</green>"));
        }
    }

    private void handleList(Player player) {
        if (itemManager.all().isEmpty()) {
            player.sendMessage(TextUtil.parse("<gray>No cooldown items configured.</gray>"));
            return;
        }
        player.sendMessage(TextUtil.parse("<gradient:#FF4444:#FF8800><bold>Cooldown Items</bold></gradient>"));
        for (CooldownItem item : itemManager.all()) {
            String duration = item.durationSeconds() > 0 ? (item.durationSeconds() / 60) + "min" : "permanent";
            String effectName = formatEffectName(item.effect());
            String multi = item.effect().equals("shard-boost") ? " (" + String.format("%.1f", item.shardMultiplier()) + "x)" : "";
            player.sendMessage(TextUtil.parse(
                    "<white>/" + item.command() + "</white> "
                    + "<dark_gray>|</dark_gray> "
                    + "<gold>" + item.displayName() + "</gold> "
                    + "<dark_gray>|</dark_gray> "
                    + "<gray>" + effectName + multi + " " + duration + "</gray>"
            ));
        }
    }

    private void handleGiveAll(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /cooldownitem giveall <player></red>"));
            return;
        }

        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            player.sendMessage(TextUtil.parse("<red>Player not found.</red>"));
            return;
        }

        int given = 0;
        for (CooldownItem item : itemManager.all()) {
            itemManager.giveItem(target, item, 1);
            given++;
        }

        player.sendMessage(TextUtil.parse("<green>Gave <white>" + given + "</white> cooldown items to <white>" + target.getName() + "</white>.</green>"));
        if (!player.equals(target)) {
            target.sendMessage(TextUtil.parse("<green>You received <white>" + given + "</white> cooldown items!</green>"));
        }
    }

    private void handleShop(Player player) {
        player.sendMessage(TextUtil.parse("<gold><bold>Cooldown Item Shop</bold></gold>"));
        player.sendMessage(TextUtil.parse("<gray>Use <white>/cooldownitem give <player> <item></white> to obtain items</gray>"));
        player.sendMessage(TextUtil.parse("<gray>Items can also be earned through kill streaks and daily rewards!</gray>"));
        player.sendMessage(TextUtil.parse(""));
        for (CooldownItem item : itemManager.all()) {
            String duration = item.durationSeconds() > 0 ? (item.durationSeconds() / 60) + "min" : "permanent";
            player.sendMessage(TextUtil.parse("<yellow>/" + item.command() + "</yellow> <dark_gray>-</dark_gray> <gold>" + item.displayName() + "</gold> <gray>" + duration + "</gray>"));
        }
    }

    private void handleReload(Player player) {
        itemManager.reload();
        player.sendMessage(TextUtil.parse("<green>Cooldown items reloaded. <white>" + itemManager.all().size() + "</white> items loaded.</green>"));
    }

    private String formatEffectName(String effect) {
        return switch (effect) {
            case "no-cooldown" -> "No Cooldown";
            case "skip-cooldown" -> "Skip Cooldown";
            case "shard-boost" -> "Shard Boost";
            case "firework-bypass" -> "Firework Bypass";
            default -> effect;
        };
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            return filter(literals("give", "giveall", "list", "reload", "shop"), args[0]);
        }
        if (args.length == 2) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            if (sub.equals("give") || sub.equals("giveall")) {
                List<String> names = new ArrayList<>();
                for (Player p : Bukkit.getOnlinePlayers()) {
                    names.add(p.getName());
                }
                return filter(names, args[1]);
            }
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            return filter(itemManager.getIds(), args[2]);
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("give")) {
            return filter(literals("1", "5", "10", "32", "64"), args[3]);
        }
        return List.of();
    }

    @Override
    protected String permission() {
        return "unstable.cooldownitem.admin";
    }
}
