package lol.folium.unstable.combat;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.quest.QuestService;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class CombatTagManager {

    private final UnstableRemixPlugin plugin;
    private final EconomyService economy;
    private final QuestService quests;
    private final Map<UUID, CombatTag> tags = new ConcurrentHashMap<>();
    private final Set<UUID> expiredNotified = new HashSet<>();
    private volatile Set<String> blockedCommands;
    private int cleanupTaskId = -1;

    public CombatTagManager(UnstableRemixPlugin plugin, EconomyService economy, QuestService quests) {
        this.plugin = plugin;
        this.economy = economy;
        this.quests = quests;
    }

    public void start() {
        stop();
        reloadBlockedCommands();
        cleanupTaskId = Bukkit.getScheduler().runTaskTimer(plugin, this::cleanupExpired, 20L, 20L).getTaskId();
    }

    public void stop() {
        if (cleanupTaskId != -1) {
            Bukkit.getScheduler().cancelTask(cleanupTaskId);
            cleanupTaskId = -1;
        }
        tags.clear();
        expiredNotified.clear();
    }

    public void tag(Player attacker, Player victim) {
        if (!plugin.getConfig().getBoolean("combat-tag.enabled", true)) {
            return;
        }
        long expiresAt = System.currentTimeMillis() + plugin.getConfig().getLong("combat-tag.duration-seconds", 15L) * 1000L;
        tags.put(attacker.getUniqueId(), new CombatTag(victim.getUniqueId(), expiresAt));
        tags.put(victim.getUniqueId(), new CombatTag(attacker.getUniqueId(), expiresAt));

        attacker.playSound(attacker.getLocation(), Sound.ENTITY_ARROW_HIT_PLAYER, 0.6F, 1.2F);
        victim.playSound(victim.getLocation(), Sound.ENTITY_ARROW_HIT_PLAYER, 0.6F, 1.2F);

        attacker.sendMessage(TextUtil.parse("<red>⚔ Combat tagged! You are in combat with <yellow>" + victim.getName() + "</yellow>.</red>"));
        victim.sendMessage(TextUtil.parse("<red>⚔ Combat tagged! You are in combat with <yellow>" + attacker.getName() + "</yellow>.</red>"));
    }

    public boolean isTagged(Player player) {
        return remainingMillis(player.getUniqueId()) > 0L;
    }

    public void untag(Player player) {
        tags.remove(player.getUniqueId());
        expiredNotified.remove(player.getUniqueId());
    }

    public void untagOpponents(Player player) {
        CombatTag tag = tags.remove(player.getUniqueId());
        expiredNotified.remove(player.getUniqueId());
        if (tag != null) {
            Player opponent = Bukkit.getPlayer(tag.opponent());
            if (opponent != null) {
                tags.remove(opponent.getUniqueId());
                expiredNotified.remove(opponent.getUniqueId());
            }
        }
    }

    public long remainingSeconds(Player player) {
        return Math.max(0L, (remainingMillis(player.getUniqueId()) + 999L) / 1000L);
    }

    public String combatBar(Player player) {
        long remaining = remainingMillis(player.getUniqueId());
        if (remaining <= 0) return "";
        int secs = (int) ((remaining + 999) / 1000);
        long maxSeconds = plugin.getConfig().getLong("combat-tag.duration-seconds", 15L);
        int max = Math.max(1, (int) Math.min(maxSeconds, 30));
        int filled = Math.min(max, Math.max(0, secs));
        int empty = max - filled;
        String bar = "<red>" + "\u2588".repeat(filled) + "</red><dark_gray>" + "\u2591".repeat(empty) + "</dark_gray>";
        return "<red>⚔</red> " + bar + " <yellow>" + secs + "s</yellow>";
    }

    public void reloadBlockedCommands() {
        Set<String> raw = Set.copyOf(plugin.getConfig().getStringList("combat-tag.blocked-commands"));
        if (raw.isEmpty()) {
            raw = Set.of("kits", "kit", "mapvote", "shop", "quests", "rentarank", "effects", "lobby");
        }
        this.blockedCommands = raw;
    }

    public boolean isBlockedCommand(String commandLine) {
        if (commandLine == null || commandLine.isBlank()) {
            return false;
        }
        Set<String> cmds = this.blockedCommands;
        if (cmds == null) {
            reloadBlockedCommands();
            cmds = this.blockedCommands;
        }
        String root = commandLine.split(" ")[0].toLowerCase(Locale.ROOT);
        for (String cmd : cmds) {
            String normalized = cmd.startsWith("/") ? cmd.substring(1) : cmd;
            if (root.equalsIgnoreCase(normalized)) {
                return true;
            }
        }
        return false;
    }

    public void handleQuit(Player quitter) {
        CombatTag tag = tags.remove(quitter.getUniqueId());
        if (tag == null || tag.expiresAtMillis() <= System.currentTimeMillis()) {
            return;
        }
        Player attacker = Bukkit.getPlayer(tag.opponent());
        dropInventory(quitter);
        if (attacker != null && attacker.isOnline()) {
            long base = plugin.getConfig().getLong("combat-tag.anti-log-base-shards", 50L);
            economy.grantShards(attacker.getUniqueId(), base, "anti-log:" + quitter.getName(), null);
            quests.trackKill(attacker, quitter);
            attacker.sendMessage(TextUtil.parse(TextUtil.apply(plugin.getConfig().getString("combat-tag.messages.anti-log-killer",
                    "<green>{player} logged out in combat. +{reward} Shards.</green>"),
                    Map.of("player", quitter.getName(), "reward", String.valueOf(base)))));
        }
        Bukkit.broadcast(TextUtil.parse(TextUtil.apply(plugin.getConfig().getString("combat-tag.messages.anti-log-broadcast",
                "<red>{player} logged out while combat tagged.</red>"), Map.of("player", quitter.getName()))));
    }

    private void dropInventory(Player player) {
        Location location = player.getLocation();
        for (ItemStack stack : player.getInventory().getContents()) {
            drop(location, stack);
        }
        for (ItemStack stack : player.getInventory().getArmorContents()) {
            drop(location, stack);
        }
        drop(location, player.getInventory().getItemInOffHand());
        player.getInventory().clear();
        player.getInventory().setArmorContents(null);
        player.getInventory().setItemInOffHand(new ItemStack(Material.AIR));
    }

    private void drop(Location location, ItemStack stack) {
        if (stack == null || stack.getType().isAir() || location.getWorld() == null) {
            return;
        }
        location.getWorld().dropItemNaturally(location, stack.clone());
    }

    private long remainingMillis(UUID uuid) {
        CombatTag tag = tags.get(uuid);
        if (tag == null) {
            return 0L;
        }
        long remaining = tag.expiresAtMillis() - System.currentTimeMillis();
        if (remaining <= 0L) {
            tags.remove(uuid);
            return 0L;
        }
        return remaining;
    }

    private void cleanupExpired() {
        long now = System.currentTimeMillis();
        for (var it = tags.entrySet().iterator(); it.hasNext();) {
            var entry = it.next();
            if (entry.getValue().expiresAtMillis() <= now) {
                UUID uuid = entry.getKey();
                it.remove();
                Player p = Bukkit.getPlayer(uuid);
                if (p != null && p.isOnline()) {
                    if (!expiredNotified.contains(uuid)) {
                        expiredNotified.add(uuid);
                        p.sendMessage(TextUtil.parse("<green>✔ Combat tag expired.</green>"));
                        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.8F, 1.8F);
                    }
                }
            }
        }
    }

    private record CombatTag(UUID opponent, long expiresAtMillis) {}
}
