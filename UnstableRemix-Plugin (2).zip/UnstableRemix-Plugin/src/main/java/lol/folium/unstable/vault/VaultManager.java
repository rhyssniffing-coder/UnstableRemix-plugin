package lol.folium.unstable.vault;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.data.PlayerDataStore;
import lol.folium.unstable.data.PlayerProfile;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.economy.TransactionResult;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.HashMap;
import java.util.Map;

public final class VaultManager {

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final PlayerDataStore store;
    private final EconomyService economy;
    private final Map<Integer, VaultTier> tiers = new HashMap<>();

    public VaultManager(UnstableRemixPlugin plugin, ConfigManager configs,
                        PlayerDataStore store, EconomyService economy) {
        this.plugin = plugin;
        this.configs = configs;
        this.store = store;
        this.economy = economy;
    }

    public void reload() {
        tiers.clear();
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("vault-perks.tiers");
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            ConfigurationSection tierCfg = section.getConfigurationSection(key);
            if (tierCfg == null) continue;
            int tierNum = Integer.parseInt(key);
            tiers.put(tierNum, new VaultTier(
                    tierNum,
                    tierCfg.getInt("rows", 1),
                    tierCfg.getString("title", "Vault Tier " + tierNum),
                    tierCfg.getLong("cost-shards", 0),
                    tierCfg.getInt("required-prestige", 0)
            ));
        }
    }

    public int currentTier(Player player) {
        return store.get(player.getUniqueId()).vaultTier();
    }

    public int nextTier(Player player) {
        int current = currentTier(player);
        return tiers.containsKey(current + 1) ? current + 1 : -1;
    }

    public boolean canUpgrade(Player player) {
        int next = nextTier(player);
        if (next < 0) return false;
        VaultTier tier = tiers.get(next);
        PlayerProfile profile = store.get(player.getUniqueId());
        return profile.shards() >= tier.cost()
                && profile.prestigeRank() >= tier.requiredPrestige();
    }

    public void openVault(Player player) {
        int tierNum = currentTier(player);
        VaultTier tier = tiers.get(tierNum);
        if (tier == null) {
            player.sendMessage(TextUtil.parse("<red>You don't have a vault yet. Purchase one with /vault buy."));
            return;
        }
        PlayerProfile profile = store.get(player.getUniqueId());
        String key = "vault_" + player.getUniqueId() + "_tier_" + tierNum;
        Inventory vault = Bukkit.createInventory(null, tier.rows() * 9,
                TextUtil.parse(tier.title() + " <dark_gray>|</dark_gray> <gray>Tier " + tierNum + "</gray>"));
        player.openInventory(vault);
    }

    public void upgrade(Player player) {
        int next = nextTier(player);
        if (next < 0) {
            player.sendMessage(TextUtil.parse("<red>You already have the highest vault tier."));
            return;
        }
        VaultTier tier = tiers.get(next);
        PlayerProfile profile = store.get(player.getUniqueId());
        if (profile.shards() < tier.cost()) {
            player.sendMessage(TextUtil.parse("<red>You need <light_purple>" + tier.cost()
                    + " Shards</light_purple> for this vault tier."));
            return;
        }
        if (profile.prestigeRank() < tier.requiredPrestige()) {
            player.sendMessage(TextUtil.parse("<red>You need Prestige " + tier.requiredPrestige() + " for this vault."));
            return;
        }
        TransactionResult result = economy.spendShards(player.getUniqueId(), tier.cost(), "vault-upgrade:" + next);
        if (!result.success()) {
            economy.notifyFailure(player, result.messageKey(), tier.cost());
            return;
        }
        profile.setVaultTier(next);
        store.saveProfile(profile);
        player.sendMessage(TextUtil.parse("<green>Upgraded to vault tier <white>" + next
                + "</white>! <gray>Use</gray> <yellow>/vault</yellow> <gray>to open it.</gray>"));
    }

    public Map<Integer, VaultTier> getTiers() {
        return Map.copyOf(tiers);
    }

    public record VaultTier(int tier, int rows, String title, long cost, int requiredPrestige) {}
}