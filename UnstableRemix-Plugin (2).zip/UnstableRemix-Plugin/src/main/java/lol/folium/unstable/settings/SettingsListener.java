package lol.folium.unstable.settings;

import lol.folium.unstable.util.GuiTheme;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class SettingsListener implements Listener {

    private static final int GUI_SIZE = 45;
    private static final int TOGGLE_KILLSTREAK = 11;
    private static final int TOGGLE_LOBBY = 13;
    private static final int TOGGLE_BOUNTY = 15;
    private static final int TOGGLE_PRIVATE = 22;

    private Component parse(String text) {
        return TextUtil.parse(text);
    }

    private ItemStack pane(Material mat) {
        return ItemBuilder.of(mat).name(Component.empty()).build();
    }

    public void openSettings(Player player) {
        Inventory inv = Bukkit.createInventory(null, GUI_SIZE, parse(GuiTheme.primary("SETTINGS")));
        PlayerSettings settings = SettingsManager.getInstance().getSettings(player.getUniqueId());

        for (int i = 0; i < GUI_SIZE; i++) inv.setItem(i, pane(Material.BLACK_STAINED_GLASS_PANE));
        for (int i = 0; i < 9; i++) {
            inv.setItem(i, pane(Material.PURPLE_STAINED_GLASS_PANE));
            inv.setItem(GUI_SIZE - 9 + i, pane(Material.PURPLE_STAINED_GLASS_PANE));
        }

        boolean killstreak = settings.isEnabled(PlayerSettings.Setting.KILLSTREAK_ALERTS);
        inv.setItem(TOGGLE_KILLSTREAK, ItemBuilder.of(killstreak ? Material.DIAMOND : Material.COAL_BLOCK)
                .name(parse(GuiTheme.secondary(killstreak ? "&a&lKILLSTREAK ALERTS" : "&c&lKILLSTREAK ALERTS")))
                .lore(List.of(
                        parse(""),
                        parse("&7Toggle killstreak titles on screen"),
                        parse(""),
                        parse(killstreak ? "&a&lENABLED" : "&c&lDISABLED"),
                        parse(""),
                        parse("&7Click to toggle")
                )).build());

        boolean lobby = settings.isEnabled(PlayerSettings.Setting.LOBBY_PLAYERS);
        inv.setItem(TOGGLE_LOBBY, ItemBuilder.of(lobby ? Material.PLAYER_HEAD : Material.SKELETON_SKULL)
                .name(parse(GuiTheme.secondary(lobby ? "&a&lLOBBY PLAYERS" : "&c&lLOBBY PLAYERS")))
                .lore(List.of(
                        parse(""),
                        parse("&7Show other players in lobby"),
                        parse(""),
                        parse(lobby ? "&a&lENABLED" : "&c&lDISABLED"),
                        parse(""),
                        parse("&7Click to toggle")
                )).build());

        boolean bounty = settings.isEnabled(PlayerSettings.Setting.BOUNTY_ALERTS);
        inv.setItem(TOGGLE_BOUNTY, ItemBuilder.of(bounty ? Material.GOLD_INGOT : Material.IRON_INGOT)
                .name(parse(GuiTheme.secondary(bounty ? "&a&lBOUNTY ALERTS" : "&c&lBOUNTY ALERTS")))
                .lore(List.of(
                        parse(""),
                        parse("&7Alert when someone sets a bounty on you"),
                        parse(""),
                        parse(bounty ? "&a&lENABLED" : "&c&lDISABLED"),
                        parse(""),
                        parse("&7Click to toggle")
                )).build());

        boolean priv = settings.isEnabled(PlayerSettings.Setting.PRIVATE_STATS);
        inv.setItem(TOGGLE_PRIVATE, ItemBuilder.of(priv ? Material.BARRIER : Material.EMERALD)
                .name(parse(GuiTheme.secondary(priv ? "&a&lPRIVATE STATS" : "&c&lPRIVATE STATS")))
                .lore(List.of(
                        parse(""),
                        parse("&7Hide your stats from other players"),
                        parse(""),
                        parse(priv ? "&a&lENABLED" : "&c&lDISABLED"),
                        parse(""),
                        parse("&7Click to toggle")
                )).build());

        inv.setItem(GUI_SIZE - 5, ItemBuilder.of(Material.ARROW)
                .name(parse(GuiTheme.secondary("&c&lBACK")))
                .lore(List.of(parse(""), parse("&7Return to menu"))).build());

        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;
        if (e.getView().getTitle() == null) return;
        String title = e.getView().getTitle();
        if (!title.equals(TextUtil.parse(GuiTheme.primary("SETTINGS")).toString())) return;
        e.setCancelled(true);

        int slot = e.getRawSlot();
        PlayerSettings settings = SettingsManager.getInstance().getSettings(player.getUniqueId());

        switch (slot) {
            case TOGGLE_KILLSTREAK -> {
                settings.toggle(PlayerSettings.Setting.KILLSTREAK_ALERTS);
                player.sendMessage(TextUtil.parse("&aKillstreak alerts " + (settings.isEnabled(PlayerSettings.Setting.KILLSTREAK_ALERTS) ? "enabled" : "disabled")));
                openSettings(player);
            }
            case TOGGLE_LOBBY -> {
                settings.toggle(PlayerSettings.Setting.LOBBY_PLAYERS);
                player.sendMessage(TextUtil.parse("&aLobby players " + (settings.isEnabled(PlayerSettings.Setting.LOBBY_PLAYERS) ? "enabled" : "disabled")));
                openSettings(player);
            }
            case TOGGLE_BOUNTY -> {
                settings.toggle(PlayerSettings.Setting.BOUNTY_ALERTS);
                player.sendMessage(TextUtil.parse("&aBounty alerts " + (settings.isEnabled(PlayerSettings.Setting.BOUNTY_ALERTS) ? "enabled" : "disabled")));
                openSettings(player);
            }
            case TOGGLE_PRIVATE -> {
                settings.toggle(PlayerSettings.Setting.PRIVATE_STATS);
                player.sendMessage(TextUtil.parse("&aPrivate stats " + (settings.isEnabled(PlayerSettings.Setting.PRIVATE_STATS) ? "enabled" : "disabled")));
                openSettings(player);
            }
            case GUI_SIZE - 5 -> player.closeInventory();
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTitle() == null) return;
        if (e.getView().getTitle().equals(TextUtil.parse(GuiTheme.primary("SETTINGS")).toString())) {
            e.setCancelled(true);
        }
    }
}
