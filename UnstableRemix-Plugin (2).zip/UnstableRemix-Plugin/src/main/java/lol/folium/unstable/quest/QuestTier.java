package lol.folium.unstable.quest;

public enum QuestTier {
    DAILY("daily"),
    WEEKLY("weekly"),
    MONTHLY("monthly"),
    MILESTONE("milestone");

    private final String id;

    QuestTier(String id) {
        this.id = id;
    }

    public String id() {
        return id;
    }

    public static QuestTier from(String raw) {
        for (QuestTier tier : values()) {
            if (tier.id.equalsIgnoreCase(raw)) {
                return tier;
            }
        }
        return null;
    }
}
