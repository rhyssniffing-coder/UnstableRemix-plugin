package lol.folium.unstable.economy;

public enum CurrencyType {
    SHARDS,
    TOKENS
}
