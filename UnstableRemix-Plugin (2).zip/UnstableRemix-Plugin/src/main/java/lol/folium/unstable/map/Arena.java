package lol.folium.unstable.map;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class Arena {

    public enum Status {
        IDLE,
        IN_GAME
    }

    private final String name;
    private String worldName;
    private int minX;
    private int minY;
    private int minZ;
    private int maxX;
    private int maxY;
    private int maxZ;
    private Location lobby;
    private Location spawn1;
    private Location spawn2;
    private final List<Location> spawns = new ArrayList<>();
    private Status status = Status.IDLE;
    private final Set<UUID> players = new HashSet<>();
    private final Set<BlockSnapshot> placedBlocks = new HashSet<>();
    private int maxPlacedBlocks = 50000;
    private String displayName;
    private boolean enabled = true;
    private int minPlayers = 2;
    private int maxPlayers = 20;
    private String gameMode = "SURVIVAL";
    private boolean allowBuild = false;
    private boolean allowBreak = false;
    private boolean naturalRegen = true;
    private boolean allowFallDamage = true;
    private boolean hunger = true;
    private String timeLock;
    private String weatherLock;
    private String teamSpawnMode = "TEAMS";
    private boolean noElytra = false;
    private boolean permanent = false;

    public Arena(String name) {
        this.name = name;
    }

    public void setMaxPlacedBlocks(int max) {
        this.maxPlacedBlocks = Math.max(1000, max);
    }

    public boolean addPlacedBlock(BlockSnapshot snapshot) {
        if (placedBlocks.size() >= maxPlacedBlocks) return false;
        return placedBlocks.add(snapshot);
    }

    public String name() {
        return name;
    }

    public String worldName() {
        return worldName;
    }

    public void setWorldName(String worldName) {
        this.worldName = worldName;
    }

    public void setBounds(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
        this.minX = minX;
        this.minY = minY;
        this.minZ = minZ;
        this.maxX = maxX;
        this.maxY = maxY;
        this.maxZ = maxZ;
    }

    public int minX() { return minX; }
    public int minY() { return minY; }
    public int minZ() { return minZ; }
    public int maxX() { return maxX; }
    public int maxY() { return maxY; }
    public int maxZ() { return maxZ; }

    public Location lobby() { return lobby; }
    public void setLobby(Location lobby) { this.lobby = lobby; }

    public Location spawn1() { return spawn1; }
    public void setSpawn1(Location spawn1) { this.spawn1 = spawn1; }

    public Location spawn2() { return spawn2; }
    public void setSpawn2(Location spawn2) { this.spawn2 = spawn2; }

    public List<Location> spawns() { return spawns; }
    public void addSpawn(Location spawn) { spawns.add(spawn); }
    public void removeSpawn(int index) { if (index >= 0 && index < spawns.size()) spawns.remove(index); }
    public void clearSpawns() { spawns.clear(); }

    public Status status() { return status; }
    public void setStatus(Status status) { this.status = status; }

    public Set<UUID> players() { return players; }

    public Set<BlockSnapshot> placedBlocks() { return placedBlocks; }

    public boolean contains(Location location) {
        if (location == null || location.getWorld() == null || worldName == null) {
            return false;
        }
        if (!location.getWorld().getName().equals(worldName)) {
            return false;
        }
        int x = location.getBlockX();
        int y = location.getBlockY();
        int z = location.getBlockZ();
        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }

    public String displayName() { return displayName != null ? displayName : name; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public int minPlayers() { return minPlayers; }
    public void setMinPlayers(int minPlayers) { this.minPlayers = Math.max(1, minPlayers); }

    public int maxPlayers() { return maxPlayers; }
    public void setMaxPlayers(int maxPlayers) { this.maxPlayers = Math.max(1, maxPlayers); }

    public String gameMode() { return gameMode; }
    public void setGameMode(String gameMode) { this.gameMode = gameMode; }

    public boolean allowBuild() { return allowBuild; }
    public void setAllowBuild(boolean allowBuild) { this.allowBuild = allowBuild; }

    public boolean allowBreak() { return allowBreak; }
    public void setAllowBreak(boolean allowBreak) { this.allowBreak = allowBreak; }

    public boolean naturalRegen() { return naturalRegen; }
    public void setNaturalRegen(boolean naturalRegen) { this.naturalRegen = naturalRegen; }

    public boolean allowFallDamage() { return allowFallDamage; }
    public void setAllowFallDamage(boolean allowFallDamage) { this.allowFallDamage = allowFallDamage; }

    public boolean hunger() { return hunger; }
    public void setHunger(boolean hunger) { this.hunger = hunger; }

    public String timeLock() { return timeLock; }
    public void setTimeLock(String timeLock) { this.timeLock = timeLock; }

    public String weatherLock() { return weatherLock; }
    public void setWeatherLock(String weatherLock) { this.weatherLock = weatherLock; }

    public String teamSpawnMode() { return teamSpawnMode; }
    public void setTeamSpawnMode(String teamSpawnMode) { this.teamSpawnMode = teamSpawnMode; }

    public boolean noElytra() { return noElytra; }
    public void setNoElytra(boolean noElytra) { this.noElytra = noElytra; }

    public boolean isPermanent() { return permanent; }
    public void setPermanent(boolean permanent) { this.permanent = permanent; }

    public World world() {
        return worldName == null ? null : Bukkit.getWorld(worldName);
    }
}
