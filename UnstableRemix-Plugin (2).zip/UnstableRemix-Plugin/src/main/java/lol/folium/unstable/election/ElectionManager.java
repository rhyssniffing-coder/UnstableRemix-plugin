package lol.folium.unstable.election;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.faction.FactionSelectionManager;
import lol.folium.unstable.util.TextUtil;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class ElectionManager {

    private final UnstableRemixPlugin plugin;
    private final ElectionDataStore store;
    private final FactionSelectionManager factionSelection;

    private int currentElectionId = -1;
    private String phase = "INACTIVE";
    private long phaseStartTime;

    private BukkitTask transitionTask;
    private BukkitTask broadcastTask;
    private BukkitTask showcaseTask;

    public ElectionManager(UnstableRemixPlugin plugin, ElectionDataStore store, FactionSelectionManager factionSelection) {
        this.plugin = plugin;
        this.store = store;
        this.factionSelection = factionSelection;
    }

    public ElectionDataStore getStore() {
        return store;
    }

    public String getPhase() {
        return phase;
    }

    public int getCurrentElectionId() {
        return currentElectionId;
    }

    public boolean isActive() {
        return !phase.equals("INACTIVE") && !phase.equals("COMPLETE");
    }

    public boolean isRegistration() {
        return phase.equals("REGISTRATION");
    }

    public boolean isVoting() {
        return phase.equals("VOTING");
    }

    public long getPhaseStartTime() {
        return phaseStartTime;
    }

    public void restoreActiveElection() {
        int id = store.getActiveElectionId();
        if (id == -1) return;
        this.currentElectionId = id;
        this.phase = store.getPhase(id);
        this.phaseStartTime = store.getStartedAt(id);
        if (phaseStartTime == -1) {
            phase = "INACTIVE";
            currentElectionId = -1;
            return;
        }
        long elapsed = System.currentTimeMillis() - phaseStartTime;
        long regMs = plugin.getConfig().getLong("elections.registration-duration-hours", 48) * 3600 * 1000L;
        long voteMs = plugin.getConfig().getLong("elections.voting-duration-hours", 120) * 3600 * 1000L;

        if (phase.equals("REGISTRATION")) {
            startBroadcastTask();
            long remaining = regMs - elapsed;
            if (remaining <= 0) {
                startVoting();
            } else {
                startTransitionTask(remaining, this::startVoting);
            }
        } else if (phase.equals("VOTING")) {
            startBroadcastTask();
            startShowcaseTask();
            long remaining = voteMs - elapsed;
            if (remaining <= 0) {
                finishElection();
            } else {
                startTransitionTask(remaining, this::finishElection);
            }
        } else {
            currentElectionId = -1;
            phase = "INACTIVE";
        }
    }

    public void startElection() {
        if (isActive()) return;
        currentElectionId = store.createElection(System.currentTimeMillis());
        if (currentElectionId == -1) return;
        phase = "REGISTRATION";
        phaseStartTime = System.currentTimeMillis();
        startBroadcastTask();
        long regHours = plugin.getConfig().getLong("elections.registration-duration-hours", 48);
        long voteHours = plugin.getConfig().getLong("elections.voting-duration-hours", 120);
        Bukkit.broadcast(TextUtil.parse("<gold><bold>An election has begun! Registration is now open for " + regHours + " hours.</bold></gold>"));
        Bukkit.broadcast(TextUtil.parse("<yellow>Use /campaign start <manifesto> to register as a candidate!</yellow>"));
        startTransitionTask(regHours * 3600 * 1000L, this::startVoting);
    }

    private void startVoting() {
        if (!phase.equals("REGISTRATION")) return;
        phase = "VOTING";
        phaseStartTime = System.currentTimeMillis();
        store.updatePhase(currentElectionId, "VOTING");
        long voteHours = plugin.getConfig().getLong("elections.voting-duration-hours", 120);
        Bukkit.broadcast(TextUtil.parse("<gold><bold>Voting is now open! Cast your vote with /vote!</bold></gold>"));
        startShowcaseTask();
        startTransitionTask(voteHours * 3600 * 1000L, this::finishElection);
    }

    public void finishElection() {
        if (!phase.equals("VOTING")) return;
        phase = "COMPLETE";
        store.updatePhase(currentElectionId, "COMPLETE");
        store.finalizeResults(currentElectionId);
        stopTasks();
        assignWinnerLeader();
        announceResults();
        resetAfterDelay();
    }

    private void assignWinnerLeader() {
        var result = store.getResult(currentElectionId);
        if (result == null) return;

        String faction = result.faction().toLowerCase();
        String factionKey;
        if (faction.equals("mafia")) factionKey = "mafia";
        else if (faction.equals("law")) factionKey = "law";
        else factionKey = "null";

        factionSelection.assignLeaderGroup(result.winnerUuid(), factionKey, () -> {
            String name = Bukkit.getOfflinePlayer(result.winnerUuid()).getName();
            if (name == null) name = result.winnerUuid().toString().substring(0, 8);
            Bukkit.broadcast(TextUtil.parse("<gold><bold>" + name + "</bold></gold> <gray>has been crowned faction leader!</gray>"));
        });
    }

    private void announceResults() {
        var result = store.getResult(currentElectionId);
        if (result == null) {
            Bukkit.broadcast(TextUtil.parse("<red>The election ended with no votes cast.</red>"));
            return;
        }
        String winnerName = Bukkit.getOfflinePlayer(result.winnerUuid()).getName();
        if (winnerName == null) winnerName = result.winnerUuid().toString().substring(0, 8);
        String factionName = result.faction();
        Map<String, String> colors = Map.of("Mafia", "<red>", "Null", "<dark_gray>", "Law", "<blue>");
        Map<String, String> displayNames = Map.of(
            "Mafia", "<gradient:#8B0000:#DC143C>Mafia</gradient>",
            "Null", "<gradient:#2c2c2c:#6b6b6b>Null</gradient>",
            "Law", "<gradient:#00008B:#00FFFF>Law</gradient>"
        );
        String color = colors.getOrDefault(factionName, "<white>");
        net.kyori.adventure.text.Component msg = net.kyori.adventure.text.Component.text()
                .append(TextUtil.parse("<gold><bold>═══════════════════════════════════</bold></gold>")).appendNewline()
                .append(TextUtil.parse("<gold><bold>Election Results!</bold></gold>")).appendNewline()
                .append(TextUtil.parse(color + "<bold>" + displayNames.getOrDefault(factionName, factionName) + "</bold></color> <gray>wins!</gray>")).appendNewline()
                .append(TextUtil.parse(color + "<bold>" + winnerName + "</bold></color> <gray>elected with <yellow>" + result.voteCount() + "</yellow> votes!</gray>")).appendNewline()
                .append(TextUtil.parse("<gold><bold>═══════════════════════════════════</bold></gold>"))
                .build();
        Bukkit.broadcast(msg);
    }

    private void resetAfterDelay() {
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            store.closeActiveElection(currentElectionId);
            currentElectionId = -1;
            phase = "INACTIVE";
        }, 20L * 60 * 5);
    }

    public void abortElection() {
        if (!isActive()) return;
        stopTasks();
        store.closeActiveElection(currentElectionId);
        Bukkit.broadcast(TextUtil.parse("<red><bold>The election has been cancelled by an administrator.</bold></red>"));
        currentElectionId = -1;
        phase = "INACTIVE";
    }

    private void startTransitionTask(long delayMs, Runnable action) {
        if (transitionTask != null) transitionTask.cancel();
        transitionTask = Bukkit.getScheduler().runTaskLater(plugin, action, delayMs / 50);
    }

    private void startBroadcastTask() {
        if (broadcastTask != null) broadcastTask.cancel();
        broadcastTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!isActive()) return;
            int candidates = store.getCandidates(currentElectionId).size();
            int totalVotes = store.getTotalVotes(currentElectionId);
            String msg;
            if (isRegistration()) {
                msg = "<gold><bold>\u2696 Election!</bold></gold> <gray>Registration open! Candidates: <yellow>" + candidates + "</yellow></gray>";
            } else if (isVoting()) {
                msg = "<gold><bold>\u2696 Election!</bold></gold> <gray>Voting open! Total votes: <yellow>" + totalVotes + "</yellow><gray>  Use /vote!</gray>";
            } else {
                return;
            }
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.sendMessage(TextUtil.parse(msg));
            }
        }, 20L * 60 * 15, 20L * 60 * 15);
    }

    private void startShowcaseTask() {
        if (showcaseTask != null) showcaseTask.cancel();
        showcaseTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!isVoting()) return;
            var candidates = store.getCandidates(currentElectionId);
            if (candidates.isEmpty()) return;
            Map<String, String> colors = Map.of("Mafia", "<red>", "Null", "<dark_gray>", "Law", "<blue>");
            Map<String, String> displayNames = Map.of(
                "Mafia", "<gradient:#8B0000:#DC143C>Mafia</gradient>",
                "Null", "<gradient:#2c2c2c:#6b6b6b>Null</gradient>",
                "Law", "<gradient:#00008B:#00FFFF>Law</gradient>"
            );
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.sendMessage(TextUtil.parse("<gold><bold>Candidate Showcase</bold></gold>"));
                for (var c : candidates) {
                    String name = Bukkit.getOfflinePlayer(c.uuid()).getName();
                    if (name == null) name = c.uuid().toString().substring(0, 8);
                    String color = colors.getOrDefault(c.faction(), "<white>");
                    String display = displayNames.getOrDefault(c.faction(), c.faction());
                    p.sendMessage(TextUtil.parse(color + name + " <dark_gray>|</dark_gray> " + display + " <dark_gray>|</dark_gray> <yellow>" + c.voteCount() + "</yellow> votes"));
                    if (!c.manifesto().isEmpty()) {
                        p.sendMessage(TextUtil.parse(color + "  \"" + c.manifesto() + "\"</color>"));
                    }
                }
            }
        }, 20L * 60 * 30, 20L * 60 * 30);
    }

    public void stopTasks() {
        if (transitionTask != null) { transitionTask.cancel(); transitionTask = null; }
        if (broadcastTask != null) { broadcastTask.cancel(); broadcastTask = null; }
        if (showcaseTask != null) { showcaseTask.cancel(); showcaseTask = null; }
    }
}
