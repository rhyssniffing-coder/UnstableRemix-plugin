package lol.folium.unstable.map;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class BlockDespawnManager {

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final Map<BlockKey, Long> trackedBlocks = new ConcurrentHashMap<>();
    private int taskId = -1;
    private boolean enabled = true;
    private int despawnDelaySeconds = 15;
    private int blocksPerTick = 20;

    public BlockDespawnManager(UnstableRemixPlugin plugin, ConfigManager configs, ArenaManager arenaManager) {
        this.plugin = plugin;
        this.configs = configs;
        loadConfig();
    }

    public void loadConfig() {
        enabled = configs.main().getBoolean("block-despawn.enabled", true);
        despawnDelaySeconds = configs.main().getInt("block-despawn.delay-seconds", 15);
        blocksPerTick = Math.max(1, configs.main().getInt("block-despawn.blocks-per-tick", 20));
    }

    public void trackBlock(Location location) {
        if (!enabled || location == null || location.getWorld() == null) {
            return;
        }
        long expireAt = System.currentTimeMillis() + Math.max(1L, despawnDelaySeconds) * 1000L;
        trackedBlocks.put(BlockKey.of(location), expireAt);
    }

    public void startAutomaticSchedule() {
        if (!enabled || taskId != -1) {
            return;
        }
        taskId = Bukkit.getScheduler().runTaskTimer(plugin, this::sweepExpiredBlocks, 20L, 20L).getTaskId();
    }

    public void despawnAllBlocks() {
        for (BlockKey key : trackedBlocks.keySet()) {
            dissolve(key);
        }
        trackedBlocks.clear();
    }

    private void sweepExpiredBlocks() {
        if (trackedBlocks.isEmpty()) {
            return;
        }
        long now = System.currentTimeMillis();
        int processed = 0;
        Iterator<Map.Entry<BlockKey, Long>> iterator = trackedBlocks.entrySet().iterator();
        while (iterator.hasNext() && processed < blocksPerTick) {
            Map.Entry<BlockKey, Long> entry = iterator.next();
            if (entry.getValue() > now) {
                continue;
            }
            dissolve(entry.getKey());
            iterator.remove();
            processed++;
        }
    }

    private void dissolve(BlockKey key) {
        var world = Bukkit.getWorld(key.world());
        if (world == null) {
            return;
        }
        Block block = world.getBlockAt(key.x(), key.y(), key.z());
        if (block.getType() != Material.AIR) {
            block.setType(Material.AIR, false);
        }
    }

    public void clearTrackedBlocks() {
        trackedBlocks.clear();
    }

    public int getTrackedBlockCount() {
        return trackedBlocks.size();
    }

    public void stop() {
        if (taskId != -1) {
            Bukkit.getScheduler().cancelTask(taskId);
            taskId = -1;
        }
        clearTrackedBlocks();
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    private record BlockKey(String world, int x, int y, int z) {
        private static BlockKey of(Location location) {
            return new BlockKey(location.getWorld().getName(), location.getBlockX(), location.getBlockY(), location.getBlockZ());
        }
    }
}
