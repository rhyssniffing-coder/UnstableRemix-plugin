package lol.folium.unstable.broadcast;

import lol.folium.unstable.util.TextUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class BroadcastNpcCommand implements CommandExecutor, TabCompleter {

    private final BroadcastNpcManager manager;

    public BroadcastNpcCommand(BroadcastNpcManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (!player.hasPermission("unstable.coreadmin")) {
            player.sendMessage(TextUtil.parse("<red>No permission."));
            return true;
        }
        if (args.length < 1) {
            usage(player);
            return true;
        }
        if (args[0].equalsIgnoreCase("create")) {
            if (args.length < 3) {
                player.sendMessage(TextUtil.parse("<red>Usage: /broadcastnpc create <interval_seconds> <message...></red>"));
                return true;
            }
            int interval;
            try {
                interval = Integer.parseInt(args[1]);
                if (interval < 10) {
                    player.sendMessage(TextUtil.parse("<red>Minimum interval is 10 seconds.</red>"));
                    return true;
                }
            } catch (NumberFormatException e) {
                player.sendMessage(TextUtil.parse("<red>Invalid interval.</red>"));
                return true;
            }
            String message = joinArgs(args, 2);
            String id = manager.createNpc(player, interval, message);
            if (!manager.isCitizensAvailable()) {
                player.sendMessage(TextUtil.parse("<yellow>Citizens not available — NPC will be virtual (message only).</yellow>"));
            }
            player.sendMessage(TextUtil.parse("<green>Created broadcast NPC <white>" + id + "</white>.</green>"));
            return true;
        }
        if (args[0].equalsIgnoreCase("remove")) {
            if (args.length >= 2) {
                if (manager.removeNpc(args[1])) {
                    player.sendMessage(TextUtil.parse("<green>Removed broadcast NPC <white>" + args[1] + "</white>.</green>"));
                } else {
                    player.sendMessage(TextUtil.parse("<red>NPC not found.</red>"));
                }
            } else {
                if (manager.removeNpcAt(player)) {
                    player.sendMessage(TextUtil.parse("<green>Removed broadcast NPC at your location.</green>"));
                } else {
                    player.sendMessage(TextUtil.parse("<red>No broadcast NPC found nearby. Use /broadcastnpc remove <id></red>"));
                }
            }
            return true;
        }
        if (args[0].equalsIgnoreCase("list")) {
            List<BroadcastNpcManager.BroadcastNpc> npcs = manager.getNpcs();
            if (npcs.isEmpty()) {
                player.sendMessage(TextUtil.parse("<gray>No broadcast NPCs configured.</gray>"));
                return true;
            }
            player.sendMessage(TextUtil.parse("<gold>--- Broadcast NPCs (" + npcs.size() + ") ---</gold>"));
            for (BroadcastNpcManager.BroadcastNpc npc : npcs) {
                String loc = npc.location.getBlockX() + ", " + npc.location.getBlockY() + ", " + npc.location.getBlockZ();
                player.sendMessage(TextUtil.parse("<gray>  <white>" + npc.id + "</white> | " + loc + " | every " + npc.interval + "s | <white>\"" + npc.message + "\"</white></gray>"));
            }
            return true;
        }
        if (args[0].equalsIgnoreCase("setmessage")) {
            if (args.length < 3) {
                player.sendMessage(TextUtil.parse("<red>Usage: /broadcastnpc setmessage <id> <message...></red>"));
                return true;
            }
            String message = joinArgs(args, 2);
            if (manager.setMessage(args[1], message)) {
                player.sendMessage(TextUtil.parse("<green>Updated message for NPC <white>" + args[1] + "</white>.</green>"));
            } else {
                player.sendMessage(TextUtil.parse("<red>NPC not found.</red>"));
            }
            return true;
        }
        if (args[0].equalsIgnoreCase("setinterval")) {
            if (args.length < 3) {
                player.sendMessage(TextUtil.parse("<red>Usage: /broadcastnpc setinterval <id> <seconds></red>"));
                return true;
            }
            try {
                int interval = Integer.parseInt(args[2]);
                if (interval < 10) {
                    player.sendMessage(TextUtil.parse("<red>Minimum interval is 10 seconds.</red>"));
                    return true;
                }
                if (manager.setInterval(args[1], interval)) {
                    player.sendMessage(TextUtil.parse("<green>Updated interval for NPC <white>" + args[1] + "</white>.</green>"));
                } else {
                    player.sendMessage(TextUtil.parse("<red>NPC not found.</red>"));
                }
            } catch (NumberFormatException e) {
                player.sendMessage(TextUtil.parse("<red>Invalid interval.</red>"));
            }
            return true;
        }
        usage(player);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return List.of("create", "remove", "list", "setmessage", "setinterval");
        if (args.length == 2 && (args[0].equalsIgnoreCase("remove") || args[0].equalsIgnoreCase("setmessage") || args[0].equalsIgnoreCase("setinterval"))) {
            return manager.getNpcs().stream().map(n -> n.id).toList();
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("create")) {
            return List.of("60", "120", "300", "600");
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("setinterval")) {
            return List.of("30", "60", "120", "300");
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("create")) {
            return List.of("<message...>");
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("setmessage")) {
            return List.of("<new message...>");
        }
        return Collections.emptyList();
    }

    private String joinArgs(String[] args, int start) {
        StringBuilder sb = new StringBuilder();
        for (int i = start; i < args.length; i++) {
            if (sb.length() > 0) sb.append(" ");
            sb.append(args[i]);
        }
        return sb.toString();
    }

    private void usage(Player player) {
        player.sendMessage(TextUtil.parse("<yellow>/broadcastnpc create <interval_seconds> <message...>"));
        player.sendMessage(TextUtil.parse("<yellow>/broadcastnpc remove [id]"));
        player.sendMessage(TextUtil.parse("<yellow>/broadcastnpc list"));
        player.sendMessage(TextUtil.parse("<yellow>/broadcastnpc setmessage <id> <message...>"));
        player.sendMessage(TextUtil.parse("<yellow>/broadcastnpc setinterval <id> <seconds>"));
    }
}
