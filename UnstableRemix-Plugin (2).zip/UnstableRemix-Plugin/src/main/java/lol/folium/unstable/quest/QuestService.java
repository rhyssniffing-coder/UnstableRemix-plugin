package lol.folium.unstable.quest;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.data.PlayerDataStore;
import lol.folium.unstable.data.PlayerProfile;
import lol.folium.unstable.economy.CurrencyType;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.economy.TransactionResult;
import lol.folium.unstable.map.ArenaManager;
import lol.folium.unstable.util.ConfigItems;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.time.Duration;
import java.time.Instant;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoField;
import java.time.temporal.TemporalAdjusters;
import java.time.temporal.WeekFields;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class QuestService {

    private static final List<QuestTier> ROTATING_TIERS = List.of(QuestTier.DAILY, QuestTier.WEEKLY, QuestTier.MONTHLY);
    private static final List<Integer> DEFAULT_QUEST_SLOTS = List.of(
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34
    );
    private static final List<Integer> ENHANCED_LAYOUT = List.of(
            10, 11, 12, 13, 14, 15,
            19, 20, 21, 22, 23, 24,
            28, 29, 30, 31, 32, 33
    );

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final PlayerDataStore store;
    private final EconomyService economy;
    private final ArenaManager arenas;
    private final Map<String, QuestDefinition> quests = new HashMap<>();
    private final Map<QuestTier, List<QuestDefinition>> questsByTier = new EnumMap<>(QuestTier.class);
    private final Map<UUID, Integer> killstreaks = new ConcurrentHashMap<>();
    private final Map<String, String> assignmentCache = new ConcurrentHashMap<>();
    private final Random random = new Random();

    public QuestService(UnstableRemixPlugin plugin, ConfigManager configs, PlayerDataStore store,
                        EconomyService economy, ArenaManager arenas) {
        this.plugin = plugin;
        this.configs = configs;
        this.store = store;
        this.economy = economy;
        this.arenas = arenas;
        for (QuestTier tier : QuestTier.values()) {
            questsByTier.put(tier, new ArrayList<>());
        }
    }

    public void reload() {
        quests.clear();
        questsByTier.values().forEach(List::clear);
        FileConfiguration config = configs.get("quests.yml");
        ConfigurationSection tiers = config.getConfigurationSection("tiers");
        if (tiers == null) {
            return;
        }
        for (QuestTier tier : QuestTier.values()) {
            ConfigurationSection tierSection = tiers.getConfigurationSection(tier.id());
            if (tierSection == null) {
                continue;
            }
            List<Map<?, ?>> pool = tierSection.getMapList("pool");
            for (Map<?, ?> entry : pool) {
                QuestDefinition definition = parseDefinition(tier, entry);
                if (definition == null) {
                    continue;
                }
                quests.put(key(definition.tier(), definition.id()), definition);
                questsByTier.get(tier).add(definition);
            }
        }
        if (config.getBoolean("procedural-generation.enabled", true)) {
            generateProceduralQuests(config);
        }
    }

    private void generateProceduralQuests(FileConfiguration config) {
        ConfigurationSection pg = config.getConfigurationSection("procedural-generation");
        if (pg == null) return;
        List<String> nameTemplates = pg.getStringList("name-templates");
        if (nameTemplates.isEmpty()) return;
        List<QuestType> generationTypes = List.of(
                QuestType.KILLS, QuestType.BLOCKS_PLACED, QuestType.BREAK_COBWEBS,
                QuestType.DAMAGE_SWORDS, QuestType.KILLSTREAK, QuestType.TRACKDOWNS
        );
        int seed = nameTemplates.hashCode();
        Random genRandom = new Random(seed);
        for (QuestTier tier : ROTATING_TIERS) {
            int variations = pg.getInt("variations-per-tier." + tier.id(), 200);
            int minTarget = pg.getInt("min-target." + tier.id(), 5);
            int maxTarget = pg.getInt("max-target." + tier.id(), 50);
            long minReward = pg.getInt("min-reward." + tier.id(), 25);
            long maxReward = pg.getInt("max-reward." + tier.id(), 150);
            List<QuestDefinition> existing = questsByTier.get(tier);
            for (int i = 0; i < variations; i++) {
                QuestType type = generationTypes.get(genRandom.nextInt(generationTypes.size()));
                String rawName = nameTemplates.get(genRandom.nextInt(nameTemplates.size()));
                String name = tierDisplayName(tier) + " " + rawName.replace("&l", "").trim();
                String descKey = "description-templates." + type.name();
                List<String> descTemplates = pg.getStringList(descKey);
                String description;
                if (descTemplates.isEmpty()) {
                    description = "Complete the " + type.name().toLowerCase().replace('_', ' ') + " quest";
                } else {
                    String template = descTemplates.get(genRandom.nextInt(descTemplates.size()));
                    description = template.replace("{target}", String.valueOf(maxTarget));
                }
                int target = minTarget + genRandom.nextInt(maxTarget - minTarget + 1);
                target = Math.max(1, (target / 5) * 5);
                long reward = minReward + genRandom.nextLong(maxReward - minReward + 1);
                reward = Math.max(1, Math.min(100L, (reward / 5) * 5));
                String id = "proc_" + tier.id() + "_" + i;
                if (existing.stream().anyMatch(d -> d.id().equals(id))) continue;
                if (existing.stream().anyMatch(d -> d.id().equals(id))) continue;
                QuestDefinition generated = new QuestDefinition(id, tier, name + " <gray>#" + (i + 1) + "</gray>",
                        description, type, target, reward);
                quests.put(key(tier, id), generated);
                questsByTier.get(tier).add(generated);
            }
        }
    }

    public void openGui(Player player) {
        ensureAssignments(player);
        openTierGui(player, QuestTier.DAILY, 0);
    }

    public void openTierGui(Player player, QuestTier tier, int page) {
        ensureAssignments(player);
        FileConfiguration config = configs.get("quests.yml");
        ConfigurationSection gui = questGui(config);
        int rows = gui.getInt("category.rows", 6);
        Map<String, String> titlePlaceholders = Map.of(
                "tier", tierDisplayName(tier),
                "time_left", timeLeftText(tier)
        );
        String rawTitle = gui.getString("category.title", "<dark_gray>{tier}");
        QuestTierGui holder = new QuestTierGui(player, tier, Math.max(0, page));
        Inventory inventory = Bukkit.createInventory(holder, rows * 9,
                TextUtil.parse(TextUtil.apply(rawTitle, titlePlaceholders)));
        holder.bind(inventory);
        paintFiller(inventory, gui.getConfigurationSection("filler"));
        paintTierPage(player, inventory, holder, gui, tier);
        player.openInventory(inventory);
    }

    public void trackKill(Player killer, Player victim) {
        ensureAssignments(killer);
        incrementQuest(killer, QuestType.KILLS, 1);
        int victimStreak = killstreaks.getOrDefault(victim.getUniqueId(), 0);
        if (victimStreak >= 10) {
            completeQuestType(killer, QuestType.SHUTDOWN);
        }
        int newStreak = killstreaks.getOrDefault(killer.getUniqueId(), 0) + 1;
        killstreaks.put(killer.getUniqueId(), newStreak);
        killstreaks.put(victim.getUniqueId(), 0);
        updateKillstreakProgress(killer, newStreak);

        if (newStreak >= 5 && newStreak % 5 == 0) {
            Component title = TextUtil.parse("<gradient:#8B00FF:#00008B><bold>KILLSTREAK</bold></gradient>");
            Component sub = TextUtil.parse("<gradient:#8B00FF:#00008B><bold>" + newStreak + "</bold></gradient>");
            net.kyori.adventure.title.Title.Times times = net.kyori.adventure.title.Title.Times.times(
                    java.time.Duration.ZERO, java.time.Duration.ofSeconds(3), java.time.Duration.ofSeconds(1));
            net.kyori.adventure.title.Title t = net.kyori.adventure.title.Title.title(title, sub, times);
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.showTitle(t);
            }
        }
        PlayerProfile killerProfile = store.get(killer.getUniqueId());
        killerProfile.setLifetimeKills(killerProfile.lifetimeKills() + 1);
        store.saveProfile(killerProfile);

        PlayerProfile victimProfile = store.get(victim.getUniqueId());
        victimProfile.setDeaths(victimProfile.deaths() + 1);
        if (victimStreak > victimProfile.highestKillstreak()) {
            victimProfile.setHighestKillstreak(victimStreak);
        }
        store.saveProfile(victimProfile);
    }

    public void trackSwordDamage(Player player, double damage) {
        if (damage <= 0 || arenas.at(player.getLocation()).isEmpty()) {
            return;
        }
        ensureAssignments(player);
        incrementQuest(player, QuestType.DAMAGE_SWORDS, Math.max(1, (int) Math.ceil(damage)));
    }

    public void trackBlockPlaced(Player player) {
        if (arenas.at(player.getLocation()).isEmpty()) {
            return;
        }
        ensureAssignments(player);
        incrementQuest(player, QuestType.BLOCKS_PLACED, 1);
    }

    public void trackCobwebBroken(Player player) {
        if (arenas.at(player.getLocation()).isEmpty()) {
            return;
        }
        ensureAssignments(player);
        incrementQuest(player, QuestType.BREAK_COBWEBS, 1);
    }

    public void trackTrackdown(Player player) {
        ensureAssignments(player);
        incrementQuest(player, QuestType.TRACKDOWNS, 1);
        PlayerProfile profile = store.get(player.getUniqueId());
        profile.setLifetimeTrackdowns(profile.lifetimeTrackdowns() + 1);
        store.saveProfile(profile);
    }

    public void trackMatchWin(Player player) {
        PlayerProfile profile = store.get(player.getUniqueId());
        profile.setMatchWins(profile.matchWins() + 1);
        store.saveProfile(profile);
    }

    public void resetDailyRerollsIfNeeded(PlayerProfile profile) {
        ZonedDateTime now = ZonedDateTime.now(ZoneId.systemDefault());
        if (now.getHour() != 0 || now.getMinute() >= 5) {
            return;
        }
        profile.setDailyRerolls(0);
        if (now.getDayOfWeek().getValue() == 1) {
            profile.setWeeklyRerolls(0);
        }
        if (now.getDayOfMonth() == 1) {
            profile.setMonthlyRerolls(0);
        }
    }

    public void sweepOnlineRotations() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            ensureAssignments(player);
            PlayerProfile profile = store.get(player.getUniqueId());
            resetDailyRerollsIfNeeded(profile);
            store.saveProfile(profile);
        }
    }

    public int claimableCount(Player player) {
        ensureAssignments(player);
        int count = 0;
        for (QuestTier tier : ROTATING_TIERS) {
            QuestDefinition definition = activeQuest(player, tier);
            if (definition != null && isClaimable(player, definition)) {
                count++;
            }
        }
        for (QuestDefinition definition : questsByTier.getOrDefault(QuestTier.MILESTONE, List.of())) {
            if (isClaimable(player, definition)) {
                count++;
            }
        }
        return count;
    }

    public int completedCount(Player player, QuestTier tier) {
        ensureAssignments(player);
        if (tier == QuestTier.MILESTONE) {
            int count = 0;
            for (QuestDefinition definition : questsByTier.getOrDefault(tier, List.of())) {
                if (isClaimed(player, definition)) {
                    count++;
                }
            }
            return count;
        }
        QuestDefinition definition = activeQuest(player, tier);
        return definition != null && isClaimed(player, definition) ? 1 : 0;
    }

    public int totalCount(QuestTier tier) {
        return tier == QuestTier.MILESTONE ? questsByTier.getOrDefault(tier, List.of()).size() : 1;
    }

    public int achievementsUnlocked(Player player) {
        return completedCount(player, QuestTier.MILESTONE);
    }

    public String activeProgressText(Player player, QuestTier tier) {
        ensureAssignments(player);
        QuestDefinition definition = tier == QuestTier.MILESTONE ? nextAchievement(player) : activeQuest(player, tier);
        if (definition == null) {
            return "0/0";
        }
        int progress = progress(player, definition);
        return Math.min(progress, definition.target()) + "/" + definition.target();
    }

    public String activeQuestName(Player player, QuestTier tier) {
        ensureAssignments(player);
        QuestDefinition definition = tier == QuestTier.MILESTONE ? nextAchievement(player) : activeQuest(player, tier);
        return definition == null ? "" : definition.name();
    }

    public String timeLeftText(QuestTier tier) {
        if (tier == QuestTier.MILESTONE) {
            return "Permanent";
        }
        Duration duration = Duration.between(ZonedDateTime.now(ZoneId.systemDefault()), nextReset(tier));
        if (duration.isNegative() || duration.isZero()) {
            return "0s";
        }
        long seconds = duration.getSeconds();
        long days = seconds / 86400;
        long hours = (seconds % 86400) / 3600;
        long minutes = (seconds % 3600) / 60;
        if (days > 0) {
            return days + "d " + hours + "h";
        }
        if (hours > 0) {
            return hours + "h " + minutes + "m";
        }
        return Math.max(1, minutes) + "m";
    }

    public int activeKillstreak(Player player) {
        return killstreaks.getOrDefault(player.getUniqueId(), 0);
    }

    public double shardMultiplier(Player player) {
        int streak = activeKillstreak(player);
        double multiplier = 1.0D + (streak / 3) * 0.1D;
        return Math.min(2.0D, multiplier);
    }

    public boolean forceComplete(Player target, String rawQuestId) {
        QuestDefinition definition = resolveQuest(rawQuestId);
        if (definition == null) {
            return false;
        }
        if (definition.tier() == QuestTier.MILESTONE) {
            PlayerProfile profile = store.get(target.getUniqueId());
            completeLifetimeRequirement(profile, definition);
            store.saveProfile(profile);
            return true;
        }
        store.setQuestAssignment(target.getUniqueId(), definition.tier().id(), definition.id(), definition.target());
        return true;
    }

    public boolean reset(Player target, QuestTier tier) {
        if (tier == null || tier == QuestTier.MILESTONE) {
            return false;
        }
        assignmentCache.remove(target.getUniqueId() + ":" + tier.id());
        PlayerProfile profile = store.get(target.getUniqueId());
        profile.claimedQuests().removeIf(value -> value.startsWith(tier.id() + ":"));
        switch (tier) {
            case DAILY -> profile.setDailyRerolls(0);
            case WEEKLY -> profile.setWeeklyRerolls(0);
            case MONTHLY -> profile.setMonthlyRerolls(0);
            case MILESTONE -> {
            }
        }
        store.clearQuestAssignment(target.getUniqueId(), tier.id());
        assignRandom(target, tier);
        store.saveProfile(profile);
        return true;
    }

    public List<String> questIdSuggestions() {
        List<String> ids = new ArrayList<>();
        for (QuestDefinition definition : quests.values()) {
            ids.add(definition.tier().id() + ":" + definition.id());
        }
        return ids;
    }

    public boolean setReward(String rawQuestId, long newReward) {
        QuestDefinition definition = resolveQuest(rawQuestId);
        if (definition == null) return false;
        long capped = Math.min(100L, Math.max(1L, newReward));
        QuestDefinition updated = new QuestDefinition(definition.id(), definition.tier(), definition.name(),
                definition.description(), definition.type(), definition.target(), capped);
        quests.put(key(definition.tier(), definition.id()), updated);
        List<QuestDefinition> tierList = questsByTier.get(definition.tier());
        tierList.removeIf(d -> d.id().equals(definition.id()));
        tierList.add(updated);
        return true;
    }

    private QuestDefinition parseDefinition(QuestTier tier, Map<?, ?> entry) {
        try {
            String id = String.valueOf(entry.get("id"));
            QuestType type = QuestType.valueOf(String.valueOf(entry.get("type")).toUpperCase(Locale.ROOT));
            return new QuestDefinition(
                    id,
                    tier,
                    String.valueOf(entry.get("name")),
                    String.valueOf(entry.get("description")),
                    type,
                    ((Number) entry.get("target")).intValue(),
                    Math.min(100L, ((Number) entry.get("reward-shards")).longValue())
            );
        } catch (RuntimeException ex) {
            plugin.getLogger().warning("Skipping invalid quest definition in " + tier.id() + ": " + ex.getMessage());
            return null;
        }
    }

    private void openMainGui(Player player) {
        FileConfiguration config = configs.get("quests.yml");
        ConfigurationSection gui = questGui(config);
        int rows = gui.getInt("main.rows", gui.getInt("rows", 6));
        String title = gui.getString("main.title", gui.getString("title", "<dark_gray>Quest Hub</dark_gray>"));
        QuestMainGui holder = new QuestMainGui(player);
        Inventory inventory = Bukkit.createInventory(holder, rows * 9, TextUtil.parse(title));
        holder.bind(inventory);
        paintFiller(inventory, gui.getConfigurationSection("filler"));
        paintTopBar(player, inventory, holder, gui);
        paintCategoryItems(player, inventory, holder, gui);
        player.openInventory(inventory);
    }

    private void paintTopBar(Player player, Inventory inventory, QuestMainGui holder, ConfigurationSection gui) {
        int[] topRowSlots = {2, 3, 5, 6};
        QuestTier[] topTiers = {QuestTier.DAILY, QuestTier.WEEKLY, QuestTier.MONTHLY, QuestTier.MILESTONE};
        Material[] topMaterials = {Material.CLOCK, Material.SUNFLOWER, Material.AMETHYST_SHARD, Material.NETHER_STAR};
        for (int i = 0; i < topTiers.length; i++) {
            QuestTier tier = topTiers[i];
            int slot = topRowSlots[i];
            if (slot < 0 || slot >= inventory.getSize()) continue;
            ConfigurationSection section = categorySection(gui, tier);
            Map<String, String> placeholders = categoryPlaceholders(player, tier);
            inventory.setItem(slot, buildConfiguredItem(section, topMaterials[i],
                    "<gradient:#FFD700:#FFAA00><bold>" + tierDisplayName(tier) + "</bold></gradient>", placeholders));
            holder.categories.put(slot, tier);
        }
    }

    private void paintCategoryItems(Player player, Inventory inventory, QuestMainGui holder, ConfigurationSection gui) {
        List<Integer> centerSlots = List.of(21, 22, 23);
        QuestTier[] centerTiers = {QuestTier.DAILY, QuestTier.WEEKLY, QuestTier.MONTHLY};
        Material[] centerMaterials = {Material.CLOCK, Material.SUNFLOWER, Material.AMETHYST_SHARD};
        for (int i = 0; i < centerTiers.length; i++) {
            QuestTier tier = centerTiers[i];
            int slot = centerSlots.get(i);
            ConfigurationSection section = categorySection(gui, tier);
            Map<String, String> placeholders = categoryPlaceholders(player, tier);
            inventory.setItem(slot, buildConfiguredItem(section, centerMaterials[i],
                    "<gradient:#FFD700:#FFAA00><bold>" + tierDisplayName(tier) + "</bold></gradient>", placeholders));
            holder.categories.put(slot, tier);
        }
        int achievementSlot = 40;
        QuestTier achievementTier = QuestTier.MILESTONE;
        ConfigurationSection achievementSection = categorySection(gui, achievementTier);
        Map<String, String> achievementPlaceholders = categoryPlaceholders(player, achievementTier);
        inventory.setItem(achievementSlot, buildConfiguredItem(achievementSection, Material.NETHER_STAR,
                "<gradient:#55FFFF:#AAFFAA><bold>" + tierDisplayName(achievementTier) + "</bold></gradient>", achievementPlaceholders));
        holder.categories.put(achievementSlot, achievementTier);
    }

    private void paintTierPage(Player player, Inventory inventory, QuestTierGui holder,
                               ConfigurationSection gui, QuestTier tier) {
        List<Integer> slots = enhancedSlots(gui, tier);
        if (slots.isEmpty()) {
            slots = questSlots(gui, tier);
        }
        if (slots.isEmpty()) {
            return;
        }
        List<QuestDefinition> definitions = new ArrayList<>();
        if (tier == QuestTier.MILESTONE) {
            definitions.addAll(questsByTier.getOrDefault(tier, List.of()));
        } else {
            QuestDefinition active = activeQuest(player, tier);
            if (active != null) {
                definitions.add(active);
            }
        }
        int maxPage = Math.max(0, (definitions.size() - 1) / slots.size());
        holder.page = Math.min(holder.page, maxPage);
        int offset = holder.page * slots.size();
        for (int index = 0; index < slots.size() && offset + index < definitions.size(); index++) {
            QuestDefinition definition = definitions.get(offset + index);
            int slot = slots.get(index);
            inventory.setItem(slot, questItem(player, definition));
            holder.visibleQuests.put(slot, definition);
        }
        paintTierTopBar(player, inventory, holder, gui, tier);
        paintNavigation(inventory, holder, gui, maxPage);
        paintReroll(player, inventory, gui, tier);
        paintClaimAll(player, inventory, holder, gui, tier);
    }

    private void paintTierTopBar(Player player, Inventory inventory, QuestTierGui holder,
                                  ConfigurationSection gui, QuestTier currentTier) {
        int[] topSlots = {2, 3, 4, 5, 6};
        QuestTier[] allTiers = QuestTier.values();
        Material[] tierMaterials = {Material.CLOCK, Material.SUNFLOWER, Material.AMETHYST_SHARD, Material.NETHER_STAR};
        for (int i = 0; i < 4; i++) {
            int slot = topSlots[i];
            QuestTier tier = allTiers[i];
            String name = (tier == currentTier
                    ? "<bold><gradient:#FFD700:#FFAA00>▶ " + tierDisplayName(tier) + " ◀</gradient></bold>"
                    : "<gradient:#555555:#888888>" + tierDisplayName(tier) + "</gradient>");
            inventory.setItem(slot, buildConfiguredItem(
                    categorySection(gui, tier), tierMaterials[i], name,
                    tier == currentTier ? categoryPlaceholders(player, tier) : Map.of("tier", name, "time_left", "")));
            holder.topNav.put(slot, tier);
        }
    }

    private void paintNavigation(Inventory inventory, QuestTierGui holder, ConfigurationSection gui, int maxPage) {
        ConfigurationSection nav = gui.getConfigurationSection("navigation");
        if (nav == null) {
            return;
        }
        int backSlot = nav.getInt("back-slot", 49);
        if (backSlot >= 0 && backSlot < inventory.getSize()) {
            ConfigurationSection back = nav.getConfigurationSection("back");
            inventory.setItem(backSlot, buildConfiguredItem(back, Material.ARROW,
                    "<gradient:#FFD700:#FFAA00><bold>← Back to Hub</bold></gradient>", Map.of()));
            holder.backSlot = backSlot;
        }
        if (holder.page > 0) {
            int previousSlot = nav.getInt("previous-slot", 45);
            if (previousSlot >= 0 && previousSlot < inventory.getSize()) {
                ConfigurationSection previous = nav.getConfigurationSection("previous");
                inventory.setItem(previousSlot, buildConfiguredItem(previous, Material.ARROW,
                        "<yellow>◀ Previous Page", Map.of()));
                holder.previousSlot = previousSlot;
            }
        }
        if (holder.page < maxPage) {
            int nextSlot = nav.getInt("next-slot", 53);
            if (nextSlot >= 0 && nextSlot < inventory.getSize()) {
                ConfigurationSection next = nav.getConfigurationSection("next");
                inventory.setItem(nextSlot, buildConfiguredItem(next, Material.ARROW,
                        "<yellow>Next Page ▶", Map.of()));
                holder.nextSlot = nextSlot;
            }
        }
    }

    private void paintReroll(Player player, Inventory inventory, ConfigurationSection gui, QuestTier tier) {
        ConfigurationSection reroll = gui.getConfigurationSection("reroll");
        if (reroll == null || !reroll.getBoolean("enabled", true) || tier == QuestTier.MILESTONE) {
            return;
        }
        int slot = reroll.getInt(tier.id() + "-slot", reroll.getInt("slot", 40));
        if (slot < 0 || slot >= inventory.getSize()) {
            return;
        }
        long cost = rerollCost(player, tier);
        inventory.setItem(slot, buildConfiguredItem(reroll, Material.RED_DYE,
                "<gradient:#FF5555:#FF0000><bold>Reroll Quest</bold></gradient>",
                Map.of("cost", String.valueOf(cost), "tier", tierDisplayName(tier))));
    }

    private void paintClaimAll(Player player, Inventory inventory, QuestTierGui holder,
                               ConfigurationSection gui, QuestTier tier) {
        if (tier == QuestTier.MILESTONE) {
            int claimableCount = 0;
            for (QuestDefinition def : questsByTier.getOrDefault(QuestTier.MILESTONE, List.of())) {
                if (isClaimable(player, def)) claimableCount++;
            }
            if (claimableCount == 0) return;
            int slot = 41;
            inventory.setItem(slot, ItemBuilder.of(Material.EMERALD_BLOCK)
                    .name(TextUtil.parse("<green><bold>Claim All (" + claimableCount + ")</bold></green>"))
                    .lore(List.of(
                            TextUtil.parse("<gray>Click to claim all"),
                            TextUtil.parse("<gray>available achievements</gray>")
                    ))
                    .glow(true)
                    .build());
            holder.claimAllSlot = slot;
            return;
        }
        QuestDefinition active = activeQuest(player, tier);
        if (active == null || !isClaimable(player, active)) return;
        int slot = 41;
        inventory.setItem(slot, ItemBuilder.of(Material.EMERALD_BLOCK)
                .name(TextUtil.parse("<green><bold>Claim All</bold></green>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Click to claim reward"),
                        TextUtil.parse("<gray>for <white>" + active.name() + "</white></gray>")
                ))
                .glow(true)
                .build());
        holder.claimAllSlot = slot;
    }

    private void claimAll(Player player, QuestTier tier) {
        if (!economy.isClickReady(player.getUniqueId())) return;
        if (tier == QuestTier.MILESTONE) {
            int claimed = 0;
            for (QuestDefinition def : questsByTier.getOrDefault(QuestTier.MILESTONE, List.of())) {
                if (isClaimable(player, def)) {
                    String claimKey = "quest-claim:" + player.getUniqueId() + ":" + claimMarker(def);
                    TransactionResult grant = economy.grantShards(player.getUniqueId(), def.rewardShards(), "quest:" + def.id(), claimKey);
                    if (grant.success()) {
                        PlayerProfile profile = store.get(player.getUniqueId());
                        profile.claimedQuests().add(claimMarker(def));
                        store.saveProfile(profile);
                        economy.notifyGrant(player, CurrencyType.SHARDS, def.rewardShards(), def.name());
                        claimed++;
                    }
                }
            }
            if (claimed > 0) {
                playSound(player, "claim.sound", "ENTITY_PLAYER_LEVELUP", Sound.ENTITY_PLAYER_LEVELUP);
                player.sendMessage(TextUtil.parse("<green>Claimed " + claimed + " achievement rewards!</green>"));
            }
            openTierGui(player, tier, 0);
            return;
        }
        QuestDefinition active = activeQuest(player, tier);
        if (active != null && isClaimable(player, active)) {
            claim(player, active, 0);
        }
    }

    private List<Integer> enhancedSlots(ConfigurationSection gui, QuestTier tier) {
        if (tier == QuestTier.MILESTONE) {
            return ENHANCED_LAYOUT;
        }
        return ENHANCED_LAYOUT;
    }

    private ItemStack questItem(Player player, QuestDefinition definition) {
        FileConfiguration config = configs.get("quests.yml");
        ConfigurationSection states = questGui(config).getConfigurationSection("states");
        String stateName = stateName(player, definition);
        ConfigurationSection state = states == null ? null : states.getConfigurationSection(stateName);
        Material fallback = switch (stateName) {
            case "claimable" -> Material.EMERALD;
            case "completed" -> Material.GRAY_STAINED_GLASS_PANE;
            default -> Material.REDSTONE;
        };
        return buildConfiguredItem(state, fallback, definition.name(), questPlaceholders(player, definition));
    }

    private ItemStack buildConfiguredItem(ConfigurationSection section, Material fallback,
                                          String fallbackName, Map<String, String> placeholders) {
        Material material = section == null ? fallback : ConfigItems.material(section, "material", fallback);
        String name = section == null ? fallbackName : section.getString("name", fallbackName);
        List<Component> lore = section == null ? List.of() : TextUtil.lore(section, "lore", placeholders);
        boolean glow = section != null && section.getBoolean("glow", false);
        Integer customModelData = section == null ? null : ConfigItems.customModelData(section, "custom-model-data");
        return ItemBuilder.of(material)
                .name(TextUtil.parse(TextUtil.apply(name, placeholders)))
                .lore(lore)
                .glow(glow)
                .customModelData(customModelData)
                .build();
    }

    private void ensureAssignments(Player player) {
        PlayerProfile profile = store.get(player.getUniqueId());
        boolean profileChanged = false;
        for (QuestTier tier : ROTATING_TIERS) {
            String cacheKey = player.getUniqueId() + ":" + tier.id();
            String assignedQuest = assignmentCache.get(cacheKey);
            long assignedAt = 0L;
            if (assignedQuest != null) {
                assignedAt = store.getQuestAssignedAt(player.getUniqueId(), tier.id());
            } else {
                assignedQuest = store.getAssignedQuest(player.getUniqueId(), tier.id());
                assignedAt = store.getQuestAssignedAt(player.getUniqueId(), tier.id());
                if (assignedQuest != null) {
                    assignmentCache.put(cacheKey, assignedQuest);
                }
            }
            if (assignedQuest == null || rotationExpired(tier, assignedAt)) {
                profileChanged |= profile.claimedQuests().removeIf(value -> value.startsWith(tier.id() + ":"));
                store.clearQuestAssignment(player.getUniqueId(), tier.id());
                assignRandom(player, tier);
                assignmentCache.remove(cacheKey);
            }
        }
        if (profileChanged) {
            store.saveProfile(profile);
        }
    }

    private void assignRandom(Player player, QuestTier tier) {
        if (tier == QuestTier.MILESTONE) {
            return;
        }
        List<QuestDefinition> pool = questsByTier.getOrDefault(tier, List.of());
        if (pool.isEmpty()) {
            return;
        }
        String current = store.getAssignedQuest(player.getUniqueId(), tier.id());
        List<QuestDefinition> candidates = pool.stream()
                .filter(quest -> !quest.id().equals(current))
                .toList();
        if (candidates.isEmpty()) {
            candidates = pool;
        }
        QuestDefinition quest = candidates.get(random.nextInt(candidates.size()));
        store.setQuestAssignment(player.getUniqueId(), tier.id(), quest.id(), 0);
        assignmentCache.put(player.getUniqueId() + ":" + tier.id(), quest.id());
    }

    private void incrementQuest(Player player, QuestType type, int amount) {
        for (QuestTier tier : ROTATING_TIERS) {
            QuestDefinition definition = activeQuest(player, tier);
            if (definition == null || definition.type() != type || isClaimed(player, definition)) {
                continue;
            }
            int progress = store.getQuestProgress(player.getUniqueId(), tier.id()) + amount;
            store.setQuestProgress(player.getUniqueId(), tier.id(), Math.min(progress, definition.target()));
        }
    }

    private void completeQuestType(Player player, QuestType type) {
        for (QuestTier tier : ROTATING_TIERS) {
            QuestDefinition definition = activeQuest(player, tier);
            if (definition != null && definition.type() == type && !isClaimed(player, definition)) {
                store.setQuestProgress(player.getUniqueId(), tier.id(), definition.target());
            }
        }
    }

    private void updateKillstreakProgress(Player player, int streak) {
        for (QuestTier tier : ROTATING_TIERS) {
            QuestDefinition definition = activeQuest(player, tier);
            if (definition == null || definition.type() != QuestType.KILLSTREAK || isClaimed(player, definition)) {
                continue;
            }
            int current = store.getQuestProgress(player.getUniqueId(), tier.id());
            if (streak > current) {
                store.setQuestProgress(player.getUniqueId(), tier.id(), Math.min(streak, definition.target()));
            }
        }
    }

    private QuestDefinition activeQuest(Player player, QuestTier tier) {
        if (tier == QuestTier.MILESTONE) {
            return null;
        }
        String questId = store.getAssignedQuest(player.getUniqueId(), tier.id());
        if (questId == null) {
            return null;
        }
        return quests.get(key(tier, questId));
    }

    private QuestDefinition nextAchievement(Player player) {
        for (QuestDefinition definition : questsByTier.getOrDefault(QuestTier.MILESTONE, List.of())) {
            if (!isClaimed(player, definition)) {
                return definition;
            }
        }
        return null;
    }

    private void claim(Player player, QuestDefinition definition, int page) {
        if (!economy.isClickReady(player.getUniqueId())) {
            return;
        }
        if (isClaimed(player, definition)) {
            player.sendMessage(TextUtil.parse(plugin.getConfig().getString("messages.already-claimed", "<gray>Already claimed.")));
            openTierGui(player, definition.tier(), page);
            return;
        }
        if (progress(player, definition) < definition.target()) {
            player.sendMessage(TextUtil.parse(configs.get("quests.yml").getString("messages.not-complete", "<red>That quest is not complete yet.")));
            return;
        }
        String claimKey = "quest-claim:" + player.getUniqueId() + ":" + claimMarker(definition);
        TransactionResult grant = economy.grantShards(player.getUniqueId(), definition.rewardShards(), "quest:" + definition.id(), claimKey);
        if (!grant.success()) {
            player.sendMessage(TextUtil.parse(plugin.getConfig().getString("messages.already-claimed", "<gray>Already claimed.")));
            openTierGui(player, definition.tier(), page);
            return;
        }
        PlayerProfile profile = store.get(player.getUniqueId());
        profile.claimedQuests().add(claimMarker(definition));
        store.saveProfile(profile);
        playSound(player, "claim.sound", "ENTITY_PLAYER_LEVELUP", Sound.ENTITY_PLAYER_LEVELUP);
        economy.notifyGrant(player, CurrencyType.SHARDS, definition.rewardShards(), definition.name());
        openTierGui(player, definition.tier(), page);
    }

    private void reroll(Player player, QuestTier tier) {
        if (tier == QuestTier.MILESTONE || !economy.isClickReady(player.getUniqueId())) {
            return;
        }
        QuestDefinition active = activeQuest(player, tier);
        if (active != null && isClaimed(player, active)) {
            player.sendMessage(TextUtil.parse(plugin.getConfig().getString("messages.already-claimed", "<gray>Already claimed.")));
            return;
        }
        PlayerProfile profile = store.get(player.getUniqueId());
        resetDailyRerollsIfNeeded(profile);
        int count = rerollCount(profile, tier);
        long cost = rerollCost(player, tier);
        TransactionResult spend = economy.spendShards(player.getUniqueId(), cost, "quest-reroll:" + tier.id());
        if (!spend.success()) {
            economy.notifyFailure(player, spend.messageKey(), cost);
            return;
        }
        setRerollCount(profile, tier, count + 1);
        store.saveProfile(profile);
        assignRandom(player, tier);
        playSound(player, "reroll.sound", "UI_BUTTON_CLICK", Sound.UI_BUTTON_CLICK);
        openTierGui(player, tier, 0);
    }

    private int progress(Player player, QuestDefinition definition) {
        if (definition.tier() != QuestTier.MILESTONE) {
            return Math.min(store.getQuestProgress(player.getUniqueId(), definition.tier().id()), definition.target());
        }
        PlayerProfile profile = store.get(player.getUniqueId());
        long value = switch (definition.type()) {
            case KILLS_LIFETIME -> profile.lifetimeKills();
            case TRACKDOWNS_LIFETIME -> profile.lifetimeTrackdowns();
            case MATCH_WINS -> profile.matchWins();
            default -> 0L;
        };
        return (int) Math.min(value, definition.target());
    }

    private boolean isClaimable(Player player, QuestDefinition definition) {
        return !isClaimed(player, definition) && progress(player, definition) >= definition.target();
    }

    private boolean isClaimed(Player player, QuestDefinition definition) {
        PlayerProfile profile = store.get(player.getUniqueId());
        return profile.claimedQuests().contains(claimMarker(definition))
                || profile.claimedQuests().contains(definition.tier().id() + ":" + definition.id());
    }

    private String stateName(Player player, QuestDefinition definition) {
        if (isClaimed(player, definition)) {
            return "completed";
        }
        if (progress(player, definition) >= definition.target()) {
            return "claimable";
        }
        return "active";
    }

    private Map<String, String> questPlaceholders(Player player, QuestDefinition definition) {
        int progress = progress(player, definition);
        return Map.of(
                "name", definition.name(),
                "description", definition.description(),
                "tier", tierDisplayName(definition.tier()),
                "progress", String.valueOf(Math.min(progress, definition.target())),
                "target", String.valueOf(definition.target()),
                "percent", String.valueOf(progressPercent(progress, definition.target())),
                "progress_bar", progressBar(progress, definition.target()),
                "reward", String.valueOf(definition.rewardShards()),
                "time_left", timeLeftText(definition.tier())
        );
    }

    private int progressPercent(int progress, int target) {
        if (target <= 0) {
            return 0;
        }
        return (int) Math.floor(Math.min(100.0D, progress * 100.0D / target));
    }

    private String progressBar(int progress, int target) {
        FileConfiguration config = configs.get("quests.yml");
        int segments = Math.max(1, config.getInt("gui.progress-bar.segments", 10));
        String filled = config.getString("gui.progress-bar.filled", "#");
        String empty = config.getString("gui.progress-bar.empty", "-");
        int filledSegments = target <= 0 ? 0 : (int) Math.round(Math.min(1.0D, progress / (double) target) * segments);
        StringBuilder builder = new StringBuilder("[");
        for (int i = 0; i < segments; i++) {
            builder.append(i < filledSegments ? filled : empty);
        }
        return builder.append("]").toString();
    }

    private Map<String, String> categoryPlaceholders(Player player, QuestTier tier) {
        int completed = completedCount(player, tier);
        int total = totalCount(tier);
        return Map.of(
                "tier", tierDisplayName(tier),
                "active", activeQuestName(player, tier),
                "progress", activeProgressText(player, tier),
                "claimable", String.valueOf(tier == QuestTier.MILESTONE ? claimableAchievements(player) : claimableForTier(player, tier)),
                "completed", String.valueOf(completed),
                "total", String.valueOf(total),
                "time_left", timeLeftText(tier)
        );
    }

    private int claimableForTier(Player player, QuestTier tier) {
        QuestDefinition definition = activeQuest(player, tier);
        return definition != null && isClaimable(player, definition) ? 1 : 0;
    }

    private int claimableAchievements(Player player) {
        int count = 0;
        for (QuestDefinition definition : questsByTier.getOrDefault(QuestTier.MILESTONE, List.of())) {
            if (isClaimable(player, definition)) {
                count++;
            }
        }
        return count;
    }

    private long rerollCost(Player player, QuestTier tier) {
        PlayerProfile profile = store.get(player.getUniqueId());
        FileConfiguration config = configs.get("quests.yml");
        double base = config.getDouble("reroll.base-cost", 50);
        double multiplier = config.getDouble("reroll.multiplier", 1.5);
        return (long) Math.ceil(base * Math.pow(multiplier, rerollCount(profile, tier)));
    }

    private int rerollCount(PlayerProfile profile, QuestTier tier) {
        return switch (tier) {
            case DAILY -> profile.dailyRerolls();
            case WEEKLY -> profile.weeklyRerolls();
            case MONTHLY -> profile.monthlyRerolls();
            case MILESTONE -> profile.milestoneRerolls();
        };
    }

    private void setRerollCount(PlayerProfile profile, QuestTier tier, int count) {
        switch (tier) {
            case DAILY -> profile.setDailyRerolls(count);
            case WEEKLY -> profile.setWeeklyRerolls(count);
            case MONTHLY -> profile.setMonthlyRerolls(count);
            case MILESTONE -> profile.setMilestoneRerolls(count);
        }
    }

    private void completeLifetimeRequirement(PlayerProfile profile, QuestDefinition definition) {
        switch (definition.type()) {
            case KILLS_LIFETIME -> profile.setLifetimeKills(Math.max(profile.lifetimeKills(), definition.target()));
            case TRACKDOWNS_LIFETIME -> profile.setLifetimeTrackdowns(Math.max(profile.lifetimeTrackdowns(), definition.target()));
            case MATCH_WINS -> profile.setMatchWins(Math.max(profile.matchWins(), definition.target()));
            default -> {
            }
        }
    }

    private QuestDefinition resolveQuest(String rawQuestId) {
        if (rawQuestId == null || rawQuestId.isBlank()) {
            return null;
        }
        QuestDefinition direct = quests.get(rawQuestId.toLowerCase(Locale.ROOT));
        if (direct != null) {
            return direct;
        }
        for (QuestDefinition definition : quests.values()) {
            if (definition.id().equalsIgnoreCase(rawQuestId)) {
                return definition;
            }
        }
        return null;
    }

    private boolean rotationExpired(QuestTier tier, long assignedAt) {
        if (assignedAt <= 0 || tier == QuestTier.MILESTONE) {
            return false;
        }
        return epoch(tier, Instant.ofEpochMilli(assignedAt)) != epoch(tier, Instant.now());
    }

    private long epoch(QuestTier tier) {
        return epoch(tier, Instant.now());
    }

    private long epoch(QuestTier tier, Instant instant) {
        ZonedDateTime time = ZonedDateTime.ofInstant(instant, ZoneId.systemDefault());
        return switch (tier) {
            case DAILY -> time.toLocalDate().toEpochDay();
            case WEEKLY -> {
                WeekFields weekFields = WeekFields.ISO;
                int year = time.get(weekFields.weekBasedYear());
                int week = time.get(weekFields.weekOfWeekBasedYear());
                yield (long) year * 100L + week;
            }
            case MONTHLY -> (long) time.getYear() * 100L + time.getMonthValue();
            case MILESTONE -> 0L;
        };
    }

    private ZonedDateTime nextReset(QuestTier tier) {
        ZoneId zone = ZoneId.systemDefault();
        ZonedDateTime now = ZonedDateTime.now(zone);
        return switch (tier) {
            case DAILY -> now.toLocalDate().plusDays(1).atStartOfDay(zone);
            case WEEKLY -> {
                LocalDate nextMonday = now.toLocalDate().with(TemporalAdjusters.next(java.time.DayOfWeek.MONDAY));
                yield nextMonday.atStartOfDay(zone);
            }
            case MONTHLY -> now.toLocalDate()
                    .with(ChronoField.DAY_OF_MONTH, 1)
                    .plusMonths(1)
                    .atStartOfDay(zone);
            case MILESTONE -> now.plusYears(100);
        };
    }

    private String claimMarker(QuestDefinition definition) {
        return definition.tier().id() + ":" + definition.id() + ":" + epoch(definition.tier());
    }

    private String key(QuestTier tier, String questId) {
        return tier.id() + ":" + questId;
    }

    private ConfigurationSection questGui(FileConfiguration config) {
        ConfigurationSection gui = config.getConfigurationSection("gui");
        return gui == null ? config.createSection("gui") : gui;
    }

    private ConfigurationSection categorySection(ConfigurationSection gui, QuestTier tier) {
        ConfigurationSection categories = gui.getConfigurationSection("categories");
        if (categories == null) {
            return null;
        }
        ConfigurationSection section = categories.getConfigurationSection(categoryKey(tier));
        if (section == null && tier == QuestTier.MILESTONE) {
            section = categories.getConfigurationSection(tier.id());
        }
        return section;
    }

    private List<Integer> questSlots(ConfigurationSection gui, QuestTier tier) {
        List<Integer> slots = gui.getIntegerList("category.quest-slots");
        if (!slots.isEmpty()) {
            return slots;
        }
        ConfigurationSection legacy = gui.getConfigurationSection("quest-slots");
        if (legacy != null) {
            slots = legacy.getIntegerList(tier.id());
            if (!slots.isEmpty()) {
                return slots;
            }
        }
        return DEFAULT_QUEST_SLOTS;
    }

    private int defaultCategorySlot(QuestTier tier) {
        return switch (tier) {
            case DAILY -> 10;
            case WEEKLY -> 12;
            case MONTHLY -> 14;
            case MILESTONE -> 16;
        };
    }

    private String categoryKey(QuestTier tier) {
        return tier == QuestTier.MILESTONE ? "achievements" : tier.id();
    }

    private String tierDisplayName(QuestTier tier) {
        return switch (tier) {
            case DAILY -> "Daily Quests";
            case WEEKLY -> "Weekly Quests";
            case MONTHLY -> "Monthly Quests";
            case MILESTONE -> "Achievements";
        };
    }

    private void paintFiller(Inventory inventory, ConfigurationSection filler) {
        if (filler == null || !filler.getBoolean("enabled", false)) {
            return;
        }
        ItemStack item = buildConfiguredItem(filler, Material.BLACK_STAINED_GLASS_PANE, " ", Map.of());
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            inventory.setItem(slot, item);
        }
    }

    private void playSound(Player player, String path, String fallbackName, Sound fallback) {
        String raw = configs.get("quests.yml").getString(path, fallbackName);
        Sound sound = fallback;
        try {
            sound = Sound.valueOf(raw.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ignored) {
        }
        player.playSound(player.getLocation(), sound, 1.0F, 1.0F);
    }

    private final class QuestMainGui extends GuiHolder {
        private final Player player;
        private final Map<Integer, QuestTier> categories = new HashMap<>();

        private QuestMainGui(Player player) {
            this.player = player;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            QuestTier tier = categories.get(event.getRawSlot());
            if (tier != null) {
                openTierGui(player, tier, 0);
            }
        }
    }

    private final class QuestTierGui extends GuiHolder {
        private final Player player;
        private final QuestTier tier;
        private final Map<Integer, QuestDefinition> visibleQuests = new HashMap<>();
        private final Map<Integer, QuestTier> topNav = new HashMap<>();
        private int page;
        private int backSlot = -1;
        private int previousSlot = -1;
        private int nextSlot = -1;
        private int claimAllSlot = -1;

        private QuestTierGui(Player player, QuestTier tier, int page) {
            this.player = player;
            this.tier = tier;
            this.page = page;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            QuestDefinition definition = visibleQuests.get(slot);
            if (definition != null) {
                claim(player, definition, page);
                return;
            }
            if (slot == backSlot) {
                openMainGui(player);
                return;
            }
            if (slot == previousSlot) {
                openTierGui(player, tier, Math.max(0, page - 1));
                return;
            }
            if (slot == nextSlot) {
                openTierGui(player, tier, page + 1);
                return;
            }
            QuestTier navTier = topNav.get(slot);
            if (navTier != null && navTier != tier) {
                openTierGui(player, navTier, 0);
                return;
            }
            if (slot == claimAllSlot) {
                claimAll(player, tier);
                return;
            }
            ConfigurationSection reroll = configs.get("quests.yml").getConfigurationSection("gui.reroll");
            if (reroll != null) {
                int rerollSlot = reroll.getInt(tier.id() + "-slot", reroll.getInt("slot", 40));
                if (slot == rerollSlot) {
                    reroll(player, tier);
                }
            }
        }
    }
}
