package lol.folium.unstable.kit;

import org.bukkit.Color;
import org.bukkit.Material;

import java.util.List;

public record KillEffectDefinition(
        String id,
        String displayName,
        Material material,
        int slot,
        long price,
        List<Color> colors,
        boolean flicker,
        boolean trail
) {}
