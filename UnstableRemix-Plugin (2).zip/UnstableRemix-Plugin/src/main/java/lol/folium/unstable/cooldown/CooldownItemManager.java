package lol.folium.unstable.cooldown;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class CooldownItemManager {

    private static final String NBT_KEY = "cooldown_item_id";

    private final UnstableRemixPlugin plugin;
    private final Map<String, CooldownItem> items = new HashMap<>();

    public CooldownItemManager(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadFromConfig() {
        items.clear();
        FileConfiguration config = plugin.getConfig();
        ConfigurationSection section = config.getConfigurationSection("cooldown-items");
        if (section == null) return;

        for (String id : section.getKeys(false)) {
            ConfigurationSection item = section.getConfigurationSection(id);
            if (item == null) continue;

            String command = item.getString("command", id);
            String materialStr = item.getString("material", "PAPER");
            Material material = matchMaterial(materialStr);
            String displayName = item.getString("name", id);
            String effect = item.getString("effect", "no-cooldown");
            int duration = item.getInt("duration-seconds", 3600);
            double shardMultiplier = item.getDouble("shard-multiplier", 2.0);

            List<String> loreLines = item.getStringList("lore");

            items.put(id.toLowerCase(Locale.ROOT), new CooldownItem(
                    id.toLowerCase(Locale.ROOT),
                    command.toLowerCase(Locale.ROOT),
                    material,
                    displayName,
                    effect,
                    duration,
                    shardMultiplier
            ));
        }
    }

    public void reload() {
        loadFromConfig();
    }

    public CooldownItem getItem(String id) {
        return items.get(id.toLowerCase(Locale.ROOT));
    }

    public CooldownItem getByCommand(String command) {
        String cmd = command.toLowerCase(Locale.ROOT);
        for (CooldownItem item : items.values()) {
            if (item.command().equals(cmd)) return item;
        }
        return null;
    }

    public Collection<CooldownItem> all() {
        return Collections.unmodifiableCollection(items.values());
    }

    public List<String> getCommands() {
        List<String> cmds = new ArrayList<>();
        for (CooldownItem item : items.values()) {
            cmds.add(item.command());
        }
        return cmds;
    }

    public List<String> getIds() {
        return new ArrayList<>(items.keySet());
    }

    public ItemStack createItem(CooldownItem item) {
        return createItem(item, 1);
    }

    public ItemStack createItem(CooldownItem item, int amount) {
        FileConfiguration config = plugin.getConfig();
        ConfigurationSection section = config.getConfigurationSection("cooldown-items." + item.id());
        List<String> rawLore = section != null ? section.getStringList("lore") : List.of();

        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        for (String line : rawLore) {
            String replaced = line
                    .replace("{duration}", String.valueOf(item.durationSeconds() / 60))
                    .replace("{multiplier}", String.format("%.1f", item.shardMultiplier()));
            lore.add(TextUtil.parse(replaced));
        }
        lore.add(Component.empty());
        lore.add(TextUtil.parse("<yellow><bold>Right-click to activate!</bold></yellow>"));

        ItemStack stack = ItemBuilder.of(item.material())
                .amount(amount)
                .name(TextUtil.parse(item.displayName()))
                .lore(lore)
                .build();

        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            NamespacedKey key = new NamespacedKey(plugin, NBT_KEY);
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, item.id());
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            stack.setItemMeta(meta);
        }

        return stack;
    }

    public String getItemId(ItemStack stack) {
        if (stack == null || stack.getType() == Material.AIR) return null;
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return null;
        NamespacedKey key = new NamespacedKey(plugin, NBT_KEY);
        return meta.getPersistentDataContainer().get(key, PersistentDataType.STRING);
    }

    public boolean isCooldownItem(ItemStack stack) {
        return getItemId(stack) != null;
    }

    public void removeOne(Player player, ItemStack stack) {
        if (stack.getAmount() <= 1) {
            player.getInventory().removeItem(stack);
        } else {
            stack.setAmount(stack.getAmount() - 1);
        }
    }

    private Material matchMaterial(String name) {
        if (name == null || name.isEmpty()) return Material.PAPER;
        String normalized = name.toUpperCase(Locale.ROOT).replace(" ", "_").replace("-", "_");
        Material mat = Material.matchMaterial(normalized);
        return mat != null ? mat : Material.PAPER;
    }

    public void giveItem(org.bukkit.entity.Player player, CooldownItem item) {
        giveItem(player, item, 1);
    }

    public void giveItem(org.bukkit.entity.Player player, CooldownItem item, int amount) {
        ItemStack stack = createItem(item, amount);
        HashMap<Integer, ItemStack> overflow = player.getInventory().addItem(stack);
        if (!overflow.isEmpty()) {
            overflow.values().forEach(extra ->
                    player.getWorld().dropItemNaturally(player.getLocation(), extra));
        }
    }
}
