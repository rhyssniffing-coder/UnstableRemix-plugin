package lol.folium.unstable.afk;

import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.entity.Player;

import java.util.List;

public final class AfkZoneCommand extends SubCommand {

    private final AfkZoneManager afk;

    public AfkZoneCommand(AfkZoneManager afk) {
        this.afk = afk;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length < 1) {
            sendUsage(player);
            return;
        }
        switch (args[0].toLowerCase()) {
            case "create" -> handleCreate(player, args);
            case "delete" -> handleDelete(player, args);
            case "setshards" -> handleSetShards(player, args);
            case "setinterval" -> handleSetInterval(player, args);
            case "toggleglow" -> handleToggleGlow(player, args);
            case "list" -> handleList(player);
            default -> sendUsage(player);
        }
    }

    private void handleCreate(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /afk create <name>"));
            return;
        }
        afk.createZone(player, args[1]);
    }

    private void handleDelete(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /afk delete <name>"));
            return;
        }
        afk.deleteZone(player, args[1]);
    }

    private void handleSetShards(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(TextUtil.parse("<red>Usage: /afk setshards <name> <amount>"));
            return;
        }
        try {
            long amount = Long.parseLong(args[2]);
            if (afk.setShards(args[1], amount)) {
                player.sendMessage(TextUtil.parse("<green>Set shard payout for <white>" + args[1] + "</white> to <light_purple>" + amount + " Shards</light_purple>."));
            } else {
                player.sendMessage(TextUtil.parse("<red>Zone not found."));
            }
        } catch (NumberFormatException e) {
            player.sendMessage(TextUtil.parse("<red>Enter a valid number."));
        }
    }

    private void handleSetInterval(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(TextUtil.parse("<red>Usage: /afk setinterval <name> <seconds>"));
            return;
        }
        try {
            long seconds = Long.parseLong(args[2]);
            if (afk.setInterval(args[1], seconds)) {
                player.sendMessage(TextUtil.parse("<green>Set interval for <white>" + args[1] + "</white> to " + seconds + " seconds."));
            } else {
                player.sendMessage(TextUtil.parse("<red>Zone not found."));
            }
        } catch (NumberFormatException e) {
            player.sendMessage(TextUtil.parse("<red>Enter a valid number."));
        }
    }

    private void handleToggleGlow(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /afk toggleglow <name>"));
            return;
        }
        if (afk.toggleGlow(args[1])) {
            player.sendMessage(TextUtil.parse("<green>Toggled glow for <white>" + args[1] + "</white>."));
        } else {
            player.sendMessage(TextUtil.parse("<red>Zone not found."));
        }
    }

    private void handleList(Player player) {
        var zones = afk.getZones();
        if (zones.isEmpty()) {
            player.sendMessage(TextUtil.parse("<gray>No AFK zones configured."));
            return;
        }
        player.sendMessage(TextUtil.parse("<aqua><bold>AFK Zones</bold></aqua>"));
        for (AfkZoneManager.AfkZone zone : zones.values()) {
            player.sendMessage(TextUtil.parse(
                    "<gray>- <white>" + zone.name() + "</white> <dark_gray>|</dark_gray> "
                            + zone.shardsPerInterval() + " shards / " + zone.intervalSeconds() + "s"
                            + (zone.glow() ? " <green>(glow)</green>" : "")));
        }
    }

    private void sendUsage(Player player) {
        player.sendMessage(TextUtil.parse("<yellow>/afk create <name>"));
        player.sendMessage(TextUtil.parse("<yellow>/afk delete <name>"));
        player.sendMessage(TextUtil.parse("<yellow>/afk setshards <name> <amount>"));
        player.sendMessage(TextUtil.parse("<yellow>/afk setinterval <name> <seconds>"));
        player.sendMessage(TextUtil.parse("<yellow>/afk toggleglow <name>"));
        player.sendMessage(TextUtil.parse("<yellow>/afk list"));
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            return filter(literals("create", "delete", "setshards", "setinterval", "toggleglow", "list"), args[0]);
        }
        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if (sub.equals("delete") || sub.equals("setshards") || sub.equals("setinterval") || sub.equals("toggleglow")) {
                return filter(afk.getZones().keySet().stream().toList(), args[1]);
            }
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("setshards")) {
            return List.of("1", "5", "10", "25", "50");
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("setinterval")) {
            return List.of("30", "60", "120", "300");
        }
        return List.of();
    }

    @Override
    protected String permission() {
        return "unstable.afk.admin";
    }
}