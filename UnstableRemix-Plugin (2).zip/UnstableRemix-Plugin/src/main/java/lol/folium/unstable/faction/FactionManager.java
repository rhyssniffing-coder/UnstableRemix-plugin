package lol.folium.unstable.faction;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.economy.TransactionResult;
import lol.folium.unstable.faction.Faction.FactionMember;
import lol.folium.unstable.faction.Faction.Role;
import lol.folium.unstable.map.WorldEditBridge;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Duration;
import java.time.Instant;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class FactionManager {

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final Map<String, Faction> factions = new ConcurrentHashMap<>();
    private final Map<UUID, String> playerFaction = new ConcurrentHashMap<>();
    private final Map<UUID, String> factionChat = new ConcurrentHashMap<>();
    private Connection db;
    private final Object dbLock = new Object();
    private BukkitTask xpTask;

    private final Map<String, FactionWar> activeWars = new ConcurrentHashMap<>();
    private final Map<String, Long> warCooldowns = new ConcurrentHashMap<>();

    public FactionManager(UnstableRemixPlugin plugin, ConfigManager configs) {
        this.plugin = plugin;
        this.configs = configs;
    }

    public void init() throws SQLException {
        synchronized (dbLock) {
        db = DriverManager.getConnection("jdbc:sqlite:" + plugin.getDataFolder() + "/factions.db");
        try (Statement st = db.createStatement()) {
            st.execute("""
                CREATE TABLE IF NOT EXISTS factions (
                    name TEXT PRIMARY KEY,
                    display_name TEXT NOT NULL,
                    description TEXT DEFAULT '',
                    level INTEGER NOT NULL DEFAULT 1,
                    xp INTEGER NOT NULL DEFAULT 0,
                    total_kills INTEGER NOT NULL DEFAULT 0,
                    total_shards_earned INTEGER NOT NULL DEFAULT 0,
                    created_at INTEGER NOT NULL
                )
                """);
            st.execute("""
                CREATE TABLE IF NOT EXISTS faction_members (
                    faction_name TEXT NOT NULL,
                    uuid TEXT NOT NULL,
                    player_name TEXT NOT NULL,
                    role TEXT NOT NULL DEFAULT 'MEMBER',
                    joined_at INTEGER NOT NULL,
                    kills INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY (faction_name, uuid)
                )
                """);
        }
        }
    }

    public void loadAll() {
        synchronized (dbLock) {
        factions.clear();
        playerFaction.clear();
        try (PreparedStatement ps = db.prepareStatement("SELECT * FROM factions");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Faction f = new Faction(rs.getString("name"));
                f.setDisplayName(rs.getString("display_name"));
                f.setDescription(rs.getString("description"));
                f.setLevel(rs.getInt("level"));
                f.setXp(rs.getLong("xp"));
                f.setTotalKills(rs.getLong("total_kills"));
                f.setTotalShardsEarned(rs.getLong("total_shards_earned"));
                factions.put(f.name(), f);
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed loading factions: " + e.getMessage());
        }
        try (PreparedStatement ps = db.prepareStatement("SELECT * FROM faction_members");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String fn = rs.getString("faction_name");
                Faction f = factions.get(fn);
                if (f == null) continue;
                FactionMember member = new FactionMember(
                        UUID.fromString(rs.getString("uuid")),
                        rs.getString("player_name"),
                        Role.valueOf(rs.getString("role")),
                        rs.getLong("joined_at"),
                        rs.getLong("kills"));
                f.members().add(member);
                playerFaction.put(member.uuid(), fn);
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed loading members: " + e.getMessage());
        }
        }
    }

    public void startTasks() {
        xpTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tickFactionXp, 20L * 60, 20L * 60 * 60);
    }

    public void stopTasks() {
        if (xpTask != null) { xpTask.cancel(); xpTask = null; }
    }

    public boolean isInFaction(Player player) {
        return playerFaction.containsKey(player.getUniqueId());
    }

    public boolean hasEverBeenInFaction(UUID uuid) {
        if (playerFaction.containsKey(uuid)) return true;
        synchronized (dbLock) {
            try (PreparedStatement ps = db.prepareStatement("SELECT 1 FROM faction_members WHERE uuid = ? LIMIT 1")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next();
                }
            } catch (SQLException e) {
                plugin.getLogger().warning("Failed checking faction history: " + e.getMessage());
            }
        }
        return false;
    }

    public Optional<Faction> getFaction(Player player) {
        String name = playerFaction.get(player.getUniqueId());
        if (name == null) return Optional.empty();
        return Optional.ofNullable(factions.get(name));
    }

    public Optional<Faction> getFaction(String name) {
        return Optional.ofNullable(factions.get(name.toLowerCase(Locale.ROOT)));
    }

    public String getFactionName(Player player) {
        return playerFaction.get(player.getUniqueId());
    }

    public Collection<Faction> allFactions() {
        return factions.values();
    }

    // ============ FACTION CHAT ============

    public void factionChat(Player player, String message) {
        String fName = playerFaction.get(player.getUniqueId());
        if (fName == null) {
            player.sendMessage(TextUtil.parse("<red>You aren't in a faction.</red>"));
            return;
        }
        Faction f = factions.get(fName);
        String formatted = "<gray>[<gradient:#FFD700:#FFAA00>FC</gradient>]</gray> <white>" + player.getName() + "</white><dark_gray>:</dark_gray> <gray>" + message + "</gray>";
        broadcastToFaction(f, TextUtil.parse(formatted));
    }

    public boolean toggleFactionChat(Player player) {
        if (factionChat.containsKey(player.getUniqueId())) {
            factionChat.remove(player.getUniqueId());
            player.sendMessage(TextUtil.parse("<gray>Faction chat <red>disabled</red>.</gray>"));
            return false;
        } else {
            factionChat.put(player.getUniqueId(), "on");
            player.sendMessage(TextUtil.parse("<gray>Faction chat <green>enabled</green>. Type normally to chat with faction.</gray>"));
            return true;
        }
    }

    public boolean isInFactionChat(UUID uuid) {
        return factionChat.containsKey(uuid);
    }

    // ============ XP & LEVELING ============

    private void tickFactionXp() {
        synchronized (dbLock) {
        for (Faction f : factions.values()) {
            int onlineCount = (int) f.members().stream()
                    .map(m -> Bukkit.getPlayer(m.uuid()))
                    .filter(p -> p != null && p.isOnline())
                    .count();
            if (onlineCount > 0) {
                addFactionXp(f, onlineCount * 10L);
            }
        }
        }
    }

    public void addFactionXp(Faction f, long amount) {
        synchronized (dbLock) {
        f.setXp(f.xp() + amount);
        checkLevelUp(f);
        }
    }

    private void checkLevelUp(Faction f) {
        synchronized (dbLock) {
        int maxLevel = plugin.getConfig().getInt("factions.max-level", 20);
        while (f.xp() >= f.xpToNextLevel() && f.level() < maxLevel) {
            f.setXp(f.xp() - f.xpToNextLevel());
            f.setLevel(f.level() + 1);
            broadcastToFaction(f, TextUtil.parse("<gradient:#FFD700:#FFAA00><bold>Faction Level Up!</bold></gradient> <white>Level " + (f.level() - 1) + " \u2192 <bold>" + f.level() + "</bold></white>"));
        }
        saveFaction(f);
        }
    }

    public void addShardsEarned(Player player, long amount) {
        synchronized (dbLock) {
        getFaction(player).ifPresent(f -> {
            f.setTotalShardsEarned(f.totalShardsEarned() + amount);
            addFactionXp(f, amount / 10);
        });
        }
    }

    // ============ PERSISTENCE ============

    private void saveFaction(Faction f) {
        synchronized (dbLock) {
        try (PreparedStatement ps = db.prepareStatement("""
            INSERT INTO factions (name, display_name, description, level, xp,
                total_kills, total_shards_earned, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?,
                COALESCE((SELECT created_at FROM factions WHERE name=?), ?))
            ON CONFLICT(name) DO UPDATE SET
                display_name=excluded.display_name, description=excluded.description,
                level=excluded.level, xp=excluded.xp,
                total_kills=excluded.total_kills, total_shards_earned=excluded.total_shards_earned
            """)) {
            ps.setString(1, f.name());
            ps.setString(2, f.displayName());
            ps.setString(3, f.description() != null ? f.description() : "");
            ps.setInt(4, f.level());
            ps.setLong(5, f.xp());
            ps.setLong(6, f.totalKills());
            ps.setLong(7, f.totalShardsEarned());
            ps.setString(8, f.name());
            ps.setLong(9, System.currentTimeMillis());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed saving faction: " + e.getMessage());
        }
        }
    }

    private void saveMember(String faction, UUID uuid, String name, Role role) {
        synchronized (dbLock) {
        try (PreparedStatement ps = db.prepareStatement(
                "INSERT OR REPLACE INTO faction_members (faction_name, uuid, player_name, role, joined_at, kills) VALUES (?, ?, ?, ?, COALESCE((SELECT joined_at FROM faction_members WHERE faction_name=? AND uuid=?), ?), COALESCE((SELECT kills FROM faction_members WHERE faction_name=? AND uuid=?), 0))")) {
            ps.setString(1, faction);
            ps.setString(2, uuid.toString());
            ps.setString(3, name);
            ps.setString(4, role.name());
            ps.setString(5, faction);
            ps.setString(6, uuid.toString());
            ps.setLong(7, System.currentTimeMillis());
            ps.setString(8, faction);
            ps.setString(9, uuid.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed saving member: " + e.getMessage());
        }
        }
    }

    private void removeMember(String faction, UUID uuid) {
        synchronized (dbLock) {
        try (PreparedStatement ps = db.prepareStatement("DELETE FROM faction_members WHERE faction_name=? AND uuid=?")) {
            ps.setString(1, faction);
            ps.setString(2, uuid.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed removing member: " + e.getMessage());
        }
        }
    }

    public void removePlayerFromFaction(UUID uuid) {
        synchronized (dbLock) {
            String fName = playerFaction.remove(uuid);
            if (fName == null) return;
            Faction f = factions.get(fName);
            if (f != null) {
                FactionMember m = findMember(f, uuid);
                if (m != null) f.members().remove(m);
            }
            removeMember(fName, uuid);
        }
    }

    // ============ UTILITY ============

    public void addPlayerToFaction(UUID playerUuid, String playerName, String factionName) {
        synchronized (dbLock) {
        Faction f = factions.get(factionName);
        if (f == null) return;
        FactionMember member = new FactionMember(playerUuid, playerName, Role.MEMBER, System.currentTimeMillis(), 0);
        f.members().add(member);
        playerFaction.put(playerUuid, factionName);
        saveMember(factionName, playerUuid, playerName, Role.MEMBER);
        }
    }

    public void handleFactionKill(Player killer) {
        synchronized (dbLock) {
        String fName = playerFaction.get(killer.getUniqueId());
        if (fName == null) return;
        Faction f = factions.get(fName);
        if (f == null) return;
        FactionMember m = findMember(f, killer.getUniqueId());
        if (m != null) {
            f.members().remove(m);
            f.members().add(new FactionMember(m.uuid(), m.playerName(), m.role(), m.joinedAt(), m.kills() + 1));
            f.setTotalKills(f.totalKills() + 1);
            addFactionXp(f, 25);
            saveMember(f.name(), killer.getUniqueId(), killer.getName(), m.role());
        }
        }
    }

    private FactionMember findMember(Faction f, UUID uuid) {
        for (FactionMember m : f.members()) {
            if (m.uuid().equals(uuid)) return m;
        }
        return null;
    }

    public void broadcastToFaction(Faction f, net.kyori.adventure.text.Component message) {
        for (FactionMember m : f.members()) {
            Player p = Bukkit.getPlayer(m.uuid());
            if (p != null && p.isOnline()) {
                p.sendMessage(message);
            }
        }
    }

    public List<String> factionNames() {
        return factions.values().stream()
                .sorted(Comparator.comparingInt(Faction::level).reversed())
                .map(Faction::name)
                .toList();
    }

    public boolean startWar(String factionA, String factionB, Player leader) {
        String key = warPairKey(factionA, factionB);
        if (activeWars.containsKey(key)) {
            leader.sendMessage(TextUtil.parse("<red>A war between these factions is already active!</red>"));
            return false;
        }
        long cooldown = warCooldowns.getOrDefault(key, 0L);
        if (System.currentTimeMillis() < cooldown) {
            long remaining = (cooldown - System.currentTimeMillis()) / 1000;
            leader.sendMessage(TextUtil.parse("<red>War is on cooldown! <yellow>" + remaining + "s</yellow> <red>remaining.</red>"));
            return false;
        }

        long duration = plugin.getConfig().getLong("faction.war-duration-seconds", 3600) * 1000L;
        long now = System.currentTimeMillis();
        FactionWar war = new FactionWar(factionA, factionB, now, now + duration);
        activeWars.put(key, war);

        Faction a = factions.get(factionA);
        Faction b = factions.get(factionB);
        if (a != null) broadcastToFaction(a, TextUtil.parse("<dark_red>\u2694 </dark_red><red>WAR has been declared against <white>" + factionB + "</white> for 1 hour!</red>"));
        if (b != null) broadcastToFaction(b, TextUtil.parse("<dark_red>\u2694 </dark_red><red>Your faction is at WAR with <white>" + factionA + "</white> for 1 hour!</red>"));

        Bukkit.getScheduler().runTaskLater(plugin, () -> endWar(key, war), duration / 50);
        return true;
    }

    public void endWar(String key, FactionWar war) {
        activeWars.remove(key);
        if (war.isTied()) {
            Faction a = factions.get(war.factionA());
            Faction b = factions.get(war.factionB());
            if (a != null) broadcastToFaction(a, TextUtil.parse("<yellow>\u2694 The war against <white>" + war.factionB() + "</white> ended in a TIE!</yellow>"));
            if (b != null) broadcastToFaction(b, TextUtil.parse("<yellow>\u2694 The war against <white>" + war.factionA() + "</white> ended in a TIE!</yellow>"));
            return;
        }
        String winner = war.winningFaction();
        String loser = war.opponent(winner);
        Faction wf = factions.get(winner);
        Faction lf = factions.get(loser);
        if (wf == null) return;

        int reward = plugin.getConfig().getInt("faction.war-reward-shards", 100);
        for (FactionMember m : wf.members()) {
            Player p = Bukkit.getPlayer(m.uuid());
            if (p != null && p.isOnline()) {
                plugin.getEconomyService().grantShards(p.getUniqueId(), reward, "war", UUID.randomUUID().toString());
                p.sendMessage(TextUtil.parse("<green>\u2714 Your faction won the war! +" + reward + " shards</green>"));
            }
        }
        if (wf != null) broadcastToFaction(wf, TextUtil.parse("<green>\u2694 Your faction defeated <white>" + loser + "</white> in the war!</green>"));
        if (lf != null) broadcastToFaction(lf, TextUtil.parse("<red>\u2694 Your faction lost the war against <white>" + winner + "</white></red>"));

        String winnerKey = warPairKey(winner, loser);
        warCooldowns.put(winnerKey, System.currentTimeMillis() + Duration.ofDays(7).toMillis());
    }

    public FactionWar getActiveWarFor(String factionName) {
        for (Map.Entry<String, FactionWar> e : activeWars.entrySet()) {
            if (e.getValue().involves(factionName) && e.getValue().isActive()) {
                return e.getValue();
            }
        }
        return null;
    }

    public boolean isAtWar(String factionName) {
        return getActiveWarFor(factionName) != null;
    }

    public void handleWarKill(Player killer) {
        String fName = playerFaction.get(killer.getUniqueId());
        if (fName == null) return;
        FactionWar war = getActiveWarFor(fName);
        if (war == null) return;
        war.addKill(fName);
        int bonus = plugin.getConfig().getInt("faction.war-kill-bonus", 5);
        plugin.getEconomyService().grantShards(killer.getUniqueId(), bonus, "war_kill", UUID.randomUUID().toString());
    }

    public long warCooldownRemaining(String factionA, String factionB) {
        Long cd = warCooldowns.get(warPairKey(factionA, factionB));
        if (cd == null) return 0;
        long rem = cd - System.currentTimeMillis();
        return rem < 0 ? 0 : rem;
    }

    private static String warPairKey(String a, String b) {
        return a.compareTo(b) < 0 ? a + ":" + b : b + ":" + a;
    }
}
