package lol.folium.unstable.faction;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;

public final class FactionListener implements Listener {

    private final UnstableRemixPlugin plugin;
    private final FactionManager factions;
    private final FactionSelectionManager selection;

    public FactionListener(UnstableRemixPlugin plugin, FactionManager factions, FactionSelectionManager selection) {
        this.plugin = plugin;
        this.factions = factions;
        this.selection = selection;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        factions.getFaction(player).ifPresent(f -> {
            player.displayName(TextUtil.parse(factions.getFaction(player).map(fac -> {
                var member = f.members().stream()
                        .filter(m -> m.uuid().equals(player.getUniqueId()))
                        .findFirst();
                String rankPrefix = member.map(m -> m.role() == Faction.Role.LEADER ? "\u00a76\u2605 " : m.role() == Faction.Role.COMMANDER ? "\u00a7b\u2726 " : "").orElse("");
                return rankPrefix + "[" + f.displayName() + "] " + player.getName();
            }).orElse(player.getName())));
            player.playerListName(TextUtil.parse("<gray>[" + f.displayName() + "]</gray> <white>" + player.getName() + "</white>"));
        });
    }

    @EventHandler
    public void onFactionChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (factions.isInFactionChat(player.getUniqueId())) {
            event.setCancelled(true);
            factions.factionChat(player, event.getMessage());
        }
    }

    @EventHandler
    public void onFactionSelectionClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!selection.isPlayerSelecting(player.getUniqueId())) return;
        event.setCancelled(true);
        selection.handleInventoryClick(player, event.getRawSlot());
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!selection.isPlayerSelecting(player.getUniqueId())) return;
        event.setCancelled(true);
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (!selection.isPlayerSelecting(player.getUniqueId())) return;

        Inventory closed = event.getInventory();
        Inventory current = player.getOpenInventory().getTopInventory();

        if (current == closed || current.getType() != org.bukkit.event.inventory.InventoryType.CHEST) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (player.isOnline() && selection.isPlayerSelecting(player.getUniqueId())) {
                    selection.openFactionGUI(player);
                }
            }, 1L);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        if (!selection.isPlayerLocked(event.getPlayer().getUniqueId())) return;
        if (event.getFrom().getBlockX() == event.getTo().getBlockX()
                && event.getFrom().getBlockY() == event.getTo().getBlockY()
                && event.getFrom().getBlockZ() == event.getTo().getBlockZ()) return;
        event.setTo(event.getFrom());
    }

    @EventHandler
    public void onPlayerDrop(PlayerDropItemEvent event) {
        if (selection.isPlayerLocked(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (selection.isPlayerLocked(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerSwapHands(PlayerSwapHandItemsEvent event) {
        if (selection.isPlayerLocked(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (selection.isPlayerLocked(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        if (selection.isPlayerLocked(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player player) {
            if (selection.isPlayerLocked(player.getUniqueId())) {
                event.setCancelled(true);
            }
        }
    }
}
