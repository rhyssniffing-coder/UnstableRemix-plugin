package lol.folium.unstable.util;

import net.kyori.adventure.text.Component;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class GuiTheme {

    public static final String PRIMARY_GRADIENT = "<gradient:#FF4444:#FF8800:#FFD700>";
    public static final String SECONDARY_GRADIENT = "<gradient:#FFD700:#FFA500>";
    public static final String ACCENT_GRADIENT = "<gradient:#FF8800:#FFD700>";
    public static final String HEADER_END = "</gradient>";

    private GuiTheme() {}

    public static String title(String text) {
        return PRIMARY_GRADIENT + "<bold>" + text + "</bold>" + HEADER_END;
    }

    public static String primary(String text) {
        return PRIMARY_GRADIENT + text + HEADER_END;
    }

    public static String secondary(String text) {
        return SECONDARY_GRADIENT + text + HEADER_END;
    }

    public static String sectionHeader(String text) {
        return SECONDARY_GRADIENT + "<bold>" + text + "</bold>" + HEADER_END;
    }

    public static String accent(String text) {
        return ACCENT_GRADIENT + text + HEADER_END;
    }

    public static String headerLine() {
        return "<dark_gray><strikethrough>                         </strikethrough></dark_gray>";
    }

    public static String separator() {
        return "  <dark_gray>\u2502</dark_gray>";
    }

    public static String iconBullet(String icon, String label, String value) {
        return "  " + icon + " <gray>" + label + "</gray> <dark_gray>\u2502</dark_gray> " + value;
    }

    public static ItemStack glassPane() {
        return ItemBuilder.of(org.bukkit.Material.GRAY_STAINED_GLASS_PANE)
                .name(Component.empty())
                .build();
    }

    public static ItemStack framePane() {
        return ItemBuilder.of(org.bukkit.Material.PURPLE_STAINED_GLASS_PANE)
                .name(Component.empty())
                .build();
    }

    public static ItemStack darkFramePane() {
        return ItemBuilder.of(org.bukkit.Material.BLACK_STAINED_GLASS_PANE)
                .name(Component.empty())
                .build();
    }

    public static void paintFrame(Inventory inventory, boolean usePurple) {
        int size = inventory.getSize();
        int rows = size / 9;
        for (int slot = 0; slot < size; slot++) {
            int row = slot / 9;
            int col = slot % 9;
            if (row == 0 || row == rows - 1 || col == 0 || col == 8) {
                inventory.setItem(slot, usePurple ? framePane() : darkFramePane());
            } else {
                inventory.setItem(slot, glassPane());
            }
        }
    }

    public static void paintDarkFrame(Inventory inventory) {
        int size = inventory.getSize();
        for (int i = 0; i < size; i++) {
            inventory.setItem(i, darkFramePane());
        }
    }

    public static String colorToHex(int color) {
        return String.format("#%06X", color & 0xFFFFFF);
    }

    public static String colorTag(int color) {
        return "#" + String.format("%06X", color & 0xFFFFFF);
    }
}
