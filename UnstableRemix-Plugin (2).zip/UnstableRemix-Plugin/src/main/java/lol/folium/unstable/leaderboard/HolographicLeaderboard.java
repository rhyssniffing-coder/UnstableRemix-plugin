package lol.folium.unstable.leaderboard;

import lol.folium.unstable.UnstableRemixPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class HolographicLeaderboard extends BukkitRunnable {

    private final UnstableRemixPlugin plugin;
    private final LeaderboardManager leaderboard;
    private final List<HologramDisplay> displays = new ArrayList<>();

    // Colors for ranks
    private static final String[] RANK_COLORS = {
            "#FFD700", // #1 Gold
            "#C0C0C0", // #2 Silver
            "#CD7F32", // #3 Bronze
            "#E8E8E8", // #4 White
            "#D4D4D4", // #5 Light gray
            "#BFBFBF", // #6 Gray
            "#AAAAAA", // #7 Gray
            "#949494", // #8 Dark gray
            "#808080", // #9 Darker gray
            "#6B6B6B"  // #10 Darkest gray
    };

    public HolographicLeaderboard(UnstableRemixPlugin plugin, LeaderboardManager leaderboard) {
        this.plugin = plugin;
        this.leaderboard = leaderboard;
        loadDisplays();
    }

    private void loadDisplays() {
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("leaderboard.holograms");
        if (section == null) return;

        for (String key : section.getKeys(false)) {
            ConfigurationSection display = section.getConfigurationSection(key);
            if (display == null) continue;

            String worldName = display.getString("world", "world");
            World world = Bukkit.getWorld(worldName);
            if (world == null) continue;

            double x = display.getDouble("x");
            double y = display.getDouble("y");
            double z = display.getDouble("z");
            float yaw = (float) display.getDouble("yaw", 0);
            String categoryStr = display.getString("category", "KILLS");
            int topCount = display.getInt("top-count", 10);

            try {
                LeaderboardManager.Category category = LeaderboardManager.Category.valueOf(categoryStr.toUpperCase());
                Location loc = new Location(world, x, y, z, yaw, 0);
                displays.add(new HologramDisplay(key, loc, category, topCount));
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Invalid leaderboard category: " + categoryStr);
            }
        }
    }

    public void start() {
        runTaskTimerAsynchronously(plugin, 0L, 600L); // Update every 30 seconds
    }

    @Override
    public void run() {
        leaderboard.refresh();
        for (HologramDisplay display : displays) {
            display.update(leaderboard);
        }
    }

    public void spawnAll() {
        for (HologramDisplay display : displays) {
            display.spawn(leaderboard);
        }
    }

    public void removeAll() {
        for (HologramDisplay display : displays) {
            display.remove();
        }
    }

    public void addDisplay(String name, Location loc, LeaderboardManager.Category category, int topCount) {
        displays.add(new HologramDisplay(name, loc.clone(), category, topCount));
        saveDisplays();
    }

    public void removeDisplay(String name) {
        displays.removeIf(d -> {
            if (d.name.equals(name)) {
                d.remove();
                return true;
            }
            return false;
        });
        saveDisplays();
    }

    public List<String> getDisplayNames() {
        List<String> names = new ArrayList<>();
        for (HologramDisplay d : displays) {
            names.add(d.name);
        }
        return names;
    }

    private void saveDisplays() {
        plugin.getConfig().set("leaderboard.holograms", null);
        for (HologramDisplay display : displays) {
            String path = "leaderboard.holograms." + display.name;
            plugin.getConfig().set(path + ".world", display.location.getWorld().getName());
            plugin.getConfig().set(path + ".x", display.location.getX());
            plugin.getConfig().set(path + ".y", display.location.getY());
            plugin.getConfig().set(path + ".z", display.location.getZ());
            plugin.getConfig().set(path + ".yaw", (double) display.location.getYaw());
            plugin.getConfig().set(path + ".category", display.category.name());
            plugin.getConfig().set(path + ".top-count", display.topCount);
        }
        plugin.saveConfig();
    }

    public static class HologramDisplay {
        private final String name;
        private final Location location;
        private final LeaderboardManager.Category category;
        private final int topCount;
        private final List<ArmorStand> armorStands = new ArrayList<>();
        private boolean spawned = false;

        public HologramDisplay(String name, Location location, LeaderboardManager.Category category, int topCount) {
            this.name = name;
            this.location = location;
            this.category = category;
            this.topCount = topCount;
        }

        public void spawn(LeaderboardManager leaderboard) {
            remove();
            update(leaderboard);
            spawned = true;
        }

        public void remove() {
            for (ArmorStand stand : armorStands) {
                if (stand != null && !stand.isDead()) {
                    stand.remove();
                }
            }
            armorStands.clear();
            spawned = false;
        }

        public void update(LeaderboardManager leaderboard) {
            if (location.getWorld() == null) return;

            // Remove old stands
            for (ArmorStand stand : armorStands) {
                if (stand != null && !stand.isDead()) {
                    stand.remove();
                }
            }
            armorStands.clear();

            LeaderboardManager.LeaderboardSnapshot snapshot = leaderboard.getSnapshot();
            if (snapshot == null) return;

            List<LeaderboardManager.LeaderboardEntry> entries = snapshot.entries.getOrDefault(category, Collections.emptyList());

            double baseY = location.getY();
            double spacing = 0.3;

            // Title line
            armorStands.add(createHologramLine(location.clone().add(0, baseY + (topCount + 2) * spacing, 0),
                    componentToString(buildTitle(category))));

            // Subtitle "RANKING"
            armorStands.add(createHologramLine(location.clone().add(0, baseY + (topCount + 1) * spacing, 0),
                    componentToString(buildSubtitle())));

            // Entries
            for (int i = 0; i < Math.min(entries.size(), topCount); i++) {
                LeaderboardManager.LeaderboardEntry entry = entries.get(i);
                String playerName = leaderboard.resolveName(entry.uuid);
                String value = leaderboard.formatValue(category, entry.value);

                Component line = buildEntryLine(i + 1, playerName, value);
                armorStands.add(createHologramLine(
                        location.clone().add(0, baseY + (topCount - i) * spacing, 0),
                        componentToString(line)));
            }

            // Player's rank line at bottom
            String playerPath = location.getWorld().getName() + "," +
                    (int) location.getX() + "," +
                    (int) location.getY() + "," +
                    (int) location.getZ();
        }

        private Component buildTitle(LeaderboardManager.Category category) {
            return Component.text()
                    .append(Component.text(category.displayName.toUpperCase() + " LEADERBOARD", NamedTextColor.GOLD, TextDecoration.BOLD))
                    .build();
        }

        private Component buildSubtitle() {
            return Component.text()
                    .append(Component.text("RANKING", NamedTextColor.GRAY))
                    .build();
        }

        private Component buildEntryLine(int rank, String playerName, String value) {
            String color = rank <= RANK_COLORS.length ? RANK_COLORS[rank - 1] : "#6B6B6B";
            net.kyori.adventure.text.format.TextColor rankColor = net.kyori.adventure.text.format.TextColor.color(
                    Integer.parseInt(color.substring(1, 3), 16),
                    Integer.parseInt(color.substring(3, 5), 16),
                    Integer.parseInt(color.substring(5, 7), 16));

            Component rankComp = Component.text("#" + rank, rankColor, TextDecoration.BOLD);
            Component nameComp;
            if (rank == 1) {
                nameComp = Component.text(" " + playerName + " ", NamedTextColor.GOLD, TextDecoration.BOLD);
            } else if (rank == 2) {
                nameComp = Component.text(" " + playerName + " ", NamedTextColor.WHITE, TextDecoration.BOLD);
            } else if (rank == 3) {
                nameComp = Component.text(" " + playerName + " ", net.kyori.adventure.text.format.TextColor.color(0xCD, 0x7F, 0x32), TextDecoration.BOLD);
            } else {
                nameComp = Component.text(" " + playerName + " ", NamedTextColor.GRAY);
            }
            Component dash = Component.text(" \u2502 ", NamedTextColor.DARK_GRAY);
            Component valueComp = Component.text(value, NamedTextColor.YELLOW, TextDecoration.BOLD);

            return Component.text()
                    .append(rankComp)
                    .append(nameComp)
                    .append(dash)
                    .append(valueComp)
                    .build();
        }

        private ArmorStand createHologramLine(Location loc, Component text) {
            ArmorStand stand = (ArmorStand) loc.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);
            stand.setCustomNameVisible(true);
            stand.customName(text);
            stand.setVisible(false);
            stand.setMarker(true);
            stand.setGravity(false);
            stand.setSmall(true);
            stand.setBasePlate(false);
            stand.setArms(false);
            stand.setInvulnerable(true);
            stand.setPersistent(false);
            stand.setRemoveWhenFarAway(false);
            return stand;
        }

        private Component componentToString(Component component) {
            return component;
        }
    }
}
