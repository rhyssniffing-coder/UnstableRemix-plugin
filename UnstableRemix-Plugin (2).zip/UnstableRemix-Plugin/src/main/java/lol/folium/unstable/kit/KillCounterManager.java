package lol.folium.unstable.kit;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public final class KillCounterManager {

    private static final String KILL_TAG = "unstable_kill_counter";

    private final UnstableRemixPlugin plugin;

    public KillCounterManager(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    public void handleKill(Player killer, Player victim) {
        ConfigurationSection cfg = plugin.getConfig().getConfigurationSection("kill-counter");
        if (cfg == null || !cfg.getBoolean("enabled", true)) {
            return;
        }
        List<String> allowedTypes = cfg.getStringList("allowed-item-types");
        ItemStack held = killer.getInventory().getItemInMainHand();
        if (held == null || held.getType() == Material.AIR) {
            return;
        }
        if (!allowedTypes.isEmpty()) {
            boolean match = false;
            for (String type : allowedTypes) {
                if (held.getType().name().endsWith(type.toUpperCase())) {
                    match = true;
                    break;
                }
            }
            if (!match) return;
        }
        ItemMeta meta = held.getItemMeta();
        if (meta == null) return;
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        int kills = pdc.getOrDefault(
                new org.bukkit.NamespacedKey(plugin, KILL_TAG),
                PersistentDataType.INTEGER, 0);
        pdc.set(new org.bukkit.NamespacedKey(plugin, KILL_TAG),
                PersistentDataType.INTEGER, kills + 1);
        held.setItemMeta(meta);
        updateLore(held, kills + 1, cfg);
    }

    private void updateLore(ItemStack item, int kills, ConfigurationSection cfg) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;
        String format = cfg.getString("lore-format", "<gray>Kills: <white>{kills}</white>");
        int loreLine = cfg.getInt("lore-line", 0);
        boolean prepend = cfg.getBoolean("prepend", true);
        Component killLore = TextUtil.parse(format.replace("{kills}", String.valueOf(kills)));
        List<Component> lore = meta.lore();
        if (lore == null) lore = new ArrayList<>();
        if (loreLine < lore.size()) {
            lore.set(loreLine, killLore);
        } else {
            if (prepend) {
                lore.addFirst(killLore);
            } else {
                lore.add(killLore);
            }
        }
        meta.lore(lore);
        item.setItemMeta(meta);
    }
}