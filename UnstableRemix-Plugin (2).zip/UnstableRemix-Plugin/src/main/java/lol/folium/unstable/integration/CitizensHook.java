package lol.folium.unstable.integration;

import lol.folium.unstable.UnstableRemixPlugin;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.plugin.EventExecutor;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

public final class CitizensHook {

    private final UnstableRemixPlugin plugin;
    private final boolean available;
    private final Map<Integer, String> npcArenaMap = new ConcurrentHashMap<>();

    public CitizensHook(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
        this.available = plugin.getServer().getPluginManager().getPlugin("Citizens") != null;
        loadNpcMap();
        if (available) {
            registerNpcClickListener();
        }
    }

    private void loadNpcMap() {
        var section = plugin.getConfig().getConfigurationSection("arena-npcs");
        if (section == null) return;
        for (String arenaName : section.getKeys(false)) {
            int npcId = section.getInt(arenaName + ".npc-id", -1);
            if (npcId >= 0) npcArenaMap.put(npcId, arenaName);
        }
    }

    public String getArenaForNpc(int npcId) {
        return npcArenaMap.get(npcId);
    }

    public boolean isAvailable() {
        return available;
    }

    public int getNpcId(Entity entity) {
        if (!available) return -1;
        try {
            Object registry = Class.forName("net.citizensnpcs.api.CitizensAPI")
                    .getMethod("getNPCRegistry").invoke(null);
            Object npc = registry.getClass()
                    .getMethod("getNPC", Entity.class)
                    .invoke(registry, entity);
            if (npc == null) return -1;
            return (int) Class.forName("net.citizensnpcs.api.npc.NPC")
                    .getMethod("getId").invoke(npc);
        } catch (Exception e) {
            return -1;
        }
    }

    private void registerNpcClickListener() {
        try {
            Class<?> npcClickEventClass = Class.forName("net.citizensnpcs.api.event.NPCRightClickEvent");
            Class<?> npcClass = Class.forName("net.citizensnpcs.api.npc.NPC");

            // Register a listener for NPCRightClickEvent via reflection
            plugin.getServer().getPluginManager().registerEvent(
                    (Class<Listener>) npcClickEventClass.asSubclass(Listener.class),
                    new Listener() {},
                    org.bukkit.event.EventPriority.NORMAL,
                    (listener, event) -> {
                        if (!npcClickEventClass.isInstance(event)) return;
                        try {
                            Object npc = npcClickEventClass.getMethod("getNPC").invoke(event);
                            int npcId = (int) npcClass.getMethod("getId").invoke(npc);
                            Player player = (Player) npcClickEventClass.getMethod("getClicker").invoke(event);
                            String arenaName = npcArenaMap.get(npcId);
                            if (arenaName != null) {
                                plugin.getServer().getScheduler().runTask(plugin, () -> {
                                    handleNpcClick(player, arenaName);
                                });
                            }
                        } catch (Exception e) {
                            plugin.getLogger().log(Level.WARNING, "NPCRightClickEvent handling failed", e);
                        }
                    },
                    plugin
            );
            plugin.getLogger().info("Registered Citizens NPCRightClickEvent listener.");
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Failed to register NPCRightClickEvent listener, falling back to PlayerInteractEntityEvent", e);
        }
    }

    private void handleNpcClick(Player player, String arenaName) {
        plugin.getLogger().info("NPC clicked: " + arenaName + " by " + player.getName());
    }

    public void setNpcClickHandler(NpcClickHandler handler) {
        this.npcClickHandler = handler;
    }

    public interface NpcClickHandler {
        void onNpcClick(Player player, String arenaName);
    }

    private NpcClickHandler npcClickHandler;

    public boolean spawnArenaNpc(Player player, String arenaName, String skinName) {
        if (!available) {
            return false;
        }
        try {
            Class<?> citizensAPI = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensAPI.getMethod("getNPCRegistry").invoke(null);
            Class<?> npcClass = Class.forName("net.citizensnpcs.api.npc.NPC");
            Object npc = registry.getClass().getMethod("createNPC", org.bukkit.entity.EntityType.class, String.class)
                    .invoke(registry, org.bukkit.entity.EntityType.PLAYER, arenaName);
            npcClass.getMethod("spawn", org.bukkit.Location.class).invoke(npc, player.getLocation());
            npcClass.getMethod("setName", String.class).invoke(npc, "<aqua>" + arenaName);
            Object data = npcClass.getMethod("getOrAddTrait", Class.class)
                    .invoke(npc, Class.forName("net.citizensnpcs.trait.SkinTrait"));
            data.getClass().getMethod("setSkinName", String.class).invoke(data, skinName);
            plugin.getConfig().set("arena-npcs." + arenaName + ".npc-id", npcClass.getMethod("getId").invoke(npc));
            plugin.saveConfig();
            int id = (int) npcClass.getMethod("getId").invoke(npc);
            npcArenaMap.put(id, arenaName);
            return true;
        } catch (ReflectiveOperationException ex) {
            plugin.getLogger().warning("Citizens NPC spawn failed: " + ex.getMessage());
            return false;
        }
    }
}
