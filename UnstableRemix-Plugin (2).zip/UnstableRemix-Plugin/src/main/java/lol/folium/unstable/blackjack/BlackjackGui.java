package lol.folium.unstable.blackjack;

import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class BlackjackGui {

    private static final Component TITLE = TextUtil.parse("<gradient:#1a472a:#2d6a4f><bold>Blackjack</bold></gradient>");

    private BlackjackGui() {}

    public static Component getTitle() {
        return TITLE;
    }

    public static void open(Player player, BlackjackGame game) {
        Inventory inv = Bukkit.createInventory(null, 54, TITLE);

        fillBackground(inv);
        renderDealerHand(inv, game);
        renderPlayerHand(inv, game);
        renderActions(inv, game);
        renderInfo(inv, game);

        player.openInventory(inv);
    }

    private static void fillBackground(Inventory inv) {
        ItemStack green = ItemBuilder.of(Material.GREEN_STAINED_GLASS_PANE)
                .name(Component.empty()).build();
        ItemStack dark = ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE)
                .name(Component.empty()).build();

        for (int i = 0; i < 54; i++) {
            inv.setItem(i, (i < 9 || i > 44) ? dark : green);
        }
    }

    private static void renderDealerHand(Inventory inv, BlackjackGame game) {
        boolean hidden = game.state() == BlackjackGame.State.PLAYER_TURN;
        inv.setItem(2, createItem(Material.BOOK, "<gold><bold>Dealer's Hand</bold></gold>",
                List.of("<gray>Value: " + (hidden ? "?" : game.dealerHand().value()) + "</gray>")));

        List<Card> cards = game.dealerHand().cards();
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 17, 18};

        if (hidden && cards.size() >= 2) {
            inv.setItem(slots[0], cardToItem(cards.get(0)));
            inv.setItem(slots[1], createItem(Material.RED_STAINED_GLASS_PANE, "<red><bold>?</bold></red>",
                    List.of("<dark_gray>Face down card</dark_gray>")));
            for (int i = 2; i < cards.size() && i < slots.length; i++) {
                inv.setItem(slots[i], cardToItem(cards.get(i)));
            }
        } else {
            for (int i = 0; i < cards.size() && i < slots.length; i++) {
                inv.setItem(slots[i], cardToItem(cards.get(i)));
            }
        }
    }

    private static void renderPlayerHand(Inventory inv, BlackjackGame game) {
        inv.setItem(39, createItem(Material.BOOK, "<green><bold>Your Hand</bold></green>",
                List.of("<gray>Value: " + game.playerHand().value() + "</gray>",
                        game.playerHand().isSoft() ? "<yellow>Soft hand</yellow>" : "<gray>Hard hand</gray>")));

        List<Card> cards = game.playerHand().cards();
        int[] slots = {28, 29, 30, 31, 32, 33, 34, 35, 36};
        for (int i = 0; i < cards.size() && i < slots.length; i++) {
            inv.setItem(slots[i], cardToItem(cards.get(i)));
        }
    }

    private static void renderActions(Inventory inv, BlackjackGame game) {
        BlackjackGame.State state = game.state();

        if (state == BlackjackGame.State.PLAYER_TURN) {
            inv.setItem(40, createItem(Material.LIME_WOOL, "<green><bold>HIT</bold></green>",
                    List.of("<gray>Draw another card</gray>")));
            inv.setItem(41, createItem(Material.RED_WOOL, "<red><bold>STAND</bold></red>",
                    List.of("<gray>Keep your current hand</gray>")));
            if (game.playerHand().size() == 2) {
                inv.setItem(42, createItem(Material.YELLOW_WOOL, "<yellow><bold>DOUBLE DOWN</bold></yellow>",
                        List.of("<gray>Double your bet, draw one card</gray>",
                                "<gray>Cost: " + game.bet() + " shards</gray>")));
            }
        } else if (state == BlackjackGame.State.RESOLVED) {
            inv.setItem(40, createItem(Material.LIME_WOOL, "<green><bold>PLAY AGAIN</bold></green>",
                    List.of("<gray>Start a new game</gray>")));
            inv.setItem(41, createItem(Material.BARRIER, "<red><bold>QUIT</bold></red>",
                    List.of("<gray>Close the table</gray>")));
        }
    }

    private static void renderInfo(Inventory inv, BlackjackGame game) {
        if (game.state() == BlackjackGame.State.RESOLVED && game.result() != null) {
            String resultText = switch (game.result()) {
                case PLAYER_BLACKJACK -> "<gold><bold>BLACKJACK!</bold></gold> <gray>Payout: " + (game.bet() + game.bet() * 3 / 2) + "</gray>";
                case PLAYER_WIN -> "<green><bold>YOU WIN!</bold></green> <gray>Payout: " + (game.bet() * 2) + "</gray>";
                case PLAYER_BUST -> "<red><bold>BUST!</bold></red> <gray>You lost " + game.bet() + " shards</gray>";
                case DEALER_WIN -> "<red><bold>DEALER WINS</bold></red> <gray>You lost " + game.bet() + " shards</gray>";
                case DEALER_BLACKJACK -> "<red><bold>DEALER BLACKJACK!</bold></red> <gray>You lost " + game.bet() + " shards</gray>";
                case PUSH -> "<yellow><bold>PUSH</bold></yellow> <gray>Your bet has been returned</gray>";
            };
            inv.setItem(4, createItem(Material.NETHERITE_INGOT, "<gold><bold>Result</bold></gold>", List.of(resultText)));
        } else {
            inv.setItem(4, createItem(Material.NETHERITE_INGOT, "<gold><bold>Current Bet</bold></gold>",
                    List.of("<gray>" + game.bet() + " shards</gray>")));
        }
    }

    public static void handleClick(InventoryClickEvent event, Player player, BlackjackGame game) {
        event.setCancelled(true);
        int slot = event.getRawSlot();

        if (game.state() == BlackjackGame.State.PLAYER_TURN) {
            switch (slot) {
                case 40 -> {
                    game.hit();
                    if (game.state() == BlackjackGame.State.RESOLVED) {
                        handleResult(player, game);
                    } else {
                        open(player, game);
                    }
                }
                case 41 -> {
                    game.stand();
                    handleResult(player, game);
                }
                case 42 -> {
                    if (game.doubleDown()) {
                        if (game.state() == BlackjackGame.State.RESOLVED) {
                            handleResult(player, game);
                        } else {
                            open(player, game);
                        }
                    } else {
                        player.sendMessage(TextUtil.parse("<red>Not enough shards to double down!"));
                        open(player, game);
                    }
                }
            }
        } else if (game.state() == BlackjackGame.State.RESOLVED) {
            if (slot == 40) {
                BlackjackGame.removeActive(player.getUniqueId());
                BlackjackGame newGame = new BlackjackGame(player.getUniqueId(), game.economy());
                BlackjackGame.getActive(player.getUniqueId());
                open(player, newGame);
            } else if (slot == 41) {
                BlackjackGame.removeActive(player.getUniqueId());
                player.closeInventory();
            }
        }
    }

    private static void handleResult(Player player, BlackjackGame game) {
        String msg = switch (game.result()) {
            case PLAYER_BLACKJACK -> "<gold><bold>BLACKJACK!</bold></gold> <gray>You won " + (game.bet() + game.bet() * 3 / 2) + " shards!</gray>";
            case PLAYER_WIN -> "<green><bold>YOU WIN!</bold></green> <gray>You won " + (game.bet() * 2) + " shards!</gray>";
            case PLAYER_BUST -> "<red><bold>BUST!</bold></red> <gray>You lost " + game.bet() + " shards.</gray>";
            case DEALER_WIN -> "<red><bold>DEALER WINS</bold></red> <gray>You lost " + game.bet() + " shards.</gray>";
            case DEALER_BLACKJACK -> "<red><bold>DEALER BLACKJACK!</bold></red> <gray>You lost " + game.bet() + " shards.</gray>";
            case PUSH -> "<yellow><bold>PUSH</bold></yellow> <gray>Bet returned.</gray>";
        };
        player.sendMessage(TextUtil.parse(msg));
        open(player, game);
    }

    private static ItemStack cardToItem(Card card) {
        return createItem(Material.PAPER, "<white><bold>" + card.shortDisplay() + "</bold></white>",
                List.of(card.suit().color() + card.suit().symbol() + " " + card.rank().display(),
                        "<gray>Value: " + card.value() + "</gray>"));
    }

    private static ItemStack createItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(TextUtil.parse(name));
        List<Component> loreComponents = new ArrayList<>();
        for (String line : lore) {
            loreComponents.add(TextUtil.parse(line));
        }
        meta.lore(loreComponents);
        item.setItemMeta(meta);
        return item;
    }
}
