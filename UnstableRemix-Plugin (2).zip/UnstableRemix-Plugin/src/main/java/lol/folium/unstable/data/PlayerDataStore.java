package lol.folium.unstable.data;

import lol.folium.unstable.UnstableRemixPlugin;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class PlayerDataStore implements AutoCloseable {

    private final UnstableRemixPlugin plugin;
    private final Map<UUID, PlayerProfile> cache = new ConcurrentHashMap<>();
    private final Map<String, Set<String>> setCache = new ConcurrentHashMap<>();
    private final ExecutorService dbExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "UnstableRemix-DB");
        t.setDaemon(true);
        return t;
    });
    private Connection connection;

    public PlayerDataStore(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    public void init() throws SQLException {
        File file = new File(plugin.getDataFolder(), "players.db");
        connection = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
        try (Statement statement = connection.createStatement()) {
            statement.execute("""
                CREATE TABLE IF NOT EXISTS profiles (
                    uuid TEXT PRIMARY KEY,
                    shards INTEGER NOT NULL DEFAULT 0,
                    tokens INTEGER NOT NULL DEFAULT 0,
                    daily_rerolls INTEGER NOT NULL DEFAULT 0,
                    weekly_rerolls INTEGER NOT NULL DEFAULT 0,
                    monthly_rerolls INTEGER NOT NULL DEFAULT 0,
                    milestone_rerolls INTEGER NOT NULL DEFAULT 0,
                    lifetime_kills INTEGER NOT NULL DEFAULT 0,
                    lifetime_trackdowns INTEGER NOT NULL DEFAULT 0,
                    match_wins INTEGER NOT NULL DEFAULT 0
                )
                """);
            statement.execute("""
                CREATE TABLE IF NOT EXISTS profile_sets (
                    uuid TEXT NOT NULL,
                    category TEXT NOT NULL,
                    value TEXT NOT NULL,
                    PRIMARY KEY (uuid, category, value)
                )
                """);
            statement.execute("""
                CREATE TABLE IF NOT EXISTS idempotency (
                    key TEXT PRIMARY KEY,
                    created_at INTEGER NOT NULL
                )
                """);
            statement.execute("""
                CREATE TABLE IF NOT EXISTS quest_progress (
                    uuid TEXT NOT NULL,
                    tier TEXT NOT NULL,
                    quest_id TEXT NOT NULL,
                    progress INTEGER NOT NULL DEFAULT 0,
                    assigned_at INTEGER NOT NULL,
                    PRIMARY KEY (uuid, tier)
                )
                """);
        }
        ensureColumn("profiles", "monthly_rerolls", "INTEGER NOT NULL DEFAULT 0");
        ensureColumn("profiles", "prestige_rank", "INTEGER NOT NULL DEFAULT 0");
        ensureColumn("profiles", "total_shards_earned", "INTEGER NOT NULL DEFAULT 0");
        ensureColumn("profiles", "login_streak", "INTEGER NOT NULL DEFAULT 0");
        ensureColumn("profiles", "last_login_date", "TEXT");
        ensureColumn("profiles", "vault_tier", "INTEGER NOT NULL DEFAULT 0");
        ensureColumn("profiles", "deaths", "INTEGER NOT NULL DEFAULT 0");
        ensureColumn("profiles", "highest_killstreak", "INTEGER NOT NULL DEFAULT 0");
        ensureColumn("profiles", "playtime", "INTEGER NOT NULL DEFAULT 0");
        ensureColumn("profiles", "last_seen", "INTEGER NOT NULL DEFAULT 0");
        ensureColumn("profiles", "social_follow_claimed", "INTEGER NOT NULL DEFAULT 0");
        ensureColumn("profiles", "social_discord_claimed", "INTEGER NOT NULL DEFAULT 0");
    }

    public PlayerProfile get(UUID uuid) {
        return cache.computeIfAbsent(uuid, this::loadProfile);
    }

    public void unload(UUID uuid) {
        PlayerProfile profile = cache.remove(uuid);
        if (profile != null) {
            saveProfile(profile);
        }
    }

    public boolean tryClaimIdempotency(String key) {
        try (PreparedStatement ps = connection.prepareStatement(
                "INSERT OR IGNORE INTO idempotency (key, created_at) VALUES (?, ?)")) {
            ps.setString(1, key);
            ps.setLong(2, System.currentTimeMillis());
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            plugin.getLogger().severe("Idempotency insert failed: " + e.getMessage());
            return false;
        }
    }

    public void saveProfile(PlayerProfile profile) {
        dbExecutor.execute(() -> doSaveProfile(profile));
    }

    private void doSaveProfile(PlayerProfile profile) {
        try (PreparedStatement ps = connection.prepareStatement("""
            INSERT INTO profiles (uuid, shards, tokens, daily_rerolls, weekly_rerolls, monthly_rerolls, milestone_rerolls,
                lifetime_kills, lifetime_trackdowns, match_wins, prestige_rank, total_shards_earned,
                login_streak, last_login_date, vault_tier, deaths, highest_killstreak, playtime, last_seen,
                social_follow_claimed, social_discord_claimed)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(uuid) DO UPDATE SET
                shards=excluded.shards,
                tokens=excluded.tokens,
                daily_rerolls=excluded.daily_rerolls,
                weekly_rerolls=excluded.weekly_rerolls,
                monthly_rerolls=excluded.monthly_rerolls,
                milestone_rerolls=excluded.milestone_rerolls,
                lifetime_kills=excluded.lifetime_kills,
                lifetime_trackdowns=excluded.lifetime_trackdowns,
                match_wins=excluded.match_wins,
                prestige_rank=excluded.prestige_rank,
                total_shards_earned=excluded.total_shards_earned,
                login_streak=excluded.login_streak,
                last_login_date=excluded.last_login_date,
                vault_tier=excluded.vault_tier,
                deaths=excluded.deaths,
                highest_killstreak=excluded.highest_killstreak,
                playtime=excluded.playtime,
                last_seen=excluded.last_seen,
                social_follow_claimed=excluded.social_follow_claimed,
                social_discord_claimed=excluded.social_discord_claimed
            """)) {
            ps.setString(1, profile.uuid().toString());
            ps.setLong(2, profile.shards());
            ps.setLong(3, profile.tokens());
            ps.setInt(4, profile.dailyRerolls());
            ps.setInt(5, profile.weeklyRerolls());
            ps.setInt(6, profile.monthlyRerolls());
            ps.setInt(7, profile.milestoneRerolls());
            ps.setLong(8, profile.lifetimeKills());
            ps.setLong(9, profile.lifetimeTrackdowns());
            ps.setLong(10, profile.matchWins());
            ps.setInt(11, profile.prestigeRank());
            ps.setLong(12, profile.totalShardsEarned());
            ps.setInt(13, profile.loginStreak());
            ps.setString(14, profile.lastLoginDate());
            ps.setInt(15, profile.vaultTier());
            ps.setLong(16, profile.deaths());
            ps.setLong(17, profile.highestKillstreak());
            ps.setLong(18, profile.playtime());
            ps.setLong(19, profile.lastSeen());
            ps.setInt(20, profile.socialFollowClaimed() ? 1 : 0);
            ps.setInt(21, profile.socialDiscordClaimed() ? 1 : 0);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed saving profile " + profile.uuid() + ": " + e.getMessage());
        }
        doSaveSet(profile.uuid(), "unlocked_effects", profile.unlockedEffects());
        doSaveSet(profile.uuid(), "enabled_effects", profile.enabledEffects());
        doSaveSet(profile.uuid(), "claimed_token_ranks", profile.claimedTokenRanks());
        doSaveSet(profile.uuid(), "claimed_quests", profile.claimedQuests());
    }

    public int getQuestProgress(UUID uuid, String tier) {
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT progress FROM quest_progress WHERE uuid=? AND tier=?")) {
            ps.setString(1, uuid.toString());
            ps.setString(2, tier);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt("progress") : 0;
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed reading quest progress: " + e.getMessage());
            return 0;
        }
    }

    public String getAssignedQuest(UUID uuid, String tier) {
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT quest_id FROM quest_progress WHERE uuid=? AND tier=?")) {
            ps.setString(1, uuid.toString());
            ps.setString(2, tier);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString("quest_id") : null;
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed reading assigned quest: " + e.getMessage());
            return null;
        }
    }

    public Set<String> getSet(UUID uuid, String category) {
        String key = uuid + ":" + category;
        Set<String> cached = setCache.get(key);
        if (cached != null) return cached;
        Set<String> values = ConcurrentHashMap.newKeySet();
        loadSet(uuid, category, values);
        setCache.put(key, values);
        return values;
    }

    public boolean hasSetValue(UUID uuid, String category, String value) {
        String key = uuid + ":" + category;
        Set<String> cached = setCache.get(key);
        if (cached != null) return cached.contains(value);
        Set<String> values = ConcurrentHashMap.newKeySet();
        loadSet(uuid, category, values);
        setCache.put(key, values);
        return values.contains(value);
    }

    public void addSetValue(UUID uuid, String category, String value) {
        try (PreparedStatement ps = connection.prepareStatement(
                "INSERT OR IGNORE INTO profile_sets (uuid, category, value) VALUES (?, ?, ?)")) {
            ps.setString(1, uuid.toString());
            ps.setString(2, category);
            ps.setString(3, value);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed adding set value: " + e.getMessage());
        }
        String key = uuid + ":" + category;
        Set<String> cached = setCache.get(key);
        if (cached != null) cached.add(value);
    }

    public void replaceSet(UUID uuid, String category, Set<String> values) {
        saveSet(uuid, category, values);
        String key = uuid + ":" + category;
        Set<String> fresh = ConcurrentHashMap.newKeySet();
        fresh.addAll(values);
        setCache.put(key, fresh);
    }

    public long getQuestAssignedAt(UUID uuid, String tier) {
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT assigned_at FROM quest_progress WHERE uuid=? AND tier=?")) {
            ps.setString(1, uuid.toString());
            ps.setString(2, tier);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong("assigned_at") : 0L;
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed reading quest assigned_at: " + e.getMessage());
            return 0L;
        }
    }

    public void setQuestAssignment(UUID uuid, String tier, String questId, int progress) {
        try (PreparedStatement ps = connection.prepareStatement("""
            INSERT INTO quest_progress (uuid, tier, quest_id, progress, assigned_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(uuid, tier) DO UPDATE SET quest_id=excluded.quest_id, progress=excluded.progress, assigned_at=excluded.assigned_at
            """)) {
            ps.setString(1, uuid.toString());
            ps.setString(2, tier);
            ps.setString(3, questId);
            ps.setInt(4, progress);
            ps.setLong(5, System.currentTimeMillis());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Quest assignment failed: " + e.getMessage());
        }
    }

    public void setQuestProgress(UUID uuid, String tier, int progress) {
        try (PreparedStatement ps = connection.prepareStatement(
                "UPDATE quest_progress SET progress=? WHERE uuid=? AND tier=?")) {
            ps.setInt(1, progress);
            ps.setString(2, uuid.toString());
            ps.setString(3, tier);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Quest progress update failed: " + e.getMessage());
        }
    }

    public void clearQuestAssignment(UUID uuid, String tier) {
        try (PreparedStatement ps = connection.prepareStatement(
                "DELETE FROM quest_progress WHERE uuid=? AND tier=?")) {
            ps.setString(1, uuid.toString());
            ps.setString(2, tier);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Quest clear failed: " + e.getMessage());
        }
    }

    private PlayerProfile loadProfile(UUID uuid) {
        PlayerProfile profile = new PlayerProfile(uuid);
        try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM profiles WHERE uuid=?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    profile.setShards(rs.getLong("shards"));
                    profile.setTokens(rs.getLong("tokens"));
                    profile.setDailyRerolls(rs.getInt("daily_rerolls"));
                    profile.setWeeklyRerolls(rs.getInt("weekly_rerolls"));
                    profile.setMonthlyRerolls(rs.getInt("monthly_rerolls"));
                    profile.setMilestoneRerolls(rs.getInt("milestone_rerolls"));
                    profile.setLifetimeKills(rs.getLong("lifetime_kills"));
                    profile.setLifetimeTrackdowns(rs.getLong("lifetime_trackdowns"));
                    profile.setMatchWins(rs.getLong("match_wins"));
                    profile.setPrestigeRank(rs.getInt("prestige_rank"));
                    profile.setTotalShardsEarned(rs.getLong("total_shards_earned"));
                    profile.setLoginStreak(rs.getInt("login_streak"));
                    profile.setLastLoginDate(rs.getString("last_login_date"));
                    profile.setVaultTier(rs.getInt("vault_tier"));
                    profile.setDeaths(rs.getLong("deaths"));
                    profile.setHighestKillstreak(rs.getLong("highest_killstreak"));
                    profile.setPlaytime(rs.getLong("playtime"));
                    profile.setLastSeen(rs.getLong("last_seen"));
                    profile.setSocialFollowClaimed(rs.getInt("social_follow_claimed") == 1);
                    profile.setSocialDiscordClaimed(rs.getInt("social_discord_claimed") == 1);
                } else {
                    profile.setShards(plugin.getConfig().getLong("economy.starting-shards", 0));
                    profile.setTokens(plugin.getConfig().getLong("economy.starting-tokens", 0));
                    saveProfile(profile);
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed loading profile: " + e.getMessage());
        }
        loadSet(uuid, "unlocked_effects", profile.unlockedEffects());
        loadSet(uuid, "enabled_effects", profile.enabledEffects());
        loadSet(uuid, "claimed_token_ranks", profile.claimedTokenRanks());
        loadSet(uuid, "claimed_quests", profile.claimedQuests());
        return profile;
    }

    private static final Set<String> ALLOWED_TABLES = Set.of("profiles");
    private static final Set<String> ALLOWED_COLUMNS = Set.of(
            "monthly_rerolls", "prestige_rank", "total_shards_earned", "login_streak",
            "last_login_date", "vault_tier", "deaths", "highest_killstreak", "playtime", "last_seen",
            "social_follow_claimed", "social_discord_claimed"
    );
    private static final Set<String> ALLOWED_DEFS = Set.of(
            "INTEGER NOT NULL DEFAULT 0", "TEXT"
    );

    private void ensureColumn(String table, String column, String definition) throws SQLException {
        if (!ALLOWED_TABLES.contains(table) || !ALLOWED_COLUMNS.contains(column) || !ALLOWED_DEFS.contains(definition)) {
            throw new SQLException("Refused unsafe ALTER TABLE: " + table + "." + column + " " + definition);
        }
        boolean exists = false;
        try (Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery("PRAGMA table_info(" + table + ")")) {
            while (rs.next()) {
                if (column.equalsIgnoreCase(rs.getString("name"))) {
                    exists = true;
                    break;
                }
            }
        }
        if (!exists) {
            try (Statement statement = connection.createStatement()) {
                statement.execute("ALTER TABLE " + table + " ADD COLUMN " + column + " " + definition);
            }
        }
    }

    private void loadSet(UUID uuid, String category, java.util.Set<String> target) {
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT value FROM profile_sets WHERE uuid=? AND category=?")) {
            ps.setString(1, uuid.toString());
            ps.setString(2, category);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    target.add(rs.getString("value"));
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed loading set " + category + ": " + e.getMessage());
        }
    }

    private void saveSet(UUID uuid, String category, java.util.Set<String> values) {
        dbExecutor.execute(() -> doSaveSet(uuid, category, values));
    }

    private void doSaveSet(UUID uuid, String category, java.util.Set<String> values) {
        try (PreparedStatement delete = connection.prepareStatement(
                "DELETE FROM profile_sets WHERE uuid=? AND category=?")) {
            delete.setString(1, uuid.toString());
            delete.setString(2, category);
            delete.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed clearing set: " + e.getMessage());
            return;
        }
        try (PreparedStatement insert = connection.prepareStatement(
                "INSERT INTO profile_sets (uuid, category, value) VALUES (?, ?, ?)")) {
            for (String value : values) {
                insert.setString(1, uuid.toString());
                insert.setString(2, category);
                insert.setString(3, value);
                insert.addBatch();
            }
            insert.executeBatch();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed saving set: " + e.getMessage());
        }
    }

    @Override
    public void close() {
        for (Map.Entry<UUID, PlayerProfile> entry : cache.entrySet()) {
            doSaveProfile(entry.getValue());
        }
        cache.clear();
        dbExecutor.shutdown();
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException ignored) {
            }
        }
    }
}
