package lol.folium.unstable.effects;

import org.bukkit.potion.PotionEffectType;

public record EffectDefinition(
        String id,
        int slot,
        String displayName,
        PotionEffectType potion,
        int amplifier,
        int tokenCost
) {}
