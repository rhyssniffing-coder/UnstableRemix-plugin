package lol.folium.unstable.command;

import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class BalanceCommand implements CommandExecutor, TabCompleter {

    private final EconomyService economy;

    public BalanceCommand(EconomyService economy) {
        this.economy = economy;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player target;
        if (args.length >= 1) {
            if (!sender.hasPermission("unstable.economy.view.others")) {
                sender.sendMessage(TextUtil.parse("<red>No permission."));
                return true;
            }
            target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                sender.sendMessage(TextUtil.parse("<red>Player not found."));
                return true;
            }
        } else if (sender instanceof Player player) {
            target = player;
        } else {
            sender.sendMessage("Console must specify a player.");
            return true;
        }
        sender.sendMessage(TextUtil.parse("<gray>" + target.getName() + " balance: <light_purple>"
                + economy.getShards(target.getUniqueId()) + " Shards</light_purple>"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1 && sender.hasPermission("unstable.economy.view.others")) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(args[0].toLowerCase(Locale.ROOT)))
                    .toList();
        }
        return Collections.emptyList();
    }
}
