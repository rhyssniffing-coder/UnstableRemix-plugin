package lol.folium.unstable.election;

import lol.folium.unstable.UnstableRemixPlugin;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class ElectionDataStore implements AutoCloseable {

    private final UnstableRemixPlugin plugin;
    private Connection connection;

    public ElectionDataStore(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    public void init() throws SQLException {
        File file = new File(plugin.getDataFolder(), "elections.db");
        connection = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
        try (Statement stmt = connection.createStatement()) {
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS elections (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    phase TEXT NOT NULL DEFAULT 'INACTIVE',
                    started_at INTEGER NOT NULL,
                    ended_at INTEGER
                )
            """);
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS candidates (
                    election_id INTEGER NOT NULL,
                    uuid TEXT NOT NULL,
                    faction TEXT NOT NULL,
                    manifesto TEXT NOT NULL DEFAULT '',
                    vote_count INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY (election_id, uuid),
                    FOREIGN KEY (election_id) REFERENCES elections(id)
                )
            """);
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS votes (
                    election_id INTEGER NOT NULL,
                    voter_uuid TEXT NOT NULL,
                    candidate_uuid TEXT NOT NULL,
                    PRIMARY KEY (election_id, voter_uuid),
                    FOREIGN KEY (election_id) REFERENCES elections(id)
                )
            """);
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS results (
                    election_id INTEGER PRIMARY KEY,
                    faction TEXT NOT NULL,
                    winner_uuid TEXT NOT NULL,
                    vote_count INTEGER NOT NULL,
                    FOREIGN KEY (election_id) REFERENCES elections(id)
                )
            """);
        }
    }

    public int createElection(long startedAt) {
        String sql = "INSERT INTO elections (phase, started_at) VALUES ('REGISTRATION', ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, startedAt);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to create election: " + e.getMessage());
        }
        return -1;
    }

    public void updatePhase(int electionId, String phase) {
        String sql = "UPDATE elections SET phase = ?, ended_at = ? WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, phase);
            ps.setLong(2, System.currentTimeMillis());
            ps.setInt(3, electionId);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to update election phase: " + e.getMessage());
        }
    }

    public int getActiveElectionId() {
        String sql = "SELECT id FROM elections WHERE phase != 'COMPLETE' AND phase != 'INACTIVE' ORDER BY id DESC LIMIT 1";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to get active election: " + e.getMessage());
        }
        return -1;
    }

    public void registerCandidate(int electionId, UUID uuid, String faction, String manifesto) {
        String sql = "INSERT OR REPLACE INTO candidates (election_id, uuid, faction, manifesto) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, electionId);
            ps.setString(2, uuid.toString());
            ps.setString(3, faction);
            ps.setString(4, manifesto);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to register candidate: " + e.getMessage());
        }
    }

    public void removeCandidate(int electionId, UUID uuid) {
        String sql = "DELETE FROM candidates WHERE election_id = ? AND uuid = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, electionId);
            ps.setString(2, uuid.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to remove candidate: " + e.getMessage());
        }
    }

    public List<CandidateData> getCandidates(int electionId) {
        List<CandidateData> list = new ArrayList<>();
        String sql = "SELECT uuid, faction, manifesto, vote_count FROM candidates WHERE election_id = ? ORDER BY vote_count DESC";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, electionId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new CandidateData(
                    UUID.fromString(rs.getString("uuid")),
                    rs.getString("faction"),
                    rs.getString("manifesto"),
                    rs.getInt("vote_count")
                ));
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to get candidates: " + e.getMessage());
        }
        return list;
    }

    public boolean hasCandidate(int electionId, UUID uuid) {
        String sql = "SELECT 1 FROM candidates WHERE election_id = ? AND uuid = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, electionId);
            ps.setString(2, uuid.toString());
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            return false;
        }
    }

    public boolean hasVoted(int electionId, UUID voterUuid) {
        String sql = "SELECT 1 FROM votes WHERE election_id = ? AND voter_uuid = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, electionId);
            ps.setString(2, voterUuid.toString());
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            return false;
        }
    }

    public void castVote(int electionId, UUID voterUuid, UUID candidateUuid) {
        String sql = "INSERT INTO votes (election_id, voter_uuid, candidate_uuid) VALUES (?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, electionId);
            ps.setString(2, voterUuid.toString());
            ps.setString(3, candidateUuid.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to cast vote: " + e.getMessage());
        }
        sql = "UPDATE candidates SET vote_count = vote_count + 1 WHERE election_id = ? AND uuid = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, electionId);
            ps.setString(2, candidateUuid.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to update vote count: " + e.getMessage());
        }
    }

    public void finalizeResults(int electionId) {
        String sql = """
            INSERT OR REPLACE INTO results (election_id, faction, winner_uuid, vote_count)
            SELECT ?, faction, uuid, vote_count FROM candidates
            WHERE election_id = ? AND vote_count = (
                SELECT MAX(vote_count) FROM candidates WHERE election_id = ?
            ) LIMIT 1
        """;
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, electionId);
            ps.setInt(2, electionId);
            ps.setInt(3, electionId);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to finalize results: " + e.getMessage());
        }
    }

    public ElectionResult getResult(int electionId) {
        String sql = "SELECT faction, winner_uuid, vote_count FROM results WHERE election_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, electionId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new ElectionResult(
                    rs.getString("faction"),
                    UUID.fromString(rs.getString("winner_uuid")),
                    rs.getInt("vote_count")
                );
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to get result: " + e.getMessage());
        }
        return null;
    }

    public void closeActiveElection(int electionId) {
        String sql = "UPDATE elections SET phase = 'INACTIVE', ended_at = ? WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, System.currentTimeMillis());
            ps.setInt(2, electionId);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to close election: " + e.getMessage());
        }
    }

    public String getPhase(int electionId) {
        String sql = "SELECT phase FROM elections WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, electionId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getString("phase");
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to get phase: " + e.getMessage());
        }
        return "INACTIVE";
    }

    public long getStartedAt(int electionId) {
        String sql = "SELECT started_at FROM elections WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, electionId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getLong("started_at");
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to get started_at: " + e.getMessage());
        }
        return -1;
    }

    public int getTotalVotes(int electionId) {
        String sql = "SELECT COUNT(*) FROM votes WHERE election_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, electionId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to count votes: " + e.getMessage());
        }
        return 0;
    }

    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to close election database: " + e.getMessage());
        }
    }

    public record CandidateData(UUID uuid, String faction, String manifesto, int voteCount) {}
    public record ElectionResult(String faction, UUID winnerUuid, int voteCount) {}
}
