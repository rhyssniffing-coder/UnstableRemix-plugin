package lol.folium.unstable.trade;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.GuiTheme;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class TradeCommand implements CommandExecutor, TabCompleter {

    private final UnstableRemixPlugin plugin;
    private final TradeManager tradeManager;
    private final TradeListener tradeListener;

    public TradeCommand(UnstableRemixPlugin plugin, TradeManager tradeManager, TradeListener tradeListener) {
        this.plugin = plugin;
        this.tradeManager = tradeManager;
        this.tradeListener = tradeListener;
    }

    private Component parse(String text) {
        return TextUtil.parse(text);
    }

    private ItemStack pane(Material mat) {
        return ItemBuilder.of(mat).name(Component.empty()).build();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        String sub = args[0].toLowerCase();
        switch (sub) {
            case "accept" -> {
                if (tradeManager.acceptRequest(player)) {
                    TradeManager.ActiveTrade trade = tradeManager.getActiveTrade(player.getUniqueId());
                    if (trade != null) {
                        Player sender2 = Bukkit.getPlayer(trade.sender());
                        player.sendMessage(parse("<green>Trade accepted with <white>" + (sender2 != null ? sender2.getName() : "Unknown") + "</white>!"));
                        if (sender2 != null) {
                            sender2.sendMessage(parse("<green><white>" + player.getName() + "</white> accepted your trade request!"));
                            tradeListener.openTradeGUI(sender2, trade);
                        }
                        tradeListener.openTradeGUI(player, trade);
                    }
                } else {
                    player.sendMessage(parse("<red>No pending trade request or player is too far away."));
                }
            }
            case "deny" -> {
                UUID senderId = tradeManager.getPendingRequest(player.getUniqueId());
                if (senderId != null) {
                    tradeManager.clearRequest(player.getUniqueId());
                    Player sender2 = Bukkit.getPlayer(senderId);
                    if (sender2 != null) {
                        sender2.sendMessage(parse("<red>" + player.getName() + " denied your trade request."));
                    }
                    player.sendMessage(parse("<gray>Trade request denied.</gray>"));
                } else {
                    player.sendMessage(parse("<red>No pending trade request."));
                }
            }
            case "history" -> {
                if (args.length >= 2 && player.hasPermission("unstable.admin")) {
                    // Staff view another player's history
                    Player target = Bukkit.getPlayer(args[1]);
                    if (target == null) {
                        player.sendMessage(parse("<red>Player not found."));
                        return true;
                    }
                    openHistoryGUI(player, target.getUniqueId(), target.getName());
                } else {
                    openHistoryGUI(player, player.getUniqueId(), player.getName());
                }
            }
            case "admin" -> {
                if (!player.hasPermission("unstable.admin")) {
                    player.sendMessage(parse("<red>No permission."));
                    return true;
                }
                openAdminGUI(player);
            }
            default -> {
                // Send request to player
                Player target = Bukkit.getPlayer(args[0]);
                if (target == null) {
                    player.sendMessage(parse("<red>Player not found."));
                    return true;
                }
                if (player.equals(target)) {
                    player.sendMessage(parse("<red>You cannot trade with yourself."));
                    return true;
                }
                if (player.getLocation().distanceSquared(target.getLocation()) > TradeManager.MAX_RANGE * TradeManager.MAX_RANGE) {
                    player.sendMessage(parse("<red>You must be within " + TradeManager.MAX_RANGE + " blocks to trade."));
                    return true;
                }
                if (!tradeManager.isTradeableItem(player)) {
                    player.sendMessage(parse("<red>You have restricted items in your inventory (shulkers/bundles)."));
                    return true;
                }
                if (!tradeManager.isTradeableItem(target)) {
                    player.sendMessage(parse("<red>" + target.getName() + " has restricted items in their inventory."));
                    return true;
                }
                if (tradeManager.sendRequest(player, target)) {
                    player.sendMessage(parse("<green>Trade request sent to <white>" + target.getName() + "</white>!"));
                    target.sendMessage(parse("<gold><white>" + player.getName() + "</white> wants to trade with you!"));
                    target.sendMessage(parse("<yellow>/trade accept</yellow> <gray>or</gray> <red>/trade deny</red>"));
                } else {
                    player.sendMessage(parse("<red>Could not send trade request. Player may be busy or too far away."));
                }
            }
        }
        return true;
    }

    private void openHistoryGUI(Player viewer, UUID targetUuid, String targetName) {
        Inventory inv = Bukkit.createInventory(null, 54,
                parse(GuiTheme.primary("TRADE HISTORY: " + targetName)));

        for (int i = 0; i < 54; i++) inv.setItem(i, pane(Material.BLACK_STAINED_GLASS_PANE));
        for (int i = 0; i < 9; i++) inv.setItem(i, pane(Material.PURPLE_STAINED_GLASS_PANE));
        for (int i = 45; i < 54; i++) inv.setItem(i, pane(Material.PURPLE_STAINED_GLASS_PANE));

        List<TradeManager.TradeRecord> history = tradeManager.getHistory(targetUuid);
        int slot = 10;
        for (TradeManager.TradeRecord record : history) {
            if (slot >= 45) break;
            String otherName = record.sender().equals(targetUuid) ?
                    getPlayerName(record.receiver()) : getPlayerName(record.sender());
            String direction = record.sender().equals(targetUuid) ? "Traded to" : "Received from";
            long timeAgo = System.currentTimeMillis() - record.timestamp();
            String timeStr = formatTimeAgo(timeAgo);

            StringBuilder senderItemsStr = new StringBuilder();
            for (String s : record.senderItems()) {
                if (!senderItemsStr.isEmpty()) senderItemsStr.append(", ");
                senderItemsStr.append(s);
            }
            StringBuilder receiverItemsStr = new StringBuilder();
            for (String s : record.receiverItems()) {
                if (!receiverItemsStr.isEmpty()) receiverItemsStr.append(", ");
                receiverItemsStr.append(s);
            }

            inv.setItem(slot, ItemBuilder.of(Material.PAPER)
                    .name(parse(GuiTheme.primary("&f" + direction + " &6" + otherName)))
                    .lore(List.of(
                            parse("&7Time: &f" + timeStr),
                            parse("&7You gave: &f" + (record.sender().equals(targetUuid) ? senderItemsStr : receiverItemsStr)),
                            parse("&7You got: &f" + (record.sender().equals(targetUuid) ? receiverItemsStr : senderItemsStr))
                    )).build());
            slot++;
        }

        if (history.isEmpty()) {
            inv.setItem(22, ItemBuilder.of(Material.BARRIER)
                    .name(parse("<gray><bold>NO TRADE HISTORY</bold></gray>"))
                    .lore(List.of(parse("&7This player has no trades yet."))).build());
        }

        viewer.openInventory(inv);
    }

    private void openAdminGUI(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54,
                parse(GuiTheme.primary("TRADE ADMIN")));

        for (int i = 0; i < 54; i++) inv.setItem(i, pane(Material.BLACK_STAINED_GLASS_PANE));
        for (int i = 0; i < 9; i++) inv.setItem(i, pane(Material.PURPLE_STAINED_GLASS_PANE));
        for (int i = 45; i < 54; i++) inv.setItem(i, pane(Material.PURPLE_STAINED_GLASS_PANE));

        inv.setItem(4, ItemBuilder.of(Material.BEACON)
                .name(parse(GuiTheme.secondary("&e&lRECENT SERVER TRADES")))
                .lore(List.of(parse("&7View the most recent trades across the server"))).build());

        List<TradeManager.TradeRecord> recent = tradeManager.getRecentTrades(36);
        int slot = 10;
        for (TradeManager.TradeRecord record : recent) {
            if (slot >= 45) break;
            String senderName = getPlayerName(record.sender());
            String receiverName = getPlayerName(record.receiver());
            long timeAgo = System.currentTimeMillis() - record.timestamp();

            inv.setItem(slot, ItemBuilder.of(Material.PAPER)
                    .name(parse(GuiTheme.primary("&f" + senderName + " &7<-> &f" + receiverName)))
                    .lore(List.of(
                            parse("&7Time: &f" + formatTimeAgo(timeAgo)),
                            parse("&7" + senderName + " gave: &f" + String.join(", ", record.senderItems())),
                            parse("&7" + receiverName + " gave: &f" + String.join(", ", record.receiverItems()))
                    )).build());
            slot++;
        }

        if (recent.isEmpty()) {
            inv.setItem(22, ItemBuilder.of(Material.BARRIER)
                    .name(parse("<gray><bold>NO TRADES YET</bold></gray>"))
                    .lore(List.of(parse("&7No trades have been recorded."))).build());
        }

        player.openInventory(inv);
    }

    private String getPlayerName(UUID uuid) {
        Player online = Bukkit.getPlayer(uuid);
        if (online != null) return online.getName();
        OfflinePlayer offline = Bukkit.getOfflinePlayer(uuid);
        return offline.getName() != null ? offline.getName() : uuid.toString().substring(0, 8);
    }

    private String formatTimeAgo(long millis) {
        if (millis < 60_000) return "just now";
        if (millis < 3_600_000) return (millis / 60_000) + "m ago";
        if (millis < 86_400_000) return (millis / 3_600_000) + "h ago";
        return (millis / 86_400_000) + "d ago";
    }

    private void sendHelp(Player player) {
        player.sendMessage(parse(GuiTheme.primary("&6&lTrading Commands")));
        player.sendMessage(parse("&7/trade <player> &f- Send a trade request"));
        player.sendMessage(parse("&7/trade accept &f- Accept a trade request"));
        player.sendMessage(parse("&7/trade deny &f- Deny a trade request"));
        player.sendMessage(parse("&7/trade history &f- View your trade history"));
        player.sendMessage(parse("&7/trade history <player> &f- View a player's history (staff)"));
        player.sendMessage(parse("&7/trade admin &f- View recent server trades (staff)"));
        player.sendMessage(parse(""));
        player.sendMessage(parse("&7Must be within " + TradeManager.MAX_RANGE + " blocks to trade."));
        player.sendMessage(parse("&7Shulker boxes and bundles are blocked."));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            completions.add("accept");
            completions.add("deny");
            completions.add("history");
            completions.add("admin");
            for (Player p : Bukkit.getOnlinePlayers()) {
                completions.add(p.getName());
            }
        } else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("history") || args[0].equalsIgnoreCase("admin")) {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    completions.add(p.getName());
                }
            }
        }
        String last = args[args.length - 1].toLowerCase();
        completions.removeIf(s -> !s.toLowerCase().startsWith(last));
        return completions;
    }
}
