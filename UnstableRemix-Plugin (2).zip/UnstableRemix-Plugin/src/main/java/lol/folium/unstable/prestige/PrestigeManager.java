package lol.folium.unstable.prestige;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.data.PlayerDataStore;
import lol.folium.unstable.data.PlayerProfile;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Map;
import java.util.Set;

public final class PrestigeManager {

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final PlayerDataStore store;

    public PrestigeManager(UnstableRemixPlugin plugin, ConfigManager configs, PlayerDataStore store) {
        this.plugin = plugin;
        this.configs = configs;
        this.store = store;
    }

    public boolean canPrestige(Player player) {
        PlayerProfile profile = store.get(player.getUniqueId());
        FileConfiguration config = configs.get("quests.yml");
        long requiredShards = config.getLong("prestige.required-total-shards", 50000L);
        return profile.totalShardsEarned() >= requiredShards;
    }

    public int prestigeRank(Player player) {
        return store.get(player.getUniqueId()).prestigeRank();
    }

    public double multiplier(Player player) {
        int rank = prestigeRank(player);
        if (rank <= 0) return 1.0;
        FileConfiguration config = configs.get("quests.yml");
        double baseMultiplier = config.getDouble("prestige.base-multiplier", 1.1);
        double increment = config.getDouble("prestige.multiplier-increment", 0.05);
        double maxMultiplier = config.getDouble("prestige.max-multiplier", 5.0);
        return Math.min(maxMultiplier, baseMultiplier + (rank - 1) * increment);
    }

    public String prefix(Player player) {
        int rank = prestigeRank(player);
        if (rank <= 0) return "";
        FileConfiguration config = configs.get("quests.yml");
        String template = config.getString("prestige.prefix-template", "<gradient:gold:yellow>[Prestige {rank}]</gradient>");
        return template.replace("{rank}", String.valueOf(rank));
    }

    public void openConfirmationGui(Player player) {
        FileConfiguration config = configs.get("quests.yml");
        int currentRank = prestigeRank(player);
        int nextRank = currentRank + 1;
        int maxRank = maxPrestige();
        long requiredShards = config.getLong("prestige.required-total-shards", 50000L);
        long totalEarned = store.get(player.getUniqueId()).totalShardsEarned();
        boolean canPrestige = totalEarned >= requiredShards;
        boolean maxed = currentRank >= maxRank;

        double currentMult = multiplier(player);
        double nextMult = Math.min(
                config.getDouble("prestige.max-multiplier", 5.0),
                config.getDouble("prestige.base-multiplier", 1.1) + currentRank * config.getDouble("prestige.multiplier-increment", 0.05));

        PrestigeGui holder = new PrestigeGui(player, canPrestige && !maxed);
        Inventory inv = Bukkit.createInventory(holder, 45,
                TextUtil.parse("<gradient:#FFD700:#FFAA00><bold>Prestige</bold></gradient>"));
        holder.bind(inv);

        ItemStack filler = ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE)
                .name(TextUtil.parse(" "))
                .build();
        for (int i = 0; i < 45; i++) {
            inv.setItem(i, filler);
        }

        inv.setItem(4, ItemBuilder.of(Material.PLAYER_HEAD)
                .name(TextUtil.parse("<gold><bold>" + player.getName() + "</bold></gold>"))
                .lore(List.of(
                        TextUtil.parse("<dark_gray>Your prestige profile</dark_gray>")
                ))
                .build());

        inv.setItem(10, ItemBuilder.of(Material.EXPERIENCE_BOTTLE)
                .name(TextUtil.parse("<green><bold>Current Rank</bold></green>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Rank: <white>" + currentRank + " / " + maxRank + "</white></gray>"),
                        TextUtil.parse("<gray>Multiplier: <yellow>" + String.format("%.2f", currentMult) + "x</yellow></gray>")
                ))
                .glow(currentRank > 0)
                .build());

        inv.setItem(11, ItemBuilder.of(Material.NETHER_STAR)
                .name(TextUtil.parse("<aqua><bold>Next Rank</bold></aqua>"))
                .lore(maxed ? List.of(
                        TextUtil.parse("<gray>You are at max prestige!</gray>")
                ) : List.of(
                        TextUtil.parse("<gray>Rank: <white>" + nextRank + " / " + maxRank + "</white></gray>"),
                        TextUtil.parse("<gray>Multiplier: <yellow>" + String.format("%.2f", nextMult) + "x</yellow></gray>"),
                        TextUtil.parse("<gray>Boost: <green>+" + String.format("%.0f", (nextMult - currentMult) * 100) + "%</green></gray>")
                ))
                .build());

        inv.setItem(13, ItemBuilder.of(Material.DIAMOND)
                .name(TextUtil.parse("<light_purple><bold>Requirements</bold></light_purple>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Total Shards Earned:</gray>"),
                        TextUtil.parse("  <white>" + formatNumber(totalEarned) + " / " + formatNumber(requiredShards) + "</white>"),
                        TextUtil.parse("<gray>Progress: " + progressBar(totalEarned, requiredShards, 20) + "</gray>"),
                        TextUtil.parse(""),
                        TextUtil.parse(canPrestige ? "<green>You meet the requirements!</green>" : "<red>You need " + formatNumber(requiredShards - totalEarned) + " more shards</red>")
                ))
                .build());

        inv.setItem(15, ItemBuilder.of(Material.BOOK)
                .name(TextUtil.parse("<yellow><bold>What Happens</bold></yellow>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Your prestige rank increases</gray>"),
                        TextUtil.parse("<gray>Your shard multiplier increases</gray>"),
                        TextUtil.parse("<red>Your milestones are reset</red>"),
                        TextUtil.parse("<red>Your milestone quests reset</red>"),
                        TextUtil.parse("<red><bold>All purchased kits are reset</bold></red>"),
                        TextUtil.parse("<red><bold>You must re-buy all kits</bold></red>"),
                        TextUtil.parse(""),
                        TextUtil.parse("<dark_gray>Prestige is permanent!</dark_gray>")
                ))
                .build());

        inv.setItem(22, canPrestige && !maxed
                ? ItemBuilder.of(Material.LIME_DYE)
                    .name(TextUtil.parse("<green><bold>Click to Prestige!</bold></green>"))
                    .lore(List.of(
                            TextUtil.parse("<gray>Prestige to rank <white>" + nextRank + "</white></gray>"),
                            TextUtil.parse("<gray>New multiplier: <yellow>" + String.format("%.2f", nextMult) + "x</yellow></gray>")
                    ))
                    .glow(true)
                    .build()
                : ItemBuilder.of(Material.BARRIER)
                    .name(TextUtil.parse("<red><bold>Cannot Prestige</bold></red>"))
                    .lore(maxed ? List.of(
                            TextUtil.parse("<gray>You are at max prestige rank!</gray>")
                    ) : List.of(
                            TextUtil.parse("<gray>You need <white>" + formatNumber(requiredShards) + "</white> total shards earned</gray>"),
                            TextUtil.parse("<gray>Current: <white>" + formatNumber(totalEarned) + "</white></gray>")
                    ))
                    .build());

        inv.setItem(31, ItemBuilder.of(Material.ARROW)
                .name(TextUtil.parse("<red><bold>Close</bold></red>"))
                .build());

        player.openInventory(inv);
    }

    public void prestige(Player player) {
        if (!canPrestige(player)) {
            player.sendMessage(TextUtil.parse("<red>You do not meet the prestige requirements!"));
            return;
        }
        if (prestigeRank(player) >= maxPrestige()) {
            player.sendMessage(TextUtil.parse("<red>You have reached the maximum prestige rank!"));
            return;
        }

        PlayerProfile profile = store.get(player.getUniqueId());
        int newRank = profile.prestigeRank() + 1;
        profile.setPrestigeRank(newRank);
        store.clearQuestAssignment(player.getUniqueId(), "milestone");
        profile.claimedQuests().removeIf(value -> value.startsWith("milestone:"));
        store.replaceSet(player.getUniqueId(), "unlocked_kits", Set.of());
        profile.unlockedEffects().clear();
        profile.claimedTokenRanks().clear();
        store.saveProfile(profile);

        String msg = configs.get("quests.yml").getString("prestige.broadcast",
                "<gradient:gold:yellow>{player} has reached Prestige {rank}!</gradient>");
        Bukkit.broadcast(TextUtil.parse(msg.replace("{player}", player.getName()).replace("{rank}", String.valueOf(newRank))));
    }

    private int maxPrestige() {
        return configs.get("quests.yml").getInt("prestige.max-rank", 50);
    }

    private String formatNumber(long n) {
        if (n >= 1_000_000_000) return String.format("%.1fB", n / 1_000_000_000.0);
        if (n >= 1_000_000) return String.format("%.1fM", n / 1_000_000.0);
        if (n >= 10_000) return String.format("%.1fk", n / 1_000.0);
        return String.valueOf(n);
    }

    private String progressBar(long current, long max, int length) {
        double pct = max <= 0 ? 0 : Math.min(1.0, (double) current / max);
        int filled = (int) Math.round(pct * length);
        int empty = length - filled;
        return "<green>" + "\u2588".repeat(Math.max(0, filled)) + "</green><dark_gray>" + "\u2591".repeat(Math.max(0, empty)) + "</dark_gray>";
    }

    private static final class PrestigeGui extends GuiHolder {
        private final Player player;
        private final boolean canPrestige;

        PrestigeGui(Player player, boolean canPrestige) {
            this.player = player;
            this.canPrestige = canPrestige;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            if (slot == 22 && canPrestige) {
                player.closeInventory();
                openConfirmChat(player);
            } else if (slot == 31) {
                player.closeInventory();
            }
        }

        private void openConfirmChat(Player player) {
            player.sendMessage(TextUtil.parse("<gold><bold>Prestige</bold></gold> <gray>Type <white>/prestige confirm</white> to prestige, or anything else to cancel.</gray>"));
        }
    }
}
