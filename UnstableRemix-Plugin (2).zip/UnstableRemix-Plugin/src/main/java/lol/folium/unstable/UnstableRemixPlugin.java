package lol.folium.unstable;

import lol.folium.unstable.afk.AfkZoneCommand;
import lol.folium.unstable.afk.AfkZoneManager;
import lol.folium.unstable.bounty.BountyCommand;
import lol.folium.unstable.bounty.BountyManager;
import lol.folium.unstable.command.AdmineventsCommand;
import lol.folium.unstable.election.CampaignCommand;
import lol.folium.unstable.election.ElectionDataStore;
import lol.folium.unstable.election.ElectionListeners;
import lol.folium.unstable.election.ElectionManager;
import lol.folium.unstable.election.VoteCommand;
import lol.folium.unstable.election.VoteGui;
import lol.folium.unstable.command.AdminKitCommand;
import lol.folium.unstable.command.AdminShardsCommand;
import lol.folium.unstable.shop.ShopCommand;
import lol.folium.unstable.shop.ShopManager;
import lol.folium.unstable.shop.AdminKitShopCommand;
import lol.folium.unstable.shop.AdminShopCommand;
import lol.folium.unstable.cooldown.KitCooldownCommand;
import lol.folium.unstable.cooldown.KitCooldownManager;
import lol.folium.unstable.cooldown.CooldownItemManager;
import lol.folium.unstable.cooldown.CooldownItemCommand;
import lol.folium.unstable.cooldown.CooldownItemListener;
import lol.folium.unstable.broadcast.BroadcastNpcCommand;
import lol.folium.unstable.broadcast.BroadcastNpcManager;
import lol.folium.unstable.leaderboard.LeaderboardCommand;
import lol.folium.unstable.leaderboard.LeaderboardManager;
import lol.folium.unstable.leaderboard.DashboardServer;
import lol.folium.unstable.leaderboard.HolographicLeaderboard;
import lol.folium.unstable.leaderboard.HologramCommand;
import lol.folium.unstable.settings.SettingsManager;
import lol.folium.unstable.settings.SettingsCommand;
import lol.folium.unstable.settings.SettingsListener;
import lol.folium.unstable.civ.CivManager;
import lol.folium.unstable.civ.CivCommand;
import lol.folium.unstable.civ.CivListener;
import lol.folium.unstable.civ.CivChatListener;
import lol.folium.unstable.civ.CivVault;
import lol.folium.unstable.trade.TradeManager;
import lol.folium.unstable.trade.TradeCommand;
import lol.folium.unstable.trade.TradeListener;
import lol.folium.unstable.kitrole.KitRoleManager;
import lol.folium.unstable.kitrole.KitRoleCommand;
import lol.folium.unstable.kitrole.KitRoleListener;
import lol.folium.unstable.map.NoRestrictedItemsListener;
import lol.folium.unstable.ffa.FFAWeaponManager;
import lol.folium.unstable.ffa.FFAWeaponCommand;
import lol.folium.unstable.ffa.FFAWeaponListener;
import lol.folium.unstable.command.AdminTokenCommand;
import lol.folium.unstable.command.BalanceCommand;
import lol.folium.unstable.command.AdminMediaCommand;
import lol.folium.unstable.command.DiscordCommand;
import lol.folium.unstable.command.FollowCommand;
import lol.folium.unstable.command.GuideCommand;
import lol.folium.unstable.command.LobbyCommand;
import lol.folium.unstable.command.MediaCommand;
import lol.folium.unstable.command.MediaLinkCommand;
import lol.folium.unstable.command.PayCommand;
import lol.folium.unstable.command.ReportCommand;
import lol.folium.unstable.command.RulesCommand;
import lol.folium.unstable.command.ShardsCommand;
import lol.folium.unstable.command.TrashCommand;
import lol.folium.unstable.command.UnstableAdminCommand;
import lol.folium.unstable.combat.CombatGuardListener;
import lol.folium.unstable.combat.CombatTagManager;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.data.PlayerDataStore;
import lol.folium.unstable.faction.FactionCommand;
import lol.folium.unstable.faction.FactionListener;
import lol.folium.unstable.blackjack.BlackjackCommand;
import lol.folium.unstable.blackjack.BlackjackListener;
import lol.folium.unstable.stats.StatsCommand;
import lol.folium.unstable.faction.FactionManager;
import lol.folium.unstable.faction.FactionSelectionManager;
import lol.folium.unstable.effects.EffectsCommand;
import lol.folium.unstable.effects.EffectsManager;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.events.ArenaEventEngine;
import lol.folium.unstable.events.ArenaEventListener;
import lol.folium.unstable.events.ArenaEventsCommand;
import lol.folium.unstable.events.EventManager;
import lol.folium.unstable.integration.CitizensHook;
import lol.folium.unstable.integration.HubNpcListener;
import lol.folium.unstable.integration.MapNpcListener;
import lol.folium.unstable.integration.LuckPermsHook;
import lol.folium.unstable.integration.MediaRankManager;
import lol.folium.unstable.kit.CoreAdminCommand;
import lol.folium.unstable.kit.KillCounterManager;
import lol.folium.unstable.kit.KitCommand;
import lol.folium.unstable.kit.KitEditorCommand;
import lol.folium.unstable.kit.KitManager;
import lol.folium.unstable.listener.CombatListener;
import lol.folium.unstable.listener.FireworkListener;
import lol.folium.unstable.listener.GuiListener;
import lol.folium.unstable.listener.PlayerLifecycleListener;
import lol.folium.unstable.listener.ChatCooldownListener;
import lol.folium.unstable.map.AdminMapVoteCommand;
import lol.folium.unstable.map.ArenaAdminCommand;
import lol.folium.unstable.map.ArenaBlockListener;
import lol.folium.unstable.map.ArenaManager;
import lol.folium.unstable.map.ArenaRegenerator;
import lol.folium.unstable.map.ArenaSetupCommand;
import lol.folium.unstable.map.BlockDespawnManager;
import lol.folium.unstable.map.MapCommand;
import lol.folium.unstable.map.MapVoteCommand;
import lol.folium.unstable.map.MapVoteListener;
import lol.folium.unstable.map.MapVoteManager;
import lol.folium.unstable.map.WorldEditBridge;
import lol.folium.unstable.prestige.PrestigeCommand;
import lol.folium.unstable.prestige.PrestigeManager;
import lol.folium.unstable.reward.DailyLoginCommand;
import lol.folium.unstable.reward.DailyRewardCommand;
import lol.folium.unstable.reward.DailyLoginManager;
import lol.folium.unstable.reward.DailyRewardManager;
import lol.folium.unstable.vault.VaultCommand;
import lol.folium.unstable.vault.VaultManager;
import lol.folium.unstable.quest.QuestCommand;
import lol.folium.unstable.quest.QuestPlaceholderExpansion;
import lol.folium.unstable.quest.QuestService;
import lol.folium.unstable.rent.RentRankCommand;
import lol.folium.unstable.rent.RentRankManager;
import lol.folium.unstable.scoreboard.ActionBarManager;
import lol.folium.unstable.scoreboard.ScoreboardManager;
import lol.folium.unstable.vibration.VibrationManager;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public final class UnstableRemixPlugin extends JavaPlugin {

    private static UnstableRemixPlugin instance;

    private ConfigManager configManager;
    private PlayerDataStore playerDataStore;
    private EconomyService economyService;
    private ArenaManager arenaManager;
    private ArenaRegenerator arenaRegenerator;
    private WorldEditBridge worldEditBridge;
    private CitizensHook citizensHook;
    private EffectsManager effectsManager;
    private RentRankManager rentRankManager;
    private QuestService questService;
    private VibrationManager vibrationManager;
    private MapVoteManager mapVoteManager;
    private EventManager eventManager;
    private BlockDespawnManager blockDespawnManager;
    private ArenaEventEngine arenaEventEngine;
    private LuckPermsHook luckPermsHook;
    private MediaRankManager mediaRankManager;
    private CombatTagManager combatTagManager;
    private KitManager kitManager;
    private BountyManager bountyManager;
    private PrestigeManager prestigeManager;
    private AfkZoneManager afkZoneManager;
    private KillCounterManager killCounterManager;
    private DailyRewardManager dailyRewardManager;
    private DailyLoginManager dailyLoginManager;
    private VaultManager vaultManager;
    private FactionManager factionManager;
    private FactionSelectionManager factionSelectionManager;
    private ElectionDataStore electionDataStore;
    private ElectionManager electionManager;
    private VoteGui voteGui;
    private ShopManager shopManager;
    private KitCooldownManager kitCooldownManager;
    private CooldownItemManager cooldownItemManager;
    private LeaderboardManager leaderboardManager;
    private DashboardServer dashboardServer;
    private FFAWeaponManager ffaWeaponManager;
    private BroadcastNpcManager broadcastNpcManager;
    private PlayerLifecycleListener playerLifecycleListener;
    private ScoreboardManager scoreboardManager;
    private ActionBarManager actionBarManager;
    private HolographicLeaderboard holographicLeaderboard;
    private SettingsListener settingsListener;
    private TradeManager tradeManager;
    private KitRoleManager kitRoleManager;
    private final List<QuestPlaceholderExpansion> placeholderExpansions = new ArrayList<>();

    @Override
    public void onEnable() {
        instance = this;
        try {
            bootstrap();
        } catch (Throwable t) {
            getLogger().severe("Fatal error during bootstrap: " + t.getMessage());
            if (getConfig().getBoolean("debug", false)) t.printStackTrace();
            getServer().getPluginManager().disablePlugin(this);
        }
    }

    @SuppressWarnings("unchecked")
    private void bootstrap() {
        configManager = new ConfigManager(this);
        safeCall(configManager::loadAll, "ConfigManager");

        playerDataStore = safeCall(() -> { var s = new PlayerDataStore(this); s.init(); return s; }, "PlayerDataStore", null);
        if (playerDataStore == null) {
            getLogger().severe("PlayerDataStore failed — disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        economyService = new EconomyService(this, playerDataStore);
        worldEditBridge = safeCall(() -> new WorldEditBridge(this), "WorldEditBridge", null);
        arenaManager = safeCall(() -> { var m = new ArenaManager(this, configManager); m.loadAll(); return m; }, "ArenaManager", null);
        arenaRegenerator = new ArenaRegenerator(this);

        luckPermsHook = safeCall(() -> new LuckPermsHook(this), "LuckPermsHook", new LuckPermsHook(this));
        if (luckPermsHook != null && luckPermsHook.isAvailable()) {
            Bukkit.getScheduler().runTaskLater(this, () ->
                    safeCall((Runnable) () -> luckPermsHook.createKitGroups(), "LuckPermsHook.createKitGroups"), 60L);
        }
        citizensHook = safeCall(() -> new CitizensHook(this), "CitizensHook", new CitizensHook(this));
        mediaRankManager = safeCall(() -> { var m = new MediaRankManager(this); m.createMediaGroup(); return m; }, "MediaRankManager", null);

        effectsManager = safeCall(() -> { var m = new EffectsManager(this, configManager, playerDataStore, economyService, luckPermsHook); m.reload(); m.startTasks(); return m; }, "EffectsManager", null);
        rentRankManager = safeCall(() -> new RentRankManager(this, configManager, economyService, luckPermsHook, effectsManager, playerDataStore), "RentRankManager", null);
        questService = safeCall(() -> { var q = new QuestService(this, configManager, playerDataStore, economyService, arenaManager); q.reload(); return q; }, "QuestService", null);
        kitManager = safeCall(() -> {
            var k = new KitManager(this, configManager, playerDataStore, economyService, luckPermsHook, arenaManager);
            k.reload();
            extractKitImportFiles();
            k.tryAutoImport();
            return k;
        }, "KitManager", null);
        bountyManager = safeCall(() -> { var b = new BountyManager(this, economyService); b.load(); return b; }, "BountyManager", null);
        combatTagManager = safeCall(() -> { var c = new CombatTagManager(this, economyService, questService); c.start(); return c; }, "CombatTagManager", null);
        vibrationManager = safeCall(() -> { var v = new VibrationManager(this, arenaManager); v.start(); return v; }, "VibrationManager", null);
        mapVoteManager = safeCall(() -> { var m = new MapVoteManager(this, configManager, arenaManager); if (configManager.main().getBoolean("map-vote.enabled", true)) m.startAutomaticSchedule(); return m; }, "MapVoteManager", null);

        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            safeCall((Runnable) () -> registerPlaceholderExpansions(), "PlaceholderExpansions");
        }

        eventManager = safeCall(() -> { var e = new EventManager(this, configManager); e.startAutomaticSchedule(); return e; }, "EventManager", null);
        blockDespawnManager = safeCall(() -> { var b = new BlockDespawnManager(this, configManager, arenaManager); if (configManager.main().getBoolean("block-despawn.enabled", true)) b.startAutomaticSchedule(); return b; }, "BlockDespawnManager", null);

        factionManager = safeCall(() -> { var f = new FactionManager(this, configManager); f.init(); f.loadAll(); f.startTasks(); return f; }, "FactionManager", null);
        factionSelectionManager = safeCall(() -> { var f = new FactionSelectionManager(this, configManager, luckPermsHook.getLuckPerms(), factionManager); f.setupGroups(); return f; }, "FactionSelectionManager", null);

        arenaEventEngine = safeCall(() -> { var a = new ArenaEventEngine(this, configManager, arenaManager, factionManager); a.startAutomaticSchedule(); return a; }, "ArenaEventEngine", null);

        prestigeManager = new PrestigeManager(this, configManager, playerDataStore);
        afkZoneManager = safeCall(() -> { var a = new AfkZoneManager(this, configManager, economyService, worldEditBridge); a.startTasks(); return a; }, "AfkZoneManager", null);
        killCounterManager = new KillCounterManager(this);
        dailyRewardManager = new DailyRewardManager(this, configManager, playerDataStore, economyService);
        dailyLoginManager = safeCall(() -> new DailyLoginManager(this, configManager, playerDataStore, economyService), "DailyLoginManager", null);
        vaultManager = safeCall(() -> { var v = new VaultManager(this, configManager, playerDataStore, economyService); v.reload(); return v; }, "VaultManager", null);

        electionDataStore = safeCall(() -> { var s = new ElectionDataStore(this); s.init(); return s; }, "ElectionDataStore", null);
        electionManager = safeCall(() -> {
            var m = new ElectionManager(this, electionDataStore, factionSelectionManager);
            m.restoreActiveElection();
            return m;
        }, "ElectionManager", null);
        voteGui = new VoteGui(this, electionManager);

        safeCall((Runnable) () -> configManager.get("shops.yml"), "shops.yml");
        kitCooldownManager = safeCall(() -> { var k = new KitCooldownManager(this); k.init(); return k; }, "KitCooldownManager", null);
        cooldownItemManager = safeCall(() -> { var c = new CooldownItemManager(this); c.loadFromConfig(); return c; }, "CooldownItemManager", null);
        shopManager = safeCall(() -> { var s = new ShopManager(this, economyService); s.reload(); return s; }, "ShopManager", null);
        leaderboardManager = new LeaderboardManager(this);
        safeCall((Runnable) () -> leaderboardManager.init(), "LeaderboardManager.init");
        if (getConfig().getBoolean("leaderboard.dashboard.enabled", false)) {
            dashboardServer = safeCall(() -> { var s = new DashboardServer(this, leaderboardManager); s.start(); return s; }, "DashboardServer", null);
        }

        ffaWeaponManager = safeCall(() -> new FFAWeaponManager(this), "FFAWeaponManager", null);
        broadcastNpcManager = safeCall(() -> { var b = new BroadcastNpcManager(this); b.init(); return b; }, "BroadcastNpcManager", null);

        holographicLeaderboard = safeCall(() -> { var h = new HolographicLeaderboard(this, leaderboardManager); h.spawnAll(); h.start(); return h; }, "HolographicLeaderboard", null);
        settingsListener = safeCall(() -> new SettingsListener(), "SettingsListener", null);
        CivManager civManager = safeCall(() -> CivManager.getInstance(), "CivManager", null);
        CivVault civVault = safeCall(() -> CivVault.getInstance(), "CivVault", null);
        tradeManager = safeCall(() -> { var t = new TradeManager(this); t.init(); return t; }, "TradeManager", null);
        kitRoleManager = safeCall(() -> { var k = new KitRoleManager(this, configManager); k.loadConfig(); return k; }, "KitRoleManager", null);

        scoreboardManager = safeCall(() -> { var s = new ScoreboardManager(this); s.start(); return s; }, "ScoreboardManager", null);
        actionBarManager = safeCall(() -> { var a = new ActionBarManager(this); a.start(); return a; }, "ActionBarManager", null);
        if (actionBarManager != null && ffaWeaponManager != null) {
            actionBarManager.setWeaponManager(ffaWeaponManager);
        }

        Bukkit.getScheduler().runTaskTimer(this, () -> { if (questService != null) questService.sweepOnlineRotations(); }, 20L * 60, 20L * 60);

        safeCall((Runnable) () -> registerCommands(), "registerCommands");
        safeCall((Runnable) this::registerListeners, "registerListeners");
        getLogger().info("UnstableRemix enabled.");
    }

    public void refreshPlaceholderExpansions() {
        unregisterPlaceholderExpansions();
        registerPlaceholderExpansions();
    }

    private void registerPlaceholderExpansions() {
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") == null) {
            return;
        }
        QuestPlaceholderExpansion unstable = new QuestPlaceholderExpansion("unstable", this, questService);
        QuestPlaceholderExpansion remix = new QuestPlaceholderExpansion("remix", this, questService);
        unstable.register();
        remix.register();
        placeholderExpansions.add(unstable);
        placeholderExpansions.add(remix);
        getLogger().info("Registered PlaceholderAPI quest placeholders: unstable, remix.");
    }

    private void unregisterPlaceholderExpansions() {
        for (QuestPlaceholderExpansion expansion : placeholderExpansions) {
            expansion.unregister();
        }
        placeholderExpansions.clear();
    }

    private void registerCommands() {
        bind("map", new MapCommand(this, arenaManager, worldEditBridge, citizensHook));
        registerDirectCommand("arenaadmin", new ArenaAdminCommand(this, arenaManager, worldEditBridge));
        bind("effects", new EffectsCommand(effectsManager));
        bind("rentarank", new RentRankCommand(rentRankManager));
        bind("quests", new QuestCommand(questService));
        bind("kits", new KitCommand(kitManager));
        bind("kit", new KitCommand(kitManager));
        bind("coreadmin", new CoreAdminCommand(kitManager));
        bind("bounty", new BountyCommand(bountyManager));
        bind("mapvote", new MapVoteCommand(mapVoteManager));
        bind("adminmapvote", new AdminMapVoteCommand(mapVoteManager, arenaManager));
        bind("arenaevents", new ArenaEventsCommand(arenaEventEngine));
        registerDirectCommand("adminevents", new AdmineventsCommand(this, eventManager, arenaEventEngine, electionManager));

        registerDirectCommand("shards", new ShardsCommand(economyService));
        registerDirectCommand("balance", new BalanceCommand(economyService));
        registerDirectCommand("pay", new PayCommand(economyService));
        registerDirectCommand("adminshards", new AdminShardsCommand(economyService));
        registerDirectCommand("admintoken", new AdminTokenCommand(economyService));
        registerDirectCommand("prestige", new PrestigeCommand(prestigeManager));
        if (dailyLoginManager != null) {
            registerDirectCommand("dailylogin", new DailyLoginCommand(dailyLoginManager));
        } else {
            registerDirectCommand("login", new DailyRewardCommand(dailyRewardManager));
        }
        registerDirectCommand("vault", new VaultCommand(vaultManager));
        bind("faction", new FactionCommand(this, factionManager, factionSelectionManager));
        if (electionManager != null) {
            registerDirectCommand("vote", new VoteCommand(this, electionManager));
            registerDirectCommand("campaign", new CampaignCommand(this, electionManager, factionManager));
        }
        bind("afk", new AfkZoneCommand(afkZoneManager));
        registerDirectCommand("kitcooldown", new KitCooldownCommand(this, kitCooldownManager));
        registerDirectCommand("cooldownitem", new CooldownItemCommand(cooldownItemManager));
        registerDirectCommand("shop", new ShopCommand(shopManager));
        registerDirectCommand("adminshop", new AdminShopCommand(shopManager));
        registerDirectCommand("adminkitshop", new AdminKitShopCommand(this, kitManager));
        registerDirectCommand("leaderboard", new LeaderboardCommand(this, leaderboardManager));
        registerDirectCommand("broadcastnpc", new BroadcastNpcCommand(broadcastNpcManager));
        registerDirectCommand("lobby", new LobbyCommand(this));
        registerDirectCommand("follow", new FollowCommand(this));
        registerDirectCommand("discord", new DiscordCommand(this));
        registerDirectCommand("stats", new StatsCommand(this));
        registerDirectCommand("media", new MediaCommand(this));
        registerDirectCommand("medialink", new MediaLinkCommand(this));
        registerDirectCommand("adminmedia", new AdminMediaCommand(this));
        bind("blackjack", new BlackjackCommand(this));
        registerDirectCommand("report", new ReportCommand(this));
        registerDirectCommand("trash", new TrashCommand(this));
        registerDirectCommand("rules", new RulesCommand(this));
        registerDirectCommand("guide", new GuideCommand(this));
        bind("setup", new ArenaSetupCommand(this, arenaManager, worldEditBridge));
        bind("kiteditor", new KitEditorCommand(this, kitManager));
        if (ffaWeaponManager != null) {
            bind("weapons", new FFAWeaponCommand(ffaWeaponManager));
        }
        if (holographicLeaderboard != null) {
            registerDirectCommand("hologram", new HologramCommand(this, holographicLeaderboard));
        }
        if (settingsListener != null) {
            registerDirectCommand("settings", new SettingsCommand(settingsListener));
        }
        CivCommand civCommand = new CivCommand(economyService);
        registerDirectCommand("civ", civCommand);
        if (tradeManager != null) {
            TradeListener tradeListener = new TradeListener(tradeManager);
            registerDirectCommand("trade", new TradeCommand(this, tradeManager, tradeListener));
        }
        if (kitRoleManager != null) {
            KitRoleCommand kitRoleCommand = new KitRoleCommand(this, kitRoleManager);
            registerDirectCommand("kitrole", kitRoleCommand);
        }

        PluginCommand admin = getCommand("admin");
        if (admin == null) {
            getLogger().warning("Missing command registration: admin");
        } else {
            AdminKitCommand adminKitCommand = new AdminKitCommand(kitManager);
            admin.setExecutor(adminKitCommand);
            admin.setTabCompleter(adminKitCommand);
        }

        PluginCommand unstable = getCommand("unstable");
        if (unstable == null) {
            getLogger().warning("Missing command registration: unstable");
        } else {
            UnstableAdminCommand adminCommand = new UnstableAdminCommand(this, configManager, arenaManager, effectsManager, questService);
            unstable.setExecutor(adminCommand);
            unstable.setTabCompleter(adminCommand);
        }
    }

    private void registerDirectCommand(String name, org.bukkit.command.CommandExecutor command) {
        PluginCommand pluginCommand = getCommand(name);
        if (pluginCommand == null) {
            getLogger().warning("Missing command registration: " + name);
            return;
        }
        pluginCommand.setExecutor(command);
        if (command instanceof org.bukkit.command.TabCompleter completer) {
            pluginCommand.setTabCompleter(completer);
        }
    }

    private void bind(String name, lol.folium.unstable.command.SubCommand command) {
        PluginCommand pluginCommand = getCommand(name);
        if (pluginCommand == null) {
            getLogger().warning("Missing command registration: " + name);
            return;
        }
        pluginCommand.setExecutor(command);
        pluginCommand.setTabCompleter(command);
    }

    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new GuiListener(), this);
        playerLifecycleListener = new PlayerLifecycleListener(this, playerDataStore, effectsManager, combatTagManager, dailyRewardManager, dailyLoginManager, factionSelectionManager);
        getServer().getPluginManager().registerEvents(playerLifecycleListener, this);
        getServer().getPluginManager().registerEvents(new CombatListener(questService, combatTagManager, kitManager, bountyManager, killCounterManager, factionManager, economyService, this), this);
        getServer().getPluginManager().registerEvents(new CombatGuardListener(combatTagManager), this);
        getServer().getPluginManager().registerEvents(new ChatCooldownListener(this), this);
        getServer().getPluginManager().registerEvents(new ArenaBlockListener(this, arenaManager, blockDespawnManager), this);
        getServer().getPluginManager().registerEvents(new MapVoteListener(mapVoteManager), this);
        getServer().getPluginManager().registerEvents(new ArenaEventListener(arenaEventEngine), this);
        getServer().getPluginManager().registerEvents(vibrationManager, this);
        getServer().getPluginManager().registerEvents(new FactionListener(this, factionManager, factionSelectionManager), this);
        getServer().getPluginManager().registerEvents(new FireworkListener(this, kitCooldownManager), this);
        getServer().getPluginManager().registerEvents(new CooldownItemListener(this, cooldownItemManager, kitCooldownManager), this);
        getServer().getPluginManager().registerEvents(new NoRestrictedItemsListener(arenaManager), this);
        if (ffaWeaponManager != null) {
            getServer().getPluginManager().registerEvents(new FFAWeaponListener(this, ffaWeaponManager), this);
        }
        if (citizensHook != null && citizensHook.isAvailable()) {
            MapNpcListener mapNpcListener = new MapNpcListener(this, arenaManager, citizensHook, mapVoteManager);
            getServer().getPluginManager().registerEvents(mapNpcListener, this);
            getServer().getPluginManager().registerEvents(mapNpcListener.new JoinGuiListener(), this);
        }
        if (electionManager != null) {
            getServer().getPluginManager().registerEvents(new ElectionListeners(electionManager), this);
        }
        if (scoreboardManager != null) {
            getServer().getPluginManager().registerEvents(scoreboardManager, this);
        }
        getServer().getPluginManager().registerEvents(new BlackjackListener(), this);
        getServer().getPluginManager().registerEvents(new TrashCommand(this).createListener(), this);
        getServer().getPluginManager().registerEvents(new RulesCommand(this).createListener(), this);
        getServer().getPluginManager().registerEvents(new GuideCommand(this).createListener(), this);
        if (citizensHook != null && citizensHook.isAvailable()) {
            getServer().getPluginManager().registerEvents(new HubNpcListener(this, citizensHook), this);
        }
        if (settingsListener != null) {
            getServer().getPluginManager().registerEvents(settingsListener, this);
        }
        CivCommand civCmd = new CivCommand(economyService);
        CivListener civListener = new CivListener(civCmd, economyService);
        getServer().getPluginManager().registerEvents(civListener, this);
        getServer().getPluginManager().registerEvents(new CivChatListener(civCmd, economyService), this);
        if (tradeManager != null) {
            getServer().getPluginManager().registerEvents(new TradeListener(tradeManager), this);
        }
        if (kitRoleManager != null) {
            KitRoleCommand kitRoleCommand = new KitRoleCommand(this, kitRoleManager);
            getServer().getPluginManager().registerEvents(new KitRoleListener(kitRoleManager), this);
            getServer().getPluginManager().registerEvents(kitRoleCommand, this);
        }
    }

    @Override
    public void onDisable() {
        if (effectsManager != null) {
            effectsManager.stopTasks();
        }
        if (vibrationManager != null) {
            vibrationManager.stop();
        }
        if (mapVoteManager != null) {
            mapVoteManager.stop();
        }
        if (eventManager != null) {
            eventManager.stop();
        }
        if (blockDespawnManager != null) {
            blockDespawnManager.stop();
        }
        if (arenaEventEngine != null) {
            arenaEventEngine.stop();
        }
        if (combatTagManager != null) {
            combatTagManager.stop();
        }
        if (kitManager != null) {
            kitManager.restoreOpenEditors();
        }
        if (afkZoneManager != null) {
            afkZoneManager.stopTasks();
        }
        if (factionManager != null) {
            factionManager.stopTasks();
        }
        if (electionManager != null) {
            electionManager.stopTasks();
        }
        if (electionDataStore != null) {
            electionDataStore.close();
        }
        if (bountyManager != null) {
            bountyManager.stopGlowTask();
            bountyManager.save();
        }
        if (leaderboardManager != null) {
            leaderboardManager.close();
        }
        if (dashboardServer != null) {
            dashboardServer.stop();
        }
        if (broadcastNpcManager != null) {
            broadcastNpcManager.shutdown();
        }
        if (scoreboardManager != null) {
            scoreboardManager.stop();
        }
        if (actionBarManager != null) {
            actionBarManager.stop();
        }
        if (playerLifecycleListener != null) {
            playerLifecycleListener.shutdown();
        }
        if (holographicLeaderboard != null) {
            holographicLeaderboard.removeAll();
            holographicLeaderboard.cancel();
        }
        CivManager.getInstance().saveAll();
        CivVault.getInstance().saveAll();
        SettingsManager.getInstance().saveAll();

        unregisterPlaceholderExpansions();
        if (playerDataStore != null) {
            playerDataStore.close();
        }
        getLogger().info("UnstableRemix disabled.");
    }

    public static UnstableRemixPlugin getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public EconomyService getEconomyService() {
        return economyService;
    }

    public ArenaManager getArenaManager() {
        return arenaManager;
    }

    public ShopManager getShopManager() {
        return shopManager;
    }

    public KitCooldownManager getKitCooldownManager() {
        return kitCooldownManager;
    }

    public CooldownItemManager getCooldownItemManager() {
        return cooldownItemManager;
    }

    public ArenaRegenerator getArenaRegenerator() {
        return arenaRegenerator;
    }

    public QuestService getQuestService() {
        return questService;
    }

    public MapVoteManager getMapVoteManager() {
        return mapVoteManager;
    }

    public LuckPermsHook getLuckPermsHook() {
        return luckPermsHook;
    }

    public MediaRankManager getMediaRankManager() {
        return mediaRankManager;
    }

    public CombatTagManager getCombatTagManager() {
        return combatTagManager;
    }

    public KitManager getKitManager() {
        return kitManager;
    }

    public BountyManager getBountyManager() {
        return bountyManager;
    }

    public EventManager getEventManager() {
        return eventManager;
    }

    public PlayerDataStore getPlayerDataStore() {
        return playerDataStore;
    }

    public ScoreboardManager getScoreboardManager() {
        return scoreboardManager;
    }

    public FactionManager getFactionManager() {
        return factionManager;
    }

    private static final String[] APPROVED_KIT_FILES = {
        "egg", "FlameFrags", "InvisWemmbu", "JadenMan", "LettuceK",
        "ManePear", "MinuteTech", "ParrotX2", "SpokeIshere",
        "TheoBaldTheBird", "Wemmbu"
    };

    private static final java.util.Set<String> APPROVED_KIT_IDS = java.util.Arrays.stream(APPROVED_KIT_FILES)
            .map(s -> s.toLowerCase(java.util.Locale.ROOT))
            .collect(java.util.stream.Collectors.toSet());

    private void extractKitImportFiles() {
        File dir = new File(getDataFolder(), "kits-import");
        dir.mkdirs();

        for (String name : APPROVED_KIT_FILES) {
            try {
                saveResource("kits-import/" + name + ".yml", true);
            } catch (Exception e) {
                getLogger().warning("Could not extract kit file: " + name + ".yml");
            }
        }

        File[] existing = dir.listFiles((d, n) -> n.endsWith(".yml") || n.endsWith(".YML"));
        if (existing != null) {
            for (File f : existing) {
                String id = f.getName().replaceAll("(?i)\\.yml$", "").toLowerCase(java.util.Locale.ROOT);
                if (!APPROVED_KIT_IDS.contains(id)) {
                    if (f.delete()) {
                        getLogger().info("Deleted stale kit import file: " + f.getName());
                    }
                }
            }
        }
    }

    private void cleanupStaleKits() {
        if (kitManager == null) return;
        java.util.List<String> toRemove = new java.util.ArrayList<>();
        for (String kitId : kitManager.kitIds()) {
            if (!APPROVED_KIT_IDS.contains(kitId.toLowerCase(java.util.Locale.ROOT))) {
                toRemove.add(kitId);
            }
        }
        if (!toRemove.isEmpty()) {
            org.bukkit.configuration.file.FileConfiguration config = getConfigManager().get("kits.yml");
            for (String id : toRemove) {
                config.set("kits." + id, null);
                getLogger().info("Removed stale kit from kits.yml: " + id);
            }
            try {
                getConfigManager().save("kits.yml");
            } catch (java.io.IOException e) {
                getLogger().severe("Failed saving kits.yml after cleanup: " + e.getMessage());
            }
            kitManager.reload();
        }
    }

    private void safeCall(Runnable block, String name) {
        try {
            block.run();
        } catch (Exception e) {
            getLogger().severe("Failed to initialize " + name + ": " + e.getMessage());
            if (getConfig().getBoolean("debug", false)) e.printStackTrace();
        }
    }

    private <T> T safeCall(java.util.concurrent.Callable<T> block, String name, T fallback) {
        try {
            return block.call();
        } catch (Exception e) {
            getLogger().severe("Failed to initialize " + name + ": " + e.getMessage());
            if (getConfig().getBoolean("debug", false)) e.printStackTrace();
            return fallback;
        }
    }
}
