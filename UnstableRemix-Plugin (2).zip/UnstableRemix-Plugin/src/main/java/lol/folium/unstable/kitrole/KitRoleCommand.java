package lol.folium.unstable.kitrole;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.map.Arena;
import lol.folium.unstable.util.GuiTheme;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

import java.util.*;

public class KitRoleCommand implements CommandExecutor, Listener {

    private final KitRoleManager manager;
    private final UnstableRemixPlugin plugin;

    private record GuiHolder(Inventory inv) implements InventoryHolder {
        @Override
        public @NotNull Inventory getInventory() { return inv; }
    }

    public KitRoleCommand(UnstableRemixPlugin plugin, KitRoleManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Players only.");
            return true;
        }

        if (args.length == 0) {
            openFactionSelectGUI(player);
            return true;
        }

        String sub = args[0].toLowerCase();
        switch (sub) {
            case "start" -> {
                if (!player.hasPermission("unstableremix.kitrole.admin")) {
                    player.sendMessage(TextUtil.parse("<red>No permission.</red>"));
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage(TextUtil.parse("<red>/kitrole start <arena></red>"));
                    return true;
                }
                String arenaName = args[1];
                if (manager.startGame(arenaName)) {
                    player.sendMessage(TextUtil.parse("<green>Kit Role game started on " + arenaName + "!</green>"));
                } else {
                    player.sendMessage(TextUtil.parse("<red>Could not start game. Is it already running? Does the arena exist?</red>"));
                }
            }
            case "stop" -> {
                if (!player.hasPermission("unstableremix.kitrole.admin")) {
                    player.sendMessage(TextUtil.parse("<red>No permission.</red>"));
                    return true;
                }
                manager.stopGame();
                player.sendMessage(TextUtil.parse("<yellow>Kit Role game stopped.</yellow>"));
            }
            case "reload" -> {
                if (!player.hasPermission("unstableremix.kitrole.admin")) {
                    player.sendMessage(TextUtil.parse("<red>No permission.</red>"));
                    return true;
                }
                manager.loadConfig();
                player.sendMessage(TextUtil.parse("<green>Kit Role config reloaded.</green>"));
            }
            case "info" -> {
                openInfoGUI(player);
            }
            case "faction" -> {
                if (args.length < 2) {
                    player.sendMessage(TextUtil.parse("<red>/kitrole faction <name></red>"));
                    return true;
                }
                String faction = args[1].toLowerCase();
                if (!manager.getFactionDefinitions().containsKey(faction)) {
                    player.sendMessage(TextUtil.parse("<red>Unknown faction: " + faction + "</red>"));
                    return true;
                }
                manager.joinFaction(player.getUniqueId(), faction);
                player.sendMessage(TextUtil.parse("<green>You joined the " + manager.getFactionDefinitions().get(faction).displayName() + " faction!</green>"));
            }
            default -> openFactionSelectGUI(player);
        }
        return true;
    }

    private void openFactionSelectGUI(Player player) {
        Map<String, KitRoleManager.FactionDefinition> factions = manager.getFactionDefinitions();
        int size = Math.max(9, ((factions.size() / 9) + 1) * 9);
        Inventory inv = Bukkit.createInventory(new GuiHolder(null), size, TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700>Kit Role - Choose Faction</gradient>"));
        // Fix: GuiHolder needs the inv reference
        inv = Bukkit.createInventory(null, size, TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700>Kit Role - Choose Faction</gradient>"));

        int slot = 0;
        for (var entry : factions.entrySet()) {
            KitRoleManager.FactionDefinition f = entry.getValue();
            List<Component> lore = new ArrayList<>();
            lore.add(Component.empty());
            for (String line : f.kitLore()) {
                lore.add(TextUtil.parse("<gray>" + line + "</gray>"));
            }
            lore.add(Component.empty());
            lore.add(TextUtil.parse("<gold>Role Kill Multiplier: " + f.roleKillMultiplier() + "x</gold>"));
            lore.add(Component.empty());
            lore.add(TextUtil.parse("<yellow>Click to join this faction</yellow>"));

            // Determine material based on faction
            Material mat = switch (f.key().toLowerCase()) {
                case "law" -> Material.IRON_SWORD;
                case "mafia" -> Material.NETHERITE_SWORD;
                case "pirate" -> Material.TRIDENT;
                case "king" -> Material.GOLDEN_SWORD;
                default -> Material.DIAMOND_SWORD;
            };

            inv.setItem(slot, ItemBuilder.of(mat)
                    .name(TextUtil.parse("<" + GuiTheme.colorToHex(f.color()) + ">" + f.displayName() + "</" + GuiTheme.colorToHex(f.color()) + ">"))
                    .build());
            slot++;
        }

        // Info button
        inv.setItem(size - 1, ItemBuilder.of(Material.BOOK)
                .name(TextUtil.parse("<aqua>Game Info</aqua>"))
                .lore(java.util.List.of(TextUtil.parse("<gray>Click to see rules and roles</gray>")))
                .build());

        player.openInventory(inv);
    }

    private void openInfoGUI(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700>Kit Role - Game Info</gradient>"));

        // Rules
        inv.setItem(11, ItemBuilder.of(Material.BOOK)
                .name(TextUtil.parse("<gold>Game Rules</gold>"))
                .lore(
                        TextUtil.parse("<gray>1. Choose a faction at spawn</gray>"),
                        TextUtil.parse("<gray>2. Random players become role holders</gray>"),
                        TextUtil.parse("<gray>3. Killing a role player = " + plugin.getConfig().getInt("kit-roles.role-kill-reward-multiplier", 3) + "x rewards</gray>"),
                        TextUtil.parse("<gray>4. Roles transfer on death</gray>"),
                        TextUtil.parse("<gray>5. Roles expire after " + plugin.getConfig().getInt("kit-roles.role-duration-minutes", 15) + " minutes</gray>")
                )
                .build());

        // Roles
        inv.setItem(13, ItemBuilder.of(Material.PLAYER_HEAD)
                .name(TextUtil.parse("<light_purple>Special Roles</light_purple>"))
                .lore(buildRoleLore())
                .build());

        // Factions
        inv.setItem(15, Material.BANNER.createBlockState().getType() == Material.BANNER ? ItemBuilder.of(Material.RED_BANNER)
                .name(TextUtil.parse("<aqua>Factions</aqua>"))
                .lore(buildFactionLore())
                .build() : ItemBuilder.of(Material.RED_BANNER)
                .name(TextUtil.parse("<aqua>Factions</aqua>"))
                .lore(buildFactionLore())
                .build());

        player.openInventory(inv);
    }

    private List<Component> buildRoleLore() {
        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        for (var entry : manager.getRoleDefinitions().entrySet()) {
            KitRoleManager.RoleDefinition role = entry.getValue();
            lore.add(TextUtil.parse("<" + GuiTheme.colorToHex(role.color()) + ">" + role.displayName() + "</" + GuiTheme.colorToHex(role.color()) + ">"));
        }
        if (manager.getRoleDefinitions().isEmpty()) {
            lore.add(TextUtil.parse("<gray>No roles configured</gray>"));
        }
        return lore;
    }

    private List<Component> buildFactionLore() {
        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        for (var entry : manager.getFactionDefinitions().entrySet()) {
            KitRoleManager.FactionDefinition f = entry.getValue();
            lore.add(TextUtil.parse("<" + GuiTheme.colorToHex(f.color()) + ">" + f.displayName() + "</" + GuiTheme.colorToHex(f.color()) + ">"));
        }
        return lore;
    }

    // ============ GUI LISTENER ============

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getView().getTitle() == null) return;
        String title = event.getView().getTitle();
        if (!title.contains("Kit Role")) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;

        event.setCancelled(true);
        if (event.getClick() != ClickType.LEFT && event.getClick() != ClickType.RIGHT) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;

        String itemName = clicked.getItemMeta() != null && clicked.getItemMeta().displayName() != null
                ? net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().serialize(clicked.getItemMeta().displayName())
                : "";

        if (title.contains("Choose Faction")) {
            // Find faction by matching display name
            for (var entry : manager.getFactionDefinitions().entrySet()) {
                if (itemName.contains(entry.getValue().displayName())) {
                    manager.getPlayerFactions().put(player.getUniqueId(), entry.getKey());
                    player.closeInventory();
                    player.sendMessage(TextUtil.parse("<green>You joined the " + entry.getValue().displayName() + " faction!</green>"));
                    return;
                }
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTitle() == null) return;
        if (!event.getView().getTitle().contains("Kit Role")) return;
        event.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        // No-op, just prevent leaks
    }

    // Public getter needed for listener registration
    public KitRoleManager getManager() { return manager; }
}
