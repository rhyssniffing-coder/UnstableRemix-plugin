package lol.folium.unstable.shop;

import lol.folium.unstable.util.TextUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;

public final class ShopCommand implements CommandExecutor, TabCompleter {

    private final ShopManager shop;

    public ShopCommand(ShopManager shop) {
        this.shop = shop;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        int page = 0;
        if (args.length > 0) {
            try {
                page = Integer.parseInt(args[0]) - 1;
            } catch (NumberFormatException e) {
                int idx = shop.pageIds().indexOf(args[0].toLowerCase());
                if (idx >= 0) page = idx;
            }
        }
        shop.openShop(player, page);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> ids = shop.pageIds();
            List<String> result = new java.util.ArrayList<>();
            for (int i = 0; i < ids.size(); i++) {
                result.add(String.valueOf(i + 1));
            }
            result.addAll(ids);
            String prefix = args[0].toLowerCase();
            return result.stream().filter(s -> s.toLowerCase().startsWith(prefix)).toList();
        }
        return Collections.emptyList();
    }
}
