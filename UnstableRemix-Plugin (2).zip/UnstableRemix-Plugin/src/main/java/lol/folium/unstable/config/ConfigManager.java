package lol.folium.unstable.config;

import lol.folium.unstable.UnstableRemixPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public final class ConfigManager {

    private final UnstableRemixPlugin plugin;
    private final Map<String, FileConfiguration> configs = new HashMap<>();

    public ConfigManager(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadAll() {
        plugin.saveDefaultConfig();
        load("effects.yml");
        load("rent-ranks.yml");
        load("quests.yml");
        load("kits.yml");
    }

    public void reloadAll() {
        plugin.reloadConfig();
        reload("effects.yml");
        reload("rent-ranks.yml");
        reload("quests.yml");
        reload("kits.yml");
    }

    public FileConfiguration get(String fileName) {
        return configs.computeIfAbsent(fileName, this::load);
    }

    public FileConfiguration main() {
        return plugin.getConfig();
    }

    public void save(String fileName) throws IOException {
        File file = new File(plugin.getDataFolder(), fileName);
        FileConfiguration config = configs.get(fileName);
        if (config != null) {
            config.save(file);
        }
    }

    private FileConfiguration load(String fileName) {
        File file = new File(plugin.getDataFolder(), fileName);
        if (!file.exists()) {
            try {
                plugin.saveResource(fileName, false);
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Resource not found in jar: " + fileName + " — using empty config");
            }
        }
        if (!file.exists()) {
            plugin.getLogger().warning("File not found: " + fileName + " — using empty config");
        }
        FileConfiguration config = YamlConfiguration.loadConfiguration(file);
        configs.put(fileName, config);
        return config;
    }

    private void reload(String fileName) {
        File file = new File(plugin.getDataFolder(), fileName);
        FileConfiguration config = YamlConfiguration.loadConfiguration(file);
        configs.put(fileName, config);
    }

    public void saveArena(String name, FileConfiguration config) throws IOException {
        File dir = new File(plugin.getDataFolder(), "arenas");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        config.save(new File(dir, name + ".yml"));
    }

    public FileConfiguration loadArena(String name) {
        File file = new File(plugin.getDataFolder(), "arenas/" + name + ".yml");
        if (!file.exists()) {
            return null;
        }
        return YamlConfiguration.loadConfiguration(file);
    }

    public void deleteArena(String name) {
        File file = new File(plugin.getDataFolder(), "arenas/" + name + ".yml");
        if (file.exists()) {
            file.delete();
        }
        File schem = new File(plugin.getDataFolder(), plugin.getConfig().getString("map.schematic-folder", "schematics") + "/" + name + ".schem");
        if (schem.exists()) {
            schem.delete();
        }
    }

    // ── Lobby location ─────────────────────────────────────────────

    public Location readLobby() {
        FileConfiguration cfg = plugin.getConfig();
        if (!cfg.contains("lobby.world")) {
            return null;
        }
        World world = Bukkit.getWorld(cfg.getString("lobby.world"));
        if (world == null) return null;
        return new Location(
                world,
                cfg.getDouble("lobby.x"),
                cfg.getDouble("lobby.y"),
                cfg.getDouble("lobby.z"),
                (float) cfg.getDouble("lobby.yaw"),
                (float) cfg.getDouble("lobby.pitch")
        );
    }

    public void writeLobby(Location location) {
        FileConfiguration cfg = plugin.getConfig();
        if (location == null || location.getWorld() == null) {
            cfg.set("lobby", null);
        } else {
            cfg.set("lobby.world", location.getWorld().getName());
            cfg.set("lobby.x", location.getX());
            cfg.set("lobby.y", location.getY());
            cfg.set("lobby.z", location.getZ());
            cfg.set("lobby.yaw", (double) location.getYaw());
            cfg.set("lobby.pitch", (double) location.getPitch());
        }
        plugin.saveConfig();
    }
}
