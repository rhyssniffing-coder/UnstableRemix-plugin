package lol.folium.unstable.command;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.entity.Player;

import java.util.List;

public final class AdminMediaCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;

    public AdminMediaCommand(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length == 0) {
            player.sendMessage(TextUtil.parse("<gold><bold>/adminmedia</bold></gold>"));
            player.sendMessage(TextUtil.parse("<gray>Set the message broadcasted by <white>/media</white></gray>"));
            player.sendMessage(TextUtil.parse("<yellow>/adminmedia set <message...></yellow> <dark_gray>- Set the media broadcast message</dark_gray>"));
            player.sendMessage(TextUtil.parse("<yellow>/adminmedia preview</yellow> <dark_gray>- Preview the current message</dark_gray>"));
            player.sendMessage(TextUtil.parse("<yellow>/adminmedia reset</yellow> <dark_gray>- Reset to default message</dark_gray>"));
            return;
        }

        String sub = args[0].toLowerCase();

        if (sub.equals("preview")) {
            String message = plugin.getConfig().getString("media.message",
                    "<gold><bold>MEDIA RANK</bold></gold> <gray>|</gray> <white>Get the Media rank by posting clips of UnstableRemix on TikTok, YouTube, or Twitter! Tag us and get noticed.</white>");
            player.sendMessage(TextUtil.parse("<gold>Current media message:</gold>"));
            player.sendMessage(TextUtil.parse(message));
            return;
        }

        if (sub.equals("reset")) {
            plugin.getConfig().set("media.message", null);
            plugin.saveConfig();
            player.sendMessage(TextUtil.parse("<green>Media message reset to default.</green>"));
            return;
        }

        if (sub.equals("set")) {
            if (args.length < 2) {
                player.sendMessage(TextUtil.parse("<red>Usage: /adminmedia set <message...>"));
                return;
            }
            StringBuilder message = new StringBuilder();
            for (int i = 1; i < args.length; i++) {
                if (i > 1) message.append(" ");
                message.append(args[i]);
            }
            plugin.getConfig().set("media.message", message.toString());
            plugin.saveConfig();
            player.sendMessage(TextUtil.parse("<green>Media message updated!</green>"));
            player.sendMessage(TextUtil.parse(message.toString()));
            return;
        }

        player.sendMessage(TextUtil.parse("<red>Unknown subcommand. Use /adminmedia for help."));
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            return filter(literals("set", "preview", "reset"), args[0]);
        }
        return List.of();
    }

    @Override
    protected String permission() {
        return "unstable.admin";
    }
}
