package lol.folium.unstable.combat;

import lol.folium.unstable.util.TextUtil;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.Map;

public final class CombatGuardListener implements Listener {

    private final CombatTagManager combatTags;

    public CombatGuardListener(CombatTagManager combatTags) {
        this.combatTags = combatTags;
    }

    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!combatTags.isTagged(event.getPlayer()) || !combatTags.isBlockedCommand(event.getMessage().substring(1))) {
            return;
        }
        event.setCancelled(true);
        event.getPlayer().sendMessage(TextUtil.parse(TextUtil.apply(
                "<red>You cannot use that menu while combat tagged. <gray>({seconds}s)</gray>",
                Map.of("seconds", String.valueOf(combatTags.remainingSeconds(event.getPlayer()))))));
    }
}
