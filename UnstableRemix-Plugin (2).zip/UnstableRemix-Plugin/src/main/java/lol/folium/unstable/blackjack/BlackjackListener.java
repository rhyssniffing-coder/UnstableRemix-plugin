package lol.folium.unstable.blackjack;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.economy.EconomyService;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

public final class BlackjackListener implements Listener {

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getView().title() == null) return;

        // Bet GUI
        if (event.getView().title().equals(BlackjackBetGui.getTitle())) {
            event.setCancelled(true);
            long bet = BlackjackBetGui.getBetForSlot(event.getRawSlot());
            if (bet <= 0) return;

            long balance = Bukkit.getPluginManager().getPlugin("UnstableRemix") instanceof UnstableRemixPlugin plugin
                    ? plugin.getEconomyService().getShards(player.getUniqueId()) : 0;
            if (balance < bet) {
                player.sendMessage("§cNot enough shards!");
                return;
            }

            player.closeInventory();
            BlackjackGame.startGame(player,
                    Bukkit.getPluginManager().getPlugin("UnstableRemix") instanceof UnstableRemixPlugin p
                            ? p.getEconomyService() : null,
                    bet);
            BlackjackGame game = BlackjackGame.getActive(player.getUniqueId());
            if (game != null) {
                BlackjackGui.open(player, game);
            }
            return;
        }

        // Game GUI
        if (!event.getView().title().equals(BlackjackGui.getTitle())) return;

        event.setCancelled(true);

        BlackjackGame game = BlackjackGame.getActive(player.getUniqueId());
        if (game == null) return;

        BlackjackGui.handleClick(event, player, game);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTitle() == null) return;
        String title = event.getView().getTitle();
        if (title.equals(BlackjackBetGui.getTitle()) || title.equals(BlackjackGui.getTitle())) {
            event.setCancelled(true);
        }
    }
}
