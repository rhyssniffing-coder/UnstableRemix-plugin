package lol.folium.unstable.vault;

import lol.folium.unstable.util.TextUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;

public final class VaultCommand implements CommandExecutor, TabCompleter {

    private final VaultManager vault;

    public VaultCommand(VaultManager vault) {
        this.vault = vault;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("buy")) {
            vault.upgrade(player);
            return true;
        }
        vault.openVault(player);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("buy");
        }
        return Collections.emptyList();
    }
}