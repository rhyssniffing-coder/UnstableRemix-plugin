package lol.folium.unstable.command;

import lol.folium.unstable.economy.CurrencyType;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.economy.TransactionResult;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class AdminShardsCommand implements CommandExecutor, TabCompleter {

    private final EconomyService economy;

    public AdminShardsCommand(EconomyService economy) {
        this.economy = economy;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("unstable.economy.admin")) {
            sender.sendMessage(TextUtil.parse("<red>No permission."));
            return true;
        }
        if (args.length >= 2 && args[0].equalsIgnoreCase("all")) {
            handleAll(sender, args);
            return true;
        }
        if (args.length < 3) {
            sender.sendMessage(TextUtil.parse("<yellow>/adminshards <give|remove|set> <player> <amount>"));
            sender.sendMessage(TextUtil.parse("<yellow>/adminshards all <amount>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(TextUtil.parse("<red>Player not found."));
            return true;
        }
        Long amount = parseAmount(args[2], args[0].equalsIgnoreCase("set"));
        if (amount == null) {
            sender.sendMessage(TextUtil.parse("<red>Enter a valid whole number."));
            return true;
        }
        TransactionResult result = switch (args[0].toLowerCase(Locale.ROOT)) {
            case "give" -> economy.grantShards(target.getUniqueId(), amount, "admin:" + sender.getName(), null);
            case "remove" -> economy.removeShards(target.getUniqueId(), amount, "admin:" + sender.getName());
            case "set" -> economy.setShards(target.getUniqueId(), amount, "admin:" + sender.getName());
            default -> TransactionResult.fail("invalid-amount", economy.getShards(target.getUniqueId()));
        };
        if (!result.success()) {
            sender.sendMessage(TextUtil.parse("<red>Transaction failed: " + result.messageKey()));
            return true;
        }
        sender.sendMessage(TextUtil.parse("<green>Updated <white>" + target.getName() + "</white> balance to <light_purple>"
                + result.balanceAfter() + " Shards</light_purple>."));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("unstable.economy.admin")) {
            return Collections.emptyList();
        }
        if (args.length == 1) {
            return filter(List.of("give", "remove", "set", "all"), args[0]);
        }
        if (args.length == 2 && !args[0].equalsIgnoreCase("all")) {
            return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[1]);
        }
        if ((args.length == 2 && args[0].equalsIgnoreCase("all")) || args.length == 3) {
            return List.of("100", "500", "1000");
        }
        return Collections.emptyList();
    }

    private void handleAll(CommandSender sender, String[] args) {
        Long amount = parseAmount(args[1], false);
        if (amount == null) {
            sender.sendMessage(TextUtil.parse("<red>Enter a positive whole number."));
            return;
        }
        for (Player online : Bukkit.getOnlinePlayers()) {
            UUID uuid = online.getUniqueId();
            economy.grantShards(uuid, amount, "admin-all:" + sender.getName(), null);
            online.playSound(online.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.15F);
            economy.notifyGrant(online, CurrencyType.SHARDS, amount, "Admin Grant");
        }
        Bukkit.broadcast(TextUtil.parse("<light_purple><bold>Shard Drop!</bold></light_purple> <gray>Everyone online received <white>"
                + amount + "</white> Shards.</gray>"));
    }

    private Long parseAmount(String raw, boolean allowZero) {
        try {
            long amount = Long.parseLong(raw);
            return amount > 0 || (allowZero && amount == 0) ? amount : null;
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private List<String> filter(List<String> options, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        return options.stream().filter(option -> option.toLowerCase(Locale.ROOT).startsWith(lower)).toList();
    }
}
