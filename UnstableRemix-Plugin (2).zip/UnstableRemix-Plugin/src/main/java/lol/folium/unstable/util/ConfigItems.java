package lol.folium.unstable.util;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

public final class ConfigItems {

    private ConfigItems() {}

    public static Material material(ConfigurationSection section, String path, Material fallback) {
        String raw = section.getString(path);
        if (raw == null) {
            return fallback;
        }
        Material material = Material.matchMaterial(raw);
        return material != null ? material : fallback;
    }

    public static Integer customModelData(ConfigurationSection section, String path) {
        if (!section.contains(path)) {
            return null;
        }
        return section.getInt(path);
    }
}
