package lol.folium.unstable.map;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ArenaBlockListener implements Listener {

    private final UnstableRemixPlugin plugin;
    private final ArenaManager arenas;
    private final BlockDespawnManager blockDespawnManager;

    private boolean blockProtectionEnabled = true;
    private boolean spawnProtectionEnabled = true;
    private int spawnProtectionRadius = 1;
    private int spawnInvulnerableSeconds = 5;

    private final Map<UUID, Long> spawnProtectUntil = new ConcurrentHashMap<>();

    public ArenaBlockListener(UnstableRemixPlugin plugin, ArenaManager arenas, BlockDespawnManager blockDespawnManager) {
        this.plugin = plugin;
        this.arenas = arenas;
        this.blockDespawnManager = blockDespawnManager;
        loadConfig();
    }

    public void loadConfig() {
        blockProtectionEnabled = plugin.getConfig().getBoolean("map.arena.block-protection.enabled", true);
        spawnProtectionEnabled = plugin.getConfig().getBoolean("map.arena.spawn-protection.enabled", true);
        spawnProtectionRadius = plugin.getConfig().getInt("map.arena.spawn-protection.radius", 1);
        spawnInvulnerableSeconds = plugin.getConfig().getInt("map.arena.spawn-protection.invulnerable-seconds", 5);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        arenas.at(event.getBlock().getLocation()).ifPresent(arena -> {
            if (canBuild(player)) {
                return;
            }
            BlockSnapshot snapshot = BlockSnapshot.from(event.getBlock());
            if (arena.placedBlocks().contains(snapshot)) {
                arena.placedBlocks().remove(snapshot);
                if (event.getBlock().getType() == Material.COBWEB) {
                    plugin.getQuestService().trackCobwebBroken(player);
                }
                return;
            }
            if (blockProtectionEnabled) {
                event.setCancelled(true);
                player.sendMessage(TextUtil.parse("<red>You cannot break original arena blocks.</red>"));
            }
        });
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        Block placed = event.getBlockPlaced();
        arenas.at(placed.getLocation()).ifPresent(arena -> {
            if (arena.status() != Arena.Status.IN_GAME && !canBuild(player)) {
                event.setCancelled(true);
                return;
            }
            if (spawnProtectionEnabled && isNearSpawn(placed.getLocation(), arena)) {
                event.setCancelled(true);
                player.sendMessage(TextUtil.parse("<red>You cannot build near spawn!</red>"));
                return;
            }
            BlockSnapshot before = new BlockSnapshot(
                    placed.getWorld().getName(),
                    placed.getX(),
                    placed.getY(),
                    placed.getZ(),
                    event.getBlockReplacedState().getType()
            );
            arena.addPlacedBlock(before);
            blockDespawnManager.trackBlock(placed.getLocation());
            plugin.getQuestService().trackBlockPlaced(player);
        });
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onEntityDamage(org.bukkit.event.entity.EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        Long until = spawnProtectUntil.get(player.getUniqueId());
        if (until != null && System.currentTimeMillis() < until) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onTeleport(PlayerTeleportEvent event) {
        if (event.getTo() == null) return;
        arenas.at(event.getTo()).ifPresent(arena -> {
            onPlayerEnterArena(event.getPlayer(), arena);
        });
    }

    public void onPlayerEnterArena(Player player, Arena arena) {
        if (spawnInvulnerableSeconds > 0) {
            spawnProtectUntil.put(player.getUniqueId(),
                    System.currentTimeMillis() + spawnInvulnerableSeconds * 1000L);
            player.sendMessage(TextUtil.parse("<green>You have <white>" + spawnInvulnerableSeconds + "s</white> of spawn protection!</green>"));
        }
    }

    public void onPlayerLeaveArena(Player player) {
        spawnProtectUntil.remove(player.getUniqueId());
    }

    private boolean isNearSpawn(Location loc, Arena arena) {
        int radius = spawnProtectionRadius;
        for (Location spawn : arena.spawns()) {
            if (spawn == null || spawn.getWorld() == null) continue;
            if (!spawn.getWorld().equals(loc.getWorld())) continue;
            if (Math.abs(loc.getBlockX() - spawn.getBlockX()) <= radius
                    && Math.abs(loc.getBlockY() - spawn.getBlockY()) <= radius
                    && Math.abs(loc.getBlockZ() - spawn.getBlockZ()) <= radius) {
                return true;
            }
        }
        if (arena.spawn1() != null && arena.spawn1().getWorld() != null
                && arena.spawn1().getWorld().equals(loc.getWorld())) {
            if (Math.abs(loc.getBlockX() - arena.spawn1().getBlockX()) <= radius
                    && Math.abs(loc.getBlockY() - arena.spawn1().getBlockY()) <= radius
                    && Math.abs(loc.getBlockZ() - arena.spawn1().getBlockZ()) <= radius) {
                return true;
            }
        }
        if (arena.spawn2() != null && arena.spawn2().getWorld() != null
                && arena.spawn2().getWorld().equals(loc.getWorld())) {
            if (Math.abs(loc.getBlockX() - arena.spawn2().getBlockX()) <= radius
                    && Math.abs(loc.getBlockY() - arena.spawn2().getBlockY()) <= radius
                    && Math.abs(loc.getBlockZ() - arena.spawn2().getBlockZ()) <= radius) {
                return true;
            }
        }
        return false;
    }

    private boolean canBuild(Player player) {
        return player.hasPermission("unstable.build")
                || player.getGameMode() == GameMode.CREATIVE
                || player.getGameMode() == GameMode.SPECTATOR;
    }
}
