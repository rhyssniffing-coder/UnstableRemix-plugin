package lol.folium.unstable.scoreboard;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.data.PlayerProfile;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ScoreboardManager implements Listener {

    private final UnstableRemixPlugin plugin;
    private final Map<UUID, org.bukkit.scoreboard.Scoreboard> boards = new HashMap<>();
    private final Map<UUID, String> rankCache = new ConcurrentHashMap<>();
    private BukkitTask task;
    private boolean enabled;
    private int onlineCountCache = 0;
    private long onlineCountTick = 0;

    public ScoreboardManager(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        setBoard(event.getPlayer());
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        boards.remove(event.getPlayer().getUniqueId());
        rankCache.remove(event.getPlayer().getUniqueId());
    }

    public void start() {
        enabled = plugin.getConfig().getBoolean("scoreboard.enabled", true);
        if (!enabled) return;

        int interval = plugin.getConfig().getInt("scoreboard.update-interval-ticks", 20);
        for (Player player : Bukkit.getOnlinePlayers()) {
            setBoard(player);
        }
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, interval, interval);
    }

    public void stop() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        }
        boards.clear();
        rankCache.clear();
    }

    public void invalidateRank(UUID uuid) {
        rankCache.remove(uuid);
    }

    public void setBoard(Player player) {
        if (!enabled) return;
        String title = plugin.getConfig().getString("scoreboard.title", "<gradient:#FF4444:#FF8800><bold>UnstableRemix</bold></gradient>");
        org.bukkit.scoreboard.Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = board.registerNewObjective("sb", Criteria.DUMMY, TextUtil.parse(title));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        List<String> lines = plugin.getConfig().getStringList("scoreboard.lines");
        int score = lines.size();
        for (int i = 0; i < lines.size(); i++) {
            score--;
            String entryKey = "\u00A7" + i + "\u00A7" + score;
            org.bukkit.scoreboard.Team team = board.registerNewTeam("line_" + score);
            team.addEntry(entryKey);
            obj.getScore(entryKey).setScore(score);
        }
        player.setScoreboard(board);
        boards.put(player.getUniqueId(), board);
    }

    private void tick() {
        List<String> lines = plugin.getConfig().getStringList("scoreboard.lines");
        if (lines.isEmpty()) return;

        long now = System.currentTimeMillis();
        if (now - onlineCountTick > 1000) {
            onlineCountCache = Bukkit.getOnlinePlayers().size();
            onlineCountTick = now;
        }

        for (Player player : Bukkit.getOnlinePlayers()) {
            org.bukkit.scoreboard.Scoreboard board = boards.get(player.getUniqueId());
            if (board == null) {
                setBoard(player);
                board = boards.get(player.getUniqueId());
                if (board == null) continue;
            }
            updateBoard(player, board, lines);
        }
    }

    private void updateBoard(Player player, org.bukkit.scoreboard.Scoreboard board, List<String> lines) {
        Objective obj = board.getObjective(DisplaySlot.SIDEBAR);
        if (obj == null) return;

        PlayerProfile profile = plugin.getPlayerDataStore().get(player.getUniqueId());

        int score = lines.size();
        for (int i = 0; i < lines.size(); i++) {
            score--;
            String raw = lines.get(i);
            if (raw.isEmpty()) {
                raw = " ";
            }
            String parsed = applyPlaceholders(player, profile, raw);
            String entryKey = "\u00A7" + i + "\u00A7" + score;
            org.bukkit.scoreboard.Team team = board.getTeam("line_" + score);
            if (team != null) {
                team.prefix(TextUtil.parse(parsed));
            }
        }
    }

    private String applyPlaceholders(Player player, PlayerProfile profile, String text) {
        long kills = profile.lifetimeKills();
        long deaths = profile.deaths();
        String kd = deaths == 0 ? String.valueOf(kills) : String.format("%.2f", (double) kills / deaths);
        long totalSeconds = profile.playtime();

        String rank = rankCache.computeIfAbsent(player.getUniqueId(), uuid -> {
            if (plugin.getLuckPermsHook() != null) {
                return plugin.getLuckPermsHook().getPrefix(player).orElse("");
            }
            return "";
        });

        String dateStr = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("MMM dd yyyy"));
        String timeStr = java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));

        Map<String, String> placeholders = Map.ofEntries(
                Map.entry("{player}", player.getName()),
                Map.entry("{shards}", formatNumber(profile.shards())),
                Map.entry("{tokens}", formatNumber(profile.tokens())),
                Map.entry("{kills}", formatNumber(kills)),
                Map.entry("{deaths}", formatNumber(deaths)),
                Map.entry("{kd}", kd),
                Map.entry("{best_streak}", formatNumber(profile.highestKillstreak())),
                Map.entry("{prestige}", String.valueOf(profile.prestigeRank())),
                Map.entry("{online_players}", String.valueOf(onlineCountCache)),
                Map.entry("{max_players}", String.valueOf(Bukkit.getMaxPlayers())),
                Map.entry("{playtime}", formatPlaytime(totalSeconds)),
                Map.entry("{rank}", rank),
                Map.entry("{active_arena}", plugin.getMapVoteManager() != null ? plugin.getMapVoteManager().activeArenaName() : "None"),
                Map.entry("{shard_multiplier}", plugin.getEventManager() != null ? String.format("%.1fx", plugin.getEventManager().getShardMultiplier()) : "1.0x"),
                Map.entry("{double_shards}", (plugin.getMapVoteManager() != null && plugin.getMapVoteManager().isDoubleShardsActive()) ? String.format("<gradient:#FFD700:#FF8C00>\u26A1 %.1fx</gradient>", plugin.getMapVoteManager().getDoubleShardsMultiplier()) : ""),
                Map.entry("{time_until_vote}", plugin.getMapVoteManager() != null ? formatDuration(plugin.getMapVoteManager().timeUntilNextVote()) : ""),
                Map.entry("{streak}", plugin.getQuestService() != null ? String.valueOf(plugin.getQuestService().activeKillstreak(player)) : "0"),
                Map.entry("{streak_multiplier}", plugin.getQuestService() != null ? String.format("%.2fx", plugin.getQuestService().shardMultiplier(player)) : "1.00x"),
                Map.entry("{date}", dateStr),
                Map.entry("{time}", timeStr)
        );

        for (Map.Entry<String, String> entry : placeholders.entrySet()) {
            text = text.replace(entry.getKey(), entry.getValue());
        }
        return text;
    }

    private String formatNumber(long n) {
        if (n >= 1_000_000_000) return String.format("%.1fB", n / 1_000_000_000.0);
        if (n >= 1_000_000) return String.format("%.1fM", n / 1_000_000.0);
        if (n >= 10_000) return String.format("%.1fk", n / 1_000.0);
        return String.valueOf(n);
    }

    private String formatPlaytime(long seconds) {
        if (seconds < 60) return seconds + "s";
        if (seconds < 3600) return (seconds / 60) + "m " + (seconds % 60) + "s";
        if (seconds < 86400) return (seconds / 3600) + "h " + ((seconds % 3600) / 60) + "m";
        return (seconds / 86400) + "d " + ((seconds % 86400) / 3600) + "h";
    }

    private String formatDuration(java.time.Duration duration) {
        long total = duration.getSeconds();
        if (total <= 0) return "Now";
        long mins = total / 60;
        long secs = total % 60;
        return mins > 0 ? mins + "m " + secs + "s" : secs + "s";
    }
}
