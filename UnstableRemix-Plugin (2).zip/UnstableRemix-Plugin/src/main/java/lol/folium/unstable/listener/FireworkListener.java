package lol.folium.unstable.listener;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.cooldown.KitCooldownManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class FireworkListener implements Listener {

    private final UnstableRemixPlugin plugin;
    private final KitCooldownManager cooldownManager;
    private final Map<UUID, Long> lastFireworkUse = new ConcurrentHashMap<>();
    private final int cooldownSeconds;

    public FireworkListener(UnstableRemixPlugin plugin, KitCooldownManager cooldownManager) {
        this.plugin = plugin;
        this.cooldownManager = cooldownManager;
        this.cooldownSeconds = plugin.getConfig().getInt("firework-cooldown.seconds", 5);
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (item == null || item.getType() != Material.FIREWORK_ROCKET) return;

        Player player = event.getPlayer();

        if (cooldownManager == null) return;

        if (cooldownManager.hasFireworkBypass(player.getUniqueId())) return;

        long now = System.currentTimeMillis();
        Long lastUse = lastFireworkUse.get(player.getUniqueId());

        if (lastUse != null && now - lastUse < cooldownSeconds * 1000L) {
            long remaining = ((cooldownSeconds * 1000L) - (now - lastUse)) / 1000L;
            event.setCancelled(true);
            player.setCooldown(Material.FIREWORK_ROCKET, (int) remaining * 20);
            player.sendMessage(net.kyori.adventure.text.Component.text(
                    "Firework on cooldown! " + remaining + "s remaining."));
            return;
        }

        lastFireworkUse.put(player.getUniqueId(), now);
        player.setCooldown(Material.FIREWORK_ROCKET, cooldownSeconds * 20);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        lastFireworkUse.remove(event.getPlayer().getUniqueId());
    }
}
