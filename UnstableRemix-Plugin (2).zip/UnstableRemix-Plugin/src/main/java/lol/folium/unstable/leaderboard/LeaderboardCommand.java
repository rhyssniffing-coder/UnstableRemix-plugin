package lol.folium.unstable.leaderboard;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import net.kyori.adventure.text.Component;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class LeaderboardCommand implements CommandExecutor, TabCompleter {

    private static final int[] DISPLAY_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22};
    private static final int ENTRY_SLOT = 23;

    private final UnstableRemixPlugin plugin;
    private final LeaderboardManager leaderboard;
    private final Map<UUID, String> nameCache = new ConcurrentHashMap<>();

    public LeaderboardCommand(UnstableRemixPlugin plugin, LeaderboardManager leaderboard) {
        this.plugin = plugin;
        this.leaderboard = leaderboard;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        LeaderboardManager.Category category = LeaderboardManager.Category.KILLS;
        if (args.length > 0) {
            try {
                category = LeaderboardManager.Category.valueOf(args[0].toUpperCase());
            } catch (IllegalArgumentException e) {
                player.sendMessage(TextUtil.parse("<red>Invalid category. Use: kills, deaths, killstreak, shards, playtime, match_wins, kd_ratio</red>"));
                return true;
            }
        }
        leaderboard.refresh();
        openLeaderboard(player, category);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("kills", "deaths", "killstreak", "shards", "playtime", "match_wins", "kd_ratio");
        }
        return Collections.emptyList();
    }

    private void openLeaderboard(Player player, LeaderboardManager.Category category) {
        LeaderboardManager.LeaderboardSnapshot snapshot = leaderboard.getSnapshot();
        List<LeaderboardManager.LeaderboardEntry> entries = snapshot != null
                ? snapshot.entries.getOrDefault(category, Collections.emptyList())
                : Collections.emptyList();

        LeaderboardHolder holder = new LeaderboardHolder(player, category);
        Inventory inv = Bukkit.createInventory(holder, 36,
                TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700><bold>TOP " + category.displayName.toUpperCase() + "</bold></gradient>"));
        holder.bind(inv);

        ItemStack blackFrame = ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE).name(TextUtil.parse(" ")).build();
        ItemStack purpleFrame = ItemBuilder.of(Material.PURPLE_STAINED_GLASS_PANE).name(TextUtil.parse(" ")).build();
        for (int slot = 0; slot < 36; slot++) {
            int row = slot / 9;
            int col = slot % 9;
            if (row == 0 || row == 3 || row == 4 || row == 5 || col == 0 || col == 8) {
                inv.setItem(slot, (row == 0 || row == 5) ? purpleFrame : blackFrame);
            }
        }

        int rank = 1;
        for (int i = 0; i < Math.min(entries.size(), DISPLAY_SLOTS.length); i++) {
            LeaderboardManager.LeaderboardEntry entry = entries.get(i);
            String name = resolveName(entry.uuid);
            String value = leaderboard.formatValue(category, entry.value);
            Material head = rank <= 3 ? materialForRank(rank) : Material.PLAYER_HEAD;
            List<Component> lore = new ArrayList<>();
            lore.add(TextUtil.parse("<gray>Rank: <white>#" + rank + "</white></gray>"));
            lore.add(TextUtil.parse("<gray>Value: <yellow>" + value + "</yellow></gray>"));

            String entryName;
            if (rank == 1) {
                entryName = "<gold><bold>#1</bold></gold> <gradient:#FFD700:#FFA500>" + name + "</gradient>";
            } else if (rank == 2) {
                entryName = "<gray><bold>#2</bold></gray> <white>" + name + "</white>";
            } else if (rank == 3) {
                entryName = "<#CD7F32><bold>#3</bold></#CD7F32> <white>" + name + "</white>";
            } else {
                entryName = "<dark_gray>#" + rank + "</dark_gray> <white>" + name + "</white>";
            }

            ItemStack item;
            if (head == Material.PLAYER_HEAD) {
                item = ItemBuilder.of(Material.PLAYER_HEAD).name(TextUtil.parse(entryName)).lore(lore).build();
                SkullMeta meta = (SkullMeta) item.getItemMeta();
                OfflinePlayer offline = Bukkit.getOfflinePlayer(entry.uuid);
                if (offline.hasPlayedBefore() || offline.isOnline()) {
                    meta.setOwningPlayer(offline);
                }
                item.setItemMeta(meta);
            } else {
                item = ItemBuilder.of(head).name(TextUtil.parse(entryName)).lore(lore).build();
            }
            inv.setItem(DISPLAY_SLOTS[i], item);
            rank++;
        }

        UUID selfUuid = player.getUniqueId();
        int selfRank = leaderboard.getPlayerRank(category, selfUuid);
        LeaderboardManager.LeaderboardEntry selfEntry = leaderboard.getPlayerEntry(category, selfUuid);

        if (selfEntry != null || selfRank > 0) {
            String selfName = player.getName();
            String selfValue = selfEntry != null ? leaderboard.formatValue(category, selfEntry.value) : "0";
            List<Component> selfLore = new ArrayList<>();
            selfLore.add(TextUtil.parse("<gray>Rank: <white>#" + (selfRank > 0 ? selfRank : "?") + "</white></gray>"));
            selfLore.add(TextUtil.parse("<gray>Value: <yellow>" + selfValue + "</yellow></gray>"));

            ItemStack selfItem = ItemBuilder.of(Material.PLAYER_HEAD)
                    .name(TextUtil.parse("<gradient:#FFD700:#FFA500><bold>\u25C6 YOU \u25C6</bold></gradient>"))
                    .lore(selfLore)
                    .build();
            SkullMeta meta = (SkullMeta) selfItem.getItemMeta();
            meta.setOwningPlayer(player);
            selfItem.setItemMeta(meta);
            inv.setItem(ENTRY_SLOT, selfItem);
        }

        for (int i = 0; i < LeaderboardManager.Category.values().length; i++) {
            LeaderboardManager.Category cat = LeaderboardManager.Category.values()[i];
            boolean active = cat == category;
            ItemStack btn = ItemBuilder.of(cat.icon)
                    .name(TextUtil.parse((active ? "<gradient:#FF4444:#FF8800:#FFD700><bold>" : "<dark_gray>") + cat.displayName + (active ? "</bold></gradient>" : "</dark_gray>")))
                    .lore(active ? List.of(TextUtil.parse("<green>Currently viewing</green>")) : List.of())
                    .glow(active)
                    .build();
            inv.setItem(i + 1, btn);
            holder.categorySlots.put(i + 1, cat);
        }

        player.openInventory(inv);
    }

    private String resolveName(UUID uuid) {
        String cached = nameCache.get(uuid);
        if (cached != null) return cached;
        Player online = Bukkit.getPlayer(uuid);
        if (online != null) {
            nameCache.put(uuid, online.getName());
            return online.getName();
        }
        OfflinePlayer offline = Bukkit.getOfflinePlayer(uuid);
        String name = offline.getName();
        if (name != null) {
            nameCache.put(uuid, name);
            return name;
        }
        String fallback = uuid.toString().substring(0, 8);
        nameCache.put(uuid, fallback);
        return fallback;
    }

    private Material materialForRank(int rank) {
        return switch (rank) {
            case 1 -> Material.PAPER;
            case 2 -> Material.PAPER;
            case 3 -> Material.PAPER;
            default -> Material.PLAYER_HEAD;
        };
    }

    private final class LeaderboardHolder extends GuiHolder {
        private final Player player;
        private final LeaderboardManager.Category currentCategory;
        private final Map<Integer, LeaderboardManager.Category> categorySlots = new HashMap<>();

        LeaderboardHolder(Player player, LeaderboardManager.Category category) {
            this.player = player;
            this.currentCategory = category;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            if (slot < 0 || slot >= event.getInventory().getSize()) return;
            LeaderboardManager.Category cat = categorySlots.get(slot);
            if (cat != null && cat != currentCategory) {
                openLeaderboard(player, cat);
            }
        }
    }
}
