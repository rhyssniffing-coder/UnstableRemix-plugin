package lol.folium.unstable.leaderboard;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import lol.folium.unstable.UnstableRemixPlugin;
import org.bukkit.Bukkit;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Executors;

public final class DashboardServer {

    private final UnstableRemixPlugin plugin;
    private final LeaderboardManager leaderboard;
    private final String apiKey;
    private final int port;
    private HttpServer server;

    public DashboardServer(UnstableRemixPlugin plugin, LeaderboardManager leaderboard) {
        this.plugin = plugin;
        this.leaderboard = leaderboard;
        this.apiKey = plugin.getConfig().getString("leaderboard.dashboard.api-key", "");
        this.port = plugin.getConfig().getInt("leaderboard.dashboard.port", 8080);
    }

    public void start() {
        try {
            server = HttpServer.create(new InetSocketAddress(port), 0);
            server.setExecutor(Executors.newFixedThreadPool(4));

            server.createContext("/", new DashboardHandler());
            server.createContext("/api/leaderboard", new LeaderboardApiHandler());
            server.createContext("/api/player", new PlayerApiHandler());
            server.createContext("/api/stats", new StatsApiHandler());
            server.createContext("/api/players", new PlayerSearchHandler());

            server.start();
            plugin.getLogger().info("Dashboard server started on port " + port);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to start dashboard server: " + e.getMessage());
        }
    }

    public void stop() {
        if (server != null) {
            server.stop(0);
            plugin.getLogger().info("Dashboard server stopped.");
        }
    }

    private boolean checkAuth(HttpExchange exchange) {
        if (apiKey.isEmpty()) return true;
        String auth = exchange.getRequestHeaders().getFirst("Authorization");
        return apiKey.equals(auth);
    }

    private void sendJson(HttpExchange exchange, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.sendResponseHeaders(200, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private void sendHtml(HttpExchange exchange, String html) throws IOException {
        byte[] bytes = html.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
        exchange.sendResponseHeaders(200, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private void sendError(HttpExchange exchange, int code, String message) throws IOException {
        byte[] bytes = ("{\"error\":\"" + message + "\"}").getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private Map<String, String> parseQuery(String query) {
        Map<String, String> params = new HashMap<>();
        if (query == null) return params;
        for (String pair : query.split("&")) {
            int eq = pair.indexOf('=');
            if (eq > 0) {
                params.put(pair.substring(0, eq), pair.substring(eq + 1));
            }
        }
        return params;
    }

    private final class DashboardHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!exchange.getRequestMethod().equals("GET")) {
                sendError(exchange, 405, "Method not allowed");
                return;
            }
            try (InputStream is = plugin.getResource("dashboard/index.html")) {
                if (is == null) {
                    sendError(exchange, 404, "Dashboard not found");
                    return;
                }
                String html = new String(is.readAllBytes(), StandardCharsets.UTF_8);
                sendHtml(exchange, html);
            }
        }
    }

    private final class LeaderboardApiHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!exchange.getRequestMethod().equals("GET")) {
                sendError(exchange, 405, "Method not allowed");
                return;
            }
            sendJson(exchange, leaderboard.toJson());
        }
    }

    private final class PlayerApiHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!exchange.getRequestMethod().equals("GET")) {
                sendError(exchange, 405, "Method not allowed");
                return;
            }
            Map<String, String> params = parseQuery(exchange.getRequestURI().getQuery());
            String uuidStr = params.get("uuid");
            if (uuidStr == null) {
                sendError(exchange, 400, "Missing uuid parameter");
                return;
            }
            try {
                UUID uuid = UUID.fromString(uuidStr);
                var profile = plugin.getPlayerDataStore().get(uuid);
                String name = leaderboard.resolveName(uuid);

                StringBuilder sb = new StringBuilder();
                sb.append("{");
                sb.append("\"uuid\":\"").append(uuid).append("\"");
                sb.append(",\"name\":\"").append(escapeJson(name)).append("\"");
                sb.append(",\"shards\":").append(profile.shards());
                sb.append(",\"tokens\":").append(profile.tokens());
                sb.append(",\"kills\":").append(profile.lifetimeKills());
                sb.append(",\"deaths\":").append(profile.deaths());
                sb.append(",\"kd\":\"").append(profile.deaths() == 0 ? "∞" : String.format("%.2f", (double) profile.lifetimeKills() / profile.deaths())).append("\"");
                sb.append(",\"bestStreak\":").append(profile.highestKillstreak());
                sb.append(",\"playtime\":").append(profile.playtime());
                sb.append(",\"matchWins\":").append(profile.matchWins());
                sb.append(",\"prestige\":").append(profile.prestigeRank());
                sb.append(",\"totalShardsEarned\":").append(profile.totalShardsEarned());
                sb.append(",\"loginStreak\":").append(profile.loginStreak());
                sb.append(",\"lastSeen\":").append(profile.lastSeen());
                sb.append("}");
                sendJson(exchange, sb.toString());
            } catch (IllegalArgumentException e) {
                sendError(exchange, 400, "Invalid UUID");
            }
        }
    }

    private final class StatsApiHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!exchange.getRequestMethod().equals("GET")) {
                sendError(exchange, 405, "Method not allowed");
                return;
            }
            LeaderboardManager.LeaderboardSnapshot snap = leaderboard.getSnapshot();
            StringBuilder sb = new StringBuilder();
            sb.append("{");
            sb.append("\"onlinePlayers\":").append(Bukkit.getOnlinePlayers().size());
            sb.append(",\"maxPlayers\":").append(Bukkit.getMaxPlayers());
            sb.append(",\"totalPlayers\":").append(snap != null ? snap.totalPlayers : 0);
            sb.append(",\"totalKills\":").append(snap != null ? snap.totalKills : 0);
            sb.append(",\"totalDeaths\":").append(snap != null ? snap.totalDeaths : 0);
            sb.append(",\"totalShards\":").append(snap != null ? snap.totalShards : 0);
            sb.append(",\"totalPlaytime\":").append(snap != null ? snap.totalPlaytime : 0);
            sb.append(",\"serverVersion\":\"").append(Bukkit.getBukkitVersion()).append("\"");
            sb.append(",\"serverName\":\"").append(escapeJson(Bukkit.getServer().getMotd())).append("\"");
            sb.append("}");
            sendJson(exchange, sb.toString());
        }
    }

    private final class PlayerSearchHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!exchange.getRequestMethod().equals("GET")) {
                sendError(exchange, 405, "Method not allowed");
                return;
            }
            Map<String, String> params = parseQuery(exchange.getRequestURI().getQuery());
            String query = params.getOrDefault("q", "").toLowerCase();
            if (query.isEmpty()) {
                sendError(exchange, 400, "Missing q parameter");
                return;
            }

            var sb = new StringBuilder();
            sb.append("[");
            boolean first = true;
            for (var player : Bukkit.getOnlinePlayers()) {
                if (player.getName().toLowerCase().contains(query)) {
                    if (!first) sb.append(",");
                    first = false;
                    sb.append("{\"uuid\":\"").append(player.getUniqueId()).append("\"");
                    sb.append(",\"name\":\"").append(escapeJson(player.getName())).append("\"");
                    sb.append(",\"online\":true}");
                }
            }
            sb.append("]");
            sendJson(exchange, sb.toString());
        }
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }
}
