package lol.folium.unstable.ffa;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.configuration.ConfigurationSection;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class FFAWeaponManager {

    private final UnstableRemixPlugin plugin;
    private final NamespacedKey weaponKey;
    private final Map<UUID, Map<String, Integer>> cooldowns = new ConcurrentHashMap<>();
    private final Map<String, FFAWeapon> weapons = new LinkedHashMap<>();

    public FFAWeaponManager(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
        this.weaponKey = new NamespacedKey(plugin, "ffa_weapon");
        loadFromConfig();
    }

    private void loadFromConfig() {
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("ffa-weapons");
        if (sec == null) return;
        ConfigurationSection weaponsSec = sec.getConfigurationSection("weapons");
        if (weaponsSec == null) return;

        for (String id : weaponsSec.getKeys(false)) {
            ConfigurationSection ws = weaponsSec.getConfigurationSection(id);
            if (ws == null) continue;

            String name = ws.getString("name", id);
            String material = ws.getString("material", "NETHERITE_SWORD");
            String character = ws.getString("character", "");
            String ability = ws.getString("ability", "");
            int cooldown = ws.getInt("cooldown", 20);
            String color = ws.getString("color", "#FFFFFF");
            Material mat = Material.matchMaterial(material);
            if (mat == null) mat = Material.NETHERITE_SWORD;

            List<String> loreLines = ws.getStringList("lore");
            List<String> enchants = ws.getStringList("enchants");
            Map<Enchantment, Integer> enchantMap = new LinkedHashMap<>();
            for (String e : enchants) {
                String[] parts = e.split(":");
                if (parts.length == 2) {
                    Enchantment ench = Enchantment.getByKey(NamespacedKey.minecraft(parts[0].toLowerCase()));
                    if (ench != null) enchantMap.put(ench, Integer.parseInt(parts[1]));
                }
            }

            weapons.put(id, new FFAWeapon(id, name, mat, character, ability, cooldown, color, loreLines, enchantMap));
        }
    }

    public FFAWeapon getWeapon(String id) { return weapons.get(id); }
    public Collection<FFAWeapon> getAllWeapons() { return weapons.values(); }
    public List<FFAWeapon> getWeaponsByCategory(String category) {
        return weapons.values().stream().filter(w -> w.category().equalsIgnoreCase(category)).toList();
    }

    public void setCooldown(UUID uuid, String weaponId, int seconds) {
        cooldowns.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>()).put(weaponId, seconds);
    }

    public int getCooldown(UUID uuid, String weaponId) {
        Map<String, Integer> playerCds = cooldowns.get(uuid);
        return playerCds != null ? playerCds.getOrDefault(weaponId, 0) : 0;
    }

    public boolean isOnCooldown(UUID uuid, String weaponId) { return getCooldown(uuid, weaponId) > 0; }
    public void clearCooldowns(UUID uuid) { cooldowns.remove(uuid); }
    public void tickCooldowns() {
        for (Map<String, Integer> playerCds : cooldowns.values()) {
            playerCds.values().removeIf(v -> v <= 1);
            playerCds.replaceAll((k, v) -> v - 1);
        }
    }

    public String getWeaponCooldownBar(UUID uuid) {
        StringBuilder sb = new StringBuilder();
        for (FFAWeapon w : weapons.values()) {
            int cd = getCooldown(uuid, w.id());
            if (!sb.isEmpty()) sb.append(" <dark_gray>\u23D0</dark_gray> ");
            if (cd > 0) {
                sb.append("<gradient:#B38EAE:#727ABE><bold>").append(w.shortName()).append("</bold></gradient>");
                sb.append(" <dark_gray>").append(cd).append("s</dark_gray>");
            } else {
                sb.append("<gradient:#B38EAE:#727ABE><bold>").append(w.shortName()).append("</bold></gradient>");
                sb.append(" <green>READY</green>");
            }
        }
        return sb.toString();
    }

    public ItemStack createWeapon(String id) {
        FFAWeapon weapon = weapons.get(id);
        if (weapon == null) return null;
        ItemStack item = new ItemStack(weapon.material());
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.displayName(TextUtil.parse(weapon.name()));
        List<Component> lore = new ArrayList<>();
        lore.add(TextUtil.parse("<dark_gray>" + weapon.character() + "</dark_gray>"));
        lore.add(Component.empty());
        for (String line : weapon.lore()) lore.add(TextUtil.parse("<gray>" + line + "</gray>"));
        lore.add(Component.empty());
        lore.add(TextUtil.parse("<dark_gray>Ability: " + weapon.ability() + "</dark_gray>"));
        lore.add(TextUtil.parse("<dark_gray>Cooldown: " + weapon.cooldown() + "s</dark_gray>"));
        meta.lore(lore);
        for (Map.Entry<Enchantment, Integer> ench : weapon.enchants().entrySet()) {
            meta.addEnchant(ench.getKey(), ench.getValue(), true);
        }
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.getPersistentDataContainer().set(weaponKey, PersistentDataType.STRING, id);
        item.setItemMeta(meta);
        return item;
    }

    public String getWeaponId(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return null;
        return meta.getPersistentDataContainer().get(weaponKey, PersistentDataType.STRING);
    }

    public boolean isFFAWeapon(ItemStack item) { return getWeaponId(item) != null; }

    public record FFAWeapon(String id, String name, Material material, String character, String ability,
                            int cooldown, String color, List<String> lore, Map<Enchantment, Integer> enchants) {
        public String category() {
            if (material.name().contains("SWORD")) return "swords";
            if (material.name().contains("MACE")) return "maces";
            if (material.name().contains("AXE")) return "axes";
            if (material == Material.BOW) return "bows";
            return "other";
        }

        public String shortName() {
            return switch (id) {
                case "dash" -> "Spoke Dash";
                case "frost" -> "Parrot Frost";
                case "strike" -> "Flame Strike";
                case "flux" -> "Spepticle Flux";
                case "adrenaline" -> "Wemmbu Adrenaline";
                case "lifestealer" -> "Ash Lifesteal";
                case "grapple" -> "Zam Grapple";
                case "seismic" -> "Branzy Seismic";
                case "dashmace" -> "Wemmbu Mace";
                default -> name;
            };
        }
    }
}
