package lol.folium.unstable.kit;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.cooldown.KitCooldownManager;
import lol.folium.unstable.data.PlayerDataStore;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.economy.TransactionResult;
import lol.folium.unstable.integration.LuckPermsHook;
import lol.folium.unstable.map.Arena;
import lol.folium.unstable.map.ArenaManager;
import lol.folium.unstable.util.ConfigItems;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class KitManager {

    private static final String UNLOCKED_KITS = "unlocked_kits";
    private static final String UNLOCKED_KILL_EFFECTS = "unlocked_kill_effects";
    private static final String SELECTED_KILL_EFFECT = "selected_kill_effect";
    private static final int PAGE_SIZE_FALLBACK = 28;

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final PlayerDataStore store;
    private final EconomyService economy;
    private final LuckPermsHook luckPerms;
    private final ArenaManager arenas;
    private final Map<String, KitDefinition> kits = new LinkedHashMap<>();
    private final Map<String, KillEffectDefinition> killEffects = new LinkedHashMap<>();
    private final Map<UUID, InventorySnapshot> editorSnapshots = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> editorSaving = new ConcurrentHashMap<>();
    private final Map<UUID, String> lastSelectedKit = new ConcurrentHashMap<>();

    public KitManager(UnstableRemixPlugin plugin, ConfigManager configs, PlayerDataStore store,
                      EconomyService economy, LuckPermsHook luckPerms, ArenaManager arenas) {
        this.plugin = plugin;
        this.configs = configs;
        this.store = store;
        this.economy = economy;
        this.luckPerms = luckPerms;
        this.arenas = arenas;
    }

    public void tryAutoImport() {
        java.io.File dir = new java.io.File(plugin.getDataFolder(), "kits-import");
        if (!dir.isDirectory()) return;
        importKitsFromFiles(dir);
    }

    public void reload() {
        kits.clear();
        killEffects.clear();
        FileConfiguration config = configs.get("kits.yml");
        ConfigurationSection kitSection = config.getConfigurationSection("kits");
        if (kitSection != null) {
            for (String id : kitSection.getKeys(false)) {
                ConfigurationSection section = kitSection.getConfigurationSection(id);
                if (section == null) {
                    continue;
                }
                Material material = ConfigItems.material(section, "material", Material.IRON_SWORD);
                List<?> offhandRaw = section.getList("offhand", List.of());
                ItemStack offhand = offhandRaw.isEmpty() ? null
                        : (offhandRaw.get(0) instanceof ItemStack stack ? stack.clone() : null);
                kits.put(id.toLowerCase(Locale.ROOT), new KitDefinition(
                        id.toLowerCase(Locale.ROOT),
                        section.getString("display-name", "<white>" + id),
                        material,
                        section.getInt("slot", 10),
                        section.getString("tier", "Common"),
                        section.getLong("price", 0L),
                        section.getString("luckperms-rank", ""),
                        section.getString("permission", ""),
                        section.getString("spawn-arena", ""),
                        readItems(section, "contents", 36),
                        readItems(section, "armor", 4),
                        offhand,
                        section.getString("required-group", ""),
                        section.getInt("cooldown-seconds", 0)
                ));
            }
        }
        ConfigurationSection effects = config.getConfigurationSection("kill-effects.entries");
        if (effects != null) {
            for (String id : effects.getKeys(false)) {
                ConfigurationSection section = effects.getConfigurationSection(id);
                if (section == null) {
                    continue;
                }
                killEffects.put(id.toLowerCase(Locale.ROOT), new KillEffectDefinition(
                        id.toLowerCase(Locale.ROOT),
                        section.getString("display-name", "<white>" + id),
                        ConfigItems.material(section, "material", Material.FIREWORK_ROCKET),
                        section.getInt("slot", 10),
                        section.getLong("price", 1000L),
                        readColors(section),
                        section.getBoolean("flicker", true),
                        section.getBoolean("trail", true)
                ));
            }
        }
    }

    public void openSelector(Player player, int page) {
        openPagedKitGui(player, page, GuiMode.SELECTOR);
    }

    public void openShop(Player player, int page) {
        openPagedKitGui(player, page, GuiMode.SHOP);
    }

    public void openKillEffects(Player player, int page) {
        FileConfiguration config = configs.get("kits.yml");
        ConfigurationSection gui = config.getConfigurationSection("kill-effects.gui");
        int rows = rows(gui, 6);
        PagedGui holder = new PagedGui(player, GuiMode.KILL_EFFECTS, Math.max(0, page));
        Inventory inventory = Bukkit.createInventory(holder, rows * 9, TextUtil.parse(guiString(gui, "title", "<gradient:#FF4444:#FF8800:#FFD700><bold>KILL EFFECTS</bold></gradient>")));
        holder.bind(inventory);
        paintFrame(inventory, gui);
        List<Integer> slots = slots(gui, "effect-slots", defaultGridSlots());
        List<KillEffectDefinition> definitions = new ArrayList<>(killEffects.values());
        paintPageNavigation(inventory, holder, definitions.size(), slots.size(), gui);
        int offset = holder.page * slots.size();
        for (int i = 0; i < slots.size() && offset + i < definitions.size(); i++) {
            KillEffectDefinition effect = definitions.get(offset + i);
            int slot = slots.get(i);
            inventory.setItem(slot, killEffectItem(player, effect));
            holder.effectSlots.put(slot, effect.id());
        }
        player.openInventory(inventory);
    }

    public void openPreview(Player player, String kitId) {
        KitDefinition kit = kits.get(kitId.toLowerCase(Locale.ROOT));
        if (kit == null) {
            return;
        }
        FileConfiguration config = configs.get("kits.yml");
        ConfigurationSection gui = config.getConfigurationSection("gui.preview");
        PreviewGui holder = new PreviewGui(player, kit.id());
        Inventory inventory = Bukkit.createInventory(holder, rows(gui, 6) * 9,
                TextUtil.parse(TextUtil.apply(guiString(gui, "title", "<dark_gray>Kit Preview: {kit}"), Map.of("kit", kit.id()))));
        holder.bind(inventory);
        for (int i = 0; i < Math.min(36, kit.contents().length); i++) {
            inventory.setItem(i, cloneItem(kit.contents()[i]));
        }
        for (int i = 0; i < Math.min(4, kit.armor().length); i++) {
            inventory.setItem(36 + i, cloneItem(kit.armor()[i]));
        }
        int backSlot = gui == null ? 49 : gui.getInt("back-slot", 49);
        holder.backSlot = backSlot;
        inventory.setItem(backSlot, simpleItem(Material.RED_WOOL, "<gradient:#FF4444:#FF8800:#FFD700><bold>\u2190 BACK</bold></gradient>", List.of()));
        player.openInventory(inventory);
    }

    public void openLayoutEditor(Player player, String kitId) {
        KitDefinition kit = kits.get(kitId.toLowerCase(Locale.ROOT));
        if (kit == null) {
            return;
        }
        if (!player.hasPermission("unstable.coreadmin") && !isUnlocked(player, kit)) {
            player.sendMessage(TextUtil.parse("<red>You must unlock that kit first."));
            return;
        }
        editorSnapshots.put(player.getUniqueId(), InventorySnapshot.capture(player));
        editorSaving.remove(player.getUniqueId());
        FileConfiguration config = configs.get("kits.yml");
        ConfigurationSection gui = config.getConfigurationSection("gui.layout-editor");
        LayoutGui holder = new LayoutGui(player, kit.id());
        Inventory inventory = Bukkit.createInventory(holder, rows(gui, 6) * 9,
                TextUtil.parse(TextUtil.apply(guiString(gui, "title", "<dark_gray>Edit Layout: {kit}"), Map.of("kit", kit.id()))));
        holder.bind(inventory);
        ItemStack[] layout = loadLayout(player.getUniqueId(), kit);
        for (int i = 0; i < Math.min(36, layout.length); i++) {
            inventory.setItem(i, cloneItem(layout[i]));
        }
        holder.saveSlot = gui == null ? 47 : gui.getInt("save-slot", 47);
        holder.resetSlot = gui == null ? 49 : gui.getInt("reset-slot", 49);
        holder.cancelSlot = gui == null ? 51 : gui.getInt("cancel-slot", 51);
        holder.offhandSlot = gui == null ? 50 : gui.getInt("offhand-slot", 50);
        inventory.setItem(holder.saveSlot, simpleItem(Material.LIME_DYE, "<green><bold>Save Layout</bold></green>", List.of()));
        inventory.setItem(holder.resetSlot, simpleItem(Material.ORANGE_DYE, "<gold><bold>Reset to Default</bold></gold>", List.of()));
        inventory.setItem(holder.cancelSlot, simpleItem(Material.PINK_DYE, "<red><bold>Cancel</bold></red>", List.of()));
        ItemStack offhandItem = kit.offhand() != null ? kit.offhand().clone() : null;
        if (offhandItem != null && offhandItem.getType() != Material.AIR) {
            inventory.setItem(holder.offhandSlot, offhandItem);
        } else {
            inventory.setItem(holder.offhandSlot, ItemBuilder.of(Material.BARRIER)
                    .name(TextUtil.parse("<gray>No Offhand</gray>"))
                    .build());
        }
        player.openInventory(inventory);
    }

    public void createKit(Player player, String id) {
        createKit(player, id, null);
    }

    public void createKit(Player player, String id, Material displayMaterial) {
        String key = id.toLowerCase(Locale.ROOT);
        FileConfiguration config = configs.get("kits.yml");
        String path = "kits." + key;
        config.set(path + ".display-name", "<white><bold>" + id + "</bold></white>");
        Material mat = displayMaterial != null ? displayMaterial : player.getInventory().getItemInMainHand().getType();
        config.set(path + ".material", mat.isAir() ? Material.IRON_SWORD.name() : mat.name());
        config.set(path + ".slot", 10 + kits.size());
        config.set(path + ".tier", "Common");
        config.set(path + ".price", 0);
        config.set(path + ".luckperms-rank", "");
        config.set(path + ".required-group", "");
        config.set(path + ".permission", "");
        config.set(path + ".spawn-arena", "");
        config.set(path + ".contents", Arrays.asList(player.getInventory().getContents()));
        config.set(path + ".armor", Arrays.asList(player.getInventory().getArmorContents()));
        config.set(path + ".offhand", List.of(player.getInventory().getItemInOffHand()));
        saveKits();
        reload();
    }

    public boolean editKit(String id, String field, String value) {
        String key = id.toLowerCase(Locale.ROOT);
        if (!kits.containsKey(key)) {
            return false;
        }
        FileConfiguration config = configs.get("kits.yml");
        String path = "kits." + key + ".";
        switch (field.toLowerCase(Locale.ROOT)) {
            case "price" -> config.set(path + "price", Long.parseLong(value));
            case "displayname", "display-name", "name" -> config.set(path + "display-name", value);
            case "material" -> {
                Material material = Material.matchMaterial(value);
                if (material == null) {
                    return false;
                }
                config.set(path + "material", material.name());
            }
            case "slot" -> config.set(path + "slot", Integer.parseInt(value));
            case "luckperms-rank", "luckperms" -> config.set(path + "luckperms-rank", value);
            case "required-group", "requiredgroup", "group" -> config.set(path + "required-group", value);
            case "tier" -> config.set(path + "tier", value);
            case "cooldown-seconds", "cooldown" -> config.set(path + "cooldown-seconds", Integer.parseInt(value));
            default -> {
                return false;
            }
        }
        saveKits();
        reload();
        return true;
    }

    public boolean editKillEffectPrice(String id, long price) {
        if (!killEffects.containsKey(id.toLowerCase(Locale.ROOT))) {
            return false;
        }
        configs.get("kits.yml").set("kill-effects.entries." + id.toLowerCase(Locale.ROOT) + ".price", price);
        saveKits();
        reload();
        return true;
    }

    public void addKitToShop(String kitId, int slot, long price, String displayMaterial) {
        String key = kitId.toLowerCase(Locale.ROOT);
        if (!kits.containsKey(key)) return;
        FileConfiguration config = configs.get("kits.yml");
        String path = "kits." + key + ".";
        config.set(path + "price", price);
        config.set(path + "slot", slot);
        Material mat = Material.matchMaterial(displayMaterial);
        if (mat != null) config.set(path + "material", mat.name());
        saveKits();
        reload();
    }

    public void removeKitFromShop(String kitId) {
        String key = kitId.toLowerCase(Locale.ROOT);
        if (!kits.containsKey(key)) return;
        FileConfiguration config = configs.get("kits.yml");
        config.set("kits." + key + ".price", -1L);
        saveKits();
        reload();
    }

    public void setKitShopPrice(String kitId, long price) {
        String key = kitId.toLowerCase(Locale.ROOT);
        if (!kits.containsKey(key)) return;
        FileConfiguration config = configs.get("kits.yml");
        config.set("kits." + key + ".price", price);
        saveKits();
        reload();
    }

    public List<String> kitIds() {
        return new ArrayList<>(kits.keySet());
    }

    public List<String> shopKitIds() {
        return new ArrayList<>(kits.keySet().stream()
                .filter(id -> SPECIAL_KIT_GROUPS.containsKey(id))
                .toList());
    }

    public boolean deleteKit(String kitId) {
        String key = kitId.toLowerCase(Locale.ROOT);
        if (!kits.containsKey(key)) return false;
        FileConfiguration config = configs.get("kits.yml");
        config.set("kits." + key, null);
        saveKits();
        reload();
        return true;
    }

    private static final java.util.Map<String, String> SPECIAL_KIT_GROUPS = java.util.Map.ofEntries(
            java.util.Map.entry("wemmbu", "wemmbu"),
            java.util.Map.entry("minutetech", "minutetech"),
            java.util.Map.entry("lettucek", "lettucek"),
            java.util.Map.entry("theobaldthebird", "theobaldthebird"),
            java.util.Map.entry("manepear", "manepear"),
            java.util.Map.entry("inviswemmbu", "inviswemmbu"),
            java.util.Map.entry("jadenman", "jadenman"),
            java.util.Map.entry("flamefrags", "flamefrags"),
            java.util.Map.entry("parrotx2", "parrotx2"),
            java.util.Map.entry("spokeishere", "spokeishere"),
            java.util.Map.entry("egg", "eggchan")
    );

    public void importKitsFromFiles(java.io.File directory) {
        java.io.File[] files = directory.listFiles((dir, name) -> name.endsWith(".yml") || name.endsWith(".YML"));
        if (files == null) return;
        FileConfiguration config = configs.get("kits.yml");
        if (config.getConfigurationSection("kits") == null) {
            config.createSection("kits");
        }
        for (java.io.File file : files) {
            try {
                String id = file.getName().replaceAll("(?i)\\.yml$", "").toLowerCase(Locale.ROOT);
                if (config.contains("kits." + id)) continue;
                org.bukkit.configuration.file.YamlConfiguration kitConfig = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(file);
                String path = "kits." + id + ".";
                config.set(path + "slot", 10 + config.getConfigurationSection("kits").getKeys(false).size());
                config.set(path + "tier", "Common");
                config.set(path + "price", 0);
                config.set(path + "luckperms-rank", SPECIAL_KIT_GROUPS.getOrDefault(id, ""));
                config.set(path + "required-group", "");
                config.set(path + "permission", "");
                config.set(path + "spawn-arena", "");
                config.set(path + "cooldown-seconds", 0);
                String rawName = kitConfig.getString("display.default.name", "<white>" + id + "</white>");
                config.set(path + "display-name", convertLegacyColors(rawName));
                String iconId = kitConfig.getString("display.default.id", "IRON_SWORD");
                Material iconMat = Material.matchMaterial(iconId.replace("minecraft:", ""));
                config.set(path + "material", iconMat != null ? iconMat.name() : "IRON_SWORD");
                org.bukkit.configuration.ConfigurationSection itemsSection = kitConfig.getConfigurationSection("items");
                if (itemsSection != null) {
                    java.util.List<ItemStack> contents = new java.util.ArrayList<>();
                    java.util.List<ItemStack> armor = new java.util.ArrayList<>();
                    for (String slotKey : itemsSection.getKeys(false)) {
                        org.bukkit.configuration.ConfigurationSection itemSection = itemsSection.getConfigurationSection(slotKey);
                        if (itemSection == null || !itemSection.contains("original")) continue;
                        Object raw = itemSection.get("original");
                        if (raw instanceof ItemStack stack) {
                            if (itemSection.getBoolean("offhand", false)) {
                                config.set(path + "offhand", java.util.List.of(stack));
                            } else {
                                String typeName = stack.getType().name();
                                if (typeName.endsWith("_HELMET") || typeName.endsWith("_CHESTPLATE")
                                        || typeName.endsWith("_LEGGINGS") || typeName.endsWith("_BOOTS")) {
                                    armor.add(stack);
                                } else {
                                    contents.add(stack);
                                }
                            }
                        }
                    }
                    config.set(path + "contents", contents);
                    config.set(path + "armor", armor);
                }
            } catch (Exception e) {
                plugin.getLogger().warning("Failed to import kit: " + file.getName() + " - " + e.getMessage());
            }
        }
        saveKits();
        reload();
    }

    public List<String> killEffectIds() {
        return new ArrayList<>(killEffects.keySet());
    }

    private static String convertLegacyColors(String input) {
        if (input == null) return "";
        String s = input;
        // Convert hex &x&r&r&g&g&b&b -> <#rrggbb>
        s = s.replaceAll("(?i)&x&([0-9a-f])&([0-9a-f])&([0-9a-f])&([0-9a-f])&([0-9a-f])&([0-9a-f])", "<#$1$2$3$4$5$6>");
        // Color codes
        s = s.replace("&0", "<black>").replace("&1", "<dark_blue>").replace("&2", "<dark_green>");
        s = s.replace("&3", "<dark_aqua>").replace("&4", "<dark_red>").replace("&5", "<dark_purple>");
        s = s.replace("&6", "<gold>").replace("&7", "<gray>").replace("&8", "<dark_gray>");
        s = s.replace("&9", "<blue>").replace("&a", "<green>").replace("&b", "<aqua>");
        s = s.replace("&c", "<red>").replace("&d", "<light_purple>").replace("&e", "<yellow>");
        s = s.replace("&f", "<white>");
        // Format codes
        s = s.replace("&l", "<bold>").replace("&m", "<strikethrough>").replace("&n", "<underlined>");
        s = s.replace("&o", "<italic>").replace("&k", "<obfuscated>").replace("&r", "<reset>");
        return s;
    }

    public void setLastSelectedKit(Player player, String kitId) {
        lastSelectedKit.put(player.getUniqueId(), kitId.toLowerCase(Locale.ROOT));
    }

    public String getLastSelectedKit(Player player) {
        return lastSelectedKit.get(player.getUniqueId());
    }

    public boolean loadLastKit(Player player) {
        String kitId = lastSelectedKit.get(player.getUniqueId());
        if (kitId == null) {
            player.sendMessage(TextUtil.parse("<red>No kit selected yet. Use /kits to select one first.</red>"));
            return false;
        }
        return loadKit(player, kitId);
    }

    public void selectKit(Player player, KitDefinition kit) {
        if (!isUnlocked(player, kit)) {
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0F, 0.6F);
            player.sendMessage(TextUtil.parse("<red>That kit is locked. Buy it in the Kit Shop."));
            return;
        }
        if (!kit.luckPermsRank().isBlank()) {
            luckPerms.swapKitGroup(player, kit.luckPermsRank(), kitIds().stream()
                    .map(id -> kits.get(id).luckPermsRank())
                    .filter(r -> r != null && !r.isBlank())
                    .toList());
        }
        lastSelectedKit.put(player.getUniqueId(), kit.id());
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.2F);
        player.sendMessage(TextUtil.parse("<green>Selected kit " + LuckPermsHook.coloredKitName(kit.id(), kit.displayName()) + "<green>. Use <yellow>/kit load</yellow> to get the items.</green>"));
    }

    public void handleKill(Player killer, Player victim) {
        Set<String> selected = store.getSet(killer.getUniqueId(), SELECTED_KILL_EFFECT);
        if (selected.isEmpty()) {
            return;
        }
        KillEffectDefinition effect = killEffects.get(selected.iterator().next());
        if (effect == null || victim.getWorld() == null) {
            return;
        }
        List<Color> colors = effect.colors();
        if (colors.isEmpty()) {
            colors = List.of(Color.WHITE);
        }
        Firework firework = victim.getWorld().spawn(victim.getLocation().add(0, 1, 0), Firework.class);
        FireworkMeta meta = firework.getFireworkMeta();
        FireworkEffect.Builder builder = FireworkEffect.builder()
                .with(FireworkEffect.Type.BALL_LARGE)
                .withColor(colors)
                .flicker(effect.flicker())
                .trail(effect.trail());
        if (colors.size() > 1) {
            builder.withFade(colors.get(1));
        }
        meta.addEffect(builder.build());
        meta.setPower(0);
        firework.setFireworkMeta(meta);
        Bukkit.getScheduler().runTaskLater(plugin, firework::detonate, 1L);
    }

    public void restoreOpenEditors() {
        for (UUID uuid : new ArrayList<>(editorSnapshots.keySet())) {
            Player player = Bukkit.getPlayer(uuid);
            InventorySnapshot snapshot = editorSnapshots.remove(uuid);
            if (player != null && snapshot != null) {
                snapshot.restore(player);
            }
        }
        editorSaving.clear();
    }

    private void openPagedKitGui(Player player, int page, GuiMode mode) {
        FileConfiguration config = configs.get("kits.yml");
        ConfigurationSection gui = config.getConfigurationSection(mode == GuiMode.SELECTOR ? "gui.selector" : "gui.shop");
        PagedGui holder = new PagedGui(player, mode, Math.max(0, page));
        Inventory inventory = Bukkit.createInventory(holder, rows(gui, 6) * 9,
                TextUtil.parse(guiString(gui, "title", mode == GuiMode.SELECTOR ? "<gradient:#FF4444:#FF8800:#FFD700><bold>UNSTABLE KITS</bold></gradient>" : "<gradient:#FF4444:#FF8800:#FFD700><bold>KIT SHOP</bold></gradient>")));
        holder.bind(inventory);
        paintFrame(inventory, gui);
        List<Integer> slots = slots(gui, "kit-slots", defaultGridSlots());
        List<KitDefinition> definitions = mode == GuiMode.SHOP
                ? new ArrayList<>(kits.values().stream().filter(kit -> SPECIAL_KIT_GROUPS.containsKey(kit.id())).toList())
                : new ArrayList<>(kits.values());
        paintPageNavigation(inventory, holder, definitions.size(), slots.size(), gui);
        int offset = holder.page * slots.size();
        for (int i = 0; i < slots.size() && offset + i < definitions.size(); i++) {
            KitDefinition kit = definitions.get(offset + i);
            int slot = slots.get(i);
            inventory.setItem(slot, kitItem(player, kit, mode));
            holder.kitSlots.put(slot, kit.id());
        }
        if (mode == GuiMode.SELECTOR) {
            int editSlot = gui == null ? 49 : gui.getInt("edit-layout-slot", 49);
            int shopSlot = gui == null ? 51 : gui.getInt("shop-slot", 51);
            holder.editSlot = editSlot;
            holder.shopSlot = shopSlot;
            inventory.setItem(editSlot, configuredItem(gui == null ? null : gui.getConfigurationSection("edit-layout"), Material.ANVIL, "<gradient:#FF4444:#FF8800:#FFD700><bold>EDIT LAYOUT</bold></gradient>", Map.of()));
            inventory.setItem(shopSlot, configuredItem(gui == null ? null : gui.getConfigurationSection("shop"), Material.EMERALD, "<gradient:#FF4444:#FF8800:#FFD700><bold>KIT SHOP</bold></gradient>", Map.of()));
        } else {
            int backSlot = gui == null ? 49 : gui.getInt("back-slot", 49);
            int cosmeticsSlot = gui == null ? 51 : gui.getInt("cosmetics-slot", 51);
            holder.backSlot = backSlot;
            holder.cosmeticsSlot = cosmeticsSlot;
            inventory.setItem(backSlot, simpleItem(Material.ARROW, "<gradient:#FF4444:#FF8800:#FFD700>\u2190 Back</gradient>", List.of()));
            inventory.setItem(cosmeticsSlot, simpleItem(Material.FIREWORK_ROCKET, "<gradient:#FF4444:#FF8800:#FFD700><bold>KILL EFFECTS</bold></gradient>", List.of(TextUtil.parse("<gray>Firework kill effects.</gray>"))));
        }
        player.openInventory(inventory);
    }

    private void buyKit(Player player, KitDefinition kit) {
        if (isUnlocked(player, kit)) {
            player.sendMessage(TextUtil.parse("<gray>You already own that kit."));
            return;
        }
        TransactionResult spend = economy.spendShards(player.getUniqueId(), kit.price(), "kit:" + kit.id());
        if (!spend.success()) {
            long missing = Math.max(0L, kit.price() - economy.getShards(player.getUniqueId()));
            player.sendMessage(TextUtil.parse("<red>You need " + missing + " more Shards."));
            return;
        }
        luckPerms.grantPermanentRank(player, kit.luckPermsRank()).thenAccept(success -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (!success) {
                economy.grantShards(player.getUniqueId(), kit.price(), "kit-refund:" + kit.id(), null);
                player.sendMessage(TextUtil.parse("<red>LuckPerms failed. Purchase refunded."));
                return;
            }
            store.addSetValue(player.getUniqueId(), UNLOCKED_KITS, kit.id());
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.2F);
            player.sendMessage(TextUtil.parse("<green>Unlocked kit <white>" + kit.id() + "</white>."));
            openShop(player, 0);
        }));
    }

    private void buyOrSelectKillEffect(Player player, KillEffectDefinition effect) {
        boolean unlocked = store.hasSetValue(player.getUniqueId(), UNLOCKED_KILL_EFFECTS, effect.id());
        if (!unlocked) {
            TransactionResult spend = economy.spendShards(player.getUniqueId(), effect.price(), "kill-effect:" + effect.id());
            if (!spend.success()) {
                long missing = Math.max(0L, effect.price() - economy.getShards(player.getUniqueId()));
                player.sendMessage(TextUtil.parse("<red>You need " + missing + " more Shards."));
                return;
            }
            store.addSetValue(player.getUniqueId(), UNLOCKED_KILL_EFFECTS, effect.id());
        }
        store.replaceSet(player.getUniqueId(), SELECTED_KILL_EFFECT, Set.of(effect.id()));
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
        player.sendMessage(TextUtil.parse("<green>Selected kill effect <white>" + effect.id() + "</white>."));
        openKillEffects(player, 0);
    }

    private void equipKit(Player player, KitDefinition kit) {
        if (!isUnlocked(player, kit)) {
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0F, 0.6F);
            player.sendMessage(TextUtil.parse("<red>That kit is locked. Buy it in the Kit Shop."));
            return;
        }
        KitCooldownManager cd = plugin.getKitCooldownManager();
        if (cd != null && !cd.hasBypass(player.getUniqueId()) && kit.cooldownSeconds() > 0) {
            long remaining = cd.getCooldown(player.getUniqueId(), kit.id());
            if (remaining > 0) {
                long secs = remaining / 1000;
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0F, 0.6F);
                player.sendMessage(TextUtil.parse("<red>That kit is on cooldown! <yellow>" + secs + "s</yellow> <red>remaining.</red>"));
                return;
            }
        }
        ItemStack[] layout = loadLayout(player.getUniqueId(), kit);
        player.getInventory().clear();
        player.getInventory().setContents(pad(layout, 41));
        player.getInventory().setArmorContents(cloneArray(kit.armor(), 4));
        if (kit.offhand() != null) {
            player.getInventory().setItemInOffHand(kit.offhand().clone());
        }
        if (!kit.spawnArena().isBlank()) {
            arenas.get(kit.spawnArena()).map(Arena::lobby).ifPresent(player::teleport);
        }
        if (cd != null && kit.cooldownSeconds() > 0) {
            cd.setCooldown(player.getUniqueId(), kit.id(), kit.cooldownSeconds());
        }
        if (!kit.luckPermsRank().isBlank()) {
            luckPerms.swapKitGroup(player, kit.luckPermsRank(), kitIds().stream()
                    .map(id -> kits.get(id).luckPermsRank())
                    .filter(r -> r != null && !r.isBlank())
                    .toList());
        }
        lastSelectedKit.put(player.getUniqueId(), kit.id());
        player.closeInventory();
    }

    public boolean loadKit(Player player, String kitId) {
        KitDefinition kit = kits.get(kitId.toLowerCase(Locale.ROOT));
        if (kit == null) {
            player.sendMessage(TextUtil.parse("<red>Kit not found.</red>"));
            return false;
        }
        if (!isUnlocked(player, kit)) {
            player.sendMessage(TextUtil.parse("<red>That kit is locked.</red>"));
            return false;
        }
        KitCooldownManager cd = plugin.getKitCooldownManager();
        if (cd != null && !cd.hasBypass(player.getUniqueId()) && kit.cooldownSeconds() > 0) {
            long remaining = cd.getCooldown(player.getUniqueId(), kit.id());
            if (remaining > 0) {
                long secs = remaining / 1000;
                player.sendMessage(TextUtil.parse("<red>That kit is on cooldown! <yellow>" + secs + "s</yellow> <red>remaining.</red>"));
                return false;
            }
        }
        ItemStack[] layout = loadLayout(player.getUniqueId(), kit);
        player.getInventory().clear();
        player.getInventory().setContents(pad(layout, 41));
        player.getInventory().setArmorContents(cloneArray(kit.armor(), 4));
        if (kit.offhand() != null) {
            player.getInventory().setItemInOffHand(kit.offhand().clone());
        }
        if (!kit.spawnArena().isBlank()) {
            arenas.get(kit.spawnArena()).map(Arena::lobby).ifPresent(player::teleport);
        }
        if (cd != null && kit.cooldownSeconds() > 0) {
            cd.setCooldown(player.getUniqueId(), kit.id(), kit.cooldownSeconds());
        }
        if (!kit.luckPermsRank().isBlank()) {
            luckPerms.swapKitGroup(player, kit.luckPermsRank(), kitIds().stream()
                    .map(id -> kits.get(id).luckPermsRank())
                    .filter(r -> r != null && !r.isBlank())
                    .toList());
        }
        player.sendMessage(TextUtil.parse("<green>Loaded kit " + LuckPermsHook.coloredKitName(kit.id(), kit.displayName()) + "<green>.</green>"));
        return true;
    }

    private boolean isUnlocked(Player player, KitDefinition kit) {
        if (!kit.requiredGroup().isBlank() && !luckPerms.hasGroup(player, kit.requiredGroup())) {
            return false;
        }
        if (!kit.permission().isBlank() && player.hasPermission(kit.permission())) {
            return true;
        }
        if (!kit.luckPermsRank().isBlank() && luckPerms.hasGroup(player, kit.luckPermsRank())) {
            return true;
        }
        if (player.hasPermission("unstable.kit." + kit.id())) {
            return true;
        }
        return store.hasSetValue(player.getUniqueId(), UNLOCKED_KITS, kit.id());
    }

    private ItemStack kitItem(Player player, KitDefinition kit, GuiMode mode) {
        boolean unlocked = isUnlocked(player, kit);
        long missing = Math.max(0L, kit.price() - economy.getShards(player.getUniqueId()));
        String coloredName = LuckPermsHook.coloredKitName(kit.id(), kit.displayName());
        Map<String, String> placeholders = Map.of(
                "kit", kit.id(),
                "display_name", coloredName,
                "kit_name", coloredName,
                "tier", kit.tier(),
                "price", String.valueOf(kit.price()),
                "missing", String.valueOf(missing),
                "rank", kit.luckPermsRank().isBlank() ? "None" : kit.luckPermsRank()
        );
        FileConfiguration config = configs.get("kits.yml");
        String path;
        if (mode == GuiMode.SELECTOR) {
            path = unlocked ? "gui.states.owned" : "gui.states.locked";
        } else {
            if (unlocked) {
                path = "gui.states.owned";
            } else if (kit.price() == 0) {
                path = "gui.states.free";
            } else {
                path = "gui.states.purchasable";
            }
        }
        ConfigurationSection state = config.getConfigurationSection(path);
        String fallbackName = mode == GuiMode.SELECTOR && unlocked ? coloredName : kit.displayName();
        Material fallbackMat = unlocked ? kit.material() : Material.RED_STAINED_GLASS_PANE;
        return configuredItem(state, fallbackMat, fallbackName, placeholders);
    }

    private ItemStack killEffectItem(Player player, KillEffectDefinition effect) {
        boolean unlocked = store.hasSetValue(player.getUniqueId(), UNLOCKED_KILL_EFFECTS, effect.id());
        boolean selected = store.getSet(player.getUniqueId(), SELECTED_KILL_EFFECT).contains(effect.id());
        ConfigurationSection state = configs.get("kits.yml").getConfigurationSection("kill-effects.states." + (selected ? "selected" : unlocked ? "unlocked" : "locked"));
        return configuredItem(state, effect.material(), effect.displayName(), Map.of(
                "effect", effect.id(),
                "display_name", effect.displayName(),
                "price", String.valueOf(effect.price())
        ));
    }

    private ItemStack configuredItem(ConfigurationSection section, Material fallback, String fallbackName, Map<String, String> placeholders) {
        Material material = section == null ? fallback : ConfigItems.material(section, "material", fallback);
        String name = section == null ? fallbackName : section.getString("name", fallbackName);
        return ItemBuilder.of(material)
                .name(TextUtil.parse(TextUtil.apply(name, placeholders)))
                .lore(section == null ? List.of() : TextUtil.lore(section, "lore", placeholders))
                .glow(section != null && section.getBoolean("glow", false))
                .customModelData(section == null ? null : ConfigItems.customModelData(section, "custom-model-data"))
                .build();
    }

    private ItemStack simpleItem(Material material, String name, List<Component> lore) {
        return ItemBuilder.of(material).name(TextUtil.parse(name)).lore(lore).build();
    }

    private void paintFrame(Inventory inventory, ConfigurationSection gui) {
        ItemStack filler = ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE).name(Component.empty()).build();
        ItemStack frame = configuredItem(gui == null ? null : gui.getConfigurationSection("frame"), Material.PURPLE_STAINED_GLASS_PANE, " ", Map.of());
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            inventory.setItem(slot, filler);
        }
        int rows = inventory.getSize() / 9;
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            int row = slot / 9;
            int col = slot % 9;
            if (row == 0 || row == rows - 1 || col == 0 || col == 8) {
                inventory.setItem(slot, frame);
            }
        }
    }

    private void paintPageNavigation(Inventory inventory, PagedGui holder, int totalItems, int pageSize, ConfigurationSection gui) {
        int maxPage = Math.max(0, (totalItems - 1) / Math.max(1, pageSize));
        holder.page = Math.min(holder.page, maxPage);
        holder.previousSlot = gui == null ? 45 : gui.getInt("previous-slot", 45);
        holder.nextSlot = gui == null ? 53 : gui.getInt("next-slot", 53);
        if (holder.page > 0) {
            inventory.setItem(holder.previousSlot, simpleItem(Material.ARROW, "<gradient:#FF4444:#FF8800:#FFD700>\u2190 Previous</gradient>", List.of()));
        }
        if (holder.page < maxPage) {
            inventory.setItem(holder.nextSlot, simpleItem(Material.ARROW, "<gradient:#FF4444:#FF8800:#FFD700>Next \u2192</gradient>", List.of()));
        }
    }

    private List<Integer> defaultGridSlots() {
        return List.of(10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43);
    }

    private List<Integer> slots(ConfigurationSection section, String path, List<Integer> fallback) {
        if (section == null) {
            return fallback;
        }
        List<Integer> slots = section.getIntegerList(path);
        return slots.isEmpty() ? fallback : slots;
    }

    private int rows(ConfigurationSection section, int fallback) {
        return Math.max(1, Math.min(6, section == null ? fallback : section.getInt("rows", fallback)));
    }

    private String guiString(ConfigurationSection section, String path, String fallback) {
        return section == null ? fallback : section.getString(path, fallback);
    }

    private ItemStack[] readItems(ConfigurationSection section, String path, int size) {
        List<?> list = section.getList(path, List.of());
        ItemStack[] items = new ItemStack[size];
        for (int i = 0; i < Math.min(size, list.size()); i++) {
            Object value = list.get(i);
            if (value instanceof ItemStack stack) {
                items[i] = stack.clone();
            }
        }
        return items;
    }

    private List<Color> readColors(ConfigurationSection section) {
        List<Map<?, ?>> rawColors = section.getMapList("colors");
        if (!rawColors.isEmpty()) {
            List<Color> colors = new ArrayList<>();
            for (Map<?, ?> raw : rawColors) {
                colors.add(Color.fromRGB(
                        colorPart(raw, "r"),
                        colorPart(raw, "g"),
                        colorPart(raw, "b")
                ));
            }
            if (!colors.isEmpty()) return colors;
        }
        String hex = section.getString("hex", "");
        if (!hex.isEmpty()) {
            hex = hex.replace("#", "");
            try {
                int rgb = Integer.parseInt(hex, 16);
                return List.of(Color.fromRGB(rgb));
            } catch (NumberFormatException ignored) {}
        }
        int r = section.getInt("r", section.getInt("rgb.r", -1));
        int g = section.getInt("g", section.getInt("rgb.g", -1));
        int b = section.getInt("b", section.getInt("rgb.b", -1));
        if (r >= 0 && g >= 0 && b >= 0) {
            return List.of(Color.fromRGB(r, g, b));
        }
        return List.of(Color.WHITE);
    }

    private int colorPart(Map<?, ?> raw, String key) {
        Object value = raw.get(key);
        return value instanceof Number number ? number.intValue() : 255;
    }

    private ItemStack[] loadLayout(UUID uuid, KitDefinition kit) {
        File file = layoutFile(uuid);
        if (!file.exists()) {
            return cloneArray(kit.contents(), 36);
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        List<?> list = yaml.getList("layouts." + kit.id(), List.of());
        if (list.isEmpty()) {
            return cloneArray(kit.contents(), 36);
        }
        ItemStack[] items = new ItemStack[36];
        for (int i = 0; i < Math.min(36, list.size()); i++) {
            if (list.get(i) instanceof ItemStack stack) {
                items[i] = stack.clone();
            }
        }
        return items;
    }

    private ItemStack loadLayoutOffhand(UUID uuid, KitDefinition kit) {
        File file = layoutFile(uuid);
        if (!file.exists()) {
            return kit.offhand() != null ? kit.offhand().clone() : null;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        List<?> list = yaml.getList("layouts." + kit.id() + "-offhand", List.of());
        if (list.isEmpty()) {
            return kit.offhand() != null ? kit.offhand().clone() : null;
        }
        Object first = list.get(0);
        if (first instanceof ItemStack stack) {
            return stack.clone();
        }
        return kit.offhand() != null ? kit.offhand().clone() : null;
    }

    private void saveLayout(UUID uuid, String kitId, ItemStack[] items, ItemStack offhand) {
        File file = layoutFile(uuid);
        file.getParentFile().mkdirs();
        YamlConfiguration yaml = file.exists() ? YamlConfiguration.loadConfiguration(file) : new YamlConfiguration();
        yaml.set("layouts." + kitId, Arrays.asList(cloneArray(items, 36)));
        if (offhand != null) {
            yaml.set("layouts." + kitId + "-offhand", List.of(offhand));
        } else {
            yaml.set("layouts." + kitId + "-offhand", null);
        }
        try {
            yaml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Failed saving kit layout: " + ex.getMessage());
        }
    }

    private void resetLayout(UUID uuid, String kitId) {
        File file = layoutFile(uuid);
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        yaml.set("layouts." + kitId, null);
        try {
            yaml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Failed resetting kit layout: " + ex.getMessage());
        }
    }

    private File layoutFile(UUID uuid) {
        return new File(plugin.getDataFolder(), "layouts/" + uuid + ".yml");
    }

    private void saveKitContents(String kitId, ItemStack[] items, ItemStack offhand) {
        String key = kitId.toLowerCase(Locale.ROOT);
        FileConfiguration config = configs.get("kits.yml");
        config.set("kits." + key + ".contents", Arrays.asList(items));
        if (offhand != null) {
            config.set("kits." + key + ".offhand", List.of(offhand));
        } else {
            config.set("kits." + key + ".offhand", List.of());
        }
        saveKits();
        reload();
    }

    private void saveKits() {
        try {
            configs.save("kits.yml");
        } catch (IOException ex) {
            plugin.getLogger().severe("Failed saving kits.yml: " + ex.getMessage());
        }
    }

    private ItemStack[] pad(ItemStack[] input, int size) {
        ItemStack[] padded = new ItemStack[size];
        for (int i = 0; i < Math.min(size, input.length); i++) {
            padded[i] = cloneItem(input[i]);
        }
        return padded;
    }

    private ItemStack[] cloneArray(ItemStack[] input, int size) {
        ItemStack[] clone = new ItemStack[size];
        for (int i = 0; i < Math.min(size, input.length); i++) {
            clone[i] = cloneItem(input[i]);
        }
        return clone;
    }

    private ItemStack cloneItem(ItemStack item) {
        return item == null ? null : item.clone();
    }

    private enum GuiMode {
        SELECTOR,
        SHOP,
        KILL_EFFECTS
    }

    private final class PagedGui extends GuiHolder {
        private final Player player;
        private final GuiMode mode;
        private final Map<Integer, String> kitSlots = new HashMap<>();
        private final Map<Integer, String> effectSlots = new HashMap<>();
        private int page;
        private int previousSlot = -1;
        private int nextSlot = -1;
        private int editSlot = -1;
        private int shopSlot = -1;
        private int backSlot = -1;
        private int cosmeticsSlot = -1;

        private PagedGui(Player player, GuiMode mode, int page) {
            this.player = player;
            this.mode = mode;
            this.page = page;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            if (slot == previousSlot) {
                openByMode(player, mode, Math.max(0, page - 1));
                return;
            }
            if (slot == nextSlot) {
                openByMode(player, mode, page + 1);
                return;
            }
            if (slot == shopSlot) {
                openShop(player, 0);
                return;
            }
            if (slot == editSlot) {
                kits.values().stream().filter(kit -> isUnlocked(player, kit)).findFirst().ifPresent(kit -> openLayoutEditor(player, kit.id()));
                return;
            }
            if (slot == backSlot) {
                openSelector(player, 0);
                return;
            }
            if (slot == cosmeticsSlot) {
                openKillEffects(player, 0);
                return;
            }
            String kitId = kitSlots.get(slot);
            if (kitId != null) {
                KitDefinition kit = kits.get(kitId);
                if (kit == null) return;
                if (mode == GuiMode.SELECTOR) {
                    if (event.getClick() == ClickType.RIGHT) {
                        openPreview(player, kit.id());
                    } else if (event.getClick() == ClickType.SHIFT_LEFT) {
                        openLayoutEditor(player, kit.id());
                    } else {
                        selectKit(player, kit);
                    }
                } else {
                    if (event.getClick() == ClickType.RIGHT) {
                        openPreview(player, kit.id());
                    } else {
                        buyKit(player, kit);
                    }
                }
                return;
            }
            String effectId = effectSlots.get(slot);
            if (effectId != null && killEffects.containsKey(effectId)) {
                buyOrSelectKillEffect(player, killEffects.get(effectId));
            }
        }

        private void openByMode(Player player, GuiMode mode, int page) {
            if (mode == GuiMode.KILL_EFFECTS) {
                openKillEffects(player, page);
            } else if (mode == GuiMode.SHOP) {
                openShop(player, page);
            } else {
                openSelector(player, page);
            }
        }
    }

    private final class PreviewGui extends GuiHolder {
        private final Player player;
        private final String kitId;
        private int backSlot = -1;

        private PreviewGui(Player player, String kitId) {
            this.player = player;
            this.kitId = kitId;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            if (event.getRawSlot() == backSlot) {
                openShop(player, 0);
            }
        }
    }

    private final class LayoutGui extends GuiHolder {
        private final Player player;
        private final String kitId;
        private int saveSlot;
        private int resetSlot;
        private int cancelSlot;
        private int offhandSlot = 50;

        private LayoutGui(Player player, String kitId) {
            this.player = player;
            this.kitId = kitId;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            int slot = event.getRawSlot();
            if (slot >= 36) {
                event.setCancelled(true);
            }
            if (slot == offhandSlot) {
                return;
            }
            if (slot == saveSlot) {
                ItemStack[] items = new ItemStack[36];
                for (int i = 0; i < 36; i++) {
                    items[i] = cloneItem(event.getInventory().getItem(i));
                }
                ItemStack offhand = cloneItem(event.getInventory().getItem(offhandSlot));
                if (offhand != null && offhand.getType() == Material.BARRIER) {
                    offhand = null;
                }
                if (player.hasPermission("unstable.coreadmin")) {
                    saveKitContents(kitId, items, offhand);
                    player.sendMessage(TextUtil.parse("<green>Saved kit <white>" + kitId + "</white> contents (server-wide).</green>"));
                } else {
                    saveLayout(player.getUniqueId(), kitId, items, offhand);
                    player.sendMessage(TextUtil.parse("<green>Saved layout for <white>" + kitId + "</white>.</green>"));
                }
                InventorySnapshot snapshot = editorSnapshots.remove(player.getUniqueId());
                editorSaving.put(player.getUniqueId(), true);
                player.closeInventory();
                if (snapshot != null) {
                    snapshot.restore(player);
                }
                openSelector(player, 0);
            } else if (slot == resetSlot) {
                resetLayout(player.getUniqueId(), kitId);
                InventorySnapshot snapshot = editorSnapshots.remove(player.getUniqueId());
                editorSaving.put(player.getUniqueId(), true);
                player.closeInventory();
                if (snapshot != null) {
                    snapshot.restore(player);
                }
                openSelector(player, 0);
            } else if (slot == cancelSlot) {
                InventorySnapshot snapshot = editorSnapshots.remove(player.getUniqueId());
                if (snapshot != null) {
                    snapshot.restore(player);
                }
                player.closeInventory();
                openSelector(player, 0);
            }
        }

        @Override
        public void handleClose(InventoryCloseEvent event) {
            if (editorSaving.remove(player.getUniqueId()) != null) {
                return;
            }
            InventorySnapshot snapshot = editorSnapshots.remove(player.getUniqueId());
            if (snapshot != null) {
                Bukkit.getScheduler().runTask(plugin, () -> snapshot.restore(player));
            }
        }
    }
}
