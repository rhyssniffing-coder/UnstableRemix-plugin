package lol.folium.unstable.cooldown;

import org.bukkit.Material;

public record CooldownItem(
        String id,
        String command,
        Material material,
        String displayName,
        String effect,
        int durationSeconds,
        double shardMultiplier
) {
}
