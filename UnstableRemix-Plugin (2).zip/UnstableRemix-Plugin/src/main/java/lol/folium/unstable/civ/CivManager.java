package lol.folium.unstable.civ;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import lol.folium.unstable.UnstableRemixPlugin;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class CivManager {

    private static CivManager instance;
    private final Map<UUID, Civilization> civs = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> playerCiv = new ConcurrentHashMap<>();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final Path dataFolder;
    private final File civFile;

    private long createCost;
    private long gradientCost;
    private int maxPrefixLength;
    private int maxNameLength;
    private int vaultSize;
    private final Map<String, String> presetColors = new LinkedHashMap<>();

    public long getCreateCost() { return createCost; }
    public long getGradientCost() { return gradientCost; }
    public int getMaxPrefixLength() { return maxPrefixLength; }
    public int getMaxNameLength() { return maxNameLength; }
    public int getVaultSize() { return vaultSize; }
    public Map<String, String> getPresetColors() { return presetColors; }

    public CivManager() {
        this.dataFolder = UnstableRemixPlugin.getInstance().getDataFolder().toPath();
        this.civFile = dataFolder.resolve("civilizations.json").toFile();
        loadConfig();
        loadAll();
    }

    private void loadConfig() {
        var config = UnstableRemixPlugin.getInstance().getConfig();
        this.createCost = config.getLong("civilizations.create-cost", 10000);
        this.gradientCost = config.getLong("civilizations.gradient-cost", 1000);
        this.maxPrefixLength = config.getInt("civilizations.max-prefix-length", 5);
        this.maxNameLength = config.getInt("civilizations.max-name-length", 16);
        this.vaultSize = config.getInt("civilizations.vault-size", 54);

        var colorsSection = config.getConfigurationSection("civilizations.colors");
        if (colorsSection != null) {
            for (String key : colorsSection.getKeys(false)) {
                presetColors.put(key, colorsSection.getString(key));
            }
        }
        if (presetColors.isEmpty()) {
            presetColors.put("Red", "&c");
            presetColors.put("Gold", "&6");
            presetColors.put("Yellow", "&e");
            presetColors.put("Green", "&a");
            presetColors.put("Aqua", "&b");
            presetColors.put("Blue", "&9");
            presetColors.put("Purple", "&5");
            presetColors.put("Pink", "&d");
            presetColors.put("White", "&f");
            presetColors.put("Dark Red", "&4");
            presetColors.put("Dark Green", "&2");
            presetColors.put("Dark Blue", "&1");
            presetColors.put("Dark Purple", "&8");
            presetColors.put("Gray", "&7");
            presetColors.put("Dark Aqua", "&3");
        }
    }

    public static CivManager getInstance() {
        if (instance == null) {
            instance = new CivManager();
        }
        return instance;
    }

    public Civilization getCiv(UUID uuid) {
        return civs.get(uuid);
    }

    public Civilization getCivByName(String name) {
        for (Civilization civ : civs.values()) {
            if (civ.getName().equalsIgnoreCase(name)) return civ;
        }
        return null;
    }

    public Civilization getCivByPrefix(String prefix) {
        for (Civilization civ : civs.values()) {
            if (civ.getPrefix().equalsIgnoreCase(prefix)) return civ;
        }
        return null;
    }

    public Collection<Civilization> getAllCivs() {
        return civs.values();
    }

    public Civilization getPlayerCiv(UUID playerUuid) {
        UUID civId = playerCiv.get(playerUuid);
        if (civId == null) return null;
        return civs.get(civId);
    }

    public boolean isPlayerInCiv(UUID playerUuid) {
        return playerCiv.containsKey(playerUuid);
    }

    public Civilization createCiv(String name, String prefix, String prefixColor, boolean gradient, UUID owner) {
        UUID id = UUID.randomUUID();
        Civilization civ = new Civilization(id, name, prefix, prefixColor, gradient, owner);
        civs.put(id, civ);
        playerCiv.put(owner, id);
        saveAll();
        return civ;
    }

    public void disbandCiv(UUID civId) {
        Civilization civ = civs.remove(civId);
        if (civ != null) {
            for (UUID member : civ.getMembers()) {
                playerCiv.remove(member);
            }
            saveAll();
        }
    }

    public boolean joinCiv(UUID playerUuid, Civilization civ) {
        if (isPlayerInCiv(playerUuid)) return false;
        civ.addMember(playerUuid);
        playerCiv.put(playerUuid, civ.getId());
        saveAll();
        return true;
    }

    public boolean leaveCiv(UUID playerUuid) {
        UUID civId = playerCiv.remove(playerUuid);
        if (civId == null) return false;
        Civilization civ = civs.get(civId);
        if (civ != null) {
            civ.removeMember(playerUuid);
            if (civ.getMembers().isEmpty() || (civ.isOwner(playerUuid) && civ.getMembers().size() <= 1)) {
                disbandCiv(civId);
            } else if (civ.isOwner(playerUuid)) {
                // Transfer ownership to first member
                UUID newOwner = civ.getMembers().iterator().next();
                civ.removeMember(newOwner);
                // Re-add to make them owner (recreate civ would be cleaner but this works)
                civ.getMembers().add(newOwner);
            }
            saveAll();
        }
        return true;
    }

    public void saveAll() {
        try {
            JsonObject root = new JsonObject();
            for (Map.Entry<UUID, Civilization> entry : civs.entrySet()) {
                Civilization civ = entry.getValue();
                JsonObject civObj = new JsonObject();
                civObj.addProperty("name", civ.getName());
                civObj.addProperty("prefix", civ.getPrefix());
                civObj.addProperty("prefixColor", civ.getPrefixColor());
                civObj.addProperty("gradientPrefix", civ.isGradientPrefix());
                civObj.addProperty("owner", civ.getOwner().toString());
                civObj.addProperty("balance", (long) civ.getBalance());
                civObj.addProperty("description", civ.getDescription() != null ? civ.getDescription() : "");

                com.google.gson.JsonArray membersArr = new com.google.gson.JsonArray();
                for (UUID m : civ.getMembers()) membersArr.add(m.toString());
                civObj.add("members", membersArr);

                com.google.gson.JsonArray invitedArr = new com.google.gson.JsonArray();
                for (UUID m : civ.getInvited()) invitedArr.add(m.toString());
                civObj.add("invited", invitedArr);

                com.google.gson.JsonArray todoArr = new com.google.gson.JsonArray();
                for (String t : civ.getTodoList()) todoArr.add(t);
                civObj.add("todoList", todoArr);

                com.google.gson.JsonArray targetsArr = new com.google.gson.JsonArray();
                for (String t : civ.getTargets()) targetsArr.add(t);
                civObj.add("targets", targetsArr);

                com.google.gson.JsonArray enemiesArr = new com.google.gson.JsonArray();
                for (String e : civ.getEnemies()) enemiesArr.add(e);
                civObj.add("enemies", enemiesArr);

                root.add(entry.getKey().toString(), civObj);
            }

            // Player -> Civ mapping
            JsonObject mapping = new JsonObject();
            for (Map.Entry<UUID, UUID> entry : playerCiv.entrySet()) {
                mapping.add(entry.getKey().toString(), gson.toJsonTree(entry.getValue().toString()));
            }
            root.add("playerMapping", mapping);

            civFile.getParentFile().mkdirs();
            try (Writer writer = new OutputStreamWriter(new FileOutputStream(civFile), StandardCharsets.UTF_8)) {
                gson.toJson(root, writer);
            }
        } catch (IOException e) {
            UnstableRemixPlugin.getInstance().getLogger().severe("Failed to save civilizations: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void loadAll() {
        if (!civFile.exists()) return;
        try {
            String json = new String(Files.readAllBytes(civFile.toPath()), StandardCharsets.UTF_8);
            JsonObject root = JsonParser.parseString(json).getAsJsonObject();

            for (Map.Entry<String, com.google.gson.JsonElement> entry : root.entrySet()) {
                if (entry.getKey().equals("playerMapping")) continue;
                UUID civId = UUID.fromString(entry.getKey());
                JsonObject civObj = entry.getValue().getAsJsonObject();

                String name = civObj.get("name").getAsString();
                String prefix = civObj.get("prefix").getAsString();
                String prefixColor = civObj.get("prefixColor").getAsString();
                boolean gradient = civObj.get("gradientPrefix").getAsBoolean();
                UUID owner = UUID.fromString(civObj.get("owner").getAsString());

                Civilization civ = new Civilization(civId, name, prefix, prefixColor, gradient, owner);
                civ.setBalance(civObj.get("balance").getAsLong());
                if (civObj.has("description")) civ.setDescription(civObj.get("description").getAsString());

                if (civObj.has("members")) {
                    for (com.google.gson.JsonElement m : civObj.getAsJsonArray("members")) {
                        UUID memberId = UUID.fromString(m.getAsString());
                        civ.getMembers().add(memberId);
                        playerCiv.put(memberId, civId);
                    }
                }
                if (civObj.has("invited")) {
                    for (com.google.gson.JsonElement m : civObj.getAsJsonArray("invited")) {
                        civ.getInvited().add(UUID.fromString(m.getAsString()));
                    }
                }
                if (civObj.has("todoList")) {
                    for (com.google.gson.JsonElement t : civObj.getAsJsonArray("todoList")) {
                        civ.getTodoList().add(t.getAsString());
                    }
                }
                if (civObj.has("targets")) {
                    for (com.google.gson.JsonElement t : civObj.getAsJsonArray("targets")) {
                        civ.getTargets().add(t.getAsString());
                    }
                }
                if (civObj.has("enemies")) {
                    for (com.google.gson.JsonElement e : civObj.getAsJsonArray("enemies")) {
                        civ.getEnemies().add(e.getAsString());
                    }
                }

                civs.put(civId, civ);
            }
        } catch (Exception e) {
            UnstableRemixPlugin.getInstance().getLogger().severe("Failed to load civilizations: " + e.getMessage());
        }
    }
}
