package lol.folium.unstable.kitrole;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class KitRoleListener implements Listener {

    private final KitRoleManager manager;

    public KitRoleListener(KitRoleManager manager) {
        this.manager = manager;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        if (!manager.isGameRunning()) return;

        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        manager.handleDeath(victim);
        if (killer != null) {
            manager.handleKill(killer, victim);
        }
    }
}
