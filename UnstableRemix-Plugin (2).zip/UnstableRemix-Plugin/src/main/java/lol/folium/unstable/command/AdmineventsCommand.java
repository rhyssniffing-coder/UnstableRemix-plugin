package lol.folium.unstable.command;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.election.ElectionManager;
import lol.folium.unstable.events.ArenaEventEngine;
import lol.folium.unstable.events.EventManager;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public final class AdmineventsCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;
    private final EventManager eventManager;
    private final ArenaEventEngine arenaEventEngine;
    private final ElectionManager electionManager;

    public AdmineventsCommand(UnstableRemixPlugin plugin, EventManager eventManager, ArenaEventEngine arenaEventEngine, ElectionManager electionManager) {
        this.plugin = plugin;
        this.eventManager = eventManager;
        this.arenaEventEngine = arenaEventEngine;
        this.electionManager = electionManager;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length == 0) {
            sendUsage(player);
            return;
        }
        switch (args[0].toLowerCase()) {
            case "shardsmulti" -> handleShardsMulti(player, args);
            case "trigger" -> handleTrigger(player, args);
            case "stop" -> handleStop(player, args);
            case "list" -> handleList(player);
            default -> sendUsage(player);
        }
    }

    private void sendUsage(Player player) {
        player.sendMessage(TextUtil.parse("<yellow>/adminevents shardsmulti <multiplier> <duration_seconds>"));
        player.sendMessage(TextUtil.parse("<yellow>/adminevents trigger <arena_event|election>"));
        player.sendMessage(TextUtil.parse("<yellow>/adminevents stop <event>"));
        player.sendMessage(TextUtil.parse("<yellow>/adminevents list"));
    }

    private void handleShardsMulti(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(TextUtil.parse("<red>Usage: /adminevents shardsmulti <multiplier> <duration_seconds>"));
            return;
        }
        try {
            double multiplier = Double.parseDouble(args[1]);
            if (multiplier <= 0) {
                player.sendMessage(TextUtil.parse("<red>Multiplier must be positive."));
                return;
            }
            int duration = Integer.parseInt(args[2]);
            if (duration <= 0) {
                player.sendMessage(TextUtil.parse("<red>Duration must be positive."));
                return;
            }
            eventManager.startEvent("2x_shards", duration, multiplier);
            player.sendMessage(TextUtil.parse("<green>Started " + multiplier + "x shards event for " + duration + " seconds."));
        } catch (NumberFormatException e) {
            player.sendMessage(TextUtil.parse("<red>Invalid number."));
        }
    }

    private void handleTrigger(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /adminevents trigger <event>"));
            return;
        }
        if (args[1].equalsIgnoreCase("election")) {
            if (electionManager == null) {
                player.sendMessage(TextUtil.parse("<red>Election system is not initialized.</red>"));
                return;
            }
            if (electionManager.isActive()) {
                player.sendMessage(TextUtil.parse("<red>An election is already active.</red>"));
                return;
            }
            electionManager.startElection();
            player.sendMessage(TextUtil.parse("<green>Started a new election!</green>"));
            return;
        }
        try {
            ArenaEventEngine.EventType eventType = ArenaEventEngine.EventType.valueOf(args[1].toUpperCase());
            if (arenaEventEngine.isEventActive(eventType)) {
                player.sendMessage(TextUtil.parse("<red>Event is already active."));
                return;
            }
            if (!arenaEventEngine.isEventEnabled(eventType)) {
                player.sendMessage(TextUtil.parse("<red>Event is disabled. Use toggle first."));
                return;
            }
            arenaEventEngine.triggerEvent(eventType);
            player.sendMessage(TextUtil.parse("<green>Triggered event: <white>" + eventType.displayName() + "</white>"));
        } catch (IllegalArgumentException e) {
            String names = Stream.of(ArenaEventEngine.EventType.values())
                    .map(Enum::name).map(String::toLowerCase)
                    .collect(Collectors.joining(", "));
            player.sendMessage(TextUtil.parse("<red>Valid events: " + names));
        }
    }

    private void handleStop(Player player, String[] args) {
        if (args.length < 2) {
            // Stop all events
            for (ArenaEventEngine.EventType type : ArenaEventEngine.EventType.values()) {
                if (arenaEventEngine.isEventActive(type)) {
                    arenaEventEngine.endEvent(type);
                }
            }
            for (Map.Entry<String, Boolean> entry : eventManager.getActiveEvents().entrySet()) {
                if (entry.getValue()) {
                    eventManager.endEvent(entry.getKey());
                }
            }
            player.sendMessage(TextUtil.parse("<green>Stopped all active events."));
            return;
        }
        // Try arena event first
        try {
            ArenaEventEngine.EventType eventType = ArenaEventEngine.EventType.valueOf(args[1].toUpperCase());
            if (!arenaEventEngine.isEventActive(eventType)) {
                player.sendMessage(TextUtil.parse("<red>Event not active."));
                return;
            }
            arenaEventEngine.endEvent(eventType);
            player.sendMessage(TextUtil.parse("<green>Stopped event: <white>" + eventType.displayName() + "</white>"));
            return;
        } catch (IllegalArgumentException ignored) {}
        if (args[1].equalsIgnoreCase("election") && electionManager != null) {
            if (!electionManager.isActive()) {
                player.sendMessage(TextUtil.parse("<red>No election is active.</red>"));
                return;
            }
            electionManager.abortElection();
            player.sendMessage(TextUtil.parse("<green>Election cancelled.</green>"));
            return;
        }
        // Try event manager event
        if (eventManager.isEventActive(args[1])) {
            eventManager.endEvent(args[1]);
            player.sendMessage(TextUtil.parse("<green>Stopped event: <white>" + args[1] + "</white>"));
            return;
        }
        player.sendMessage(TextUtil.parse("<red>Unknown event: " + args[1]));
    }

    private void handleList(Player player) {
        player.sendMessage(TextUtil.parse("<aqua><bold>Active Events</bold></aqua>"));
        boolean found = false;
        for (ArenaEventEngine.EventType type : ArenaEventEngine.EventType.values()) {
            boolean enabled = arenaEventEngine.isEventEnabled(type);
            boolean active = arenaEventEngine.isEventActive(type);
            String color = active ? "<green>" : (enabled ? "<yellow>" : "<red>");
            String status = active ? "Active" : (enabled ? "Enabled" : "Disabled");
            player.sendMessage(TextUtil.parse(color + type.displayName() + " <dark_gray>|</dark_gray> " + status + "</color>"));
            if (active) found = true;
        }
        for (Map.Entry<String, Boolean> entry : eventManager.getActiveEvents().entrySet()) {
            if (entry.getValue()) {
                String label = entry.getKey().equals("2x_shards")
                        ? String.format("%.1fx Shards", eventManager.getShardMultiplier())
                        : entry.getKey();
                player.sendMessage(TextUtil.parse("<green>" + label + " <dark_gray>|</dark_gray> Active</green>"));
                found = true;
            }
        }
        if (!found) {
            player.sendMessage(TextUtil.parse("<gray>No active events.</gray>"));
        }
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            return filter(literals("shardsmulti", "trigger", "stop", "list"), args[0]);
        }
        if (args.length == 2) {
            return switch (args[0].toLowerCase()) {
                case "trigger" -> {
                    List<String> events = new ArrayList<>();
                    events.add("election");
                    Stream.of(ArenaEventEngine.EventType.values()).map(Enum::name).map(String::toLowerCase).forEach(events::add);
                    yield filter(events, args[1]);
                }
                case "stop" -> {
                    List<String> all = new ArrayList<>();
                    all.add("all");
                    Stream.of(ArenaEventEngine.EventType.values())
                            .filter(arenaEventEngine::isEventActive)
                            .map(Enum::name).map(String::toLowerCase)
                            .forEach(all::add);
                    if (eventManager.isEventActive("2x_shards")) all.add("2x_shards");
                    if (electionManager != null && electionManager.isActive()) all.add("election");
                    yield filter(all, args[1]);
                }
                default -> List.of();
            };
        }
        return List.of();
    }

    @Override
    protected String permission() {
        return "unstable.admin";
    }
}
