package lol.folium.unstable.trade;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import lol.folium.unstable.UnstableRemixPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class TradeManager {

    private static TradeManager instance;
    private final UnstableRemixPlugin plugin;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final Path dataFolder;
    private final File historyFile;

    private final Map<UUID, ActiveTrade> activeTrades = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> pendingRequests = new ConcurrentHashMap<>();

    private final Set<Material> ALLOWED_MATERIALS = EnumSet.of(
            Material.ELYTRA,
            Material.MACE,
            Material.TOTEM_OF_UNDYING,
            Material.END_CRYSTAL,
            Material.FIREWORK_ROCKET,
            Material.GOLDEN_APPLE,
            Material.ENCHANTED_GOLDEN_APPLE,
            Material.ENDER_PEARL,
            Material.ENDER_EYE,
            Material.BOW,
            Material.CROSSBOW,
            Material.TRIDENT,
            Material.SHIELD,
            Material.NETHERITE_SWORD,
            Material.NETHERITE_AXE,
            Material.NETHERITE_PICKAXE,
            Material.NETHERITE_HELMET,
            Material.NETHERITE_CHESTPLATE,
            Material.NETHERITE_LEGGINGS,
            Material.NETHERITE_BOOTS,
            Material.DIAMOND_SWORD,
            Material.DIAMOND_AXE,
            Material.DIAMOND_PICKAXE,
            Material.DIAMOND_HELMET,
            Material.DIAMOND_CHESTPLATE,
            Material.DIAMOND_LEGGINGS,
            Material.DIAMOND_BOOTS,
            Material.IRON_SWORD,
            Material.IRON_AXE,
            Material.IRON_CHESTPLATE,
            Material.IRON_LEGGINGS,
            Material.IRON_BOOTS,
            Material.GOLDEN_SWORD,
            Material.GOLDEN_HELMET,
            Material.GOLDEN_CHESTPLATE,
            Material.GOLDEN_BOOTS,
            Material.CHAINMAIL_HELMET,
            Material.CHAINMAIL_CHESTPLATE,
            Material.CHAINMAIL_LEGGINGS,
            Material.CHAINMAIL_BOOTS,
            Material.TURTLE_HELMET,
            Material.BREATHING_STILL_AIR,
            Material.ARROW,
            Material.SPECTRAL_ARROW,
            Material.TIPPED_ARROW,
            Material.EXPERIENCE_BOTTLE,
            Material.EMERALD,
            Material.DIAMOND,
            Material.NETHERITE_INGOT,
            Material.GOLD_INGOT,
            Material.IRON_INGOT,
            Material.NETHER_STAR,
            Material.DRAGON_BREATH,
            Material.CHORUS_FRUIT,
            Material.PHANTOM_MEMBRANE,
            Material.CONDUIT,
            Material.BEACON,
            Material.SHULKER_BOX,
            Material.BUNDLE,
            Material.CHEST,
            Material.BARREL
    );

    private final Set<Material> BLOCKED_MATERIALS = EnumSet.of(
            Material.SHULKER_BOX,
            Material.BUNDLE,
            Material.WHITE_SHULKER_BOX, Material.ORANGE_SHULKER_BOX, Material.MAGENTA_SHULKER_BOX,
            Material.LIGHT_BLUE_SHULKER_BOX, Material.YELLOW_SHULKER_BOX, Material.LIME_SHULKER_BOX,
            Material.PINK_SHULKER_BOX, Material.GRAY_SHULKER_BOX, Material.LIGHT_GRAY_SHULKER_BOX,
            Material.CYAN_SHULKER_BOX, Material.PURPLE_SHULKER_BOX, Material.BLUE_SHULKER_BOX,
            Material.BROWN_SHULKER_BOX, Material.GREEN_SHULKER_BOX, Material.RED_SHULKER_BOX,
            Material.BLACK_SHULKER_BOX
    );

    public static final int MAX_RANGE = 20;

    public static TradeManager getInstance() {
        return instance;
    }

    public TradeManager(UnstableRemixPlugin plugin) {
        instance = this;
        this.plugin = plugin;
        this.dataFolder = plugin.getDataFolder().toPath();
        this.historyFile = dataFolder.resolve("trade-history.json").toFile();
    }

    public void init() {
        loadHistory();
    }

    // ============ TRADE REQUESTS ============

    public boolean sendRequest(Player sender, Player target) {
        if (sender.equals(target)) return false;
        if (activeTrades.containsKey(sender.getUniqueId())) return false;
        if (activeTrades.containsKey(target.getUniqueId())) return false;
        if (sender.getLocation().distanceSquared(target.getLocation()) > MAX_RANGE * MAX_RANGE) return false;
        if (!isTradeableItem(sender)) return false;
        if (!isTradeableItem(target)) return false;

        pendingRequests.put(target.getUniqueId(), sender.getUniqueId());
        return true;
    }

    public UUID getPendingRequest(UUID uuid) {
        return pendingRequests.get(uuid);
    }

    public void clearRequest(UUID uuid) {
        pendingRequests.remove(uuid);
    }

    // ============ TRADE EXECUTION ============

    public boolean acceptRequest(Player accepter) {
        UUID senderId = pendingRequests.remove(accepter.getUniqueId());
        if (senderId == null) return false;

        Player sender = Bukkit.getPlayer(senderId);
        if (sender == null || !sender.isOnline()) return false;

        if (sender.getLocation().distanceSquared(accepter.getLocation()) > MAX_RANGE * MAX_RANGE) return false;

        ActiveTrade trade = new ActiveTrade(sender.getUniqueId(), accepter.getUniqueId());
        activeTrades.put(sender.getUniqueId(), trade);
        activeTrades.put(accepter.getUniqueId(), trade);
        return true;
    }

    public ActiveTrade getActiveTrade(UUID uuid) {
        return activeTrades.get(uuid);
    }

    public void cancelTrade(UUID uuid) {
        ActiveTrade trade = activeTrades.remove(uuid);
        if (trade == null) return;
        activeTrades.remove(trade.sender());
        activeTrades.remove(trade.receiver());
        returnItems(trade);
    }

    public void confirmTrade(UUID uuid) {
        ActiveTrade trade = activeTrades.get(uuid);
        if (trade == null) return;

        if (uuid.equals(trade.sender())) {
            trade.setSenderConfirmed(true);
        } else {
            trade.setReceiverConfirmed(true);
        }

        if (trade.bothConfirmed()) {
            executeTrade(trade);
        }
    }

    private void executeTrade(ActiveTrade trade) {
        Player sender = Bukkit.getPlayer(trade.sender());
        Player receiver = Bukkit.getPlayer(trade.receiver());

        if (sender == null || !sender.isOnline() || receiver == null || !receiver.isOnline()) {
            cancelTrade(trade.sender());
            return;
        }

        if (sender.getLocation().distanceSquared(receiver.getLocation()) > MAX_RANGE * MAX_RANGE) {
            cancelTrade(trade.sender());
            return;
        }

        if (!trade.isCountdownComplete()) {
            return;
        }

        ItemStack[] senderItems = trade.getSenderItems().clone();
        ItemStack[] receiverItems = trade.getReceiverItems().clone();

        // Validate items still in inventory
        if (!validateItems(sender, senderItems) || !validateItems(receiver, receiverItems)) {
            cancelTrade(trade.sender());
            return;
        }

        // Atomic swap: remove all first, then give all
        for (ItemStack item : senderItems) {
            if (item != null) removeItemFromInventory(sender, item);
        }
        for (ItemStack item : receiverItems) {
            if (item != null) removeItemFromInventory(receiver, item);
        }

        // Give items
        for (ItemStack item : senderItems) {
            if (item != null) giveItem(receiver, item);
        }
        for (ItemStack item : receiverItems) {
            if (item != null) giveItem(sender, item);
        }

        // Clean up
        activeTrades.remove(trade.sender());
        activeTrades.remove(trade.receiver());

        // Log trade
        logTrade(trade, senderItems, receiverItems);

        sender.sendMessage(lol.folium.unstable.util.TextUtil.parse("<green><bold>Trade Complete!</bold></green> <gray>You traded with</gray> <white>" + receiver.getName() + "</white>"));
        receiver.sendMessage(lol.folium.unstable.util.TextUtil.parse("<green><bold>Trade Complete!</bold></green> <gray>You traded with</gray> <white>" + sender.getName() + "</white>"));
    }

    // ============ ITEM VALIDATION ============

    public boolean isBlocked(Material mat) {
        return BLOCKED_MATERIALS.contains(mat);
    }

    public boolean isTradeableItem(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && isBlocked(item.getType())) {
                return false;
            }
        }
        return true;
    }

    public long getItemValue(ItemStack item) {
        if (item == null) return 0;
        // Simple value calculation based on material
        return switch (item.getType()) {
            case NETHERITE_SWORD, NETHERITE_AXE, NETHERITE_PICKAXE -> 500;
            case NETHERITE_HELMET, NETHERITE_CHESTPLATE, NETHERITE_LEGGINGS, NETHERITE_BOOTS -> 400;
            case DIAMOND_SWORD, DIAMOND_AXE, DIAMOND_PICKAXE -> 300;
            case DIAMOND_HELMET, DIAMOND_CHESTPLATE, DIAMOND_LEGGINGS, DIAMOND_BOOTS -> 250;
            case ELYTRA -> 1000;
            case MACE -> 800;
            case TOTEM_OF_UNDYING -> 600;
            case TRIDENT -> 700;
            case NETHER_STAR -> 900;
            case ENCHANTED_GOLDEN_APPLE -> 500;
            case GOLDEN_APPLE -> 100;
            case BEACON -> 400;
            case CONDUIT -> 350;
            case NETHERITE_INGOT -> 200;
            case DIAMOND -> 50;
            case EMERALD -> 10;
            case GOLD_INGOT -> 5;
            case IRON_INGOT -> 2;
            case EXPERIENCE_BOTTLE -> 15;
            case END_CRYSTAL -> 150;
            case FIREWORK_ROCKET -> 5;
            case SHIELD -> 50;
            case BOW -> 75;
            case CROSSBOW -> 100;
            default -> 1;
        } * item.getAmount();
    }

    private boolean validateItems(Player player, ItemStack[] items) {
        for (ItemStack item : items) {
            if (item == null) continue;
            if (!hasItem(player, item)) return false;
        }
        return true;
    }

    private boolean hasItem(Player player, ItemStack item) {
        for (ItemStack inv : player.getInventory().getContents()) {
            if (inv != null && inv.isSimilar(item) && inv.getAmount() >= item.getAmount()) {
                return true;
            }
        }
        return false;
    }

    private void removeItemFromInventory(Player player, ItemStack item) {
        int remaining = item.getAmount();
        for (int i = 0; i < player.getInventory().getSize() && remaining > 0; i++) {
            ItemStack inv = player.getInventory().getItem(i);
            if (inv != null && inv.isSimilar(item)) {
                int take = Math.min(remaining, inv.getAmount());
                inv.setAmount(inv.getAmount() - take);
                remaining -= take;
            }
        }
    }

    private void giveItem(Player player, ItemStack item) {
        HashMap<Integer, ItemStack> leftover = player.getInventory().addItem(item.clone());
        for (ItemStack drop : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), drop);
        }
    }

    private void returnItems(ActiveTrade trade) {
        Player sender = Bukkit.getPlayer(trade.sender());
        Player receiver = Bukkit.getPlayer(trade.receiver());

        if (sender != null && sender.isOnline()) {
            for (ItemStack item : trade.getSenderItems()) {
                if (item != null) giveItem(sender, item);
            }
            sender.sendMessage(lol.folium.unstable.util.TextUtil.parse("<red>Trade cancelled.</red>"));
        }
        if (receiver != null && receiver.isOnline()) {
            for (ItemStack item : trade.getReceiverItems()) {
                if (item != null) giveItem(receiver, item);
            }
            receiver.sendMessage(lol.folium.unstable.util.TextUtil.parse("<red>Trade cancelled.</red>"));
        }
    }

    // ============ HISTORY ============

    private final List<TradeRecord> tradeHistory = new ArrayList<>();

    private void logTrade(ActiveTrade trade, ItemStack[] senderItems, ItemStack[] receiverItems) {
        TradeRecord record = new TradeRecord(
                trade.sender(),
                trade.receiver(),
                serializeItems(senderItems),
                serializeItems(receiverItems),
                System.currentTimeMillis()
        );
        tradeHistory.add(record);
        saveHistory();
    }

    public List<TradeRecord> getHistory(UUID uuid) {
        List<TradeRecord> result = new ArrayList<>();
        for (TradeRecord r : tradeHistory) {
            if (r.sender().equals(uuid) || r.receiver().equals(uuid)) {
                result.add(r);
            }
        }
        result.sort((a, b) -> Long.compare(b.timestamp(), a.timestamp()));
        return result;
    }

    public List<TradeRecord> getRecentTrades(int limit) {
        List<TradeRecord> sorted = new ArrayList<>(tradeHistory);
        sorted.sort((a, b) -> Long.compare(b.timestamp(), a.timestamp()));
        return sorted.subList(0, Math.min(limit, sorted.size()));
    }

    private String[] serializeItems(ItemStack[] items) {
        List<String> result = new ArrayList<>();
        for (ItemStack item : items) {
            if (item != null) {
                result.add(item.getAmount() + "x " + item.getType().name());
            }
        }
        return result.toArray(new String[0]);
    }

    private void saveHistory() {
        try {
            JsonObject root = new JsonObject();
            com.google.gson.JsonArray arr = new com.google.gson.JsonArray();
            for (TradeRecord r : tradeHistory) {
                JsonObject obj = new JsonObject();
                obj.addProperty("sender", r.sender().toString());
                obj.addProperty("receiver", r.receiver().toString());
                obj.addProperty("timestamp", r.timestamp());
                com.google.gson.JsonArray senderItems = new com.google.gson.JsonArray();
                for (String s : r.senderItems()) senderItems.add(s);
                obj.add("senderItems", senderItems);
                com.google.gson.JsonArray receiverItems = new com.google.gson.JsonArray();
                for (String s : r.receiverItems()) receiverItems.add(s);
                obj.add("receiverItems", receiverItems);
                arr.add(obj);
            }
            root.add("trades", arr);
            historyFile.getParentFile().mkdirs();
            try (Writer writer = new OutputStreamWriter(new FileOutputStream(historyFile), StandardCharsets.UTF_8)) {
                gson.toJson(root, writer);
            }
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to save trade history: " + e.getMessage());
        }
    }

    private void loadHistory() {
        if (!historyFile.exists()) return;
        try {
            String json = new String(Files.readAllBytes(historyFile.toPath()), StandardCharsets.UTF_8);
            JsonObject root = JsonParser.parseString(json).getAsJsonObject();
            com.google.gson.JsonArray arr = root.getAsJsonArray("trades");
            if (arr == null) return;
            for (com.google.gson.JsonElement el : arr) {
                JsonObject obj = el.getAsJsonObject();
                UUID sender = UUID.fromString(obj.get("sender").getAsString());
                UUID receiver = UUID.fromString(obj.get("receiver").getAsString());
                long timestamp = obj.get("timestamp").getAsLong();
                List<String> sItems = new ArrayList<>();
                for (com.google.gson.JsonElement si : obj.getAsJsonArray("senderItems")) sItems.add(si.getAsString());
                List<String> rItems = new ArrayList<>();
                for (com.google.gson.JsonElement ri : obj.getAsJsonArray("receiverItems")) rItems.add(ri.getAsString());
                tradeHistory.add(new TradeRecord(sender, receiver, sItems.toArray(new String[0]), rItems.toArray(new String[0]), timestamp));
            }
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to load trade history: " + e.getMessage());
        }
    }

    // ============ ACTIVE TRADE ============

    public static class ActiveTrade {
        private final UUID sender;
        private final UUID receiver;
        private final ItemStack[] senderItems = new ItemStack[27];
        private final ItemStack[] receiverItems = new ItemStack[27];
        private boolean senderConfirmed = false;
        private boolean receiverConfirmed = false;
        private long countdownStart = 0;
        private boolean countdownStarted = false;
        private boolean completed = false;

        public ActiveTrade(UUID sender, UUID receiver) {
            this.sender = sender;
            this.receiver = receiver;
        }

        public UUID sender() { return sender; }
        public UUID receiver() { return receiver; }
        public ItemStack[] getSenderItems() { return senderItems; }
        public ItemStack[] getReceiverItems() { return receiverItems; }
        public boolean isSenderConfirmed() { return senderConfirmed; }
        public boolean isReceiverConfirmed() { return receiverConfirmed; }
        public boolean bothConfirmed() { return senderConfirmed && receiverConfirmed; }
        public boolean isCompleted() { return completed; }

        public void setSenderConfirmed(boolean v) { senderConfirmed = v; }
        public void setReceiverConfirmed(boolean v) { receiverConfirmed = v; }

        public void startCountdown() {
            countdownStart = System.currentTimeMillis();
            countdownStarted = true;
        }

        public boolean isCountdownStarted() { return countdownStarted; }

        public boolean isCountdownComplete() {
            if (!countdownStarted) return false;
            return System.currentTimeMillis() - countdownStart >= 5000;
        }

        public long getCountdownRemaining() {
            if (!countdownStarted) return 5;
            long elapsed = (System.currentTimeMillis() - countdownStart) / 1000;
            return Math.max(0, 5 - elapsed);
        }

        public void resetConfirmations() {
            senderConfirmed = false;
            receiverConfirmed = false;
            countdownStarted = false;
            countdownStart = 0;
        }

        public ItemStack[] getItemsFor(UUID uuid) {
            return uuid.equals(sender) ? senderItems : receiverItems;
        }

        public ItemStack[] getOtherItems(UUID uuid) {
            return uuid.equals(sender) ? receiverItems : senderItems;
        }
    }

    // ============ TRADE RECORD ============

    public record TradeRecord(UUID sender, UUID receiver, String[] senderItems, String[] receiverItems, long timestamp) {}
}
