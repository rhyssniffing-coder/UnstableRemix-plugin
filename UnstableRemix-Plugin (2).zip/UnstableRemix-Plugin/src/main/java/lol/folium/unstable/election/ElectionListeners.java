package lol.folium.unstable.election;

import lol.folium.unstable.util.TextUtil;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.util.List;

public final class ElectionListeners implements Listener {

    private final ElectionManager elections;

    private static final List<String> PHASE_JOIN_MESSAGES = List.of(
        "REGISTRATION",
        "VOTING"
    );

    public ElectionListeners(ElectionManager elections) {
        this.elections = elections;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        String phase = elections.getPhase();

        if (!PHASE_JOIN_MESSAGES.contains(phase)) return;

        switch (phase) {
            case "REGISTRATION" -> {
                player.sendMessage(TextUtil.parse("<gold><bold>\u2696 An election is underway! Registration is open.</bold></gold>"));
                player.sendMessage(TextUtil.parse("<yellow>Use /campaign start <manifesto> to run!</yellow>"));
            }
            case "VOTING" -> {
                player.sendMessage(TextUtil.parse("<gold><bold>\u2696 Voting is now open!</bold></gold>"));
                int electionId = elections.getCurrentElectionId();
                if (electionId >= 0 && !elections.getStore().hasVoted(electionId, player.getUniqueId())) {
                    player.sendMessage(TextUtil.parse("<yellow>Use /vote to cast your ballot!</yellow>"));
                }
            }
        }
    }
}
