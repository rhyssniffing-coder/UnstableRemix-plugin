package lol.folium.unstable.leaderboard;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.GuiTheme;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class HologramCommand implements CommandExecutor, TabCompleter {

    private final UnstableRemixPlugin plugin;
    private final HolographicLeaderboard hologramLeaderboard;

    public HologramCommand(UnstableRemixPlugin plugin, HolographicLeaderboard hologramLeaderboard) {
        this.plugin = plugin;
        this.hologramLeaderboard = hologramLeaderboard;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        String sub = args[0].toLowerCase();
        switch (sub) {
            case "create":
                return handleCreate(player, args);
            case "remove":
                return handleRemove(player, args);
            case "list":
                return handleList(player);
            case "spawn":
                hologramLeaderboard.spawnAll();
                player.sendMessage(GuiTheme.primary("&aSpawned all holographic leaderboards!"));
                return true;
            case "removeall":
                hologramLeaderboard.removeAll();
                player.sendMessage(GuiTheme.primary("&cRemoved all holographic leaderboards!"));
                return true;
            default:
                sendHelp(player);
                return true;
        }
    }

    private boolean handleCreate(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(GuiTheme.primary("&cUsage: /hologram create <name> <category>"));
            return true;
        }

        String name = args[1];
        String categoryStr = args[2];

        try {
            LeaderboardManager.Category category = LeaderboardManager.Category.valueOf(categoryStr.toUpperCase());
            hologramLeaderboard.addDisplay(name, player.getLocation().clone(), category, 10);
            player.sendMessage(GuiTheme.primary("&aCreated holographic leaderboard: &f" + name));
            player.sendMessage(GuiTheme.primary("&7Category: &f" + category.displayName));
            player.sendMessage(GuiTheme.primary("&7Location: &f" + formatLocation(player.getLocation())));
            hologramLeaderboard.removeAll();
            hologramLeaderboard.spawnAll();
        } catch (IllegalArgumentException e) {
            player.sendMessage(GuiTheme.primary("&cInvalid category! Use: kills, deaths, killstreak, shards, playtime, match_wins, kd_ratio"));
        }
        return true;
    }

    private boolean handleRemove(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(GuiTheme.primary("&cUsage: /hologram remove <name>"));
            return true;
        }

        String name = args[1];
        hologramLeaderboard.removeDisplay(name);
        player.sendMessage(GuiTheme.primary("&cRemoved holographic leaderboard: &f" + name));
        return true;
    }

    private boolean handleList(Player player) {
        List<String> names = hologramLeaderboard.getDisplayNames();
        if (names.isEmpty()) {
            player.sendMessage(GuiTheme.primary("&7No holographic leaderboards placed."));
            return true;
        }

        player.sendMessage(GuiTheme.primary("&aHolographic Leaderboards:"));
        for (String name : names) {
            player.sendMessage(GuiTheme.primary("  &7- &f" + name));
        }
        return true;
    }

    private void sendHelp(Player player) {
        player.sendMessage(GuiTheme.primary("&6&lHolographic Leaderboard Commands"));
        player.sendMessage(GuiTheme.primary("&7/hologram create <name> <category> &f- Create at your location"));
        player.sendMessage(GuiTheme.primary("&7/hologram remove <name> &f- Remove a hologram"));
        player.sendMessage(GuiTheme.primary("&7/hologram list &f- List all holograms"));
        player.sendMessage(GuiTheme.primary("&7/hologram spawn &f- Spawn all holograms"));
        player.sendMessage(GuiTheme.primary("&7/hologram removeall &f- Remove all holograms"));
    }

    private String formatLocation(org.bukkit.Location loc) {
        return loc.getWorld().getName() + " " +
                String.format("%.1f", loc.getX()) + ", " +
                String.format("%.1f", loc.getY()) + ", " +
                String.format("%.1f", loc.getZ());
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            completions.add("create");
            completions.add("remove");
            completions.add("list");
            completions.add("spawn");
            completions.add("removeall");
        } else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("create")) {
                completions.add("kills");
                completions.add("deaths");
                completions.add("killstreak");
                completions.add("shards");
                completions.add("playtime");
                completions.add("match_wins");
                completions.add("kd_ratio");
            } else if (args[0].equalsIgnoreCase("remove")) {
                completions.addAll(hologramLeaderboard.getDisplayNames());
            }
        }

        String lastArg = args[args.length - 1].toLowerCase();
        completions.removeIf(s -> !s.toLowerCase().startsWith(lastArg));
        return completions;
    }
}
