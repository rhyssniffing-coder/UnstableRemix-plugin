package lol.folium.unstable.map;

import lol.folium.unstable.command.SubCommand;
import org.bukkit.entity.Player;

import java.util.List;

public final class MapVoteCommand extends SubCommand {

    private final MapVoteManager mapVoteManager;

    public MapVoteCommand(MapVoteManager mapVoteManager) {
        this.mapVoteManager = mapVoteManager;
    }

    @Override
    protected void execute(Player player, String[] args) {
        mapVoteManager.openVoteGUI(player);
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        return List.of();
    }

    @Override
    protected String permission() {
        return null;
    }
}
