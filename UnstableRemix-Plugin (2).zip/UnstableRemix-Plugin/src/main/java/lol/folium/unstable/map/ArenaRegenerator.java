package lol.folium.unstable.map;

import lol.folium.unstable.UnstableRemixPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class ArenaRegenerator {

    private final UnstableRemixPlugin plugin;
    private final Map<String, BukkitTask> active = new ConcurrentHashMap<>();

    public ArenaRegenerator(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    public void regenerate(Arena arena) {
        cancel(arena.name());
        List<BlockSnapshot> blocks = new ArrayList<>(arena.placedBlocks());
        if (blocks.isEmpty()) {
            return;
        }
        int perTick = plugin.getConfig().getInt("map.regeneration-blocks-per-tick", 5);
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, new Runnable() {
            private final Iterator<BlockSnapshot> iterator = blocks.iterator();

            @Override
            public void run() {
                World world = arena.world();
                if (world == null) {
                    finish(arena);
                    return;
                }
                int processed = 0;
                while (iterator.hasNext() && processed < perTick) {
                    BlockSnapshot snapshot = iterator.next();
                    world.getBlockAt(snapshot.x(), snapshot.y(), snapshot.z())
                            .setType(snapshot.original() == Material.AIR ? Material.AIR : snapshot.original(), false);
                    arena.placedBlocks().remove(snapshot);
                    processed++;
                }
                if (!iterator.hasNext()) {
                    finish(arena);
                }
            }

            private void finish(Arena arena) {
                arena.placedBlocks().clear();
                cancel(arena.name());
            }
        }, 1L, 1L);
        active.put(arena.name(), task);
    }

    public void cancel(String arenaName) {
        BukkitTask task = active.remove(arenaName);
        if (task != null) {
            task.cancel();
        }
    }
}
