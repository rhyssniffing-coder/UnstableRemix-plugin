package lol.folium.unstable.kitrole;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.map.Arena;
import lol.folium.unstable.map.ArenaManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.*;

public class KitRoleManager {

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;

    // Role definitions loaded from config
    private final Map<String, RoleDefinition> roleDefinitions = new LinkedHashMap<>();
    // Faction definitions loaded from config
    private final Map<String, FactionDefinition> factionDefinitions = new LinkedHashMap<>();

    // Active game state
    private final Map<UUID, String> playerFactions = new HashMap<>();       // player -> faction name
    private final Map<UUID, String> playerRoles = new HashMap<>();         // player -> role name (only for assigned role players)
    private final Map<UUID, Long> roleStartTime = new HashMap<>();         // player -> role assignment timestamp
    private final Map<UUID, List<ItemSnapshot>> roleInventory = new HashMap<>(); // saved role inventory on death
    private String activeGameArena = null;
    private boolean gameRunning = false;
    private BukkitRunnable roleTimer;

    // Role inventory snapshots on assignment
    private record ItemSnapshot(Material material, int amount, short durability, Map<String, String> meta) {}

    public KitRoleManager(UnstableRemixPlugin plugin, ConfigManager configs) {
        this.plugin = plugin;
        this.configs = configs;
    }

    public void loadConfig() {
        roleDefinitions.clear();
        factionDefinitions.clear();

        FileConfiguration config = plugin.getConfig();

        // Load role definitions
        var roleSection = config.getConfigurationSection("kit-roles.roles");
        if (roleSection != null) {
            for (String key : roleSection.getKeys(false)) {
                var section = roleSection.getConfigurationSection(key);
                if (section == null) continue;
                String displayName = section.getString("display-name", key);
                String kitName = section.getString("kit", key.toLowerCase());
                int color = section.getInt("color", 0xFFFFFF);
                List<String> kitItems = section.getStringList("kit-items");
                List<String> kitLore = section.getStringList("lore");
                roleDefinitions.put(key.toLowerCase(), new RoleDefinition(key, displayName, kitName, color, kitItems, kitLore));
            }
        }

        // Load faction definitions
        var factionSection = config.getConfigurationSection("kit-roles.factions");
        if (factionSection != null) {
            for (String key : factionSection.getKeys(false)) {
                var section = factionSection.getConfigurationSection(key);
                if (section == null) continue;
                String displayName = section.getString("display-name", key);
                int color = section.getInt("color", 0xFFFFFF);
                String prefix = section.getString("prefix", "");
                List<String> items = section.getStringList("kit-items");
                List<String> kitLore = section.getStringList("lore");
                int roleKillMultiplier = section.getInt("role-kill-reward-multiplier", 3);
                factionDefinitions.put(key.toLowerCase(), new FactionDefinition(key, displayName, color, prefix, items, kitLore, roleKillMultiplier));
            }
        }
    }

    // ============ GAME STATE ============

    public boolean startGame(String arenaName) {
        if (gameRunning) return false;
        Arena arena = plugin.getArenaManager().getArena(arenaName);
        if (arena == null) return false;

        gameRunning = true;
        activeGameArena = arenaName;
        playerFactions.clear();
        playerRoles.clear();
        roleStartTime.clear();
        roleInventory.clear();

        // Teleport all players to arena
        for (UUID uuid : arena.players()) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null && arena.lobby() != null) {
                player.teleport(arena.lobby());
            }
        }

        // Assign random roles after 30 second lobby
        new BukkitRunnable() {
            int countdown = 30;
            @Override
            public void run() {
                if (!gameRunning || countdown <= 0) {
                    assignRoles();
                    broadcastRoleAssignments();
                    startRoleTimer();
                    cancel();
                    return;
                }
                // Broadcast countdown
                for (UUID uuid : arena.players()) {
                    Player p = Bukkit.getPlayer(uuid);
                    if (p != null) {
                        p.sendActionBar(Component.text("Roles assigned in " + countdown + "s...", NamedTextColor.GOLD));
                    }
                }
                countdown--;
            }
        }.runTaskTimer(plugin, 0L, 20L);

        return true;
    }

    public void stopGame() {
        gameRunning = false;
        activeGameArena = null;
        playerFactions.clear();
        playerRoles.clear();
        roleStartTime.clear();
        roleInventory.clear();
        if (roleTimer != null) {
            roleTimer.cancel();
            roleTimer = null;
        }
    }

    // ============ ROLE ASSIGNMENT ============

    private void assignRoles() {
        if (activeGameArena == null) return;
        Arena arena = plugin.getArenaManager().getArena(activeGameArena);
        if (arena == null) return;

        List<UUID> onlinePlayers = new ArrayList<>(arena.players());
        Collections.shuffle(onlinePlayers);

        // Pick one role player per available role definition
        List<String> availableRoles = new ArrayList<>(roleDefinitions.keySet());
        Collections.shuffle(availableRoles);

        int roleIndex = 0;
        for (UUID uuid : onlinePlayers) {
            if (roleIndex >= availableRoles.size()) break;
            String roleName = availableRoles.get(roleIndex);
            playerRoles.put(uuid, roleName);
            roleStartTime.put(uuid, System.currentTimeMillis());
            roleIndex++;
        }

        // Assign remaining players random factions
        List<String> factionNames = new ArrayList<>(factionDefinitions.keySet());
        Collections.shuffle(factionNames);

        int factionIndex = 0;
        for (UUID uuid : onlinePlayers) {
            if (playerRoles.containsKey(uuid)) continue; // already has role
            String faction = factionNames.get(factionIndex % factionNames.size());
            playerFactions.put(uuid, faction);
            factionIndex++;
        }

        // Give starting items
        for (UUID uuid : onlinePlayers) {
            Player player = Bukkit.getPlayer(uuid);
            if (player == null) continue;

            if (playerRoles.containsKey(uuid)) {
                giveRoleKit(player, playerRoles.get(uuid));
            } else if (playerFactions.containsKey(uuid)) {
                giveFactionKit(player, playerFactions.get(uuid));
            }

            player.setGameMode(GameMode.SURVIVAL);
            if (arena.lobby() != null) {
                player.teleport(arena.lobby());
            }
        }
    }

    private void giveRoleKit(Player player, String roleName) {
        RoleDefinition role = roleDefinitions.get(roleName);
        if (role == null) return;
        player.getInventory().clear();
        for (String itemStr : role.kitItems()) {
            ItemStack item = parseItem(itemStr);
            if (item != null) {
                player.getInventory().addItem(item);
            }
        }
    }

    private void giveFactionKit(Player player, String factionName) {
        FactionDefinition faction = factionDefinitions.get(factionName);
        if (faction == null) return;
        player.getInventory().clear();
        for (String itemStr : faction.kitItems()) {
            ItemStack item = parseItem(itemStr);
            if (item != null) {
                player.getInventory().addItem(item);
            }
        }
    }

    // ============ DEATH / KILL HANDLING ============

    public void handleDeath(Player player) {
        if (!gameRunning) return;
        UUID uuid = player.getUniqueId();

        // If this player was a role player, transfer the role randomly
        if (playerRoles.containsKey(uuid)) {
            transferRole(uuid);
        }
    }

    public void handleKill(Player killer, Player victim) {
        if (!gameRunning) return;
        UUID killerUuid = killer.getUniqueId();
        UUID victimUuid = victim.getUniqueId();

        String killerFaction = playerFactions.get(killerUuid);
        String killerRole = playerRoles.get(killerUuid);
        String victimRole = playerRoles.get(victimUuid);

        if (killerFaction == null && killerRole == null) return;

        FactionDefinition factionDef = killerFaction != null ? factionDefinitions.get(killerFaction) : null;
        int multiplier = 1;
        if (victimRole != null && factionDef != null) {
            multiplier = factionDef.roleKillMultiplier();
        }

        // Grant reward via economy service
        var econ = plugin.getEconomyService();
        if (econ != null) {
            long baseReward = plugin.getConfig().getLong("kit-roles.kill-reward", 10);
            long totalReward = baseReward * multiplier;
            econ.grantShards(killerUuid, totalReward, "kit-role-kill", UUID.randomUUID().toString());
        }

        // Send messages
        killer.sendMessage(net.kyori.adventure.text.Component.text(
                "You earned " + (plugin.getConfig().getLong("kit-roles.kill-reward", 10) * multiplier) + " shards!",
                NamedTextColor.GREEN
        ));
        if (victimRole != null) {
            killer.sendMessage(net.kyori.adventure.text.Component.text(
                    "You killed a ROLE PLAYER! " + multiplier + "x reward!",
                    NamedTextColor.GOLD
            ));
            killer.sendMessage(net.kyori.adventure.text.Component.text(
                    "Their kit has been added to your inventory!",
                    NamedTextColor.AQUA
            ));
            // Give killer the role's kit items
            RoleDefinition role = roleDefinitions.get(victimRole);
            if (role != null) {
                for (String itemStr : role.kitItems()) {
                    ItemStack item = parseItem(itemStr);
                    if (item != null) {
                        killer.getInventory().addItem(item);
                    }
                }
            }
        }
    }

    private void transferRole(UUID deadPlayer) {
        String roleName = playerRoles.remove(deadPlayer);
        roleStartTime.remove(deadPlayer);
        if (roleName == null) return;

        // Find eligible players in the arena (online, alive, not already a role)
        if (activeGameArena == null) return;
        Arena arena = plugin.getArenaManager().getArena(activeGameArena);
        if (arena == null) return;

        List<UUID> candidates = new ArrayList<>();
        for (UUID uuid : arena.players()) {
            if (uuid.equals(deadPlayer)) continue;
            if (playerRoles.containsKey(uuid)) continue; // already a role
            if (Bukkit.getPlayer(uuid) != null) candidates.add(uuid);
        }

        if (candidates.isEmpty()) {
            // Role lost — no eligible players
            return;
        }

        // Random pick
        UUID newHolder = candidates.get(new Random().nextInt(candidates.size()));
        playerRoles.put(newHolder, roleName);
        roleStartTime.put(newHolder, System.currentTimeMillis());

        Player player = Bukkit.getPlayer(newHolder);
        if (player != null) {
            giveRoleKit(player, roleName);
            player.sendMessage(net.kyori.adventure.text.Component.text(
                    "You have inherited the role: " + roleName + "!",
                    NamedTextColor.LIGHT_PURPLE
            ));
        }
    }

    // ============ ROLE TIMER ============

    private void startRoleTimer() {
        if (roleTimer != null) roleTimer.cancel();

        long roleDurationTicks = plugin.getConfig().getLong("kit-roles.role-duration-minutes", 15) * 60 * 20L;

        roleTimer = new BukkitRunnable() {
            int ticksRemaining = (int) roleDurationTicks;
            @Override
            public void run() {
                if (!gameRunning || ticksRemaining <= 0) {
                    // Reassign roles
                    reassignRoles();
                    ticksRemaining = (int) roleDurationTicks;
                    return;
                }

                // Warn at 60s, 30s, 10s remaining
                if (ticksRemaining == 1200 || ticksRemaining == 600 || ticksRemaining == 200) {
                    for (UUID uuid : playerRoles.keySet()) {
                        Player p = Bukkit.getPlayer(uuid);
                        if (p != null) {
                            int seconds = ticksRemaining / 20;
                            p.sendMessage(net.kyori.adventure.text.Component.text(
                                    "Your role expires in " + seconds + "s!",
                                    NamedTextColor.YELLOW
                            ));
                        }
                    }
                }

                ticksRemaining -= 20; // check every second
            }
        };
        roleTimer.runTaskTimer(plugin, 0L, 20L);
    }

    private void reassignRoles() {
        // Remove all role assignments
        for (Map.Entry<UUID, String> entry : new HashMap<>(playerRoles).entrySet()) {
            Player p = Bukkit.getPlayer(entry.getKey());
            if (p != null) {
                p.sendMessage(net.kyori.adventure.text.Component.text(
                        "Your role has expired! New roles will be assigned.",
                        NamedTextColor.RED
                ));
            }
        }
        playerRoles.clear();
        roleStartTime.clear();

        // Re-assign
        assignRoles();
        broadcastRoleAssignments();
    }

    private void broadcastRoleAssignments() {
        if (activeGameArena == null) return;
        Arena arena = plugin.getArenaManager().getArena(activeGameArena);
        if (arena == null) return;

        for (UUID uuid : arena.players()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) continue;

            p.sendMessage(Component.empty());
            p.sendMessage(Component.text("══════════════════════", NamedTextColor.DARK_PURPLE));
            p.sendMessage(Component.text("  ROLE ASSIGNMENTS", NamedTextColor.LIGHT_PURPLE));
            p.sendMessage(Component.text("══════════════════════", NamedTextColor.DARK_PURPLE));

            if (playerRoles.containsKey(uuid)) {
                RoleDefinition role = roleDefinitions.get(playerRoles.get(uuid));
                if (role != null) {
                    p.sendMessage(Component.text("  You are: " + role.displayName(), NamedTextColor.GOLD));
                }
            } else if (playerFactions.containsKey(uuid)) {
                FactionDefinition faction = factionDefinitions.get(playerFactions.get(uuid));
                if (faction != null) {
                    p.sendMessage(Component.text("  You are: " + faction.displayName(), NamedTextColor.AQUA));
                }
            }
            p.sendMessage(Component.empty());
        }
    }

    // ============ GETTERS ============

    public boolean isGameRunning() { return gameRunning; }
    public String getActiveGameArena() { return activeGameArena; }
    public String getPlayerFaction(UUID uuid) { return playerFactions.get(uuid); }
    public String getPlayerRole(UUID uuid) { return playerRoles.get(uuid); }
    public void joinFaction(UUID uuid, String factionName) { playerFactions.put(uuid, factionName); }
    public boolean isRolePlayer(UUID uuid) { return playerRoles.containsKey(uuid); }
    public boolean hasFaction(UUID uuid) { return playerFactions.containsKey(uuid) || playerRoles.containsKey(uuid); }
    public Map<String, RoleDefinition> getRoleDefinitions() { return Collections.unmodifiableMap(roleDefinitions); }
    public Map<String, FactionDefinition> getFactionDefinitions() { return Collections.unmodifiableMap(factionDefinitions); }

    // ============ HELPER ============

    private ItemStack parseItem(String itemStr) {
        // Format: "material:amount" or "material:amount:data"
        String[] parts = itemStr.split(":");
        try {
            Material mat = Material.valueOf(parts[0].toUpperCase());
            int amount = parts.length > 1 ? Integer.parseInt(parts[1]) : 1;
            return new ItemStack(mat, amount);
        } catch (Exception e) {
            return null;
        }
    }

    // ============ RECORDS ============

    public record RoleDefinition(String key, String displayName, String kitName, int color, List<String> kitItems, List<String> kitLore) {}
    public record FactionDefinition(String key, String displayName, int color, String prefix, List<String> kitItems, List<String> kitLore, int roleKillMultiplier) {}
}
