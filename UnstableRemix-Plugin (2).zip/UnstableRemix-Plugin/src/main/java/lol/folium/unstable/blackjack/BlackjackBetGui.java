package lol.folium.unstable.blackjack;

import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public final class BlackjackBetGui {

    private static final Component TITLE = TextUtil.parse("<gradient:#1a472a:#2d6a4f><bold>Blackjack — Place Bet</bold></gradient>");

    private static final long[] BET_AMOUNTS = {100, 500, 1000, 5000, 10000, 25000, 50000, 100000};
    private static final int[] BET_SLOTS = {11, 12, 13, 14, 15, 29, 30, 31, 32, 33};

    private BlackjackBetGui() {}

    public static Component getTitle() {
        return TITLE;
    }

    public static void open(Player player, EconomyService economy) {
        Inventory inv = Bukkit.createInventory(null, 45, TITLE);

        ItemStack frame = ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE)
                .name(Component.empty()).build();
        for (int i = 0; i < 45; i++) {
            inv.setItem(i, frame);
        }

        ItemStack border = ItemBuilder.of(Material.GREEN_STAINED_GLASS_PANE)
                .name(Component.empty()).build();
        for (int slot : new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 36, 37, 38, 39, 40, 41, 42, 43, 44}) {
            inv.setItem(slot, border);
        }

        inv.setItem(4, ItemBuilder.of(Material.GOLD_NUGGET)
                .name(TextUtil.parse("<gold><bold>Select Bet</bold></gold>"))
                .lore(List.of(TextUtil.parse("<gray>Choose a bet amount to start.</gray>")))
                .build());

        long balance = economy.getShards(player.getUniqueId());
        int[] slots = {19, 20, 21, 22, 23, 24, 25};
        for (int i = 0; i < BET_AMOUNTS.length && i < slots.length; i++) {
            long amount = BET_AMOUNTS[i];
            boolean canAfford = balance >= amount;
            Material mat = canAfford ? Material.SUNFLOWER : Material.BARRIER;
            inv.setItem(slots[i], ItemBuilder.of(mat)
                    .name(TextUtil.parse((canAfford ? "<green>" : "<red>") + "<bold>" + amount + " Shards</bold></green>"))
                    .lore(List.of(
                            TextUtil.parse(canAfford ? "<green>Click to play!</green>" : "<red>Not enough shards!</red>")
                    ))
                    .build());
        }

        player.openInventory(inv);
    }

    public static long getBetForSlot(int slot) {
        int[] slots = {19, 20, 21, 22, 23, 24, 25};
        for (int i = 0; i < BET_AMOUNTS.length && i < slots.length; i++) {
            if (slots[i] == slot) {
                return BET_AMOUNTS[i];
            }
        }
        return -1;
    }
}
