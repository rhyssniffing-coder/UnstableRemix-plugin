package lol.folium.unstable.settings;

import lol.folium.unstable.util.GuiTheme;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SettingsCommand implements CommandExecutor {

    private final SettingsListener listener;

    public SettingsCommand(SettingsListener listener) {
        this.listener = listener;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(GuiTheme.primary("&cOnly players can use this command"));
            return true;
        }

        Player player = (Player) sender;
        listener.openSettings(player);
        return true;
    }
}
