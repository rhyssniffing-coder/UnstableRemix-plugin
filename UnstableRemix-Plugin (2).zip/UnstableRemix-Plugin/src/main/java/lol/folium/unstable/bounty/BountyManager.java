package lol.folium.unstable.bounty;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.economy.TransactionResult;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.io.IOException;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

public final class BountyManager {

    private final UnstableRemixPlugin plugin;
    private final EconomyService economy;
    private final Map<UUID, Long> bounties = new ConcurrentHashMap<>();
    private final AtomicBoolean savePending = new AtomicBoolean(false);
    private int glowTaskId = -1;
    private File file;

    public BountyManager(UnstableRemixPlugin plugin, EconomyService economy) {
        this.plugin = plugin;
        this.economy = economy;
    }

    public void load() {
        bounties.clear();
        file = new File(plugin.getDataFolder(), "bounties.yml");
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        if (!yaml.contains("bounties")) {
            return;
        }
        for (String key : yaml.getConfigurationSection("bounties").getKeys(false)) {
            try {
                bounties.put(UUID.fromString(key), yaml.getLong("bounties." + key));
            } catch (IllegalArgumentException ignored) {
            }
        }
        startGlowTask();
    }

    public void startGlowTask() {
        stopGlowTask();
        glowTaskId = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (bounties.containsKey(player.getUniqueId())) {
                    player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 100, 0, false, false));
                }
            }
        }, 40L, 40L).getTaskId();
    }

    public void stopGlowTask() {
        if (glowTaskId != -1) {
            Bukkit.getScheduler().cancelTask(glowTaskId);
            glowTaskId = -1;
        }
    }

    public void place(Player placer, Player target, long amount) {
        if (amount <= 0 || target.equals(placer)) {
            placer.sendMessage(TextUtil.parse("<red>Invalid bounty."));
            return;
        }
        TransactionResult spend = economy.spendShards(placer.getUniqueId(), amount, "bounty:" + target.getUniqueId());
        if (!spend.success()) {
            economy.notifyFailure(placer, spend.messageKey(), amount);
            return;
        }
        bounties.merge(target.getUniqueId(), amount, Long::sum);
        save();
        Bukkit.broadcast(TextUtil.parse("<red><bold>Bounty</bold></red> <gray>" + placer.getName()
                + " placed <light_purple>" + amount + " Shards</light_purple> on <white>" + target.getName() + "</white>.</gray>"));
    }

    public void claim(Player killer, Player victim) {
        Long amount = bounties.remove(victim.getUniqueId());
        if (amount == null || amount <= 0) {
            return;
        }
        economy.grantShards(killer.getUniqueId(), amount, "bounty-claim:" + victim.getUniqueId(), null);
        save();
        Bukkit.broadcast(TextUtil.parse("<gold><bold>Bounty Claimed!</bold></gold> <white>" + killer.getName()
                + "</white><gray> claimed <light_purple>" + amount + " Shards</light_purple> from " + victim.getName() + ".</gray>"));
    }

    public UnstableRemixPlugin getPlugin() {
        return plugin;
    }

    public Map<UUID, Long> all() {
        return new LinkedHashMap<>(bounties);
    }

    public Map<UUID, Long> top(int limit) {
        Map<UUID, Long> out = new LinkedHashMap<>();
        bounties.entrySet().stream()
                .sorted(Map.Entry.<UUID, Long>comparingByValue(Comparator.reverseOrder()))
                .limit(limit)
                .forEach(entry -> out.put(entry.getKey(), entry.getValue()));
        return out;
    }

    public long bounty(UUID uuid) {
        return bounties.getOrDefault(uuid, 0L);
    }

    public void adminSet(UUID targetId, long amount) {
        bounties.put(targetId, amount);
        save();
    }

    public void adminAdd(UUID targetId, long amount) {
        bounties.merge(targetId, amount, Long::sum);
        save();
    }

    public void adminRemove(UUID targetId) {
        bounties.remove(targetId);
        save();
    }

    public String name(UUID uuid) {
        OfflinePlayer player = Bukkit.getOfflinePlayer(uuid);
        return player.getName() == null ? uuid.toString().substring(0, 8) : player.getName();
    }

    public void save() {
        if (savePending.compareAndSet(false, true)) {
            Bukkit.getScheduler().runTaskLaterAsynchronously(plugin, () -> {
                savePending.set(false);
                doSave();
            }, 100L);
        }
    }

    private void doSave() {
        if (file == null) {
            file = new File(plugin.getDataFolder(), "bounties.yml");
        }
        file.getParentFile().mkdirs();
        YamlConfiguration yaml = new YamlConfiguration();
        for (Map.Entry<UUID, Long> entry : bounties.entrySet()) {
            yaml.set("bounties." + entry.getKey(), entry.getValue());
        }
        try {
            yaml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Failed saving bounties.yml: " + ex.getMessage());
        }
    }
}
