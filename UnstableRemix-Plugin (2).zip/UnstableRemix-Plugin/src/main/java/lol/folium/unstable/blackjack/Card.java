package lol.folium.unstable.blackjack;

public final class Card {

    public enum Suit {
        HEARTS, DIAMONDS, CLUBS, SPADES;

        public String symbol() {
            return switch (this) {
                case HEARTS -> "♥";
                case DIAMONDS -> "♦";
                case CLUBS -> "♣";
                case SPADES -> "♠";
            };
        }

        public String color() {
            return this == HEARTS || this == DIAMONDS ? "§c" : "§7";
        }
    }

    public enum Rank {
        ACE(11, "A"), TWO(2, "2"), THREE(3, "3"), FOUR(4, "4"), FIVE(5, "5"),
        SIX(6, "6"), SEVEN(7, "7"), EIGHT(8, "8"), NINE(9, "9"), TEN(10, "10"),
        JACK(10, "J"), QUEEN(10, "Q"), KING(10, "K");

        private final int value;
        private final String display;

        Rank(int value, String display) {
            this.value = value;
            this.display = display;
        }

        public int value() { return value; }
        public String display() { return display; }
    }

    private final Suit suit;
    private final Rank rank;

    public Card(Suit suit, Rank rank) {
        this.suit = suit;
        this.rank = rank;
    }

    public Suit suit() { return suit; }
    public Rank rank() { return rank; }
    public int value() { return rank.value(); }

    public String display() {
        return suit.color() + rank.display() + suit.symbol();
    }

    public String shortDisplay() {
        return rank.display() + suit.symbol();
    }
}
