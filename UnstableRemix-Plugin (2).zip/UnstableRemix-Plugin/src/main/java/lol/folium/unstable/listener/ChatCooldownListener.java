package lol.folium.unstable.listener;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.integration.MediaRankManager;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ChatCooldownListener implements Listener {

    private final UnstableRemixPlugin plugin;
    private final int cooldownMs;
    private final Map<UUID, Long> lastChat = new ConcurrentHashMap<>();

    public ChatCooldownListener(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
        this.cooldownMs = plugin.getConfig().getInt("media.rank.chat-cooldown-ms", 1000);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();

        if (player.hasPermission("unstable.media.nochatcooldown")) {
            return;
        }

        if (player.hasPermission("unstable.admin") || player.hasPermission("unstable.coreadmin")) {
            return;
        }

        long now = System.currentTimeMillis();
        Long last = lastChat.get(player.getUniqueId());
        if (last != null && now - last < cooldownMs) {
            event.setCancelled(true);
            long remaining = (cooldownMs - (now - last)) / 1000;
            if (remaining < 1) remaining = 1;
            player.sendMessage(TextUtil.parse("<red>Chat cooldown! Wait " + remaining + "s.</red>"));
            return;
        }
        lastChat.put(player.getUniqueId(), now);
    }
}
