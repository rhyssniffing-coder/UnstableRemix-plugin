package lol.folium.unstable.bounty;

import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class BountyCommand extends SubCommand {

    private final BountyManager bounties;
    private static final long[] AMOUNTS = {100, 250, 500, 1000, 2500, 5000};
    private final Map<UUID, UUID> pendingCustomTarget = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> pendingCustomPage = new ConcurrentHashMap<>();

    public BountyCommand(BountyManager bounties) {
        this.bounties = bounties;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length >= 1 && args[0].equalsIgnoreCase("admin") && player.hasPermission("unstable.admin")) {
            handleAdmin(player, args);
            return;
        }
        if (args.length >= 2 && args[0].equalsIgnoreCase("set")) {
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                player.sendMessage(TextUtil.parse("<red>Player not found.</red>"));
                return;
            }
            if (args.length >= 3) {
                try {
                    long amount = Long.parseLong(args[2]);
                    bounties.place(player, target, amount);
                } catch (NumberFormatException ex) {
                    player.sendMessage(TextUtil.parse("<red>Invalid number.</red>"));
                }
                return;
            }
            openAmountGui(player, target, 0);
            return;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("top")) {
            var top = bounties.top(10);
            if (top.isEmpty()) {
                player.sendMessage(TextUtil.parse("<gray>No active bounties.</gray>"));
                return;
            }
            player.sendMessage(TextUtil.parse("<gold><bold>Top Bounties</bold></gold>"));
            for (var entry : top.entrySet()) {
                player.sendMessage(TextUtil.parse("<gray>- <white>" + bounties.name(entry.getKey()) + "</white> <dark_gray>|</dark_gray> <light_purple>" + entry.getValue() + " Shards</light_purple></gray>"));
            }
            return;
        }
        openBountyListGui(player, 0);
    }

    private void handleAdmin(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<gold><bold>Admin Bounty Commands</bold></gold>"));
            player.sendMessage(TextUtil.parse("<gray>/bounty admin set <player> <amount> — Set bounty (no cost)</gray>"));
            player.sendMessage(TextUtil.parse("<gray>/bounty admin give <player> <amount> — Add to bounty (no cost)</gray>"));
            player.sendMessage(TextUtil.parse("<gray>/bounty admin remove <player> — Remove bounty</gray>"));
            return;
        }
        String sub = args[1].toLowerCase(Locale.ROOT);
        if (args.length < 3) {
            player.sendMessage(TextUtil.parse("<red>Usage: /bounty admin " + sub + " <player> [amount]</red>"));
            return;
        }
        Player target = Bukkit.getPlayerExact(args[2]);
        if (target == null) {
            player.sendMessage(TextUtil.parse("<red>Player not found.</red>"));
            return;
        }
        switch (sub) {
            case "set" -> {
                if (args.length < 4) {
                    player.sendMessage(TextUtil.parse("<red>Usage: /bounty admin set <player> <amount></red>"));
                    return;
                }
                try {
                    long amount = Long.parseLong(args[3]);
                    bounties.adminSet(target.getUniqueId(), amount);
                    player.sendMessage(TextUtil.parse("<green>Set bounty on <white>" + target.getName() + "</white> to <light_purple>" + amount + " Shards</light_purple>.</green>"));
                    Bukkit.broadcast(TextUtil.parse("<red><bold>Bounty</bold></red> <gray>An admin placed <light_purple>" + amount + " Shards</light_purple> on <white>" + target.getName() + "</white>.</gray>"));
                } catch (NumberFormatException ex) {
                    player.sendMessage(TextUtil.parse("<red>Invalid number.</red>"));
                }
            }
            case "give" -> {
                if (args.length < 4) {
                    player.sendMessage(TextUtil.parse("<red>Usage: /bounty admin give <player> <amount></red>"));
                    return;
                }
                try {
                    long amount = Long.parseLong(args[3]);
                    bounties.adminAdd(target.getUniqueId(), amount);
                    player.sendMessage(TextUtil.parse("<green>Added <light_purple>" + amount + " Shards</light_purple> to <white>" + target.getName() + "</white>'s bounty.</green>"));
                } catch (NumberFormatException ex) {
                    player.sendMessage(TextUtil.parse("<red>Invalid number.</red>"));
                }
            }
            case "remove" -> {
                long old = bounties.bounty(target.getUniqueId());
                bounties.adminRemove(target.getUniqueId());
                player.sendMessage(TextUtil.parse("<green>Removed <white>" + target.getName() + "</white>'s bounty (<light_purple>" + old + " Shards</light_purple>).</green>"));
            }
            default -> player.sendMessage(TextUtil.parse("<red>Unknown subcommand. Use set, give, or remove.</red>"));
        }
    }

    private void openAmountGui(Player player, Player target, int page) {
        int rows = 3;
        AmountGuiHolder holder = new AmountGuiHolder(player, target, page);
        Inventory inv = Bukkit.createInventory(holder, rows * 9,
                TextUtil.parse("<dark_gray>Bounty on <white>" + target.getName() + "</white></dark_gray>"));
        holder.bind(inv);

        ItemStack filler = ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE).name(Component.empty()).build();
        ItemStack frame = ItemBuilder.of(Material.PURPLE_STAINED_GLASS_PANE).name(Component.empty()).build();
        for (int i = 0; i < rows * 9; i++) {
            int row = i / 9;
            int col = i % 9;
            if (row == 0 || row == rows - 1 || col == 0 || col == 8) {
                inv.setItem(i, frame);
            } else {
                inv.setItem(i, filler);
            }
        }

        ItemStack infoHead = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta headMeta = (SkullMeta) infoHead.getItemMeta();
        headMeta.displayName(TextUtil.parse("<gold>" + target.getName() + "</gold>"));
        long current = bounties.bounty(target.getUniqueId());
        headMeta.lore(List.of(
                TextUtil.parse("<gray>Current bounty: <light_purple>" + current + " Shards</light_purple></gray>"),
                Component.empty(),
                TextUtil.parse("<gray>Select an amount or type a custom one</gray>")
        ));
        headMeta.setPlayerProfile(Bukkit.getOfflinePlayer(target.getUniqueId()).getPlayerProfile());
        infoHead.setItemMeta(headMeta);
        inv.setItem(4, infoHead);

        int[] amountSlots = {10, 11, 12, 14, 15, 16};
        for (int i = 0; i < AMOUNTS.length && i < amountSlots.length; i++) {
            long amt = AMOUNTS[i];
            inv.setItem(amountSlots[i], ItemBuilder.of(Material.SUNFLOWER)
                    .name(TextUtil.parse("<yellow><bold>" + amt + " Shards</bold></yellow>"))
                    .lore(List.of(
                            TextUtil.parse("<gray>Click to add <light_purple>" + amt + " Shards</light_purple></gray>"),
                            TextUtil.parse("<gray>to this bounty</gray>")
                    ))
                    .build());
            holder.amountSlots.put(amountSlots[i], amt);
        }

        inv.setItem(22, ItemBuilder.of(Material.ANVIL)
                .name(TextUtil.parse("<aqua><bold>Custom Amount</bold></aqua>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Click to type a custom amount</gray>"),
                        TextUtil.parse("<gray>in chat</gray>")
                ))
                .build());
        holder.customSlot = 22;

        player.openInventory(inv);
    }

    private void openBountyListGui(Player player, int page) {
        List<Map.Entry<UUID, Long>> sorted = new ArrayList<>(bounties.all().entrySet());
        sorted.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));

        int perPage = 28;
        int maxPage = Math.max(0, (sorted.size() - 1) / perPage);
        page = Math.min(page, maxPage);

        BountyListGuiHolder holder = new BountyListGuiHolder(player, page);
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.parse("<dark_gray>Bounties</dark_gray>"));
        holder.bind(inv);

        ItemStack filler = ItemBuilder.of(Material.GRAY_STAINED_GLASS_PANE).name(Component.empty()).build();
        ItemStack frame = ItemBuilder.of(Material.PURPLE_STAINED_GLASS_PANE).name(Component.empty()).build();
        for (int i = 0; i < 54; i++) {
            int row = i / 9;
            int col = i % 9;
            if (row == 0 || row == 5 || col == 0 || col == 8) {
                inv.setItem(i, frame);
            } else {
                inv.setItem(i, filler);
            }
        }

        int[] slots = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43
        };

        int offset = page * perPage;
        for (int i = 0; i < slots.length && offset + i < sorted.size(); i++) {
            Map.Entry<UUID, Long> entry = sorted.get(offset + i);
            UUID targetId = entry.getKey();
            long amount = entry.getValue();
            String name = bounties.name(targetId);

            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.displayName(TextUtil.parse("<gold>" + name + "</gold>"));
            meta.lore(List.of(
                    TextUtil.parse("<light_purple>" + amount + " Shards</light_purple>"),
                    Component.empty(),
                    TextUtil.parse("<yellow>Click to add to this bounty</yellow>")
            ));
            meta.setPlayerProfile(Bukkit.getOfflinePlayer(targetId).getPlayerProfile());
            head.setItemMeta(meta);
            inv.setItem(slots[i], head);
            holder.bountySlots.put(slots[i], targetId);
        }

        if (page > 0) {
            holder.prevSlot = 45;
            inv.setItem(45, ItemBuilder.of(Material.ARROW).name(TextUtil.parse("<yellow>Previous Page</yellow>")).build());
        }
        if (page < maxPage) {
            holder.nextSlot = 53;
            inv.setItem(53, ItemBuilder.of(Material.ARROW).name(TextUtil.parse("<yellow>Next Page</yellow>")).build());
        }

        inv.setItem(49, ItemBuilder.of(Material.SUNFLOWER)
                .name(TextUtil.parse("<green><bold>Set Bounty</bold></green>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Click to choose a player</gray>"),
                        TextUtil.parse("<gray>and set a bounty</gray>")
                ))
                .build());
        holder.setBountySlot = 49;

        player.openInventory(inv);
    }

    private void openPlayerSelectGui(Player player, int page) {
        List<Player> online = new ArrayList<>(Bukkit.getOnlinePlayers());
        int perPage = 28;
        int maxPage = Math.max(0, (online.size() - 1) / perPage);
        page = Math.min(page, maxPage);

        PlayerSelectGuiHolder holder = new PlayerSelectGuiHolder(player, page);
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.parse("<dark_gray>Select Target</dark_gray>"));
        holder.bind(inv);

        ItemStack filler = ItemBuilder.of(Material.GRAY_STAINED_GLASS_PANE).name(Component.empty()).build();
        ItemStack frame = ItemBuilder.of(Material.PURPLE_STAINED_GLASS_PANE).name(Component.empty()).build();
        for (int i = 0; i < 54; i++) {
            int row = i / 9;
            int col = i % 9;
            if (row == 0 || row == 5 || col == 0 || col == 8) {
                inv.setItem(i, frame);
            } else {
                inv.setItem(i, filler);
            }
        }

        int[] slots = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43
        };

        int offset = page * perPage;
        for (int i = 0; i < slots.length && offset + i < online.size(); i++) {
            Player target = online.get(offset + i);
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.displayName(TextUtil.parse("<gold>" + target.getName() + "</gold>"));
            long current = bounties.bounty(target.getUniqueId());
            meta.lore(List.of(
                    TextUtil.parse("<gray>Current bounty: <light_purple>" + current + " Shards</light_purple></gray>"),
                    Component.empty(),
                    TextUtil.parse("<yellow>Click to set bounty</yellow>")
            ));
            meta.setPlayerProfile(target.getPlayerProfile());
            head.setItemMeta(meta);
            inv.setItem(slots[i], head);
            holder.playerSlots.put(slots[i], target);
        }

        if (page > 0) {
            holder.prevSlot = 45;
            inv.setItem(45, ItemBuilder.of(Material.ARROW).name(TextUtil.parse("<yellow>Previous Page</yellow>")).build());
        }
        if (page < maxPage) {
            holder.nextSlot = 53;
            inv.setItem(53, ItemBuilder.of(Material.ARROW).name(TextUtil.parse("<yellow>Next Page</yellow>")).build());
        }

        player.openInventory(inv);
    }

    private static class ItemBuilder {
        private final ItemStack item;
        private ItemBuilder(Material mat) { this.item = new ItemStack(mat); }
        public static ItemBuilder of(Material mat) { return new ItemBuilder(mat); }
        public ItemBuilder name(Component name) { item.editMeta(m -> m.displayName(name)); return this; }
        public ItemBuilder lore(List<Component> lore) { item.editMeta(m -> m.lore(lore)); return this; }
        public ItemStack build() { return item; }
    }

    private final class AmountGuiHolder extends GuiHolder {
        private final Player player;
        private final Player target;
        private final int page;
        private final Map<Integer, Long> amountSlots = new HashMap<>();
        private int customSlot = -1;

        AmountGuiHolder(Player player, Player target, int page) {
            this.player = player;
            this.target = target;
            this.page = page;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();

            Long amount = amountSlots.get(slot);
            if (amount != null) {
                bounties.place(player, target, amount);
                openAmountGui(player, target, page);
                return;
            }

            if (slot == customSlot) {
                player.closeInventory();
                pendingCustomTarget.put(player.getUniqueId(), target.getUniqueId());
                pendingCustomPage.put(player.getUniqueId(), page);
                player.sendMessage(TextUtil.parse("<yellow>Type the bounty amount for <white>" + target.getName() + "</white>:</yellow>"));
                player.sendMessage(TextUtil.parse("<gray>(or type <white>cancel</white> to cancel)</gray>"));
                listenChat(player, message -> {
                    UUID pendingTargetId = pendingCustomTarget.remove(player.getUniqueId());
                    int p = pendingCustomPage.remove(player.getUniqueId());
                    if (pendingTargetId == null) return;
                    Player t = Bukkit.getPlayer(pendingTargetId);
                    if (t == null) {
                        player.sendMessage(TextUtil.parse("<red>Target player went offline.</red>"));
                        return;
                    }
                    if (message.equalsIgnoreCase("cancel")) {
                        player.sendMessage(TextUtil.parse("<red>Cancelled.</red>"));
                        openAmountGui(player, t, p);
                        return;
                    }
                    try {
                        long amt = Long.parseLong(message.trim());
                        bounties.place(player, t, amt);
                    } catch (NumberFormatException ex) {
                        player.sendMessage(TextUtil.parse("<red>Invalid number.</red>"));
                    }
                    openAmountGui(player, t, p);
                });
                return;
            }
        }

        private void listenChat(Player player, java.util.function.Consumer<String> callback) {
            Bukkit.getScheduler().runTaskLater(bounties.getPlugin(), () -> {
                org.bukkit.event.Listener listener = new org.bukkit.event.Listener() {
                    @org.bukkit.event.EventHandler
                    public void onChat(org.bukkit.event.player.PlayerChatEvent e) {
                        if (!e.getPlayer().equals(player)) return;
                        e.setCancelled(true);
                        callback.accept(e.getMessage().trim());
                        org.bukkit.event.HandlerList.unregisterAll(this);
                    }
                };
                Bukkit.getPluginManager().registerEvents(listener, bounties.getPlugin());
            }, 1L);
        }
    }

    private final class BountyListGuiHolder extends GuiHolder {
        private final Player player;
        private final int page;
        private final Map<Integer, UUID> bountySlots = new HashMap<>();
        private int prevSlot = -1;
        private int nextSlot = -1;
        private int setBountySlot = -1;

        BountyListGuiHolder(Player player, int page) {
            this.player = player;
            this.page = page;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();

            if (slot == prevSlot) {
                openBountyListGui(player, page - 1);
                return;
            }
            if (slot == nextSlot) {
                openBountyListGui(player, page + 1);
                return;
            }
            if (slot == setBountySlot) {
                openPlayerSelectGui(player, 0);
                return;
            }

            UUID targetId = bountySlots.get(slot);
            if (targetId != null) {
                Player target = Bukkit.getPlayer(targetId);
                if (target == null || !target.isOnline()) {
                    player.sendMessage(TextUtil.parse("<red>That player is no longer online.</red>"));
                    openBountyListGui(player, page);
                    return;
                }
                openAmountGui(player, target, 0);
            }
        }
    }

    private final class PlayerSelectGuiHolder extends GuiHolder {
        private final Player player;
        private final int page;
        private final Map<Integer, Player> playerSlots = new HashMap<>();
        private int prevSlot = -1;
        private int nextSlot = -1;

        PlayerSelectGuiHolder(Player player, int page) {
            this.player = player;
            this.page = page;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();

            if (slot == prevSlot) {
                openPlayerSelectGui(player, page - 1);
                return;
            }
            if (slot == nextSlot) {
                openPlayerSelectGui(player, page + 1);
                return;
            }

            Player target = playerSlots.get(slot);
            if (target != null && target.isOnline()) {
                openAmountGui(player, target, 0);
            }
        }
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            var options = new java.util.ArrayList<>(java.util.List.of("set", "top"));
            if (player.hasPermission("unstable.admin")) {
                options.add("admin");
            }
            for (Player p : Bukkit.getOnlinePlayers()) {
                options.add(p.getName());
            }
            return filter(options, args[0]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("set")) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT)))
                    .toList();
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("admin") && player.hasPermission("unstable.admin")) {
            return filter(java.util.List.of("set", "give", "remove"), args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("admin")) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(args[2].toLowerCase(Locale.ROOT)))
                    .toList();
        }
        return List.of();
    }

    @Override
    protected String permission() {
        return null;
    }
}
