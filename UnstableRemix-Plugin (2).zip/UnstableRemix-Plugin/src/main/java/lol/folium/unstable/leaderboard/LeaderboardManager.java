package lol.folium.unstable.leaderboard;

import lol.folium.unstable.UnstableRemixPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class LeaderboardManager {

    public enum Category {
        KILLS("lifetime_kills", "Kills", Material.DIAMOND_SWORD),
        DEATHS("deaths", "Deaths", Material.SKELETON_SKULL),
        KILLSTREAK("highest_killstreak", "Best Streak", Material.BLAZE_POWDER),
        SHARDS("shards", "Shards", Material.SUNFLOWER),
        PLAYTIME("playtime", "Playtime", Material.CLOCK),
        MATCH_WINS("match_wins", "Match Wins", Material.CHEST),
        KD_RATIO(null, "K/D Ratio", Material.ARROW);

        final String column;
        final String displayName;
        final Material icon;
        Category(String column, String displayName, Material icon) {
            this.column = column;
            this.displayName = displayName;
            this.icon = icon;
        }
    }

    private final UnstableRemixPlugin plugin;
    private final Object dbLock = new Object();
    private Connection connection;
    private volatile LeaderboardSnapshot cache;
    private long lastRefresh;
    private final int topCount;

    public LeaderboardManager(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
        this.topCount = plugin.getConfig().getInt("leaderboard.top-count", 10);
    }

    public void init() {
        try {
            String dbPath = plugin.getDataFolder() + "/players.db";
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
        } catch (SQLException e) {
            plugin.getLogger().severe("Leaderboard DB init failed: " + e.getMessage());
        }
    }

    public void close() {
        synchronized (dbLock) {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException ignored) {
                }
            }
        }
    }

    public void refresh() {
        long now = System.currentTimeMillis();
        if (now - lastRefresh < 15_000) return;
        lastRefresh = now;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            LeaderboardSnapshot snapshot = new LeaderboardSnapshot(now);
            for (Category cat : Category.values()) {
                if (cat == Category.KD_RATIO) {
                    snapshot.entries.put(cat, queryTopKD(topCount));
                } else {
                    snapshot.entries.put(cat, queryTop(cat, topCount));
                }
            }
            snapshot.totalPlayers = queryTotalPlayers();
            snapshot.totalKills = querySum("lifetime_kills");
            snapshot.totalDeaths = querySum("deaths");
            snapshot.totalShards = querySum("shards");
            snapshot.totalPlaytime = querySum("playtime");
            cache = snapshot;
        });
    }

    public LeaderboardSnapshot getSnapshot() {
        LeaderboardSnapshot snap = cache;
        if (snap == null || System.currentTimeMillis() - snap.timestamp > 30_000) {
            refresh();
            snap = cache;
        }
        return snap;
    }

    public int getPlayerRank(Category category, UUID uuid) {
        LeaderboardSnapshot snap = getSnapshot();
        if (snap == null) return -1;
        List<LeaderboardEntry> entries = snap.entries.get(category);
        if (entries == null) return -1;
        for (int i = 0; i < entries.size(); i++) {
            if (entries.get(i).uuid.equals(uuid)) return i + 1;
        }
        return -1;
    }

    public LeaderboardEntry getPlayerEntry(Category category, UUID uuid) {
        LeaderboardSnapshot snap = getSnapshot();
        if (snap == null) return null;
        List<LeaderboardEntry> entries = snap.entries.get(category);
        if (entries == null) return null;
        for (LeaderboardEntry entry : entries) {
            if (entry.uuid.equals(uuid)) return entry;
        }
        return null;
    }

    public String formatValue(Category category, long value) {
        return switch (category) {
            case PLAYTIME -> formatPlaytime(value);
            case KD_RATIO -> {
                long kills = value / 10000L;
                long deaths = value % 10000L;
                yield deaths == 0 ? "∞" : String.format("%.2f", (double) kills / deaths);
            }
            default -> String.format("%,d", value);
        };
    }

    public static String formatPlaytime(long seconds) {
        if (seconds < 60) return seconds + "s";
        if (seconds < 3600) return (seconds / 60) + "m " + (seconds % 60) + "s";
        if (seconds < 86400) return (seconds / 3600) + "h " + ((seconds % 3600) / 60) + "m";
        return (seconds / 86400) + "d " + ((seconds % 86400) / 3600) + "h";
    }

    public String resolveName(UUID uuid) {
        Player online = Bukkit.getPlayer(uuid);
        if (online != null) return online.getName();
        OfflinePlayer offline = Bukkit.getOfflinePlayer(uuid);
        String name = offline.getName();
        return name != null ? name : uuid.toString().substring(0, 8);
    }

    private List<LeaderboardEntry> queryTop(Category category, int limit) {
        String sql = "SELECT uuid, " + category.column + " AS val FROM profiles ORDER BY val DESC LIMIT ?";
        synchronized (dbLock) {
            if (connection == null) return Collections.emptyList();
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setInt(1, limit);
                try (ResultSet rs = ps.executeQuery()) {
                    List<LeaderboardEntry> result = new ArrayList<>(limit);
                    while (rs.next()) {
                        try {
                            UUID uuid = UUID.fromString(rs.getString("uuid"));
                            long value = rs.getLong("val");
                            result.add(new LeaderboardEntry(uuid, value));
                        } catch (IllegalArgumentException ignored) {
                        }
                    }
                    return result;
                }
            } catch (SQLException e) {
                plugin.getLogger().severe("Leaderboard query failed for " + category + ": " + e.getMessage());
                return Collections.emptyList();
            }
        }
    }

    private List<LeaderboardEntry> queryTopKD(int limit) {
        String sql = "SELECT uuid, lifetime_kills, deaths FROM profiles WHERE (lifetime_kills > 0 OR deaths > 0) ORDER BY CASE WHEN deaths = 0 THEN lifetime_kills * 10000.0 ELSE CAST(lifetime_kills AS REAL) / deaths END DESC LIMIT ?";
        synchronized (dbLock) {
            if (connection == null) return Collections.emptyList();
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setInt(1, limit);
                try (ResultSet rs = ps.executeQuery()) {
                    List<LeaderboardEntry> result = new ArrayList<>(limit);
                    while (rs.next()) {
                        try {
                            UUID uuid = UUID.fromString(rs.getString("uuid"));
                            long kills = rs.getLong("lifetime_kills");
                            long deaths = rs.getLong("deaths");
                            long encoded = kills * 10000L + Math.min(deaths, 9999L);
                            result.add(new LeaderboardEntry(uuid, encoded));
                        } catch (IllegalArgumentException ignored) {
                        }
                    }
                    return result;
                }
            } catch (SQLException e) {
                plugin.getLogger().severe("Leaderboard K/D query failed: " + e.getMessage());
                return Collections.emptyList();
            }
        }
    }

    private long querySum(String column) {
        String sql = "SELECT COALESCE(SUM(" + column + "), 0) AS total FROM profiles";
        synchronized (dbLock) {
            if (connection == null) return 0;
            try (PreparedStatement ps = connection.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong("total") : 0;
            } catch (SQLException e) {
                return 0;
            }
        }
    }

    private int queryTotalPlayers() {
        String sql = "SELECT COUNT(*) AS total FROM profiles";
        synchronized (dbLock) {
            if (connection == null) return 0;
            try (PreparedStatement ps = connection.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt("total") : 0;
            } catch (SQLException e) {
                return 0;
            }
        }
    }

    public String toJson() {
        LeaderboardSnapshot snap = getSnapshot();
        if (snap == null) return "{}";

        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"totalPlayers\":").append(snap.totalPlayers).append(",");
        sb.append("\"totalKills\":").append(snap.totalKills).append(",");
        sb.append("\"totalDeaths\":").append(snap.totalDeaths).append(",");
        sb.append("\"totalShards\":").append(snap.totalShards).append(",");
        sb.append("\"totalPlaytime\":").append(snap.totalPlaytime).append(",");
        sb.append("\"onlinePlayers\":").append(Bukkit.getOnlinePlayers().size()).append(",");
        sb.append("\"maxPlayers\":").append(Bukkit.getMaxPlayers()).append(",");
        sb.append("\"categories\":{");

        boolean firstCat = true;
        for (Category cat : Category.values()) {
            List<LeaderboardEntry> entries = snap.entries.getOrDefault(cat, Collections.emptyList());
            if (!firstCat) sb.append(",");
            firstCat = false;
            sb.append("\"").append(cat.name().toLowerCase()).append("\":");
            sb.append("{\"displayName\":\"").append(cat.displayName).append("\",\"entries\":[");

            boolean first = true;
            for (LeaderboardEntry entry : entries) {
                if (!first) sb.append(",");
                first = false;
                String name = resolveName(entry.uuid);
                sb.append("{\"uuid\":\"").append(entry.uuid).append("\"");
                sb.append(",\"name\":\"").append(escapeJson(name)).append("\"");
                sb.append(",\"value\":").append(entry.value);
                sb.append(",\"formatted\":\"").append(escapeJson(formatValue(cat, entry.value))).append("\"");
                sb.append(",\"rank\":").append(entries.indexOf(entry) + 1);
                sb.append("}");
            }
            sb.append("]}");
        }

        sb.append("}}");
        return sb.toString();
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }

    public static final class LeaderboardEntry {
        public final UUID uuid;
        public final long value;

        public LeaderboardEntry(UUID uuid, long value) {
            this.uuid = uuid;
            this.value = value;
        }
    }

    public static final class LeaderboardSnapshot {
        public final long timestamp;
        public final java.util.Map<Category, List<LeaderboardEntry>> entries = new ConcurrentHashMap<>();
        public volatile int totalPlayers;
        public volatile long totalKills;
        public volatile long totalDeaths;
        public volatile long totalShards;
        public volatile long totalPlaytime;

        public LeaderboardSnapshot(long timestamp) {
            this.timestamp = timestamp;
        }
    }
}
