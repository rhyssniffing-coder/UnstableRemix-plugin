package lol.folium.unstable.events;

import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.stream.Collectors;

public final class ArenaEventsCommand extends SubCommand {

    private final ArenaEventEngine eventEngine;

    public ArenaEventsCommand(ArenaEventEngine eventEngine) {
        this.eventEngine = eventEngine;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length == 0) {
            player.sendMessage(TextUtil.parse("<yellow>/arenaevents <trigger|stop|toggle|list|reload> ..."));
            return;
        }
        switch (args[0].toLowerCase()) {
            case "trigger" -> handleTrigger(player, args);
            case "stop" -> handleStop(player, args);
            case "toggle" -> handleToggle(player, args);
            case "list" -> handleList(player);
            case "reload" -> handleReload(player);
            default -> player.sendMessage(TextUtil.parse("<red>Unknown subcommand."));
        }
    }

    private void handleTrigger(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /arenaevents trigger <event_name>"));
            return;
        }
        try {
            ArenaEventEngine.EventType eventType = ArenaEventEngine.EventType.valueOf(args[1].toUpperCase());
            if (eventEngine.isEventActive(eventType)) {
                player.sendMessage(TextUtil.parse("<red>Event is already active."));
                return;
            }
            eventEngine.triggerEvent(eventType);
            player.sendMessage(TextUtil.parse("<green>Triggered event: <white>" + eventType.displayName() + "</white>"));
        } catch (IllegalArgumentException ex) {
            player.sendMessage(TextUtil.parse("<red>Invalid event type. Valid types: " + 
                getEventNames().stream().collect(Collectors.joining(", "))));
        }
    }

    private void handleStop(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /arenaevents stop <event_name>"));
            return;
        }
        try {
            ArenaEventEngine.EventType eventType = ArenaEventEngine.EventType.valueOf(args[1].toUpperCase());
            if (!eventEngine.isEventActive(eventType)) {
                player.sendMessage(TextUtil.parse("<red>Event is not active."));
                return;
            }
            eventEngine.endEvent(eventType);
            player.sendMessage(TextUtil.parse("<green>Stopped event: <white>" + eventType.displayName() + "</white>"));
        } catch (IllegalArgumentException ex) {
            player.sendMessage(TextUtil.parse("<red>Invalid event type. Valid types: " + 
                getEventNames().stream().collect(Collectors.joining(", "))));
        }
    }

    private void handleToggle(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /arenaevents toggle <event_name>"));
            return;
        }
        try {
            ArenaEventEngine.EventType eventType = ArenaEventEngine.EventType.valueOf(args[1].toUpperCase());
            eventEngine.toggleEvent(eventType);
            player.sendMessage(TextUtil.parse("<green>Toggled event: <white>" + eventType.displayName() + "</white>"));
        } catch (IllegalArgumentException ex) {
            player.sendMessage(TextUtil.parse("<red>Invalid event type. Valid types: " + 
                getEventNames().stream().collect(Collectors.joining(", "))));
        }
    }

    private void handleList(Player player) {
        player.sendMessage(TextUtil.parse("<aqua><bold>Arena Events</bold></aqua>"));
        for (ArenaEventEngine.EventType eventType : ArenaEventEngine.EventType.values()) {
            boolean enabled = eventEngine.isEventEnabled(eventType);
            boolean active = eventEngine.isEventActive(eventType);
            String statusColor = active ? "<green>" : (enabled ? "<yellow>" : "<red>");
            String statusText = active ? "Active" : (enabled ? "Enabled" : "Disabled");
            player.sendMessage(TextUtil.parse(
                "<gray>- <white>" + eventType.displayName() + "</white> <dark_gray>|</dark_gray> " +
                statusColor + statusText
            ));
        }
    }

    private void handleReload(Player player) {
        eventEngine.reload();
        player.sendMessage(TextUtil.parse("<green>Arena events reloaded."));
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            return filter(literals("trigger", "stop", "toggle", "list", "reload"), args[0]);
        }
        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if (sub.equals("trigger") || sub.equals("stop") || sub.equals("toggle")) {
                return filter(getEventNames(), args[1]);
            }
        }
        return List.of();
    }

    private List<String> getEventNames() {
        return List.of(ArenaEventEngine.EventType.values()).stream()
            .map(type -> type.name().toLowerCase())
            .collect(Collectors.toList());
    }

    @Override
    protected String permission() {
        return "unstable.arenaevents.admin";
    }
}
