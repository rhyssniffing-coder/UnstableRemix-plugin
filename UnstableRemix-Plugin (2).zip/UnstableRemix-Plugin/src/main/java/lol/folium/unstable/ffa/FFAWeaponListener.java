package lol.folium.unstable.ffa;

import lol.folium.unstable.UnstableRemixPlugin;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public final class FFAWeaponListener implements Listener {

    private final UnstableRemixPlugin plugin;
    private final FFAWeaponManager weaponManager;
    private static final Map<UUID, Set<UUID>> seismicHit = new ConcurrentHashMap<>();
    private static final Map<UUID, Boolean> frozenPlayers = new ConcurrentHashMap<>();

    public FFAWeaponListener(UnstableRemixPlugin plugin, FFAWeaponManager weaponManager) {
        this.plugin = plugin;
        this.weaponManager = weaponManager;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        String weaponId = weaponManager.getWeaponId(item);
        if (weaponId == null) return;

        if (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            if (!player.isSneaking()) return;
            switch (weaponId) {
                case "dash" -> handleDash(player);
                case "dashmace" -> handleDashMace(player);
                case "flux" -> handleFlux(player);
                case "adrenaline" -> handleAdrenaline(player);
                case "seismic" -> handleSeismic(player);
            }
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof Player victim)) return;
        ItemStack weapon = attacker.getInventory().getItemInMainHand();
        String weaponId = weaponManager.getWeaponId(weapon);
        if (weaponId == null) return;
        switch (weaponId) {
            case "strike" -> handleStrike(attacker, victim);
            case "frost" -> handleFrost(attacker, victim);
            case "lifestealer" -> handleLifesteal(attacker);
        }
    }

    @EventHandler
    public void onShoot(ProjectileLaunchEvent event) {
        if (!(event.getEntity() instanceof Arrow arrow)) return;
        if (!(arrow.getShooter() instanceof Player shooter)) return;
        ItemStack weapon = shooter.getInventory().getItemInMainHand();
        String weaponId = weaponManager.getWeaponId(weapon);
        if (weaponId == null || !weaponId.equals("grapple")) return;
        if (weaponManager.isOnCooldown(shooter.getUniqueId(), "grapple")) return;
        weaponManager.setCooldown(shooter.getUniqueId(), "grapple", weaponManager.getWeapon("grapple").cooldown());
        Vector direction = shooter.getLocation().getDirection();
        shooter.setVelocity(direction.multiply(2.2).setY(0.5));
        shooter.getWorld().playSound(shooter.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 1.0f, 1.0f);
        event.setCancelled(true);
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        if (frozenPlayers.getOrDefault(event.getPlayer().getUniqueId(), false)) {
            if (event.getFrom().distanceSquared(event.getTo()) > 0.01) {
                event.setTo(event.getFrom());
            }
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        frozenPlayers.remove(victim.getUniqueId());
        event.getDrops().removeIf(item -> {
            ItemMeta meta = item.getItemMeta();
            return meta != null && meta.hasDisplayName() && meta.getDisplayName().contains("Kill Token");
        });
    }

    private void handleDash(Player player) {
        if (weaponManager.isOnCooldown(player.getUniqueId(), "dash")) return;
        weaponManager.setCooldown(player.getUniqueId(), "dash", weaponManager.getWeapon("dash").cooldown());
        Vector dir = player.getLocation().getDirection();
        player.setVelocity(dir.multiply(2.5));
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 1.0f, 1.0f);
        player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 30, 0.3, 0.3, 0.3, 0.05);
        player.getWorld().spawnParticle(Particle.END_ROD, player.getLocation(), 30, 0.3, 0.3, 0.3, 0.02);
    }

    private void handleDashMace(Player player) {
        if (weaponManager.isOnCooldown(player.getUniqueId(), "dashmace")) return;
        weaponManager.setCooldown(player.getUniqueId(), "dashmace", weaponManager.getWeapon("dashmace").cooldown());
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_BREEZE_WIND_BURST, 1.0f, 0.6f);
        Vector dir = player.getLocation().getDirection();
        player.setVelocity(dir.multiply(3.5).setY(0.4));
        player.getWorld().spawnParticle(Particle.ITEM_SLIME, player.getLocation(), 30, 0.3, 0.3, 0.3, 0.1);
    }

    private void handleStrike(Player attacker, Player victim) {
        double chance = plugin.getConfig().getDouble("ffa-weapons.weapons.strike.chance", 0.15);
        if (Math.random() > chance) return;
        victim.getWorld().strikeLightningEffect(victim.getLocation());
        victim.getWorld().playSound(victim.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 0.5f);
        victim.getWorld().playSound(victim.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 1.0f);
        victim.damage(3.0);
        for (int i = 0; i < 20; i++) {
            Location loc = victim.getLocation().clone().add(
                    ThreadLocalRandom.current().nextDouble(-0.6, 0.6),
                    ThreadLocalRandom.current().nextDouble(0, 2),
                    ThreadLocalRandom.current().nextDouble(-0.6, 0.6));
            victim.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 1);
            victim.getWorld().spawnParticle(Particle.FIREWORK, loc, 1);
        }
    }

    private void handleFrost(Player attacker, Player victim) {
        double chance = plugin.getConfig().getDouble("ffa-weapons.weapons.frost.chance", 0.20);
        if (Math.random() > chance) return;
        if (weaponManager.isOnCooldown(attacker.getUniqueId(), "frost")) return;
        weaponManager.setCooldown(attacker.getUniqueId(), "frost", weaponManager.getWeapon("frost").cooldown());
        frozenPlayers.put(victim.getUniqueId(), true);
        victim.getWorld().playSound(victim.getLocation(), Sound.BLOCK_GLASS_BREAK, 1.0f, 1.8f);
        victim.getWorld().playSound(victim.getLocation(), Sound.ENTITY_PLAYER_HURT_FREEZE, 1.0f, 0.5f);
        victim.getWorld().spawnParticle(Particle.SNOWFLAKE, victim.getLocation(), 20, 0.5, 0.5, 0.5, 0.05);
        int duration = plugin.getConfig().getInt("ffa-weapons.weapons.frost.duration-ticks", 60);
        Bukkit.getScheduler().runTaskLater(plugin, () -> frozenPlayers.remove(victim.getUniqueId()), duration);
    }

    private void handleFlux(Player player) {
        if (weaponManager.isOnCooldown(player.getUniqueId(), "flux")) return;
        weaponManager.setCooldown(player.getUniqueId(), "flux", weaponManager.getWeapon("flux").cooldown());
        int range = plugin.getConfig().getInt("ffa-weapons.weapons.flux.range", 15);
        double damage = plugin.getConfig().getDouble("ffa-weapons.weapons.flux.damage", 3.0);
        double hitRange = plugin.getConfig().getDouble("ffa-weapons.weapons.flux.hit-range", 2.0);
        Location start = player.getEyeLocation().clone();
        Vector direction = start.getDirection().normalize();
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 2.0f, 1.6f);
        for (int i = 0; i < range; i++) {
            start.add(direction.multiply(1.2));
            player.getWorld().spawnParticle(Particle.SONIC_BOOM, start, 1);
            for (Entity entity : player.getWorld().getNearbyEntities(start, hitRange, hitRange, hitRange)) {
                if (entity instanceof LivingEntity living && !entity.equals(player)) {
                    living.damage(damage);
                    living.getWorld().playSound(living.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 2.0f, 1.2f);
                    return;
                }
            }
        }
    }

    private void handleAdrenaline(Player player) {
        if (weaponManager.isOnCooldown(player.getUniqueId(), "adrenaline")) return;
        weaponManager.setCooldown(player.getUniqueId(), "adrenaline", weaponManager.getWeapon("adrenaline").cooldown());
        player.getWorld().playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 1.0f, 1.4f);
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_BREAK, 2.0f, 1.6f);
        player.setHealth(Math.min(player.getHealth() + 20, player.getMaxHealth()));
        player.addPotionEffect(new org.bukkit.potion.PotionEffect(
                org.bukkit.potion.PotionEffectType.ABSORPTION, 80, 1, false, false, false));
        player.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, player.getLocation().add(0, 1, 0), 50, 0.5, 0.5, 0.5, 0.1);
    }

    private void handleSeismic(Player player) {
        if (weaponManager.isOnCooldown(player.getUniqueId(), "seismic")) return;
        weaponManager.setCooldown(player.getUniqueId(), "seismic", weaponManager.getWeapon("seismic").cooldown());
        int range = plugin.getConfig().getInt("ffa-weapons.weapons.seismic.range", 10);
        double damage = plugin.getConfig().getDouble("ffa-weapons.weapons.seismic.damage", 3.0);
        Location loc = player.getLocation().clone();
        loc.getWorld().playSound(loc, Sound.ITEM_TRIDENT_THUNDER, 1.5f, 0.5f);
        Location ground = loc.clone();
        while (ground.getBlock().getType() == Material.AIR && ground.getY() > -64) {
            ground.add(0, -1, 0);
        }
        seismicHit.put(player.getUniqueId(), new HashSet<>());
        for (int ring = 1; ring <= range; ring++) {
            int currentRing = ring;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                for (double angle = 0; angle < 360; angle += 10) {
                    double x = Math.cos(Math.toRadians(angle)) * currentRing;
                    double z = Math.sin(Math.toRadians(angle)) * currentRing;
                    Location blockLoc = ground.clone().add(x, 0, z);
                    if (blockLoc.getBlock().getType() != Material.AIR) {
                        blockLoc.getWorld().spawnParticle(Particle.BLOCK, blockLoc.add(0, 0.5, 0), 5,
                                0.2, 0.2, 0.2, 0.01, blockLoc.getBlock().getBlockData());
                    }
                }
                for (Entity entity : player.getWorld().getNearbyEntities(ground, currentRing, 2, currentRing)) {
                    if (entity instanceof LivingEntity living && !entity.equals(player)) {
                        Set<UUID> hits = seismicHit.getOrDefault(player.getUniqueId(), new HashSet<>());
                        if (!hits.contains(living.getUniqueId())) {
                            hits.add(living.getUniqueId());
                            living.setVelocity(new Vector(0, 0.9, 0));
                            living.damage(damage);
                            living.getWorld().playSound(living.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 0.8f);
                        }
                    }
                }
            }, ring * 2L);
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> seismicHit.remove(player.getUniqueId()), range * 2L + 20);
    }

    private void handleLifesteal(Player attacker) {
        double chance = plugin.getConfig().getDouble("ffa-weapons.weapons.lifestealer.chance", 0.20);
        if (Math.random() > chance) return;
        double heal = plugin.getConfig().getDouble("ffa-weapons.weapons.lifestealer.heal", 4.0);
        attacker.setHealth(Math.min(attacker.getHealth() + heal, attacker.getMaxHealth()));
        attacker.getWorld().spawnParticle(Particle.HEART, attacker.getEyeLocation(), 5);
    }
}
