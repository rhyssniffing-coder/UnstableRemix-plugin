package lol.folium.unstable.command;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.data.PlayerProfile;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.entity.Player;

import java.util.List;

public final class FollowCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;

    public FollowCommand(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    protected void execute(Player player, String[] args) {
        String link = plugin.getConfig().getString("social.follow-link",
                "https://www.tiktok.com/@unstableremixofficial?is_from_webapp=1&sender_device=pc");
        long reward = plugin.getConfig().getLong("social.follow-reward", 100L);

        player.sendMessage(TextUtil.parse("<gold><bold>FOLLOW US</bold></gold>"));
        player.sendMessage(TextUtil.parse("<gray>Follow us on TikTok for updates and clips!</gray>"));
        player.sendMessage(TextUtil.parse("<aqua><underlined>" + link + "</underlined></aqua>"));

        PlayerProfile profile = plugin.getPlayerDataStore().get(player.getUniqueId());
        if (profile.socialFollowClaimed()) {
            player.sendMessage(TextUtil.parse("<dark_gray>You have already claimed the follow reward.</dark_gray>"));
            return;
        }

        profile.setSocialFollowClaimed(true);
        plugin.getPlayerDataStore().saveProfile(profile);
        plugin.getEconomyService().grantShards(player.getUniqueId(), reward, "social:follow", null);
        player.sendMessage(TextUtil.parse("<green><bold>+100 Shards</bold></green> <gray>Thanks for following!</gray>"));
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        return List.of();
    }

    @Override
    protected String permission() {
        return null;
    }
}
