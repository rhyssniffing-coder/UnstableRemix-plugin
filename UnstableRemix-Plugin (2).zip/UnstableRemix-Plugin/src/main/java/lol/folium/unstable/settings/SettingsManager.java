package lol.folium.unstable.settings;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import lol.folium.unstable.UnstableRemixPlugin;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class SettingsManager {

    private static SettingsManager instance;
    private final Map<UUID, PlayerSettings> cache = new ConcurrentHashMap<>();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final Path dataFolder;
    private final File settingsFile;

    public SettingsManager() {
        this.dataFolder = UnstableRemixPlugin.getInstance().getDataFolder().toPath();
        this.settingsFile = dataFolder.resolve("player-settings.json").toFile();
        loadAll();
    }

    public static SettingsManager getInstance() {
        if (instance == null) {
            instance = new SettingsManager();
        }
        return instance;
    }

    public PlayerSettings getSettings(UUID uuid) {
        return cache.computeIfAbsent(uuid, PlayerSettings::new);
    }

    public void toggle(UUID uuid, PlayerSettings.Setting setting) {
        PlayerSettings settings = getSettings(uuid);
        settings.toggle(setting);
        save(uuid, settings);
    }

    public void set(UUID uuid, PlayerSettings.Setting setting, boolean value) {
        PlayerSettings settings = getSettings(uuid);
        settings.set(setting, value);
        save(uuid, settings);
    }

    private void save(UUID uuid, PlayerSettings settings) {
        try {
            JsonObject root = readRoot();
            root.add(uuid.toString(), gson.toJsonTree(settings.serialize()));
            writeRoot(root);
        } catch (IOException e) {
            UnstableRemixPlugin.getInstance().getLogger().severe("Failed to save settings for " + uuid + ": " + e.getMessage());
        }
    }

    public void saveAll() {
        try {
            JsonObject root = new JsonObject();
            for (Map.Entry<UUID, PlayerSettings> entry : cache.entrySet()) {
                root.add(entry.getKey().toString(), gson.toJsonTree(entry.getValue().serialize()));
            }
            writeRoot(root);
        } catch (IOException e) {
            UnstableRemixPlugin.getInstance().getLogger().severe("Failed to save settings: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void loadAll() {
        if (!settingsFile.exists()) return;
        try {
            String json = new String(Files.readAllBytes(settingsFile.toPath()), StandardCharsets.UTF_8);
            JsonObject root = JsonParser.parseString(json).getAsJsonObject();
            for (Map.Entry<String, com.google.gson.JsonElement> entry : root.entrySet()) {
                UUID uuid = UUID.fromString(entry.getKey());
                PlayerSettings settings = new PlayerSettings(uuid);
                Map<String, Object> data = gson.fromJson(entry.getValue(), Map.class);
                settings.load(data);
                cache.put(uuid, settings);
            }
        } catch (Exception e) {
            UnstableRemixPlugin.getInstance().getLogger().severe("Failed to load settings: " + e.getMessage());
        }
    }

    private JsonObject readRoot() throws IOException {
        if (!settingsFile.exists()) {
            settingsFile.getParentFile().mkdirs();
            settingsFile.createNewFile();
            return new JsonObject();
        }
        String json = new String(Files.readAllBytes(settingsFile.toPath()), StandardCharsets.UTF_8);
        if (json.trim().isEmpty()) return new JsonObject();
        return JsonParser.parseString(json).getAsJsonObject();
    }

    private void writeRoot(JsonObject root) throws IOException {
        settingsFile.getParentFile().mkdirs();
        try (Writer writer = new OutputStreamWriter(new FileOutputStream(settingsFile), StandardCharsets.UTF_8)) {
            gson.toJson(root, writer);
        }
    }
}
