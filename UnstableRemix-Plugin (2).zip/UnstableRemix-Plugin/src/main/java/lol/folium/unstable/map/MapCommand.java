package lol.folium.unstable.map;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.integration.CitizensHook;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MapCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;
    private final ArenaManager arenas;
    private final WorldEditBridge worldEdit;
    private final CitizensHook citizens;
    private final Map<UUID, String> pendingInput = new ConcurrentHashMap<>();

    public MapCommand(UnstableRemixPlugin plugin, ArenaManager arenas, WorldEditBridge worldEdit, CitizensHook citizens) {
        this.plugin = plugin;
        this.arenas = arenas;
        this.worldEdit = worldEdit;
        this.citizens = citizens;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length == 0) {
            player.sendMessage(TextUtil.parse("<yellow>/map create|quick|setup|delete|setlobby|setspawn|addspawn|removespawn|clearspawns|list|npc|setpermanent|removepermanent</yellow>"));
            return;
        }
        switch (args[0].toLowerCase()) {
            case "create" -> handleCreate(player, args);
            case "quick" -> handleQuick(player, args);
            case "setup" -> handleSetup(player, args);
            case "delete" -> handleDelete(player, args);
            case "setlobby" -> handleSetLobby(player, args);
            case "setspawn" -> handleSetSpawn(player, args);
            case "addspawn" -> handleAddSpawn(player, args);
            case "removespawn" -> handleRemoveSpawn(player, args);
            case "clearspawns" -> handleClearSpawns(player, args);
            case "list" -> handleList(player);
            case "npc" -> handleNpc(player, args);
            case "setpermanent" -> handleSetPermanent(player, args);
            case "removepermanent" -> handleRemovePermanent(player, args);
            default -> player.sendMessage(TextUtil.parse("<red>Unknown subcommand.</red>"));
        }
    }

    private void handleNpc(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(TextUtil.parse("<red>Usage: /map npc <arena|vote|permanent> <skin></red>"));
            return;
        }
        if (!citizens.isAvailable()) {
            player.sendMessage(TextUtil.parse("<red>Citizens is required for NPC spawning.</red>"));
            return;
        }
        String target = args[1].toLowerCase();
        String skin = args[2];

        // Handle permanent arena NPC
        if (target.equals("permanent")) {
            // Find the first permanent arena
            String permanentArena = null;
            for (String arenaName : arenas.names()) {
                Arena a = arenas.getArena(arenaName);
                if (a != null && a.isPermanent()) {
                    permanentArena = arenaName;
                    break;
                }
            }
            if (permanentArena == null) {
                player.sendMessage(TextUtil.parse("<red>No permanent arena found. Use <yellow>/map setpermanent <arena></yellow> first.</red>"));
                return;
            }
            if (citizens.spawnArenaNpc(player, permanentArena, skin)) {
                player.sendMessage(TextUtil.parse("<green>NPC linked to permanent arena: <white>" + permanentArena + "</white>.</green>"));
            } else {
                player.sendMessage(TextUtil.parse("<red>Failed to spawn NPC.</red>"));
            }
            return;
        }

        if (!target.equals("vote") && !arenas.exists(target)) {
            player.sendMessage(TextUtil.parse("<red>Arena not found.</red>"));
            return;
        }
        if (citizens.spawnArenaNpc(player, target, skin)) {
            String display = target.equals("vote") ? "current voted map" : target;
            player.sendMessage(TextUtil.parse("<green>NPC linked to <white>" + display + "</white>.</green>"));
        } else {
            player.sendMessage(TextUtil.parse("<red>Failed to spawn NPC.</red>"));
        }
    }

    private void handleSetPermanent(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /map setpermanent <arena></red>"));
            return;
        }
        String name = args[1].toLowerCase();
        Arena arena = arenas.getArena(name);
        if (arena == null) {
            player.sendMessage(TextUtil.parse("<red>Arena not found.</red>"));
            return;
        }
        // Remove any existing permanent arena first
        for (String other : arenas.names()) {
            Arena a = arenas.getArena(other);
            if (a != null && a.isPermanent() && !a.name().equals(name)) {
                a.setPermanent(false);
                a.setNoElytra(false);
                try {
                    arenas.save(a);
                } catch (Exception e) {
                    player.sendMessage(TextUtil.parse("<red>Failed to save arena: " + e.getMessage() + "</red>"));
                }
                player.sendMessage(TextUtil.parse("<yellow>Removed permanent status from <white>" + a.name() + "</white>.</yellow>"));
            }
        }
        arena.setPermanent(true);
        arena.setNoElytra(true);
        try {
            arenas.save(arena);
        } catch (Exception e) {
            player.sendMessage(TextUtil.parse("<red>Failed to save arena: " + e.getMessage() + "</red>"));
            return;
        }
        player.sendMessage(TextUtil.parse("<green><bold>" + arena.displayName() + "</bold> is now the permanent No-Mace & No-Elytra arena!</green>"));
        player.sendMessage(TextUtil.parse("<gray>Maces and elytras are now disabled here.</gray>"));
        player.sendMessage(TextUtil.parse("<gray>Use <yellow>/map npc permanent <skin></yellow> to spawn a join NPC.</gray>"));
        player.sendMessage(TextUtil.parse("<gray>This arena will NOT appear in map voting.</gray>"));
    }

    private void handleRemovePermanent(Player player, String[] args) {
        if (args.length < 2) {
            // List all permanent arenas
            boolean found = false;
            for (String name : arenas.names()) {
                Arena a = arenas.getArena(name);
                if (a != null && a.isPermanent()) {
                    player.sendMessage(TextUtil.parse("<aqua>" + a.name() + "</aqua> <gray>(permanent, no-elytra: " + a.noElytra() + ")</gray>"));
                    found = true;
                }
            }
            if (!found) {
                player.sendMessage(TextUtil.parse("<gray>No permanent arenas set.</gray>"));
            }
            player.sendMessage(TextUtil.parse("<yellow>/map removepermanent <arena></yellow>"));
            return;
        }
        String name = args[1].toLowerCase();
        Arena arena = arenas.getArena(name);
        if (arena == null) {
            player.sendMessage(TextUtil.parse("<red>Arena not found.</red>"));
            return;
        }
        if (!arena.isPermanent()) {
            player.sendMessage(TextUtil.parse("<red>This arena is not a permanent arena.</red>"));
            return;
        }
        arena.setPermanent(false);
        arena.setNoElytra(false);
        try {
            arenas.save(arena);
        } catch (Exception e) {
            player.sendMessage(TextUtil.parse("<red>Failed to save arena: " + e.getMessage() + "</red>"));
            return;
        }
        player.sendMessage(TextUtil.parse("<yellow><bold>" + arena.displayName() + "</bold> is no longer a permanent arena.</yellow>"));
        player.sendMessage(TextUtil.parse("<gray>Maces and elytras are re-enabled.</gray>"));
    }

    private void handleCreate(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /map create <name>"));
            return;
        }
        if (!worldEdit.isAvailable()) {
            player.sendMessage(TextUtil.parse("<red>WorldEdit is required for /map create."));
            return;
        }
        String name = args[1].toLowerCase();
        if (arenas.exists(name)) {
            player.sendMessage(TextUtil.parse("<red>Arena already exists."));
            return;
        }
        var selection = worldEdit.getSelection(player);
        if (selection.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>Select an area with the WorldEdit wand first."));
            return;
        }
        try {
            Arena arena = arenas.create(name, selection.get());
            if (!worldEdit.saveSchematic(player, name, selection.get())) {
                arenas.delete(name);
                player.sendMessage(TextUtil.parse("<red>Failed to save schematic."));
                return;
            }
            player.sendMessage(TextUtil.parse("<green>Created arena <white>" + name + "</white>."));
        } catch (Exception ex) {
            player.sendMessage(TextUtil.parse("<red>Failed: " + ex.getMessage()));
        }
    }

    private void handleQuick(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /map quick <name>"));
            player.sendMessage(TextUtil.parse("<gray>Creates arena from WE selection, adds spawns, barriers, enables, adds to mapvote.</gray>"));
            return;
        }
        if (!worldEdit.isAvailable()) {
            player.sendMessage(TextUtil.parse("<red>WorldEdit is required."));
            return;
        }
        String name = args[1].toLowerCase();
        if (arenas.exists(name)) {
            player.sendMessage(TextUtil.parse("<red>Arena already exists."));
            return;
        }
        var selection = worldEdit.getSelection(player);
        if (selection.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>Select an area with the WorldEdit wand first."));
            return;
        }
        try {
            Arena arena = arenas.create(name, selection.get());
            if (!worldEdit.saveSchematic(player, name, selection.get())) {
                arenas.delete(name);
                player.sendMessage(TextUtil.parse("<red>Failed to save schematic."));
                return;
            }

            Location loc = player.getLocation();
            arena.setSpawn1(loc);
            arena.setTeamSpawnMode("FFA");
            arena.setDisplayName(capitalize(name));
            arena.setEnabled(true);
            arenas.save(arena);

            placeBarriers(selection.get());

            MapVoteManager mapVote = plugin.getMapVoteManager();
            if (mapVote != null && !mapVote.getVoteOptions().containsKey(name)) {
                mapVote.addVoteOption(name, name, capitalize(name), Material.GRASS_BLOCK);
            }

            player.sendMessage(TextUtil.parse("<green><bold>Arena created and ready!</bold></green>"));
            player.sendMessage(TextUtil.parse("<green>Name: <white>" + name + "</white>"));
            player.sendMessage(TextUtil.parse("<green>Spawn: <white>Set to your location (FFA)</white>"));
            player.sendMessage(TextUtil.parse("<green>Barriers: <white>Placed around arena</white>"));
            player.sendMessage(TextUtil.parse("<green>Mapvote: <white>Added as '" + capitalize(name) + "'</white>"));
            player.sendMessage(TextUtil.parse("<gray>Use /map setup " + name + " to add more spawns or fine-tune.</gray>"));
        } catch (Exception ex) {
            player.sendMessage(TextUtil.parse("<red>Failed: " + ex.getMessage()));
        }
    }

    private void handleSetup(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /map setup <name>"));
            return;
        }
        String name = args[1].toLowerCase();
        arenas.get(name).ifPresentOrElse(
                arena -> openSetupGui(player, arena),
                () -> player.sendMessage(TextUtil.parse("<red>Arena not found. Use /map quick <name> to create one."))
        );
    }

    private void openSetupGui(Player player, Arena arena) {
        SetupGuiHolder holder = new SetupGuiHolder(player, arena);
        Inventory inv = Bukkit.createInventory(holder, 3 * 9,
                TextUtil.parse("<gradient:#FF4444:#FF8800>Setup: " + arena.name() + "</gradient>"));
        holder.bind(inv);

        for (int i = 0; i < inv.getSize(); i++) {
            inv.setItem(i, ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE).name(Component.text("")).build());
        }

        inv.setItem(4, ItemBuilder.of(Material.NAME_TAG)
                .name(TextUtil.parse("<gold><bold>" + arena.name() + "</bold></gold>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Display: <white>" + arena.displayName() + "</white></gray>"),
                        TextUtil.parse("<gray>Mode: <white>" + arena.teamSpawnMode() + "</white></gray>"),
                        TextUtil.parse("<gray>Enabled: " + (arena.isEnabled() ? "<green>Yes" : "<red>No") + "</gray>")
                ))
                .build());

        boolean hasSpawns = arena.spawn1() != null || !arena.spawns().isEmpty();
        int spawnCount = arena.spawns().size() + (arena.spawn1() != null ? 1 : 0) + (arena.spawn2() != null ? 1 : 0);
        inv.setItem(10, ItemBuilder.of(hasSpawns ? Material.LIME_DYE : Material.RED_DYE)
                .name(TextUtil.parse((hasSpawns ? "<green>" : "<red>") + "<bold>Add Spawn</bold></" + (hasSpawns ? "green" : "red") + ">"))
                .lore(List.of(
                        TextUtil.parse("<gray>Spawns placed: <white>" + spawnCount + "</white></gray>"),
                        TextUtil.parse("<gray>Mode: <white>" + arena.teamSpawnMode() + "</white></gray>"),
                        Component.empty(),
                        TextUtil.parse("<yellow>Click to add spawn at your feet</yellow>")
                ))
                .build());

        inv.setItem(11, ItemBuilder.of(Material.IRON_SWORD)
                .name(TextUtil.parse("<aqua><bold>Set Spawn Mode</bold></aqua>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Current: <white>" + arena.teamSpawnMode() + "</white></gray>"),
                        Component.empty(),
                        TextUtil.parse("<yellow>Click to toggle FFA / TEAMS</yellow>")
                ))
                .build());

        inv.setItem(13, ItemBuilder.of(Material.BOOK)
                .name(TextUtil.parse("<blue><bold>Set Display Name</bold></blue>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Current: <white>" + arena.displayName() + "</white></gray>"),
                        Component.empty(),
                        TextUtil.parse("<yellow>Click to type in chat</yellow>")
                ))
                .build());

        inv.setItem(14, ItemBuilder.of(Material.PLAYER_HEAD)
                .name(TextUtil.parse("<light_purple><bold>Set Players</bold></light_purple>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Min: <white>" + arena.minPlayers() + "</white>  Max: <white>" + arena.maxPlayers() + "</white></gray>"),
                        Component.empty(),
                        TextUtil.parse("<yellow>Click to set min/max via chat</yellow>")
                ))
                .build());

        MapVoteManager mapVote = plugin.getMapVoteManager();
        boolean inMapvote = mapVote != null && mapVote.getVoteOptions().containsKey(arena.name());
        inv.setItem(15, ItemBuilder.of(inMapvote ? Material.LIME_DYE : Material.RED_DYE)
                .name(TextUtil.parse((inMapvote ? "<green>" : "<red>") + "<bold>Map Vote</bold></" + (inMapvote ? "green" : "red") + ">"))
                .lore(List.of(
                        TextUtil.parse("<gray>Status: " + (inMapvote ? "<green>In mapvote</green>" : "<red>Not in mapvote</red>") + "</gray>"),
                        Component.empty(),
                        TextUtil.parse("<yellow>Click to toggle</yellow>")
                ))
                .build());

        inv.setItem(16, ItemBuilder.of(Material.BARRIER)
                .name(TextUtil.parse("<dark_purple><bold>Place Barriers</bold></dark_purple>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Place barrier walls + roof</gray>"),
                        TextUtil.parse("<gray>around the arena borders.</gray>"),
                        Component.empty(),
                        TextUtil.parse("<yellow>Click to place barriers</yellow>")
                ))
                .build());

        inv.setItem(22, ItemBuilder.of(arena.isEnabled() ? Material.LIME_DYE : Material.RED_DYE)
                .name(TextUtil.parse((arena.isEnabled() ? "<green>" : "<red>") + "<bold>" + (arena.isEnabled() ? "Arena Enabled" : "Arena Disabled") + "</bold></" + (arena.isEnabled() ? "green" : "red") + ">"))
                .lore(List.of(
                        TextUtil.parse("<yellow>Click to toggle enable/disable</yellow>")
                ))
                .build());

        inv.setItem(24, ItemBuilder.of(Material.ENDER_PEARL)
                .name(TextUtil.parse("<yellow><bold>Teleport to Arena</bold></yellow>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Teleport to the arena</gray>")
                ))
                .build());

        inv.setItem(26, ItemBuilder.of(Material.BARRIER)
                .name(TextUtil.parse("<red><bold>Delete Arena</bold></red>"))
                .lore(List.of(
                        TextUtil.parse("<red>Permanently delete this arena.</red>"),
                        Component.empty(),
                        TextUtil.parse("<yellow>Click to confirm</yellow>")
                ))
                .build());

        player.openInventory(inv);
    }

    private void handleDelete(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /map delete <name>"));
            return;
        }
        String name = args[1].toLowerCase();
        if (!arenas.exists(name)) {
            player.sendMessage(TextUtil.parse("<red>Arena not found."));
            return;
        }
        arenas.delete(name);
        player.sendMessage(TextUtil.parse("<green>Deleted arena <white>" + name + "</white>."));
    }

    private void handleSetLobby(Player player, String[] args) {
        var cfg = plugin.getConfigManager();
        cfg.writeLobby(player.getLocation());
        player.sendMessage(TextUtil.parse("<green>Main server lobby set to your location.</green>"));
    }

    private void handleSetSpawn(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(TextUtil.parse("<red>Usage: /map setspawn <name> <1|2>"));
            return;
        }
        int team;
        try {
            team = Integer.parseInt(args[2]);
        } catch (NumberFormatException ex) {
            player.sendMessage(TextUtil.parse("<red>Team must be 1 or 2."));
            return;
        }
        if (team != 1 && team != 2) {
            player.sendMessage(TextUtil.parse("<red>Team must be 1 or 2."));
            return;
        }
        arenas.get(args[1].toLowerCase()).ifPresentOrElse(arena -> {
            if (team == 1) {
                arena.setSpawn1(player.getLocation());
            } else {
                arena.setSpawn2(player.getLocation());
            }
            try {
                arenas.save(arena);
                player.sendMessage(TextUtil.parse("<green>Spawn " + team + " set for <white>" + arena.name() + "</white>."));
            } catch (Exception ex) {
                player.sendMessage(TextUtil.parse("<red>Save failed."));
            }
        }, () -> player.sendMessage(TextUtil.parse("<red>Arena not found.")));
    }

    private void handleAddSpawn(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /map addspawn <name>"));
            return;
        }
        arenas.get(args[1].toLowerCase()).ifPresentOrElse(arena -> {
            arena.addSpawn(player.getLocation());
            try {
                arenas.save(arena);
                player.sendMessage(TextUtil.parse("<green>Spawn added for <white>" + arena.name() + "</white>. Total: " + arena.spawns().size()));
            } catch (Exception ex) {
                player.sendMessage(TextUtil.parse("<red>Save failed."));
            }
        }, () -> player.sendMessage(TextUtil.parse("<red>Arena not found.")));
    }

    private void handleRemoveSpawn(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(TextUtil.parse("<red>Usage: /map removespawn <name> <index>"));
            return;
        }
        int index;
        try {
            index = Integer.parseInt(args[2]);
        } catch (NumberFormatException ex) {
            player.sendMessage(TextUtil.parse("<red>Index must be a number."));
            return;
        }
        arenas.get(args[1].toLowerCase()).ifPresentOrElse(arena -> {
            if (index < 0 || index >= arena.spawns().size()) {
                player.sendMessage(TextUtil.parse("<red>Invalid spawn index. Valid range: 0-" + (arena.spawns().size() - 1)));
                return;
            }
            arena.removeSpawn(index);
            try {
                arenas.save(arena);
                player.sendMessage(TextUtil.parse("<green>Spawn " + index + " removed from <white>" + arena.name() + "</white>."));
            } catch (Exception ex) {
                player.sendMessage(TextUtil.parse("<red>Save failed."));
            }
        }, () -> player.sendMessage(TextUtil.parse("<red>Arena not found.")));
    }

    private void handleClearSpawns(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /map clearspawns <name>"));
            return;
        }
        arenas.get(args[1].toLowerCase()).ifPresentOrElse(arena -> {
            arena.clearSpawns();
            try {
                arenas.save(arena);
                player.sendMessage(TextUtil.parse("<green>All spawns cleared from <white>" + arena.name() + "</white>."));
            } catch (Exception ex) {
                player.sendMessage(TextUtil.parse("<red>Save failed."));
            }
        }, () -> player.sendMessage(TextUtil.parse("<red>Arena not found.")));
    }

    private void handleList(Player player) {
        if (arenas.all().isEmpty()) {
            player.sendMessage(TextUtil.parse("<gray>No arenas registered."));
            return;
        }
        MapVoteManager mapVote = plugin.getMapVoteManager();
        player.sendMessage(TextUtil.parse("<gradient:#FF4444:#FF8800><bold>Arena Status</bold></gradient>"));
        for (Arena arena : arenas.all()) {
            boolean hasSpawns = arena.spawn1() != null || !arena.spawns().isEmpty();
            boolean inMapvote = mapVote != null && mapVote.getVoteOptions().containsKey(arena.name());
            String spawns = hasSpawns ? "<green>✓</green>" : "<red>✗</red>";
            String enabled = arena.isEnabled() ? "<green>✓</green>" : "<red>✗</red>";
            String mapvote = inMapvote ? "<green>✓</green>" : "<red>✗</red>";
            String permanent = arena.isPermanent() ? " <aqua>[PERMANENT]</aqua>" : "";
            String noElytra = arena.noElytra() ? " <red>[NO-ELYTRA/NO-MACE]</red>" : "";
            player.sendMessage(TextUtil.parse(
                    "<white>" + arena.name() + "</white> "
                    + permanent + noElytra
                    + "<dark_gray>|</dark_gray> "
                    + "Spawns:" + spawns + " "
                    + "Enabled:" + enabled + " "
                    + "Vote:" + mapvote + " "
                    + "<dark_gray>|</dark_gray> "
                    + "<gray>" + arena.players().size() + " players</gray>"
            ));
        }
        player.sendMessage(TextUtil.parse("<gray>Use <white>/map setup <name></white> to configure an arena.</gray>"));
    }

    private String capitalize(String s) {
        if (s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }

    private void placeBarriers(WorldEditBridge.RegionSelection sel) {
        org.bukkit.World world = Bukkit.getWorld(sel.world());
        if (world == null) return;

        int minX = sel.minX() - 1;
        int maxX = sel.maxX() + 1;
        int minZ = sel.minZ() - 1;
        int maxZ = sel.maxZ() + 1;
        int roofY = sel.maxY() + 1;

        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                if (x == minX || x == maxX || z == minZ || z == maxZ) {
                    world.getBlockAt(x, roofY, z).setType(Material.BARRIER);
                }
            }
        }

        for (int x = minX; x <= maxX; x++) {
            for (int y = sel.minY(); y <= roofY; y++) {
                if (x == minX || x == maxX) {
                    world.getBlockAt(x, y, minZ).setType(Material.BARRIER);
                    world.getBlockAt(x, y, maxZ).setType(Material.BARRIER);
                }
            }
        }

        for (int z = minZ; z <= maxZ; z++) {
            for (int y = sel.minY(); y <= roofY; y++) {
                if (z == minZ || z == maxZ) {
                    world.getBlockAt(minX, y, z).setType(Material.BARRIER);
                    world.getBlockAt(maxX, y, z).setType(Material.BARRIER);
                }
            }
        }
    }

    private void listenChat(Player player, java.util.function.Consumer<String> callback) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            org.bukkit.event.Listener listener = new org.bukkit.event.Listener() {
                @org.bukkit.event.EventHandler
                public void onChat(org.bukkit.event.player.PlayerChatEvent e) {
                    if (!e.getPlayer().equals(player)) return;
                    e.setCancelled(true);
                    callback.accept(e.getMessage().trim());
                    org.bukkit.event.HandlerList.unregisterAll(this);
                }
            };
            Bukkit.getPluginManager().registerEvents(listener, plugin);
        }, 1L);
    }

    private final class SetupGuiHolder extends GuiHolder {
        private final Player player;
        private final Arena arena;

        SetupGuiHolder(Player player, Arena arena) {
            this.player = player;
            this.arena = arena;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();

            switch (slot) {
                case 10 -> {
                    player.closeInventory();
                    if (arena.teamSpawnMode().equals("FFA")) {
                        arena.addSpawn(player.getLocation());
                    } else {
                        if (arena.spawn1() == null) {
                            arena.setSpawn1(player.getLocation());
                            player.sendMessage(TextUtil.parse("<green>Spawn 1 set.</green>"));
                        } else {
                            arena.setSpawn2(player.getLocation());
                            player.sendMessage(TextUtil.parse("<green>Spawn 2 set.</green>"));
                        }
                    }
                    try {
                        arenas.save(arena);
                        int count = arena.spawns().size() + (arena.spawn1() != null ? 1 : 0) + (arena.spawn2() != null ? 1 : 0);
                        if (arena.teamSpawnMode().equals("FFA")) {
                            player.sendMessage(TextUtil.parse("<green>Spawn added. Total: " + arena.spawns().size()));
                        }
                    } catch (Exception ex) {
                        player.sendMessage(TextUtil.parse("<red>Save failed."));
                    }
                    openSetupGui(player, arena);
                }
                case 11 -> {
                    String newMode = arena.teamSpawnMode().equals("FFA") ? "TEAMS" : "FFA";
                    arena.setTeamSpawnMode(newMode);
                    try {
                        arenas.save(arena);
                        player.sendMessage(TextUtil.parse("<green>Spawn mode set to <white>" + newMode + "</white>."));
                    } catch (Exception ex) {
                        player.sendMessage(TextUtil.parse("<red>Save failed."));
                    }
                    openSetupGui(player, arena);
                }
                case 13 -> {
                    player.closeInventory();
                    player.sendMessage(TextUtil.parse("<yellow>Type a display name for <white>" + arena.name() + "</white>:</yellow>"));
                    player.sendMessage(TextUtil.parse("<gray>(or type <white>cancel</white>)</gray>"));
                    listenChat(player, message -> {
                        if (message.equalsIgnoreCase("cancel")) {
                            player.sendMessage(TextUtil.parse("<red>Cancelled.</red>"));
                            openSetupGui(player, arena);
                            return;
                        }
                        arena.setDisplayName(message);
                        try {
                            arenas.save(arena);
                            MapVoteManager mapVote = plugin.getMapVoteManager();
                            if (mapVote != null && mapVote.getVoteOptions().containsKey(arena.name())) {
                                mapVote.updateVoteOptionDisplayName(arena.name(), message);
                            }
                            player.sendMessage(TextUtil.parse("<green>Display name set to <white>" + message + "</white>."));
                        } catch (Exception ex) {
                            player.sendMessage(TextUtil.parse("<red>Save failed."));
                        }
                        openSetupGui(player, arena);
                    });
                }
                case 14 -> {
                    player.closeInventory();
                    player.sendMessage(TextUtil.parse("<yellow>Type min,max for players (e.g. 2,20):</yellow>"));
                    player.sendMessage(TextUtil.parse("<gray>(or type <white>cancel</white>)</gray>"));
                    listenChat(player, message -> {
                        if (message.equalsIgnoreCase("cancel")) {
                            player.sendMessage(TextUtil.parse("<red>Cancelled.</red>"));
                            openSetupGui(player, arena);
                            return;
                        }
                        try {
                            String[] parts = message.split(",");
                            int min = Integer.parseInt(parts[0].trim());
                            int max = Integer.parseInt(parts[1].trim());
                            arena.setMinPlayers(min);
                            arena.setMaxPlayers(max);
                            arenas.save(arena);
                            player.sendMessage(TextUtil.parse("<green>Players set to min:<white>" + min + "</white> max:<white>" + max + "</white>."));
                        } catch (Exception ex) {
                            player.sendMessage(TextUtil.parse("<red>Invalid format. Use: min,max</red>"));
                        }
                        openSetupGui(player, arena);
                    });
                }
                case 15 -> {
                    MapVoteManager mapVote = plugin.getMapVoteManager();
                    if (mapVote == null) {
                        player.sendMessage(TextUtil.parse("<red>MapVote system not available."));
                        return;
                    }
                    if (mapVote.getVoteOptions().containsKey(arena.name())) {
                        mapVote.removeVoteOption(arena.name());
                        player.sendMessage(TextUtil.parse("<green>Removed <white>" + arena.name() + "</white> from mapvote.</green>"));
                    } else {
                        mapVote.addVoteOption(arena.name(), arena.name(), arena.displayName(), Material.GRASS_BLOCK);
                        player.sendMessage(TextUtil.parse("<green>Added <white>" + arena.name() + "</white> to mapvote.</green>"));
                    }
                    openSetupGui(player, arena);
                }
                case 16 -> {
                    var selection = worldEdit.getSelection(player);
                    if (selection.isEmpty()) {
                        player.closeInventory();
                        player.sendMessage(TextUtil.parse("<red>Select an area with the WorldEdit wand first, then click this button again.</red>"));
                        return;
                    }
                    player.closeInventory();
                    placeBarriers(selection.get());
                    player.sendMessage(TextUtil.parse("<green><bold>Barriers placed around arena!</bold></green>"));
                    openSetupGui(player, arena);
                }
                case 22 -> {
                    arena.setEnabled(!arena.isEnabled());
                    try {
                        arenas.save(arena);
                        player.sendMessage(TextUtil.parse("<green>Arena " + (arena.isEnabled() ? "<white>enabled</white>" : "<red>disabled</red>") + "."));
                    } catch (Exception ex) {
                        player.sendMessage(TextUtil.parse("<red>Save failed."));
                    }
                    openSetupGui(player, arena);
                }
                case 24 -> {
                    player.closeInventory();
                    var loc = arena.spawns().isEmpty() ? arena.spawn1() : arena.spawns().getFirst();
                    if (loc != null) {
                        player.teleport(loc);
                        player.sendMessage(TextUtil.parse("<green>Teleported to <white>" + arena.name() + "</white>."));
                    } else {
                        player.sendMessage(TextUtil.parse("<red>No spawns set for this arena. Add one first.</red>"));
                    }
                    openSetupGui(player, arena);
                }
                case 26 -> {
                    player.closeInventory();
                    player.sendMessage(TextUtil.parse("<red>Type <white>delete</white> in chat to confirm deleting arena <white>" + arena.name() + "</white>:</red>"));
                    player.sendMessage(TextUtil.parse("<gray>(or type anything else to cancel)</gray>"));
                    listenChat(player, message -> {
                        if (message.equalsIgnoreCase("delete")) {
                            arenas.delete(arena.name());
                            player.sendMessage(TextUtil.parse("<green>Deleted arena <white>" + arena.name() + "</white>.</green>"));
                        } else {
                            player.sendMessage(TextUtil.parse("<red>Cancelled.</red>"));
                            openSetupGui(player, arena);
                        }
                    });
                }
            }
        }
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            return filter(literals("create", "quick", "setup", "delete", "setlobby", "setspawn", "addspawn", "removespawn", "clearspawns", "list", "npc", "setpermanent", "removepermanent"), args[0]);
        }
        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if (sub.equals("npc")) {
                var names = new java.util.ArrayList<>(arenas.names());
                names.add("vote");
                names.add("permanent");
                return filter(names, args[1]);
            }
            if (sub.equals("delete") || sub.equals("setspawn") ||
                sub.equals("addspawn") || sub.equals("removespawn") || sub.equals("clearspawns") || sub.equals("setup") ||
                sub.equals("setpermanent") || sub.equals("removepermanent")) {
                return filter(arenas.names(), args[1]);
            }
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("setspawn")) {
            return filter(literals("1", "2"), args[2]);
        }
        return List.of();
    }

    @Override
    protected String permission() {
        return "unstable.map.admin";
    }
}
