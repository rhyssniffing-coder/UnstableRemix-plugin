package lol.folium.unstable.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public abstract class SubCommand implements CommandExecutor, TabCompleter {

    protected abstract void execute(org.bukkit.entity.Player player, String[] args);

    protected abstract List<String> tabComplete(org.bukkit.entity.Player player, String[] args);

    protected abstract String permission();

    @Override
    public final boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof org.bukkit.entity.Player player)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (permission() != null && !player.hasPermission(permission())) {
            player.sendMessage(net.kyori.adventure.text.Component.text("No permission."));
            return true;
        }
        execute(player, args);
        return true;
    }

    @Override
    public final List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof org.bukkit.entity.Player player)) {
            return Collections.emptyList();
        }
        if (permission() != null && !player.hasPermission(permission())) {
            return Collections.emptyList();
        }
        return filter(tabComplete(player, args), args.length == 0 ? "" : args[args.length - 1]);
    }

    protected List<String> filter(List<String> options, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String option : options) {
            if (option.toLowerCase(Locale.ROOT).startsWith(lower)) {
                out.add(option);
            }
        }
        return out;
    }

    protected List<String> literals(String... values) {
        return Arrays.asList(values);
    }
}
