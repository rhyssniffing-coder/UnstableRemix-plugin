package lol.folium.unstable.listener;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.combat.CombatTagManager;
import lol.folium.unstable.data.PlayerDataStore;
import lol.folium.unstable.data.PlayerProfile;
import lol.folium.unstable.effects.EffectsManager;
import lol.folium.unstable.faction.FactionSelectionManager;
import lol.folium.unstable.reward.DailyLoginManager;
import lol.folium.unstable.reward.DailyRewardManager;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PlayerLifecycleListener implements Listener {

    private final UnstableRemixPlugin plugin;
    private final PlayerDataStore store;
    private final EffectsManager effects;
    private final CombatTagManager combatTags;
    private final DailyRewardManager dailyRewards;
    private final DailyLoginManager dailyLogin;
    private final FactionSelectionManager factionSelection;
    private final Map<UUID, Long> sessionStarts = new ConcurrentHashMap<>();

    public PlayerLifecycleListener(UnstableRemixPlugin plugin, PlayerDataStore store, EffectsManager effects,
                                   CombatTagManager combatTags, DailyRewardManager dailyRewards,
                                   DailyLoginManager dailyLogin, FactionSelectionManager factionSelection) {
        this.plugin = plugin;
        this.store = store;
        this.effects = effects;
        this.combatTags = combatTags;
        this.dailyRewards = dailyRewards;
        this.dailyLogin = dailyLogin;
        this.factionSelection = factionSelection;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        PlayerProfile profile = store.get(event.getPlayer().getUniqueId());
        sessionStarts.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
        effects.processTokenClaims(event.getPlayer());
        if (dailyLogin != null) {
            dailyLogin.processLogin(event.getPlayer());
        } else {
            dailyRewards.processLogin(event.getPlayer());
        }
        if (factionSelection != null) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> factionSelection.handlePlayerJoin(event.getPlayer()), 5L);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        Long start = sessionStarts.remove(uuid);
        if (start != null) {
            PlayerProfile profile = store.get(uuid);
            long elapsed = (System.currentTimeMillis() - start) / 1000;
            profile.setPlaytime(profile.playtime() + elapsed);
            profile.setLastSeen(System.currentTimeMillis());
            store.saveProfile(profile);
        }
        combatTags.handleQuit(event.getPlayer());
        store.unload(uuid);
    }

    public void shutdown() {
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Long> entry : sessionStarts.entrySet()) {
            UUID uuid = entry.getKey();
            Long start = entry.getValue();
            if (start != null) {
                PlayerProfile profile = store.get(uuid);
                long elapsed = (now - start) / 1000;
                profile.setPlaytime(profile.playtime() + elapsed);
                profile.setLastSeen(now);
                store.saveProfile(profile);
            }
            store.unload(uuid);
        }
        sessionStarts.clear();
    }
}
