package lol.folium.unstable.stats;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.data.PlayerProfile;
import lol.folium.unstable.settings.SettingsManager;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.List;

public final class StatsCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;

    public StatsCommand(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    protected void execute(Player player, String[] args) {
        Player target = args.length >= 1 ? Bukkit.getPlayer(args[0]) : player;
        if (target == null) {
            player.sendMessage(TextUtil.parse("<red>Player not found."));
            return;
        }
        if (!player.equals(target)) {
            boolean targetPrivate = SettingsManager.getInstance().getSettings(target.getUniqueId())
                    .isEnabled(lol.folium.unstable.settings.PlayerSettings.Setting.PRIVATE_STATS);
            if (targetPrivate) {
                player.sendMessage(TextUtil.parse("<red>This player has private stats."));
                return;
            }
        }
        openStats(player, target);
    }

    private void openStats(Player viewer, Player target) {
        PlayerProfile profile = plugin.getPlayerDataStore().get(target.getUniqueId());

        StatsGui holder = new StatsGui();
        Inventory inv = Bukkit.createInventory(holder, 54, TextUtil.parse("<gradient:#8A2387:#E94057><bold>Player Stats</bold></gradient>"));
        holder.bind(inv);

        ItemStack filler = ItemBuilder.of(Material.GRAY_STAINED_GLASS_PANE)
                .name(Component.empty())
                .build();
        for (int i = 0; i < 54; i++) {
            inv.setItem(i, filler);
        }

        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta skull = (SkullMeta) head.getItemMeta();
        skull.setOwningPlayer(target);
        skull.displayName(TextUtil.parse("<gold><bold>" + target.getName() + "</bold></gold>"));
        skull.lore(List.of(TextUtil.parse("<dark_gray>Stats overview</dark_gray>")));
        head.setItemMeta(skull);
        inv.setItem(4, head);

        long kills = profile.lifetimeKills();
        long deaths = profile.deaths();
        String kd = deaths == 0 ? "∞" : String.format("%.2f", (double) kills / deaths);

        inv.setItem(10, ItemBuilder.of(Material.IRON_SWORD)
                .name(TextUtil.parse("<red><bold>Kills</bold></red>"))
                .lore(List.of(TextUtil.parse("<gray>" + formatNumber(kills) + "</gray>")))
                .build());

        inv.setItem(11, ItemBuilder.of(Material.BONE)
                .name(TextUtil.parse("<red><bold>Deaths</bold></red>"))
                .lore(List.of(TextUtil.parse("<gray>" + formatNumber(deaths) + "</gray>")))
                .build());

        inv.setItem(12, ItemBuilder.of(Material.CROSSBOW)
                .name(TextUtil.parse("<gold><bold>K/D Ratio</bold></gold>"))
                .lore(List.of(TextUtil.parse("<gray>" + kd + "</gray>")))
                .build());

        inv.setItem(13, ItemBuilder.of(Material.NETHERITE_HELMET)
                .name(TextUtil.parse("<aqua><bold>Best Killstreak</bold></aqua>"))
                .lore(List.of(TextUtil.parse("<gray>" + formatNumber(profile.highestKillstreak()) + "</gray>")))
                .build());

        inv.setItem(14, ItemBuilder.of(Material.DIAMOND)
                .name(TextUtil.parse("<light_purple><bold>Shards</bold></light_purple>"))
                .lore(List.of(TextUtil.parse("<gray>" + formatNumber(profile.shards()) + "</gray>")))
                .build());

        inv.setItem(15, ItemBuilder.of(Material.GOLD_INGOT)
                .name(TextUtil.parse("<yellow><bold>Total Earned</bold></yellow>"))
                .lore(List.of(TextUtil.parse("<gray>" + formatNumber(profile.totalShardsEarned()) + " shards</gray>")))
                .build());

        inv.setItem(16, ItemBuilder.of(Material.EXPERIENCE_BOTTLE)
                .name(TextUtil.parse("<green><bold>Prestige</bold></green>"))
                .lore(List.of(TextUtil.parse("<gray>Rank " + profile.prestigeRank() + "</gray>")))
                .build());

        inv.setItem(22, ItemBuilder.of(Material.CLOCK)
                .name(TextUtil.parse("<aqua><bold>Playtime</bold></aqua>"))
                .lore(List.of(TextUtil.parse("<gray>" + formatPlaytime(profile.playtime()) + "</gray>")))
                .build());

        inv.setItem(31, ItemBuilder.of(Material.CHEST)
                .name(TextUtil.parse("<green><bold>Match Wins</bold></green>"))
                .lore(List.of(TextUtil.parse("<gray>" + formatNumber(profile.matchWins()) + "</gray>")))
                .build());

        inv.setItem(32, ItemBuilder.of(Material.COMPASS)
                .name(TextUtil.parse("<gold><bold>Login Streak</bold></gold>"))
                .lore(List.of(TextUtil.parse("<gray>" + profile.loginStreak() + " days</gray>")))
                .build());

        inv.setItem(49, ItemBuilder.of(Material.BARRIER)
                .name(TextUtil.parse("<red><bold>Close</bold></red>"))
                .build());

        viewer.openInventory(inv);
    }

    private String formatNumber(long n) {
        if (n >= 1_000_000_000) return String.format("%.1fB", n / 1_000_000_000.0);
        if (n >= 1_000_000) return String.format("%.1fM", n / 1_000_000.0);
        if (n >= 10_000) return String.format("%.1fk", n / 1_000.0);
        return String.valueOf(n);
    }

    private String formatPlaytime(long seconds) {
        if (seconds < 60) return seconds + "s";
        if (seconds < 3600) return (seconds / 60) + "m " + (seconds % 60) + "s";
        if (seconds < 86400) return (seconds / 3600) + "h " + ((seconds % 3600) / 60) + "m";
        return (seconds / 86400) + "d " + ((seconds % 86400) / 3600) + "h";
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            java.util.ArrayList<String> names = new java.util.ArrayList<>();
            for (Player p : Bukkit.getOnlinePlayers()) {
                names.add(p.getName());
            }
            return filter(names, args[0]);
        }
        return List.of();
    }

    @Override
    protected String permission() {
        return null;
    }

    private static final class StatsGui extends GuiHolder {
        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            if (slot == 49) {
                event.getWhoClicked().closeInventory();
            }
        }
    }
}
