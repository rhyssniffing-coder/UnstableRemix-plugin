package lol.folium.unstable.settings;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerSettings {

    private final UUID uuid;
    private final Map<Setting, Boolean> toggles = new HashMap<>();

    public enum Setting {
        KILLSTREAK_ALERTS("killstreak-alerts", true),
        LOBBY_PLAYERS("lobby-players", true),
        BOUNTY_ALERTS("bounty-alerts", true),
        PRIVATE_STATS("private-stats", false);

        private final String configKey;
        private final boolean defaultValue;

        Setting(String configKey, boolean defaultValue) {
            this.configKey = configKey;
            this.defaultValue = defaultValue;
        }

        public String getConfigKey() {
            return configKey;
        }

        public boolean getDefaultValue() {
            return defaultValue;
        }
    }

    public PlayerSettings(UUID uuid) {
        this.uuid = uuid;
        for (Setting s : Setting.values()) {
            toggles.put(s, s.getDefaultValue());
        }
    }

    public UUID getUuid() {
        return uuid;
    }

    public boolean isEnabled(Setting setting) {
        return toggles.getOrDefault(setting, setting.getDefaultValue());
    }

    public void toggle(Setting setting) {
        toggles.put(setting, !isEnabled(setting));
    }

    public void set(Setting setting, boolean value) {
        toggles.put(setting, value);
    }

    public Map<Setting, Boolean> getAll() {
        return new HashMap<>(toggles);
    }

    public Map<String, Object> serialize() {
        Map<String, Object> data = new HashMap<>();
        for (Setting s : Setting.values()) {
            data.put(s.getConfigKey(), isEnabled(s));
        }
        return data;
    }

    @SuppressWarnings("unchecked")
    public void load(Map<String, Object> data) {
        if (data == null) return;
        for (Setting s : Setting.values()) {
            if (data.containsKey(s.getConfigKey())) {
                toggles.put(s, (Boolean) data.get(s.getConfigKey()));
            }
        }
    }
}
