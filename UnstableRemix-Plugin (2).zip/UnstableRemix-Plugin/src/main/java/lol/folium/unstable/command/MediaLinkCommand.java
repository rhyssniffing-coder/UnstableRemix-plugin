package lol.folium.unstable.command;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MediaLinkCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();
    private static final long COOLDOWN_MS = 60 * 60 * 1000L;

    public MediaLinkCommand(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length == 0) {
            player.sendMessage(TextUtil.parse("<red>Usage: /medialink <live link>"));
            return;
        }

        long now = System.currentTimeMillis();
        Long lastUsed = cooldowns.get(player.getUniqueId());
        if (lastUsed != null && (now - lastUsed) < COOLDOWN_MS) {
            long remaining = COOLDOWN_MS - (now - lastUsed);
            long mins = remaining / 60000;
            long secs = (remaining % 60000) / 1000;
            player.sendMessage(TextUtil.parse("<red>You can use /medialink again in <white>" + mins + "m " + secs + "s</white></red>"));
            return;
        }

        String link = String.join(" ", args);
        cooldowns.put(player.getUniqueId(), now);

        String format = plugin.getConfig().getString("media.link-broadcast",
                "<gold><bold>LIVE</bold></gold> <gray>|</gray> <white>{player}</white> <gray>is live!</gray> <aqua>{link}</aqua>");
        String message = format.replace("{player}", player.getName()).replace("{link}", link);
        Bukkit.broadcast(TextUtil.parse(message));
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            return List.of("<live link>");
        }
        return List.of();
    }

    @Override
    protected String permission() {
        return "unstable.media.link";
    }
}
