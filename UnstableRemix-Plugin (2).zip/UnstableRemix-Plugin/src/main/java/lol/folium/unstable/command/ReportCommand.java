package lol.folium.unstable.command;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ReportCommand extends SubCommand {

    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss").withZone(ZoneId.systemDefault());
    private final UnstableRemixPlugin plugin;
    private final ConcurrentHashMap<UUID, Long> cooldowns = new ConcurrentHashMap<>();

    public ReportCommand(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /report <player> <reason></red>"));
            return;
        }

        long cooldownMs = plugin.getConfig().getLong("report.cooldown-seconds", 60) * 1000;
        long now = System.currentTimeMillis();
        Long last = cooldowns.get(player.getUniqueId());
        if (last != null && now - last < cooldownMs) {
            long wait = (cooldownMs - (now - last)) / 1000;
            player.sendMessage(TextUtil.parse("<red>Please wait <yellow>" + wait + "s</yellow> before filing another report.</red>"));
            return;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            player.sendMessage(TextUtil.parse("<red>Player <white>" + args[0] + "</white> is not online.</red>"));
            return;
        }
        if (target.equals(player)) {
            player.sendMessage(TextUtil.parse("<red>You cannot report yourself.</red>"));
            return;
        }

        String reason = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
        String timestamp = TIME_FMT.format(Instant.now());

        cooldowns.put(player.getUniqueId(), now);

        String reportFormat = plugin.getConfig().getString("report.format",
                "<dark_purple><bold>[REPORT]</bold></dark_purple> <gray>{timestamp}</gray> <white>{reporter}</white> <gray>reported</gray> <white>{target}</white> <dark_gray>-</dark_gray> <red>{reason}</red>");
        String reportMsg = reportFormat
                .replace("{timestamp}", timestamp)
                .replace("{reporter}", player.getName())
                .replace("{target}", target.getName())
                .replace("{reason}", reason);

        String permission = plugin.getConfig().getString("report.receive-permission", "unstable.report.receive");
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission(permission)) {
                staff.sendMessage(TextUtil.parse(reportMsg));
                String sound = plugin.getConfig().getString("report.sound", "BLOCK_NOTE_BLOCK_PLING");
                try {
                    staff.playSound(staff.getLocation(), org.bukkit.Sound.valueOf(sound), 1.0F, 1.5F);
                } catch (IllegalArgumentException ignored) {
                }
            }
        }

        String confirmMsg = plugin.getConfig().getString("report.confirm-message",
                "<green>Your report has been submitted. Staff will review it shortly.</green>");
        player.sendMessage(TextUtil.parse(confirmMsg));
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            List<String> names = new ArrayList<>();
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!p.equals(player)) {
                    names.add(p.getName());
                }
            }
            return filter(names, args[0]);
        }
        if (args.length == 2) {
            return filter(literals("cheating", "griefing", "chat abuse", "bug exploit", "other"), args[1]);
        }
        return List.of();
    }

    @Override
    protected String permission() {
        return null;
    }
}
