package lol.folium.unstable.command;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.map.ArenaManager;
import lol.folium.unstable.effects.EffectsManager;
import lol.folium.unstable.quest.QuestService;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class ShardsCommand implements CommandExecutor, TabCompleter {

    private final EconomyService economy;

    public ShardsCommand(EconomyService economy) {
        this.economy = economy;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player target;
        if (args.length >= 1) {
            if (!sender.hasPermission("unstable.admin")) {
                sender.sendMessage(TextUtil.parse("<red>No permission."));
                return true;
            }
            target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                sender.sendMessage(TextUtil.parse("<red>Player not found."));
                return true;
            }
        } else if (sender instanceof Player player) {
            target = player;
        } else {
            sender.sendMessage("Console must specify a player.");
            return true;
        }
        long shards = economy.getShards(target.getUniqueId());
        long tokens = economy.getTokens(target.getUniqueId());
        sender.sendMessage(TextUtil.parse(
                "<gray>" + target.getName() + ": <light_purple>" + shards + " Shards</light_purple>, "
                        + "<gold>" + tokens + " Tokens</gold>"
        ));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1 && sender.hasPermission("unstable.admin")) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(args[0].toLowerCase(Locale.ROOT)))
                    .toList();
        }
        return Collections.emptyList();
    }
}
