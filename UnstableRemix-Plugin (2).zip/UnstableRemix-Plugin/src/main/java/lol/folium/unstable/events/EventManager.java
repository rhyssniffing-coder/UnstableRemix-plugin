package lol.folium.unstable.events;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class EventManager {

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final Map<String, Boolean> activeEvents = new ConcurrentHashMap<>();
    private final Map<String, ActiveBossBar> activeBossBars = new ConcurrentHashMap<>();
    private int taskId = -1;
    private double shardMultiplier = 1.0;
    private BukkitTask bossbarTask;

    public EventManager(UnstableRemixPlugin plugin, ConfigManager configs) {
        this.plugin = plugin;
        this.configs = configs;
    }

    public void startAutomaticSchedule() {
        ConfigurationSection eventsConfig = configs.main().getConfigurationSection("events");
        if (eventsConfig == null || !eventsConfig.getBoolean("enabled", true)) {
            return;
        }

        int intervalMinutes = eventsConfig.getInt("interval-minutes", 60);
        int durationMinutes = eventsConfig.getInt("duration-minutes", 10);

        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            startEvent("2x_shards", durationMinutes * 60);
        }, intervalMinutes * 60 * 20L, intervalMinutes * 60 * 20L);
    }

    public void startEvent(String eventId, int durationSeconds) {
        startEvent(eventId, durationSeconds, 2.0);
    }

    public void startEvent(String eventId, int durationSeconds, double multiplier) {
        if (activeEvents.containsKey(eventId) && activeEvents.get(eventId)) {
            return;
        }

        activeEvents.put(eventId, true);
        long endTime = System.currentTimeMillis() + durationSeconds * 1000L;
        BossBar bar = createBossBar();
        activeBossBars.put(eventId, new ActiveBossBar(endTime, durationSeconds, bar));

        switch (eventId.toLowerCase()) {
            case "2x_shards" -> {
                shardMultiplier = multiplier;
                Bukkit.broadcast(TextUtil.parse("<green><bold>" + multiplier + "x Shards Event Started!</bold></green> <gray>All shard rewards multiplied by " + multiplier + " for " + (durationSeconds / 60) + " minutes!</gray>"));
            }
            default -> Bukkit.broadcast(TextUtil.parse("<yellow>Event started: <white>" + eventId + "</white>"));
        }

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            endEvent(eventId);
        }, durationSeconds * 20L);

        updateBossbarTask();
    }

    public void endEvent(String eventId) {
        if (!activeEvents.containsKey(eventId) || !activeEvents.get(eventId)) {
            return;
        }

        activeEvents.put(eventId, false);
        ActiveBossBar abb = activeBossBars.remove(eventId);
        if (abb != null && abb.bar() != null) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                player.hideBossBar(abb.bar());
            }
        }

        switch (eventId.toLowerCase()) {
            case "2x_shards" -> {
                shardMultiplier = 1.0;
                Bukkit.broadcast(TextUtil.parse("<red><bold>2x Shards Event Ended!</bold></red> <gray>Shard rewards back to normal.</gray>"));
            }
            default -> Bukkit.broadcast(TextUtil.parse("<yellow>Event ended: <white>" + eventId + "</white>"));
        }

        updateBossbarTask();
    }

    public boolean isEventActive(String eventId) {
        return activeEvents.containsKey(eventId) && activeEvents.get(eventId);
    }

    public Map<String, Boolean> getActiveEvents() {
        return new ConcurrentHashMap<>(activeEvents);
    }

    public double getShardMultiplier() {
        return shardMultiplier;
    }

    public void stop() {
        if (taskId != -1) {
            Bukkit.getScheduler().cancelTask(taskId);
            taskId = -1;
        }
        if (bossbarTask != null) {
            bossbarTask.cancel();
            bossbarTask = null;
        }
        for (ActiveBossBar abb : activeBossBars.values()) {
            if (abb.bar() != null) {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    player.hideBossBar(abb.bar());
                }
            }
        }
        activeEvents.clear();
        activeBossBars.clear();
        shardMultiplier = 1.0;
    }

    private BossBar createBossBar() {
        ConfigurationSection bossbarCfg = configs.main().getConfigurationSection("events.bossbar");
        String colorName = bossbarCfg != null ? bossbarCfg.getString("color", "PINK") : "PINK";
        String styleName = bossbarCfg != null ? bossbarCfg.getString("style", "PROGRESS") : "PROGRESS";
        BossBar.Color color;
        BossBar.Overlay style;
        try {
            color = BossBar.Color.valueOf(colorName.toUpperCase());
        } catch (IllegalArgumentException e) {
            color = BossBar.Color.PINK;
        }
        try {
            style = BossBar.Overlay.valueOf(styleName.toUpperCase());
        } catch (IllegalArgumentException e) {
            style = BossBar.Overlay.PROGRESS;
        }
        return BossBar.bossBar(Component.empty(), 1.0f, color, style);
    }

    private void updateBossbarTask() {
        if (bossbarTask != null) {
            bossbarTask.cancel();
            bossbarTask = null;
        }
        if (activeBossBars.isEmpty()) {
            return;
        }
        bossbarTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            long now = System.currentTimeMillis();
            for (Map.Entry<String, ActiveBossBar> entry : activeBossBars.entrySet()) {
                ActiveBossBar abb = entry.getValue();
                if (abb.bar() == null) continue;
                long remaining = Math.max(0L, abb.endTime() - now);
                float progress = Math.min(1.0f, Math.max(0.0f, (float) remaining / (abb.totalDuration() * 1000f)));
                abb.bar().progress(progress);
                abb.bar().name(TextUtil.parse(
                        "<gradient:#FFD700:#FFA500><bold>" + displayName(entry.getKey()) + "</bold></gradient>"
                                + " <gray>|</gray> <white>" + formatTime(remaining) + "</white>"
                                + " <gray>|</gray> <yellow>" + Math.round(progress * 100) + "%</yellow>"
                ));
                for (Player player : Bukkit.getOnlinePlayers()) {
                    player.showBossBar(abb.bar());
                }
            }
        }, 0L, 40L);
    }

    private String displayName(String eventId) {
        return switch (eventId.toLowerCase()) {
            case "2x_shards" -> String.format("%.1fx Shards", shardMultiplier);
            default -> eventId.replace("_", " ");
        };
    }

    private String formatTime(long millis) {
        long totalSecs = millis / 1000;
        long mins = totalSecs / 60;
        long secs = totalSecs % 60;
        return String.format("%02d:%02d", mins, secs);
    }

    private record ActiveBossBar(long endTime, long totalDuration, BossBar bar) {}
}