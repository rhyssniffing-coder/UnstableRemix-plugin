package lol.folium.unstable.kit;

import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.List;

public final class CoreAdminCommand extends SubCommand {

    private final KitManager kits;

    public CoreAdminCommand(KitManager kits) {
        this.kits = kits;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length < 2) {
            usage(player);
            return;
        }
        if (args[0].equalsIgnoreCase("kit")) {
            handleKit(player, args);
            return;
        }
        if (args[0].equalsIgnoreCase("killeffect")) {
            handleKillEffect(player, args);
            return;
        }
        usage(player);
    }

    private void handleKit(Player player, String[] args) {
        if (args[1].equalsIgnoreCase("create") && args.length >= 3) {
            kits.createKit(player, args[2]);
            player.sendMessage(TextUtil.parse("<green>Created kit <white>" + args[2] + "</white> from your inventory."));
            return;
        }
        if (args[1].equalsIgnoreCase("edit") && args.length >= 5) {
            String value = String.join(" ", java.util.Arrays.copyOfRange(args, 4, args.length));
            try {
                if (kits.editKit(args[2], args[3], value)) {
                    player.sendMessage(TextUtil.parse("<green>Updated kit <white>" + args[2] + "</white>."));
                } else {
                    player.sendMessage(TextUtil.parse("<red>Could not edit that kit/field."));
                }
            } catch (RuntimeException ex) {
                player.sendMessage(TextUtil.parse("<red>Invalid value."));
            }
            return;
        }
        usage(player);
    }

    private void handleKillEffect(Player player, String[] args) {
        if (args.length >= 5 && args[1].equalsIgnoreCase("edit") && args[3].equalsIgnoreCase("price")) {
            try {
                if (kits.editKillEffectPrice(args[2], Long.parseLong(args[4]))) {
                    player.sendMessage(TextUtil.parse("<green>Updated kill effect price."));
                } else {
                    player.sendMessage(TextUtil.parse("<red>Unknown kill effect."));
                }
            } catch (NumberFormatException ex) {
                player.sendMessage(TextUtil.parse("<red>Invalid price."));
            }
            return;
        }
        usage(player);
    }

    private void usage(Player player) {
        player.sendMessage(TextUtil.parse("<yellow>/coreadmin kit create <id>"));
        player.sendMessage(TextUtil.parse("<yellow>/coreadmin kit edit <id> <price|displayname|material|slot|luckperms-rank|required-group|tier> <value>"));
        player.sendMessage(TextUtil.parse("<yellow>/coreadmin killeffect edit <id> price <amount>"));
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) return List.of("kit", "killeffect");
        if (args.length == 2 && args[0].equalsIgnoreCase("kit")) return List.of("create", "edit");
        if (args.length == 2 && args[0].equalsIgnoreCase("killeffect")) return List.of("edit");
        if (args.length == 3 && args[0].equalsIgnoreCase("kit") && args[1].equalsIgnoreCase("edit")) return kits.kitIds();
        if (args.length == 3 && args[0].equalsIgnoreCase("killeffect")) return kits.killEffectIds();
        if (args.length == 4 && args[0].equalsIgnoreCase("kit") && args[1].equalsIgnoreCase("edit")) {
            return List.of("price", "displayname", "material", "slot", "luckperms-rank", "required-group", "tier");
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("killeffect")) return List.of("price");
        if (args.length == 5 && args[0].equalsIgnoreCase("kit") && args[3].equalsIgnoreCase("material")) {
            return java.util.Arrays.stream(Material.values()).map(Material::name).toList();
        }
        if (args.length == 5 && args[3].equalsIgnoreCase("price")) return List.of("1000", "2500", "5000");
        return List.of();
    }

    @Override
    protected String permission() {
        return "unstable.coreadmin";
    }
}
