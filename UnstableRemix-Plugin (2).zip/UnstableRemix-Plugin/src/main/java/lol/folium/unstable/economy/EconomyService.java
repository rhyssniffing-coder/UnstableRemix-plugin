package lol.folium.unstable.economy;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.data.PlayerDataStore;
import lol.folium.unstable.data.PlayerProfile;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class EconomyService {

    private static final int STRIPE_COUNT = 256;
    private final Object[] stripes = new Object[STRIPE_COUNT];

    private final UnstableRemixPlugin plugin;
    private final PlayerDataStore store;
    private final Map<UUID, Long> clickCooldown = new ConcurrentHashMap<>();

    public EconomyService(UnstableRemixPlugin plugin, PlayerDataStore store) {
        this.plugin = plugin;
        this.store = store;
        for (int i = 0; i < STRIPE_COUNT; i++) stripes[i] = new Object();
    }

    public long getShards(UUID uuid) {
        return store.get(uuid).shards();
    }

    public long getTokens(UUID uuid) {
        return store.get(uuid).tokens();
    }

    public boolean isClickReady(UUID uuid) {
        long cooldown = plugin.getConfig().getLong("economy.gui-click-cooldown-ms", 350L);
        long now = System.currentTimeMillis();
        Long last = clickCooldown.get(uuid);
        if (last != null && now - last < cooldown) {
            return false;
        }
        clickCooldown.put(uuid, now);
        return true;
    }

    public TransactionResult grantShards(UUID uuid, long amount, String source, String idempotencyKey) {
        if (amount <= 0) {
            return TransactionResult.fail("invalid-amount", getShards(uuid));
        }
        double multiplier = 1.0;
        StringBuilder flags = new StringBuilder();
        if (plugin.getMapVoteManager().isDoubleShardsActive()) {
            multiplier *= plugin.getMapVoteManager().getDoubleShardsMultiplier();
            flags.append(" MAPVOTE").append(String.format("%.1fX", plugin.getMapVoteManager().getDoubleShardsMultiplier()));
        }
        double eventMulti = plugin.getEventManager().getShardMultiplier();
        if (eventMulti > 1.0) {
            multiplier *= eventMulti;
            flags.append(" EVENT").append(String.format("%.1fX", eventMulti));
        }
        if (plugin.getKitCooldownManager().hasShardBoost(uuid)) {
            double boostMulti = plugin.getKitCooldownManager().getShardBoostMultiplier(uuid);
            multiplier *= boostMulti;
            flags.append(" BOOST").append(String.format("%.1fX", boostMulti));
        }
        if (plugin.getMediaRankManager() != null && plugin.getMediaRankManager().hasMediaRank(uuid)) {
            double mediaMulti = plugin.getMediaRankManager().getShardMultiplierValue();
            multiplier *= mediaMulti;
            flags.append(" MEDIA").append(String.format("%.1fX", mediaMulti));
        }
        if (multiplier > 1.0) {
            amount = Math.round(amount * multiplier);
        }
        synchronized (lock(uuid)) {
            if (idempotencyKey != null && !store.tryClaimIdempotency(idempotencyKey)) {
                return TransactionResult.fail("already-claimed", getShards(uuid));
            }
            PlayerProfile profile = store.get(uuid);
            profile.setShards(profile.shards() + amount);
            store.saveProfile(profile);
            log("GRANT SHARDS", uuid, amount, source + flags);
            return TransactionResult.ok(profile.shards());
        }
    }

    public TransactionResult removeShards(UUID uuid, long amount, String source) {
        if (amount <= 0) {
            return TransactionResult.fail("invalid-amount", getShards(uuid));
        }
        synchronized (lock(uuid)) {
            PlayerProfile profile = store.get(uuid);
            if (profile.shards() < amount) {
                return TransactionResult.fail("insufficient-shards", profile.shards());
            }
            profile.setShards(profile.shards() - amount);
            store.saveProfile(profile);
            log("REMOVE SHARDS", uuid, amount, source);
            return TransactionResult.ok(profile.shards());
        }
    }

    public TransactionResult setShards(UUID uuid, long amount, String source) {
        if (amount < 0) {
            return TransactionResult.fail("invalid-amount", getShards(uuid));
        }
        synchronized (lock(uuid)) {
            PlayerProfile profile = store.get(uuid);
            profile.setShards(amount);
            store.saveProfile(profile);
            log("SET SHARDS", uuid, amount, source);
            return TransactionResult.ok(profile.shards());
        }
    }

    public TransactionResult transferShards(UUID from, UUID to, long amount, String source) {
        if (amount <= 0 || from.equals(to)) {
            return TransactionResult.fail("invalid-amount", getShards(from));
        }
        UUID first = from.compareTo(to) <= 0 ? from : to;
        UUID second = first.equals(from) ? to : from;
        synchronized (lock(first)) {
            synchronized (lock(second)) {
                PlayerProfile sender = store.get(from);
                PlayerProfile receiver = store.get(to);
                if (sender.shards() < amount) {
                    return TransactionResult.fail("insufficient-shards", sender.shards());
                }
                if (Long.MAX_VALUE - receiver.shards() < amount) {
                    return TransactionResult.fail("invalid-amount", sender.shards());
                }
                sender.setShards(sender.shards() - amount);
                receiver.setShards(receiver.shards() + amount);
                store.saveProfile(sender);
                store.saveProfile(receiver);
                log("TRANSFER SHARDS", from, amount, source + " to=" + to);
                return TransactionResult.ok(sender.shards());
            }
        }
    }

    public TransactionResult grantTokens(UUID uuid, long amount, String source, String idempotencyKey) {
        if (amount <= 0) {
            return TransactionResult.fail("invalid-amount", getTokens(uuid));
        }
        synchronized (lock(uuid)) {
            if (idempotencyKey != null && !store.tryClaimIdempotency(idempotencyKey)) {
                return TransactionResult.fail("already-claimed", getTokens(uuid));
            }
            PlayerProfile profile = store.get(uuid);
            profile.setTokens(profile.tokens() + amount);
            store.saveProfile(profile);
            log("GRANT TOKENS", uuid, amount, source);
            return TransactionResult.ok(profile.tokens());
        }
    }

    public TransactionResult spendShards(UUID uuid, long amount, String source) {
        if (amount <= 0) {
            return TransactionResult.fail("invalid-amount", getShards(uuid));
        }
        synchronized (lock(uuid)) {
            PlayerProfile profile = store.get(uuid);
            if (profile.shards() < amount) {
                return TransactionResult.fail("insufficient-shards", profile.shards());
            }
            profile.setShards(profile.shards() - amount);
            store.saveProfile(profile);
            log("SPEND SHARDS", uuid, amount, source);
            return TransactionResult.ok(profile.shards());
        }
    }

    public TransactionResult spendTokens(UUID uuid, long amount, String source) {
        if (amount <= 0) {
            return TransactionResult.fail("invalid-amount", getTokens(uuid));
        }
        synchronized (lock(uuid)) {
            PlayerProfile profile = store.get(uuid);
            if (profile.tokens() < amount) {
                return TransactionResult.fail("insufficient-tokens", profile.tokens());
            }
            profile.setTokens(profile.tokens() - amount);
            store.saveProfile(profile);
            log("SPEND TOKENS", uuid, amount, source);
            return TransactionResult.ok(profile.tokens());
        }
    }

    public TransactionResult removeTokens(UUID uuid, long amount, String source) {
        if (amount <= 0) {
            return TransactionResult.fail("invalid-amount", getTokens(uuid));
        }
        synchronized (lock(uuid)) {
            PlayerProfile profile = store.get(uuid);
            if (profile.tokens() < amount) {
                return TransactionResult.fail("insufficient-tokens", profile.tokens());
            }
            profile.setTokens(profile.tokens() - amount);
            store.saveProfile(profile);
            log("REMOVE TOKENS", uuid, amount, source);
            return TransactionResult.ok(profile.tokens());
        }
    }

    public TransactionResult setTokens(UUID uuid, long amount, String source) {
        if (amount < 0) {
            return TransactionResult.fail("invalid-amount", getTokens(uuid));
        }
        synchronized (lock(uuid)) {
            PlayerProfile profile = store.get(uuid);
            profile.setTokens(amount);
            store.saveProfile(profile);
            log("SET TOKENS", uuid, amount, source);
            return TransactionResult.ok(profile.tokens());
        }
    }

    public void notifyGrant(Player player, CurrencyType type, long amount, String source) {
        String path = type == CurrencyType.SHARDS ? "messages.reward-shards" : "messages.reward-tokens";
        player.sendMessage(TextUtil.parse(plugin.getConfig().getString(path, "")
                .replace("{amount}", String.valueOf(amount))
                .replace("{source}", source)));
    }

    public void notifyFailure(Player player, String messageKey, long needed) {
        String raw = plugin.getConfig().getString("messages." + messageKey, "<red>Transaction failed.");
        player.sendMessage(TextUtil.parse(raw.replace("{amount}", String.valueOf(needed))));
    }

    private Object lock(UUID uuid) {
        return stripes[Math.floorMod(uuid.hashCode(), STRIPE_COUNT)];
    }

    private void log(String action, UUID uuid, long amount, String source) {
        if (plugin.getConfig().getBoolean("economy.log-transactions", true)) {
            plugin.getLogger().info(action + " uuid=" + uuid + " amount=" + amount + " source=" + source);
        }
    }
}
