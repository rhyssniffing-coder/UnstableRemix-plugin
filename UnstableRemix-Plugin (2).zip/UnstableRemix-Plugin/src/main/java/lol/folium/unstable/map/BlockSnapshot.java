package lol.folium.unstable.map;

import org.bukkit.Material;
import org.bukkit.block.Block;

import java.util.Objects;

public record BlockSnapshot(String world, int x, int y, int z, Material original) {

    public static BlockSnapshot from(Block block) {
        return new BlockSnapshot(
                block.getWorld().getName(),
                block.getX(),
                block.getY(),
                block.getZ(),
                block.getType()
        );
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof BlockSnapshot other)) {
            return false;
        }
        return x == other.x && y == other.y && z == other.z && world.equals(other.world);
    }

    @Override
    public int hashCode() {
        return Objects.hash(world, x, y, z);
    }
}
