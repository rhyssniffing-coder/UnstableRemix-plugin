package lol.folium.unstable.rent;

import lol.folium.unstable.command.SubCommand;
import org.bukkit.entity.Player;

import java.util.List;

public final class RentRankCommand extends SubCommand {

    private final RentRankManager rentRank;

    public RentRankCommand(RentRankManager rentRank) {
        this.rentRank = rentRank;
    }

    @Override
    protected void execute(Player player, String[] args) {
        rentRank.openShop(player);
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        return List.of();
    }

    @Override
    protected String permission() {
        return null;
    }
}
