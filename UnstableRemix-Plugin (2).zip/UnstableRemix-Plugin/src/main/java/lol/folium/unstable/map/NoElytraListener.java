package lol.folium.unstable.map;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class NoElytraListener implements Listener {

    private final ArenaManager arenaManager;

    public NoElytraListener(ArenaManager arenaManager) {
        this.arenaManager = arenaManager;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onGlideToggle(EntityToggleGlideEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (event.isCancelled()) return;

        Arena arena = arenaManager.getArenaAt(player.getLocation());
        if (arena == null || !arena.noElytra()) return;

        // Allow if they're currently in a match (falling from respawn, etc.)
        // but block starting a new glide
        if (!event.isGliding()) {
            event.setCancelled(true);
            player.sendMessage(TextUtil.parse("<red>You cannot use elytras in the No-Elytra Arena!</red>"));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteract(PlayerInteractEvent event) {
        if (event.isCancelled()) return;
        Player player = event.getPlayer();
        if (event.getHand() != EquipmentSlot.HAND) return;

        Arena arena = arenaManager.getArenaAt(player.getLocation());
        if (arena == null || !arena.noElytra()) return;

        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType() == Material.ELYTRA) {
            event.setCancelled(true);
            player.sendMessage(TextUtil.parse("<red>You cannot use elytras in the No-Elytra Arena!</red>"));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.isCancelled()) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;

        Arena arena = arenaManager.getArenaAt(player.getLocation());
        if (arena == null || !arena.noElytra()) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked != null && clicked.getType() == Material.ELYTRA) {
            event.setCancelled(true);
            player.sendMessage(TextUtil.parse("<red>You cannot equip elytras in the No-Elytra Arena!</red>"));
        }
    }
}
