package lol.folium.unstable.map;

import com.sk89q.worldedit.IncompleteRegionException;
import com.sk89q.worldedit.LocalSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.bukkit.BukkitPlayer;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.Region;
import com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.BuiltInClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardWriter;
import com.sk89q.worldedit.function.operation.ForwardExtentCopy;
import com.sk89q.worldedit.session.ClipboardHolder;
import lol.folium.unstable.UnstableRemixPlugin;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Optional;

public final class WorldEditBridge {

    private final UnstableRemixPlugin plugin;
    private final boolean available;

    public WorldEditBridge(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
        this.available = plugin.getServer().getPluginManager().getPlugin("WorldEdit") != null
                || plugin.getServer().getPluginManager().getPlugin("FastAsyncWorldEdit") != null;
    }

    public boolean isAvailable() {
        return available;
    }

    public Optional<RegionSelection> getSelection(Player player) {
        if (!available) {
            return Optional.empty();
        }
        try {
            BukkitPlayer actor = BukkitAdapter.adapt(player);
            LocalSession session = WorldEdit.getInstance().getSessionManager().get(actor);
            Region region = session.getSelection(actor.getWorld());
            BlockVector3 min = region.getMinimumPoint();
            BlockVector3 max = region.getMaximumPoint();
            return Optional.of(new RegionSelection(
                    player.getWorld().getName(),
                    min.x(), min.y(), min.z(),
                    max.x(), max.y(), max.z()
            ));
        } catch (IncompleteRegionException ex) {
            return Optional.empty();
        }
    }

    public boolean saveSchematic(Player player, String arenaName, RegionSelection selection) {
        if (!available) {
            return false;
        }
        try {
            BukkitPlayer actor = BukkitAdapter.adapt(player);
            LocalSession session = WorldEdit.getInstance().getSessionManager().get(actor);
            Region region = session.getSelection(actor.getWorld());

            BlockArrayClipboard clipboard = new BlockArrayClipboard(region);
            ForwardExtentCopy copy = new ForwardExtentCopy(
                    actor.getWorld(),
                    region,
                    clipboard,
                    region.getMinimumPoint()
            );
            Operations.complete(copy);

            File dir = new File(plugin.getDataFolder(), plugin.getConfig().getString("map.schematic-folder", "schematics"));
            if (!dir.exists()) {
                dir.mkdirs();
            }
            File file = new File(dir, arenaName + ".schem");
            try (ClipboardWriter writer = BuiltInClipboardFormat.SPONGE_SCHEMATIC.getWriter(new FileOutputStream(file))) {
                writer.write(clipboard);
            }
            return true;
        } catch (Exception ex) {
            plugin.getLogger().severe("Failed saving schematic for " + arenaName + ": " + ex.getMessage());
            return false;
        }
    }

    public boolean pasteSchematic(String arenaName, Location location) {
        if (!available) return false;
        File dir = new File(plugin.getDataFolder(), plugin.getConfig().getString("map.schematic-folder", "schematics"));
        File file = new File(dir, arenaName + ".schem");
        if (!file.exists()) return false;
        try {
            Clipboard clipboard;
            try (ClipboardReader reader = BuiltInClipboardFormat.SPONGE_SCHEMATIC.getReader(new FileInputStream(file))) {
                clipboard = reader.read();
            }
            var actor = BukkitAdapter.adapt(location.getWorld());
            try (var editSession = WorldEdit.getInstance().newEditSession(actor)) {
                var builder = new ClipboardHolder(clipboard).createPaste(editSession)
                        .to(BlockVector3.at(location.getBlockX(), location.getBlockY(), location.getBlockZ()))
                        .ignoreAirBlocks(false)
                        .build();
                Operations.complete(builder);
            }
            return true;
        } catch (Exception ex) {
            plugin.getLogger().severe("Failed pasting schematic for " + arenaName + ": " + ex.getMessage());
            return false;
        }
    }

    public boolean hasSchematic(String arenaName) {
        File dir = new File(plugin.getDataFolder(), plugin.getConfig().getString("map.schematic-folder", "schematics"));
        return new File(dir, arenaName + ".schem").exists();
    }

    public boolean placeBarriers(org.bukkit.World world, RegionSelection selection, int heightBuffer) {
        if (!available) return false;
        try {
            com.sk89q.worldedit.world.World weWorld = BukkitAdapter.adapt(world);
            BlockVector3 min = BlockVector3.at(selection.minX() - 1, selection.minY() - 1, selection.minZ() - 1);
            BlockVector3 max = BlockVector3.at(selection.maxX() + 1, selection.maxY() + heightBuffer, selection.maxZ() + 1);

            try (var editSession = WorldEdit.getInstance().newEditSession(weWorld)) {
                com.sk89q.worldedit.world.block.BlockState barrier = com.sk89q.worldedit.world.block.BlockTypes.BARRIER.getDefaultState();

                for (int x = min.x(); x <= max.x(); x++) {
                    for (int z = min.z(); z <= max.z(); z++) {
                        editSession.setBlock(BlockVector3.at(x, min.y(), z), barrier);
                        editSession.setBlock(BlockVector3.at(x, max.y(), z), barrier);
                    }
                }
                for (int x = min.x(); x <= max.x(); x++) {
                    for (int y = min.y(); y <= max.y(); y++) {
                        editSession.setBlock(BlockVector3.at(x, y, min.z()), barrier);
                        editSession.setBlock(BlockVector3.at(x, y, max.z()), barrier);
                    }
                }
                for (int z = min.z(); z <= max.z(); z++) {
                    for (int y = min.y(); y <= max.y(); y++) {
                        editSession.setBlock(BlockVector3.at(min.x(), y, z), barrier);
                        editSession.setBlock(BlockVector3.at(max.x(), y, z), barrier);
                    }
                }
            }
            return true;
        } catch (Exception ex) {
            plugin.getLogger().warning("Failed to place barriers: " + ex.getMessage());
            return false;
        }
    }

    public boolean removeBarriers(org.bukkit.World world, RegionSelection selection, int heightBuffer) {
        if (!available) return false;
        try {
            com.sk89q.worldedit.world.World weWorld = BukkitAdapter.adapt(world);
            BlockVector3 min = BlockVector3.at(selection.minX() - 1, selection.minY() - 1, selection.minZ() - 1);
            BlockVector3 max = BlockVector3.at(selection.maxX() + 1, selection.maxY() + heightBuffer, selection.maxZ() + 1);

            try (var editSession = WorldEdit.getInstance().newEditSession(weWorld)) {
                com.sk89q.worldedit.world.block.BlockState air = com.sk89q.worldedit.world.block.BlockTypes.AIR.getDefaultState();

                for (int x = min.x(); x <= max.x(); x++) {
                    for (int z = min.z(); z <= max.z(); z++) {
                        if (editSession.getBlock(BlockVector3.at(x, min.y(), z)).getBlockType().equals(com.sk89q.worldedit.world.block.BlockTypes.BARRIER)) {
                            editSession.setBlock(BlockVector3.at(x, min.y(), z), air);
                        }
                        if (editSession.getBlock(BlockVector3.at(x, max.y(), z)).getBlockType().equals(com.sk89q.worldedit.world.block.BlockTypes.BARRIER)) {
                            editSession.setBlock(BlockVector3.at(x, max.y(), z), air);
                        }
                    }
                }
                for (int x = min.x(); x <= max.x(); x++) {
                    for (int y = min.y(); y <= max.y(); y++) {
                        if (editSession.getBlock(BlockVector3.at(x, y, min.z())).getBlockType().equals(com.sk89q.worldedit.world.block.BlockTypes.BARRIER)) {
                            editSession.setBlock(BlockVector3.at(x, y, min.z()), air);
                        }
                        if (editSession.getBlock(BlockVector3.at(x, y, max.z())).getBlockType().equals(com.sk89q.worldedit.world.block.BlockTypes.BARRIER)) {
                            editSession.setBlock(BlockVector3.at(x, y, max.z()), air);
                        }
                    }
                }
                for (int z = min.z(); z <= max.z(); z++) {
                    for (int y = min.y(); y <= max.y(); y++) {
                        if (editSession.getBlock(BlockVector3.at(min.x(), y, z)).getBlockType().equals(com.sk89q.worldedit.world.block.BlockTypes.BARRIER)) {
                            editSession.setBlock(BlockVector3.at(min.x(), y, z), air);
                        }
                        if (editSession.getBlock(BlockVector3.at(max.x(), y, z)).getBlockType().equals(com.sk89q.worldedit.world.block.BlockTypes.BARRIER)) {
                            editSession.setBlock(BlockVector3.at(max.x(), y, z), air);
                        }
                    }
                }
            }
            return true;
        } catch (Exception ex) {
            plugin.getLogger().warning("Failed to remove barriers: " + ex.getMessage());
            return false;
        }
    }

    public boolean deleteSchematic(String arenaName) {
        File dir = new File(plugin.getDataFolder(), plugin.getConfig().getString("map.schematic-folder", "schematics"));
        return new File(dir, arenaName + ".schem").delete();
    }

    public File schematicFile(String arenaName) {
        File dir = new File(plugin.getDataFolder(), plugin.getConfig().getString("map.schematic-folder", "schematics"));
        return new File(dir, arenaName + ".schem");
    }

    public record RegionSelection(String world, int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {}
}
