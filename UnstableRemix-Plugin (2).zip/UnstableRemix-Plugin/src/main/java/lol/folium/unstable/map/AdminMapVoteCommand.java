package lol.folium.unstable.map;

import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.stream.Collectors;

public final class AdminMapVoteCommand extends SubCommand {

    private final MapVoteManager mapVoteManager;
    private final ArenaManager arenaManager;

    public AdminMapVoteCommand(MapVoteManager mapVoteManager, ArenaManager arenaManager) {
        this.mapVoteManager = mapVoteManager;
        this.arenaManager = arenaManager;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length == 0) {
            showHelp(player);
            return;
        }
        switch (args[0].toLowerCase()) {
            case "add" -> handleAdd(player, args);
            case "remove" -> handleRemove(player, args);
            case "list" -> handleList(player);
            case "start" -> handleStart(player);
            case "force" -> handleForce(player, args);
            case "setmaterial" -> handleSetMaterial(player, args);
            case "setdisplayname" -> handleSetDisplayName(player, args);
            case "setarena" -> handleSetArena(player, args);
            default -> player.sendMessage(TextUtil.parse("<red>Unknown subcommand."));
        }
    }

    private void showHelp(Player player) {
        player.sendMessage(TextUtil.parse("<gold><bold>Admin Map Vote Commands:</bold></gold>"));
        player.sendMessage(TextUtil.parse("<yellow>/adminmapvote add <id> <arena> <display_name> [material]</yellow> <dark_gray>-</dark_gray> <gray>Add vote option</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/adminmapvote remove <id></yellow> <dark_gray>-</dark_gray> <gray>Remove vote option</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/adminmapvote list</yellow> <dark_gray>-</dark_gray> <gray>List all vote options</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/adminmapvote setmaterial <id></yellow> <dark_gray>-</dark_gray> <gray>Set material from item in hand</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/adminmapvote setdisplayname <id> <name...></yellow> <dark_gray>-</dark_gray> <gray>Set display name</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/adminmapvote setarena <id> <arena></yellow> <dark_gray>-</dark_gray> <gray>Set linked arena</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/adminmapvote start</yellow> <dark_gray>-</dark_gray> <gray>Start vote now</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/adminmapvote force <arena></yellow> <dark_gray>-</dark_gray> <gray>Force map change</gray>"));
    }

    private void handleAdd(Player player, String[] args) {
        if (args.length < 4) {
            player.sendMessage(TextUtil.parse("<red>Usage: /adminmapvote add <id> <arena> <display_name> [material]"));
            return;
        }
        String id = args[1].toLowerCase();
        String arenaName = args[2].toLowerCase();
        String displayName = args[3];
        Material material = Material.GRASS_BLOCK;

        if (args.length >= 5) {
            material = parseMaterial(player, args[4]);
        }

        if (!arenaManager.exists(arenaName)) {
            player.sendMessage(TextUtil.parse("<red>Arena not found: " + arenaName));
            return;
        }

        if (mapVoteManager.getVoteOptions().containsKey(id)) {
            player.sendMessage(TextUtil.parse("<red>Vote option already exists: " + id));
            return;
        }

        mapVoteManager.addVoteOption(id, arenaName, displayName, material);
        player.sendMessage(TextUtil.parse("<green>Added vote option <white>" + id + "</white> for arena <white>" + arenaName + "</white>."));
    }

    private void handleRemove(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /adminmapvote remove <id>"));
            return;
        }
        String id = args[1].toLowerCase();
        if (!mapVoteManager.getVoteOptions().containsKey(id)) {
            player.sendMessage(TextUtil.parse("<red>Vote option not found: " + id));
            return;
        }
        mapVoteManager.removeVoteOption(id);
        player.sendMessage(TextUtil.parse("<green>Removed vote option <white>" + id + "</white>."));
    }

    private void handleList(Player player) {
        if (mapVoteManager.getVoteOptions().isEmpty()) {
            player.sendMessage(TextUtil.parse("<gray>No vote options configured."));
            return;
        }
        player.sendMessage(TextUtil.parse("<aqua><bold>Map Vote Options</bold></aqua>"));
        for (MapVoteManager.MapVoteOption option : mapVoteManager.getVoteOptions().values()) {
            player.sendMessage(TextUtil.parse(
                "<gray>- <white>" + option.id() + "</white>: <yellow>" + option.displayName() +
                "</yellow> <dark_gray>|</dark_gray> Arena: <white>" + option.arenaName() +
                "</white> <dark_gray>|</dark_gray> Material: <white>" + option.material().name() + "</white>"
            ));
        }
    }

    private void handleStart(Player player) {
        if (mapVoteManager.isVotingActive()) {
            player.sendMessage(TextUtil.parse("<red>A vote is already active."));
            return;
        }
        mapVoteManager.startVoting();
        player.sendMessage(TextUtil.parse("<green>Map vote started."));
    }

    private void handleForce(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /adminmapvote force <arena>"));
            return;
        }
        String arenaName = args[1].toLowerCase();
        if (!arenaManager.exists(arenaName)) {
            player.sendMessage(TextUtil.parse("<red>Arena not found: " + arenaName));
            return;
        }
        mapVoteManager.forceMapChange(arenaName);
        player.sendMessage(TextUtil.parse("<green>Forced map change to <white>" + arenaName + "</white>."));
    }

    private void handleSetMaterial(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /adminmapvote setmaterial <id>"));
            return;
        }
        String id = args[1].toLowerCase();
        if (!mapVoteManager.getVoteOptions().containsKey(id)) {
            player.sendMessage(TextUtil.parse("<red>Vote option not found: " + id));
            return;
        }
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType() == Material.AIR) {
            player.sendMessage(TextUtil.parse("<red>Hold an item in your main hand to set as material."));
            return;
        }
        mapVoteManager.updateVoteOptionMaterial(id, hand.getType());
        player.sendMessage(TextUtil.parse("<green>Set material for <white>" + id + "</white> to <white>" + hand.getType().name() + "</white>."));
    }

    private void handleSetDisplayName(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(TextUtil.parse("<red>Usage: /adminmapvote setdisplayname <id> <name...>"));
            return;
        }
        String id = args[1].toLowerCase();
        if (!mapVoteManager.getVoteOptions().containsKey(id)) {
            player.sendMessage(TextUtil.parse("<red>Vote option not found: " + id));
            return;
        }
        String name = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
        mapVoteManager.updateVoteOptionDisplayName(id, name);
        player.sendMessage(TextUtil.parse("<green>Set display name for <white>" + id + "</white> to <white>" + name + "</white>."));
    }

    private void handleSetArena(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(TextUtil.parse("<red>Usage: /adminmapvote setarena <id> <arena>"));
            return;
        }
        String id = args[1].toLowerCase();
        if (!mapVoteManager.getVoteOptions().containsKey(id)) {
            player.sendMessage(TextUtil.parse("<red>Vote option not found: " + id));
            return;
        }
        String arenaName = args[2].toLowerCase();
        if (!arenaManager.exists(arenaName)) {
            player.sendMessage(TextUtil.parse("<red>Arena not found: " + arenaName));
            return;
        }
        mapVoteManager.updateVoteOptionArena(id, arenaName);
        player.sendMessage(TextUtil.parse("<green>Set arena for <white>" + id + "</white> to <white>" + arenaName + "</white>."));
    }

    private Material parseMaterial(Player player, String input) {
        try {
            Material material = Material.matchMaterial(input.toUpperCase());
            if (material == null) {
                player.sendMessage(TextUtil.parse("<red>Invalid material. Using GRASS_BLOCK."));
                return Material.GRASS_BLOCK;
            }
            return material;
        } catch (Exception ex) {
            player.sendMessage(TextUtil.parse("<red>Invalid material. Using GRASS_BLOCK."));
            return Material.GRASS_BLOCK;
        }
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            return filter(literals("add", "remove", "list", "start", "force", "setmaterial", "setdisplayname", "setarena"), args[0]);
        }
        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if (List.of("remove", "setmaterial", "setdisplayname", "setarena").contains(sub)) {
                return filter(mapVoteManager.getVoteOptions().keySet().stream().toList(), args[1]);
            }
            if (sub.equals("force")) {
                return filter(arenaManager.names(), args[1]);
            }
        }
        if (args.length == 3) {
            String sub = args[0].toLowerCase();
            if (sub.equals("add")) {
                return filter(arenaManager.names(), args[2]);
            }
            if (sub.equals("setarena")) {
                return filter(arenaManager.names(), args[2]);
            }
        }
        if (args.length == 5 && args[0].equalsIgnoreCase("add")) {
            return filter(getMaterialNames(), args[4]);
        }
        return List.of();
    }

    private List<String> getMaterialNames() {
        return List.of(Material.values()).stream()
            .map(Material::name)
            .collect(Collectors.toList());
    }

    @Override
    protected String permission() {
        return "unstable.mapvote.admin";
    }
}
