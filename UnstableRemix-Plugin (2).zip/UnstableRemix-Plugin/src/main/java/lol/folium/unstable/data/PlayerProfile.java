package lol.folium.unstable.data;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PlayerProfile {

    private final UUID uuid;
    private long shards;
    private long tokens;
    private final Set<String> unlockedEffects = ConcurrentHashMap.newKeySet();
    private final Set<String> enabledEffects = ConcurrentHashMap.newKeySet();
    private final Set<String> claimedTokenRanks = ConcurrentHashMap.newKeySet();
    private final Set<String> claimedQuests = ConcurrentHashMap.newKeySet();
    private int dailyRerolls;
    private int weeklyRerolls;
    private int monthlyRerolls;
    private int milestoneRerolls;
    private long lifetimeKills;
    private long lifetimeTrackdowns;
    private long matchWins;
    private int prestigeRank;
    private long totalShardsEarned;
    private int loginStreak;
    private String lastLoginDate;
    private int vaultTier;
    private long deaths;
    private long highestKillstreak;
    private long playtime;
    private long lastSeen;
    private boolean socialFollowClaimed;
    private boolean socialDiscordClaimed;

    public PlayerProfile(UUID uuid) {
        this.uuid = uuid;
    }

    public UUID uuid() {
        return uuid;
    }

    public long shards() {
        return shards;
    }

    public void setShards(long shards) {
        this.shards = Math.max(0, shards);
    }

    public long tokens() {
        return tokens;
    }

    public void setTokens(long tokens) {
        this.tokens = Math.max(0, tokens);
    }

    public Set<String> unlockedEffects() {
        return unlockedEffects;
    }

    public Set<String> enabledEffects() {
        return enabledEffects;
    }

    public Set<String> claimedTokenRanks() {
        return claimedTokenRanks;
    }

    public Set<String> claimedQuests() {
        return claimedQuests;
    }

    public int dailyRerolls() {
        return dailyRerolls;
    }

    public void setDailyRerolls(int dailyRerolls) {
        this.dailyRerolls = dailyRerolls;
    }

    public int weeklyRerolls() {
        return weeklyRerolls;
    }

    public void setWeeklyRerolls(int weeklyRerolls) {
        this.weeklyRerolls = weeklyRerolls;
    }

    public int monthlyRerolls() {
        return monthlyRerolls;
    }

    public void setMonthlyRerolls(int monthlyRerolls) {
        this.monthlyRerolls = monthlyRerolls;
    }

    public int milestoneRerolls() {
        return milestoneRerolls;
    }

    public void setMilestoneRerolls(int milestoneRerolls) {
        this.milestoneRerolls = milestoneRerolls;
    }

    public long lifetimeKills() {
        return lifetimeKills;
    }

    public void setLifetimeKills(long lifetimeKills) {
        this.lifetimeKills = Math.max(0, lifetimeKills);
    }

    public long lifetimeTrackdowns() {
        return lifetimeTrackdowns;
    }

    public void setLifetimeTrackdowns(long lifetimeTrackdowns) {
        this.lifetimeTrackdowns = Math.max(0, lifetimeTrackdowns);
    }

    public long matchWins() {
        return matchWins;
    }

    public void setMatchWins(long matchWins) {
        this.matchWins = Math.max(0, matchWins);
    }

    public int prestigeRank() {
        return prestigeRank;
    }

    public void setPrestigeRank(int prestigeRank) {
        this.prestigeRank = prestigeRank;
    }

    public long totalShardsEarned() {
        return totalShardsEarned;
    }

    public void setTotalShardsEarned(long totalShardsEarned) {
        this.totalShardsEarned = totalShardsEarned;
    }

    public int loginStreak() {
        return loginStreak;
    }

    public void setLoginStreak(int loginStreak) {
        this.loginStreak = loginStreak;
    }

    public String lastLoginDate() {
        return lastLoginDate;
    }

    public void setLastLoginDate(String lastLoginDate) {
        this.lastLoginDate = lastLoginDate;
    }

    public int vaultTier() {
        return vaultTier;
    }

    public void setVaultTier(int vaultTier) {
        this.vaultTier = vaultTier;
    }

    public long deaths() {
        return deaths;
    }

    public void setDeaths(long deaths) {
        this.deaths = Math.max(0, deaths);
    }

    public long highestKillstreak() {
        return highestKillstreak;
    }

    public void setHighestKillstreak(long highestKillstreak) {
        this.highestKillstreak = Math.max(0, highestKillstreak);
    }

    public long playtime() {
        return playtime;
    }

    public void setPlaytime(long playtime) {
        this.playtime = Math.max(0, playtime);
    }

    public long lastSeen() {
        return lastSeen;
    }

    public void setLastSeen(long lastSeen) {
        this.lastSeen = lastSeen;
    }

    public boolean socialFollowClaimed() {
        return socialFollowClaimed;
    }

    public void setSocialFollowClaimed(boolean claimed) {
        this.socialFollowClaimed = claimed;
    }

    public boolean socialDiscordClaimed() {
        return socialDiscordClaimed;
    }

    public void setSocialDiscordClaimed(boolean claimed) {
        this.socialDiscordClaimed = claimed;
    }
}
