package lol.folium.unstable.civ;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.util.GuiTheme;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class CivListener implements Listener {

    private final CivCommand civCommand;
    private final EconomyService economy;
    private final Map<UUID, Integer> civListPages = new HashMap<>();

    private static final int CIVS_PER_PAGE = 35;
    private static final int PREV_SLOT = 45;
    private static final int NEXT_SLOT = 53;

    public CivListener(CivCommand civCommand, EconomyService economy) {
        this.civCommand = civCommand;
        this.economy = economy;
    }

    private Component parse(String text) {
        return TextUtil.parse(text);
    }

    private ItemStack pane(Material mat) {
        return ItemBuilder.of(mat).name(Component.empty()).build();
    }

    private String guiTitle(String suffix) {
        return TextUtil.parse(GuiTheme.primary(suffix)).toString();
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;
        String title = e.getView().getTitle();
        if (title == null) return;

        if (title.equals(guiTitle("CIVILIZATIONS"))) {
            e.setCancelled(true);
            handleMainMenu(player, e.getRawSlot());
        } else if (title.startsWith("SETUP:")) {
            e.setCancelled(true);
            handlePrefixSetup(player, e.getRawSlot());
        } else if (title.contains("VAULT")) {
            handleVaultInteraction(e, player, title);
        } else if (title.equals(guiTitle("TODO LIST")) ||
                   title.equals(guiTitle("TARGETS")) ||
                   title.equals(guiTitle("MEMBERS")) ||
                   title.equals(guiTitle("INVITES")) ||
                   title.equals(guiTitle("CIV LIST")) ||
                   title.equals(guiTitle("DEPOSIT SHARDS")) ||
                   title.equals(guiTitle("WITHDRAW SHARDS"))) {
            e.setCancelled(true);
            if (title.equals(guiTitle("CIV LIST"))) {
                handleCivListClick(player, e.getRawSlot());
            }
        }
    }

    private void handleMainMenu(Player player, int slot) {
        Civilization civ = CivManager.getInstance().getPlayerCiv(player.getUniqueId());

        if (civ != null) {
            switch (slot) {
                case 20 -> openVault(player, civ);
                case 22 -> openTodoList(player, civ);
                case 24 -> openTargets(player, civ);
                case 29 -> openMembers(player, civ);
                case 31 -> {
                    if (civ.isOwner(player.getUniqueId())) openInvites(player, civ);
                }
                case 33 -> openDepositGUI(player, civ);
                case 35 -> {
                    if (civ.isOwner(player.getUniqueId())) openWithdrawGUI(player, civ);
                }
                case 49 -> {
                    player.closeInventory();
                    player.performCommand("civ leave");
                }
            }
        } else {
            switch (slot) {
                case 20 -> {
                    player.closeInventory();
                    player.sendMessage(parse("&7Type &f/civ create <name> &7to create a civilization!"));
                }
                case 24 -> openCivList(player);
            }
        }
    }

    private void handleCivListClick(Player player, int slot) {
        Integer currentPage = civListPages.getOrDefault(player.getUniqueId(), 0);
        if (slot == PREV_SLOT) {
            openCivList(player, currentPage - 1);
        } else if (slot == NEXT_SLOT) {
            openCivList(player, currentPage + 1);
        }
    }

    private void handlePrefixSetup(Player player, int slot) {
        CivCommand.PendingCivSetup setup = civCommand.getPendingSetup(player.getUniqueId());
        if (setup == null) return;

        int[] colorSlots = {10, 11, 12, 13, 14, 19, 20, 21, 22, 23, 24};
        for (int i = 0; i < colorSlots.length; i++) {
            if (slot == colorSlots[i]) {
                List<String> colorKeys = new ArrayList<>(CivManager.getInstance().getPresetColors().keySet());
                if (i < colorKeys.size()) {
                    String colorName = colorKeys.get(i);
                    String colorCode = CivManager.getInstance().getPresetColors().get(colorName);
                    civCommand.pendingColorSelection.put(player.getUniqueId(), colorCode);
                    player.closeInventory();
                    civCommand.pendingPrefixInput.put(player.getUniqueId(), setup.civName());
                    player.sendMessage(parse("&7Type your prefix in chat (" + CivManager.getInstance().getMaxPrefixLength() + " chars max):"));
                    player.sendMessage(parse("&7Selected color: " + colorName));
                }
                return;
            }
        }

        if (slot == 25) {
            civCommand.pendingColorSelection.put(player.getUniqueId(), "gradient");
            player.closeInventory();
            civCommand.pendingPrefixInput.put(player.getUniqueId(), setup.civName());
            player.sendMessage(parse("&7Type your prefix in chat (" + CivManager.getInstance().getMaxPrefixLength() + " chars max):"));
            player.sendMessage(parse("&7Selected: &6GRADIENT &7(+" + CivManager.getInstance().getGradientCost() + " shards)"));
        }
    }

    private void openVault(Player player, Civilization civ) {
        Inventory vault = CivVault.getInstance().getVault(civ);
        player.openInventory(vault);
    }

    private void handleVaultInteraction(InventoryClickEvent e, Player player, String title) {
        Civilization civ = CivManager.getInstance().getPlayerCiv(player.getUniqueId());
        if (civ == null || !title.contains(civ.getName())) {
            e.setCancelled(true);
            return;
        }
        Bukkit.getScheduler().runTaskLater(UnstableRemixPlugin.getInstance(),
                () -> CivVault.getInstance().saveVault(civ.getId()), 5L);
    }

    private void openTodoList(Player player, Civilization civ) {
        Inventory inv = Bukkit.createInventory(null, 45, parse(GuiTheme.primary("TODO LIST")));
        for (int i = 0; i < 45; i++) inv.setItem(i, pane(Material.BLACK_STAINED_GLASS_PANE));
        for (int i = 0; i < 9; i++) { inv.setItem(i, pane(Material.PURPLE_STAINED_GLASS_PANE)); inv.setItem(36 + i, pane(Material.PURPLE_STAINED_GLASS_PANE)); }

        inv.setItem(4, ItemBuilder.of(Material.PAPER).name(parse(GuiTheme.secondary("&e&l" + civ.getName() + " TODO"))).lore(List.of(parse(""), parse("&7Items: &f" + civ.getTodoList().size()))).build());

        int slot = 10;
        for (String todo : civ.getTodoList()) {
            if (slot >= 36) break;
            inv.setItem(slot++, ItemBuilder.of(Material.PAPER).name(parse(GuiTheme.primary("&f" + todo))).lore(List.of(parse(""), parse("&7Click to remove"))).build());
        }
        inv.setItem(40, ItemBuilder.of(Material.EMERALD).name(parse(GuiTheme.primary("&a&lADD TODO"))).lore(List.of(parse(""), parse("&7Click then type in chat"))).build());
        player.openInventory(inv);
    }

    private void openTargets(Player player, Civilization civ) {
        Inventory inv = Bukkit.createInventory(null, 45, parse(GuiTheme.primary("TARGETS")));
        for (int i = 0; i < 45; i++) inv.setItem(i, pane(Material.BLACK_STAINED_GLASS_PANE));
        for (int i = 0; i < 9; i++) { inv.setItem(i, pane(Material.PURPLE_STAINED_GLASS_PANE)); inv.setItem(36 + i, pane(Material.PURPLE_STAINED_GLASS_PANE)); }

        inv.setItem(4, ItemBuilder.of(Material.RED_BANNER).name(parse(GuiTheme.secondary("&c&lTARGETS"))).lore(List.of(parse(""), parse("&7Civs your civ is targeting"))).build());

        int slot = 10;
        for (String target : civ.getTargets()) {
            if (slot >= 36) break;
            inv.setItem(slot++, ItemBuilder.of(Material.RED_WOOL).name(parse(GuiTheme.primary("&c" + target))).lore(List.of(parse(""), parse("&7Click to remove"))).build());
        }
        inv.setItem(40, ItemBuilder.of(Material.PAPER).name(parse(GuiTheme.primary("&a&lADD TARGET"))).lore(List.of(parse(""), parse("&7Click then type in chat"))).build());
        player.openInventory(inv);
    }

    private void openMembers(Player player, Civilization civ) {
        Inventory inv = Bukkit.createInventory(null, 45, parse(GuiTheme.primary("MEMBERS")));
        for (int i = 0; i < 45; i++) inv.setItem(i, pane(Material.BLACK_STAINED_GLASS_PANE));
        for (int i = 0; i < 9; i++) { inv.setItem(i, pane(Material.PURPLE_STAINED_GLASS_PANE)); inv.setItem(36 + i, pane(Material.PURPLE_STAINED_GLASS_PANE)); }

        inv.setItem(4, ItemBuilder.of(Material.PLAYER_HEAD).name(parse(GuiTheme.secondary("&a&lMEMBERS"))).lore(List.of(parse(""), parse("&7Members: &f" + civ.getMembers().size()))).build());

        int slot = 10;
        for (UUID memberId : civ.getMembers()) {
            if (slot >= 36) break;
            OfflinePlayer member = Bukkit.getOfflinePlayer(memberId);
            String memberName = member.getName() != null ? member.getName() : "Unknown";
            inv.setItem(slot++, ItemBuilder.of(Material.PLAYER_HEAD).name(parse(GuiTheme.primary("&f" + memberName)))
                    .lore(List.of(parse(""), member.getUniqueId().equals(civ.getOwner()) ? parse("&6&lOWNER") : parse("&7MEMBER"))).build());
        }
        if (civ.isOwner(player.getUniqueId())) {
            inv.setItem(40, ItemBuilder.of(Material.WRITABLE_BOOK).name(parse(GuiTheme.primary("&a&lINVITE PLAYER"))).lore(List.of(parse(""), parse("&7Click then type player name in chat"))).build());
        }
        player.openInventory(inv);
    }

    private void openInvites(Player player, Civilization civ) {
        Inventory inv = Bukkit.createInventory(null, 45, parse(GuiTheme.primary("INVITES")));
        for (int i = 0; i < 45; i++) inv.setItem(i, pane(Material.BLACK_STAINED_GLASS_PANE));
        for (int i = 0; i < 9; i++) { inv.setItem(i, pane(Material.PURPLE_STAINED_GLASS_PANE)); inv.setItem(36 + i, pane(Material.PURPLE_STAINED_GLASS_PANE)); }

        inv.setItem(4, ItemBuilder.of(Material.WRITABLE_BOOK).name(parse(GuiTheme.secondary("&6&lINVITES"))).lore(List.of(parse(""), parse("&7Pending invites: &f" + civ.getInvited().size()))).build());

        int slot = 10;
        for (UUID invitedId : civ.getInvited()) {
            if (slot >= 36) break;
            OfflinePlayer invited = Bukkit.getOfflinePlayer(invitedId);
            inv.setItem(slot++, ItemBuilder.of(Material.PLAYER_HEAD).name(parse(GuiTheme.primary("&f" + (invited.getName() != null ? invited.getName() : "Unknown"))))
                    .lore(List.of(parse(""), parse("&7Click to revoke invite"))).build());
        }
        player.openInventory(inv);
    }

    private void openDepositGUI(Player player, Civilization civ) {
        Inventory inv = Bukkit.createInventory(null, 27, parse(GuiTheme.primary("DEPOSIT SHARDS")));
        for (int i = 0; i < 27; i++) inv.setItem(i, pane(Material.BLACK_STAINED_GLASS_PANE));

        inv.setItem(13, ItemBuilder.of(Material.GOLD_BLOCK).name(parse(GuiTheme.secondary("&6&lDEPOSIT SHARDS")))
                .lore(List.of(parse(""), parse("&7Your balance: &6" + economy.getShards(player.getUniqueId())), parse("&7Civ balance: &6" + civ.getBalance()), parse(""))).build());

        int[] amounts = {100, 500, 1000, 5000, 10000};
        int[] slots = {0, 1, 2, 3, 4};
        for (int i = 0; i < amounts.length; i++) {
            inv.setItem(slots[i], ItemBuilder.of(Material.GOLD_NUGGET).name(parse(GuiTheme.primary("&6" + amounts[i]))).lore(List.of(parse(""), parse("&7Click to deposit"))).build());
        }
        player.openInventory(inv);
    }

    private void openWithdrawGUI(Player player, Civilization civ) {
        Inventory inv = Bukkit.createInventory(null, 27, parse(GuiTheme.primary("WITHDRAW SHARDS")));
        for (int i = 0; i < 27; i++) inv.setItem(i, pane(Material.BLACK_STAINED_GLASS_PANE));

        inv.setItem(13, ItemBuilder.of(Material.IRON_BLOCK).name(parse(GuiTheme.secondary("&f&lWITHDRAW SHARDS")))
                .lore(List.of(parse(""), parse("&7Civ balance: &6" + civ.getBalance()), parse(""))).build());

        int[] amounts = {100, 500, 1000, 5000, 10000};
        int[] slots = {0, 1, 2, 3, 4};
        for (int i = 0; i < amounts.length; i++) {
            inv.setItem(slots[i], ItemBuilder.of(Material.IRON_NUGGET).name(parse(GuiTheme.primary("&f" + amounts[i]))).lore(List.of(parse(""), parse("&7Click to withdraw"))).build());
        }
        player.openInventory(inv);
    }

    private void openCivList(Player player) {
        openCivList(player, 0);
    }

    private void openCivList(Player player, int page) {
        List<Civilization> allCivs = new ArrayList<>(CivManager.getInstance().getAllCivs());
        int totalPages = Math.max(1, (int) Math.ceil((double) allCivs.size() / CIVS_PER_PAGE));
        page = Math.max(0, Math.min(page, totalPages - 1));
        civListPages.put(player.getUniqueId(), page);

        Inventory inv = Bukkit.createInventory(null, 54, parse(GuiTheme.primary("CIV LIST")));
        for (int i = 0; i < 54; i++) inv.setItem(i, pane(Material.BLACK_STAINED_GLASS_PANE));
        for (int i = 0; i < 9; i++) { inv.setItem(i, pane(Material.PURPLE_STAINED_GLASS_PANE)); inv.setItem(45 + i, pane(Material.PURPLE_STAINED_GLASS_PANE)); }

        int start = page * CIVS_PER_PAGE;
        int end = Math.min(start + CIVS_PER_PAGE, allCivs.size());
        int slot = 10;
        for (int i = start; i < end; i++) {
            if (slot == 17) slot = 19;
            if (slot == 26) slot = 28;
            if (slot >= 45) break;
            Civilization civ = allCivs.get(i);
            inv.setItem(slot++, ItemBuilder.of(Material.BEACON).name(parse(GuiTheme.secondary("&b&l" + civ.getName())))
                    .lore(List.of(parse(""), parse("&7Prefix: " + civ.getFormattedPrefix()), parse("&7Members: &f" + civ.getMembers().size()), parse("&7Balance: &6" + civ.getBalance() + " shards"), parse(""))).build());
        }

        // Page info
        inv.setItem(49, ItemBuilder.of(Material.PAPER).name(parse(GuiTheme.primary("Page " + (page + 1) + " / " + totalPages)))
                .lore(List.of(parse(""), parse("&7Total civs: &f" + allCivs.size()), parse(""))).build());

        // Prev/Next arrows
        if (page > 0) {
            inv.setItem(PREV_SLOT, ItemBuilder.of(Material.ARROW).name(parse("<yellow><bold>Previous Page</bold></yellow>"))
                    .lore(List.of(parse(""), parse("&7Go to page " + page), parse(""))).build());
        }
        if (page < totalPages - 1) {
            inv.setItem(NEXT_SLOT, ItemBuilder.of(Material.ARROW).name(parse("<yellow><bold>Next Page</bold></yellow>"))
                    .lore(List.of(parse(""), parse("&7Go to page " + (page + 2)), parse(""))).build());
        }

        player.openInventory(inv);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTitle() == null) return;
        String title = e.getView().getTitle();
        if (title.equals(guiTitle("CIVILIZATIONS")) || title.startsWith("SETUP:") ||
            title.equals(guiTitle("TODO LIST")) || title.equals(guiTitle("TARGETS")) ||
            title.equals(guiTitle("MEMBERS")) || title.equals(guiTitle("INVITES")) ||
            title.equals(guiTitle("CIV LIST")) || title.contains("VAULT") ||
            title.equals(guiTitle("DEPOSIT SHARDS")) || title.equals(guiTitle("WITHDRAW SHARDS"))) {
            e.setCancelled(true);
        }
    }
}
