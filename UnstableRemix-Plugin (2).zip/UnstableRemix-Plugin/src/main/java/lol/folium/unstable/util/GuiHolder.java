package lol.folium.unstable.util;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public abstract class GuiHolder implements InventoryHolder {

    private Inventory inventory;

    public void bind(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public abstract void handleClick(org.bukkit.event.inventory.InventoryClickEvent event);

    public void handleClose(org.bukkit.event.inventory.InventoryCloseEvent event) {
    }
}
