package lol.folium.unstable.reward;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.data.PlayerDataStore;
import lol.folium.unstable.data.PlayerProfile;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class DailyRewardManager {

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final PlayerDataStore store;
    private final EconomyService economy;

    public DailyRewardManager(UnstableRemixPlugin plugin, ConfigManager configs,
                              PlayerDataStore store, EconomyService economy) {
        this.plugin = plugin;
        this.configs = configs;
        this.store = store;
        this.economy = economy;
    }

    public void processLogin(Player player) {
        ConfigurationSection cfg = plugin.getConfig().getConfigurationSection("daily-rewards");
        if (cfg == null || !cfg.getBoolean("enabled", true)) return;
        PlayerProfile profile = store.get(player.getUniqueId());
        String today = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
        String lastLogin = profile.lastLoginDate();
        if (today.equals(lastLogin)) return;
        if (lastLogin != null) {
            LocalDate last = LocalDate.parse(lastLogin);
            LocalDate yesterday = LocalDate.now().minusDays(1);
            if (last.equals(yesterday)) {
                profile.setLoginStreak(profile.loginStreak() + 1);
            } else {
                profile.setLoginStreak(1);
            }
        } else {
            profile.setLoginStreak(1);
        }
        profile.setLastLoginDate(today);
        int streak = profile.loginStreak();
        int maxStreak = cfg.getInt("max-streak", 30);
        int cappedStreak = Math.min(streak, maxStreak);
        long shards = cfg.getLong("rewards.shards.base", 10)
                + cappedStreak * cfg.getLong("rewards.shards.per-streak", 2);
        long tokens = cfg.getLong("rewards.tokens.base", 0)
                + cappedStreak * cfg.getLong("rewards.tokens.per-streak", 0) / 5;
        economy.grantShards(player.getUniqueId(), shards, "daily-streak:" + streak, null);
        if (tokens > 0) {
            economy.grantTokens(player.getUniqueId(), tokens, "daily-streak:" + streak, null);
        }
        String msg = cfg.getString("messages.claim",
                "<gradient:#FFD700:#FFAA00><bold>Daily Login!</bold></gradient> <gray>Day</gray> <white>{streak}</white> <gray>|</gray> <light_purple>+{shards} Shards</light_purple>{tokens_text}");
        player.sendMessage(TextUtil.parse(msg
                .replace("{streak}", String.valueOf(streak))
                .replace("{shards}", String.valueOf(shards))
                .replace("{tokens}", String.valueOf(tokens))
                .replace("{tokens_text}", tokens > 0 ? " <gold>+" + tokens + " Tokens</gold>" : "")));
        String broadcastMsg = cfg.getString("messages.milestone-broadcast", "");
        List<Integer> milestones = cfg.getIntegerList("milestone-broadcasts");
        if (!broadcastMsg.isEmpty() && milestones.contains(streak)) {
            Bukkit.broadcast(TextUtil.parse(broadcastMsg
                    .replace("{player}", player.getName())
                    .replace("{streak}", String.valueOf(streak))));
        }
        store.saveProfile(profile);
    }

    public void openGui(Player player) {
        ConfigurationSection cfg = plugin.getConfig().getConfigurationSection("daily-rewards");
        if (cfg == null) return;
        PlayerProfile profile = store.get(player.getUniqueId());
        int streak = profile.loginStreak();
        int maxStreak = cfg.getInt("max-streak", 30);
        int days = cfg.getInt("gui.days-visible", 7);
        int rows = cfg.getInt("gui.rows", 3);
        int startSlot = cfg.getInt("gui.start-slot", 10);
        String title = cfg.getString("gui.title", "<gradient:#FFD700:#FFAA00>Daily Rewards</gradient>");
        Inventory inventory = Bukkit.createInventory(null, rows * 9, TextUtil.parse(title));
        ItemStack filler = ItemBuilder.of(Material.matchMaterial(
                cfg.getString("gui.filler.material", "BLACK_STAINED_GLASS_PANE")))
                .name(TextUtil.parse(" "))
                .build();
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, filler);
        }
        Material streakMat = Material.matchMaterial(cfg.getString("gui.streak-indicator.material", "NETHER_STAR"));
        if (streakMat == null) streakMat = Material.NETHER_STAR;
        String streakName = cfg.getString("gui.streak-indicator.name",
                "<gradient:#FFD700:#FFAA00><bold>Day {day}</bold></gradient>");
        int streakSlot = cfg.getInt("gui.streak-indicator.slot", 4);
        inventory.setItem(streakSlot, ItemBuilder.of(streakMat)
                .name(TextUtil.parse(streakName.replace("{day}", String.valueOf(streak))))
                .lore(cfg.getStringList("gui.streak-indicator.lore").stream()
                        .map(l -> TextUtil.parse(l.replace("{streak}", String.valueOf(streak))
                                .replace("{max_streak}", String.valueOf(maxStreak))))
                        .toList())
                .build());
        for (int day = 0; day < days; day++) {
            int slot = startSlot + day;
            if (slot >= inventory.getSize()) break;
            int displayDay = day + 1;
            boolean claimed = displayDay <= streak;
            Material mat;
            String name;
            List<Component> lore = new ArrayList<>();
            ConfigurationSection dayCfg = cfg.getConfigurationSection("gui.day-template");
            if (claimed) {
                mat = Material.matchMaterial(cfg.getString("gui.claimed.material", "LIME_DYE"));
                if (mat == null) mat = Material.LIME_DYE;
                name = cfg.getString("gui.claimed.name", "<green><bold>Day {day}</bold></green>");
                for (String l : cfg.getStringList("gui.claimed.lore")) {
                    lore.add(TextUtil.parse(l.replace("{day}", String.valueOf(displayDay))
                            .replace("{shards}", String.valueOf(cfg.getLong("rewards.shards.base", 10)
                                    + displayDay * cfg.getLong("rewards.shards.per-streak", 2)))
                            .replace("{tokens}", String.valueOf(cfg.getLong("rewards.tokens.base", 0)
                                    + displayDay * cfg.getLong("rewards.tokens.per-streak", 0) / 5))));
                }
            } else {
                mat = Material.matchMaterial(cfg.getString("gui.unclaimed.material", "GRAY_DYE"));
                if (mat == null) mat = Material.GRAY_DYE;
                name = cfg.getString("gui.unclaimed.name", "<gray>Day {day}</gray>");
                for (String l : cfg.getStringList("gui.unclaimed.lore")) {
                    lore.add(TextUtil.parse(l.replace("{day}", String.valueOf(displayDay))
                            .replace("{shards}", String.valueOf(cfg.getLong("rewards.shards.base", 10)
                                    + displayDay * cfg.getLong("rewards.shards.per-streak", 2)))
                            .replace("{tokens}", String.valueOf(cfg.getLong("rewards.tokens.base", 0)
                                    + displayDay * cfg.getLong("rewards.tokens.per-streak", 0) / 5))));
                }
            }
            inventory.setItem(slot, ItemBuilder.of(mat)
                    .name(TextUtil.parse(name.replace("{day}", String.valueOf(displayDay))))
                    .lore(lore.isEmpty() ? null : lore)
                    .build());
        }
        player.openInventory(inventory);
    }
}