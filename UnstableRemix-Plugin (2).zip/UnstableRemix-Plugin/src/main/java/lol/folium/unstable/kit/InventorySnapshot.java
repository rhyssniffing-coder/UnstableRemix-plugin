package lol.folium.unstable.kit;

import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public record InventorySnapshot(
        ItemStack[] contents,
        ItemStack[] armor,
        ItemStack offhand,
        ItemStack cursor,
        int heldSlot,
        GameMode gameMode
) {
    public static InventorySnapshot capture(Player player) {
        return new InventorySnapshot(
                cloneArray(player.getInventory().getContents()),
                cloneArray(player.getInventory().getArmorContents()),
                cloneItem(player.getInventory().getItemInOffHand()),
                cloneItem(player.getItemOnCursor()),
                player.getInventory().getHeldItemSlot(),
                player.getGameMode()
        );
    }

    public void restore(Player player) {
        player.getInventory().setContents(cloneArray(contents));
        player.getInventory().setArmorContents(cloneArray(armor));
        player.getInventory().setItemInOffHand(cloneItem(offhand));
        player.setItemOnCursor(cloneItem(cursor));
        player.getInventory().setHeldItemSlot(heldSlot);
        player.setGameMode(gameMode);
    }

    private static ItemStack[] cloneArray(ItemStack[] input) {
        ItemStack[] clone = new ItemStack[input.length];
        for (int i = 0; i < input.length; i++) {
            clone[i] = cloneItem(input[i]);
        }
        return clone;
    }

    private static ItemStack cloneItem(ItemStack item) {
        return item == null ? null : item.clone();
    }
}
