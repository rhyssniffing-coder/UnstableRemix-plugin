package lol.folium.unstable.integration;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class HubNpcListener implements Listener {

    private static final Component MENU_TITLE = Component.text("Hub Menu");

    private final UnstableRemixPlugin plugin;
    private final CitizensHook citizens;
    private final Map<UUID, Long> clickCooldowns = new ConcurrentHashMap<>();
    private final Map<UUID, String> pendingConfirm = new ConcurrentHashMap<>();

    public HubNpcListener(UnstableRemixPlugin plugin, CitizensHook citizens) {
        this.plugin = plugin;
        this.citizens = citizens;
    }

    @EventHandler
    public void onEntityInteract(PlayerInteractEntityEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!citizens.isAvailable()) return;

        Player player = event.getPlayer();
        int npcId = -1;
        try {
            Object npc = Class.forName("net.citizensnpcs.api.CitizensAPI")
                    .getMethod("getNPCRegistry").invoke(null)
                    .getClass().getMethod("getNPC", org.bukkit.entity.Entity.class)
                    .invoke(
                            Class.forName("net.citizensnpcs.api.CitizensAPI").getMethod("getNPCRegistry").invoke(null),
                            event.getRightClicked()
                    );
            if (npc == null) return;
            npcId = (int) Class.forName("net.citizensnpcs.api.npc.NPC").getMethod("getId").invoke(npc);
        } catch (Exception e) {
            return;
        }

        ConfigurationSection hubNpcs = plugin.getConfig().getConfigurationSection("hub-npcs");
        if (hubNpcs == null) return;
        ConfigurationSection ids = hubNpcs.getConfigurationSection("ids");
        if (ids == null) return;
        String action = ids.getString(String.valueOf(npcId));
        if (action == null) return;

        long cooldownMs = hubNpcs.getLong("click-cooldown-ms", 500);
        long now = System.currentTimeMillis();
        Long last = clickCooldowns.get(player.getUniqueId());
        if (last != null && now - last < cooldownMs) return;
        clickCooldowns.put(player.getUniqueId(), now);

        handleHubAction(player, action);
    }

    private void handleHubAction(Player player, String action) {
        switch (action.toLowerCase()) {
            case "menu" -> openHubMenu(player);
            case "discord" -> {
                String link = plugin.getConfig().getString("social.discord-link", "https://discord.gg/unstableremix");
                pendingConfirm.put(player.getUniqueId(), "discord");
                openConfirmGui(player, Material.ENDER_EYE, "Join Discord",
                        List.of(
                                TextUtil.parse("<gray>You will be opening an external link:</gray>"),
                                TextUtil.parse("<aqua><underlined>" + link + "</underlined></aqua>"),
                                TextUtil.parse(""),
                                TextUtil.parse("<green>Click to confirm.</green>")
                        ));
            }
            case "rules" -> {
                pendingConfirm.put(player.getUniqueId(), "rules");
                openConfirmGui(player, Material.BOOK, "View Rules",
                        List.of(TextUtil.parse("<gray>Open the server rules GUI?</gray>"), TextUtil.parse(""), TextUtil.parse("<green>Click to confirm.</green>")));
            }
            case "guide" -> {
                pendingConfirm.put(player.getUniqueId(), "guide");
                openConfirmGui(player, Material.COMPASS, "New Player Guide",
                        List.of(TextUtil.parse("<gray>Open the new player guide?</gray>"), TextUtil.parse(""), TextUtil.parse("<green>Click to confirm.</green>")));
            }
            case "shop" -> {
                pendingConfirm.put(player.getUniqueId(), "shop");
                openConfirmGui(player, Material.EMERALD, "Kit Shop",
                        List.of(TextUtil.parse("<gray>Open the Kit Shop?</gray>"), TextUtil.parse(""), TextUtil.parse("<green>Click to confirm.</green>")));
            }
            default -> player.sendMessage(TextUtil.parse("<red>Unknown hub action: " + action + "</red>"));
        }
    }

    private void openHubMenu(Player player) {
        ConfigurationSection menuSection = plugin.getConfig().getConfigurationSection("hub-npcs.menu");
        int rows = menuSection != null ? menuSection.getInt("rows", 3) : 3;
        String menuTitle = menuSection != null ? menuSection.getString("title", "<gradient:#FFD700:#FF8C00>\u2726 Hub Menu \u2726</gradient>") : "<gradient:#FFD700:#FF8C00>\u2726 Hub Menu \u2726</gradient>";

        HubMenuHolder holder = new HubMenuHolder();
        Inventory inv = Bukkit.createInventory(holder, rows * 9, TextUtil.parse(menuTitle));
        holder.bind(inv);

        String fillerMatName = menuSection != null ? menuSection.getString("filler-material", "BLACK_STAINED_GLASS_PANE") : "BLACK_STAINED_GLASS_PANE";
        Material fillerMat = Material.matchMaterial(fillerMatName);
        if (fillerMat == null) fillerMat = Material.BLACK_STAINED_GLASS_PANE;

        for (int i = 0; i < rows * 9; i++) {
            inv.setItem(i, ItemBuilder.of(fillerMat).name(Component.empty()).build());
        }

        ConfigurationSection items = menuSection != null ? menuSection.getConfigurationSection("items") : null;
        if (items != null) {
            for (String key : items.getKeys(false)) {
                ConfigurationSection item = items.getConfigurationSection(key);
                if (item == null) continue;

                String materialName = item.getString("material", "PAPER");
                Material mat = Material.matchMaterial(materialName);
                if (mat == null) mat = Material.PAPER;

                int slot = item.getInt("slot", -1);
                if (slot < 0 || slot >= rows * 9) continue;

                String name = item.getString("name", "<white>" + key + "</white>");
                List<String> rawLore = item.getStringList("lore");
                List<Component> lore = new ArrayList<>();
                for (String line : rawLore) {
                    lore.add(TextUtil.parse(line));
                }

                inv.setItem(slot, ItemBuilder.of(mat)
                        .name(TextUtil.parse(name))
                        .lore(lore)
                        .build());
            }
        }

        int closeSlot = rows * 9 - 1;
        inv.setItem(closeSlot, ItemBuilder.of(Material.BARRIER)
                .name(TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700><bold>\u2718 CLOSE</bold></gradient>"))
                .build());

        player.openInventory(inv);
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
    }

    private void openConfirmGui(Player player, Material icon, String title, List<Component> lore) {
        ConfigurationSection confirmSection = plugin.getConfig().getConfigurationSection("hub-npcs.confirm");
        String confirmTitle = confirmSection != null ? confirmSection.getString("title", "<gradient:#FF4444:#FF8800>\u26A0 Confirm</gradient>") : "<gradient:#FF4444:#FF8800>\u26A0 Confirm</gradient>";

        ConfirmHolder holder = new ConfirmHolder();
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.parse(confirmTitle));
        holder.bind(inv);

        String fillerMatName = confirmSection != null ? confirmSection.getString("filler-material", "BLACK_STAINED_GLASS_PANE") : "BLACK_STAINED_GLASS_PANE";
        Material fillerMat = Material.matchMaterial(fillerMatName);
        if (fillerMat == null) fillerMat = Material.BLACK_STAINED_GLASS_PANE;

        for (int i = 0; i < 27; i++) {
            inv.setItem(i, ItemBuilder.of(fillerMat).name(Component.empty()).build());
        }

        inv.setItem(11, ItemBuilder.of(Material.LIME_DYE)
                .name(TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700><bold>\u2714 CONFIRM</bold></gradient>"))
                .lore(lore)
                .build());

        inv.setItem(15, ItemBuilder.of(Material.RED_DYE)
                .name(TextUtil.parse("<dark_gray><bold>\u2718 CANCEL</bold></dark_gray>"))
                .lore(List.of(TextUtil.parse("<gray>Go back to the menu.</gray>")))
                .build());

        inv.setItem(13, ItemBuilder.of(icon)
                .name(TextUtil.parse("<gold><bold>" + title + "</bold></gold>"))
                .build());

        player.openInventory(inv);
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
    }

    private void executeConfirmed(Player player, String action) {
        switch (action) {
            case "discord" -> {
                String link = plugin.getConfig().getString("social.discord-link", "https://discord.gg/unstableremix");
                player.closeInventory();
                player.sendMessage(TextUtil.parse("<aqua><bold>DISCORD</bold></aqua>"));
                player.sendMessage(TextUtil.parse("<aqua><underlined>" + link + "</underlined></aqua>"));
            }
            case "rules" -> {
                player.closeInventory();
                plugin.getServer().dispatchCommand(player, "rules");
            }
            case "guide" -> {
                player.closeInventory();
                plugin.getServer().dispatchCommand(player, "guide");
            }
            case "shop" -> {
                player.closeInventory();
                plugin.getServer().dispatchCommand(player, "kit shop");
            }
        }
    }

    public final class HubMenuHolder extends GuiHolder {
        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            Player player = (Player) event.getWhoClicked();
            int slot = event.getRawSlot();
            if (slot < 0 || slot >= getInventory().getSize()) return;
            if (event.getCurrentItem() == null) return;
            if (event.getCurrentItem().getType() == Material.BLACK_STAINED_GLASS_PANE
                    || event.getCurrentItem().getType() == Material.GRAY_STAINED_GLASS_PANE) return;

            if (slot == getInventory().getSize() - 1) {
                player.closeInventory();
                return;
            }

            ConfigurationSection menuSection = plugin.getConfig().getConfigurationSection("hub-npcs.menu.items");
            if (menuSection == null) return;

            String clickedAction = null;
            for (String key : menuSection.getKeys(false)) {
                ConfigurationSection item = menuSection.getConfigurationSection(key);
                if (item != null && item.getInt("slot", -1) == slot) {
                    clickedAction = item.getString("action", key);
                    break;
                }
            }

            if (clickedAction == null) return;
            player.closeInventory();

            if ("follow".equals(clickedAction)) {
                String followLink = plugin.getConfig().getString("social.follow-link",
                        "https://www.tiktok.com/@unstableremixofficial");
                player.sendMessage(TextUtil.parse("<yellow><bold>FOLLOW US</bold></yellow>"));
                player.sendMessage(TextUtil.parse("<aqua><underlined>" + followLink + "</underlined></aqua>"));
                return;
            }

            handleHubAction(player, clickedAction);
        }
    }

    public final class ConfirmHolder extends GuiHolder {
        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            Player player = (Player) event.getWhoClicked();
            int slot = event.getRawSlot();
            if (slot < 0 || slot >= 27) return;

            String action = pendingConfirm.remove(player.getUniqueId());
            if (action == null) {
                player.closeInventory();
                return;
            }

            if (slot == 11) {
                executeConfirmed(player, action);
            } else if (slot == 15 || slot == 13) {
                player.closeInventory();
            }
        }
    }
}
