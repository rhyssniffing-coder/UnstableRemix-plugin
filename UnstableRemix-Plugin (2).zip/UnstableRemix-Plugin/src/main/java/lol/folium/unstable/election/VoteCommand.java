package lol.folium.unstable.election;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.util.TextUtil;

import org.bukkit.entity.Player;

import java.util.List;

public final class VoteCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;
    private final ElectionManager elections;

    public VoteCommand(UnstableRemixPlugin plugin, ElectionManager elections) {
        this.plugin = plugin;
        this.elections = elections;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (!elections.isVoting()) {
            player.sendMessage(TextUtil.parse("<red>Voting is not currently open.</red>"));
            return;
        }
        int electionId = elections.getCurrentElectionId();
        if (elections.getStore().hasVoted(electionId, player.getUniqueId())) {
            player.sendMessage(TextUtil.parse("<red>You have already voted in this election.</red>"));
            return;
        }
        new VoteGui(plugin, elections).open(player);
    }

    @Override
    protected String permission() {
        return null;
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        return List.of();
    }
}
