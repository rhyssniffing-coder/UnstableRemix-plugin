package lol.folium.unstable.election;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class VoteGui implements Listener {

    private static final Map<String, String> FACTION_COLORS = Map.of(
        "Mafia", "<gradient:#8B0000:#DC143C>",
        "Null", "<gradient:#2c2c2c:#6b6b6b>",
        "Law", "<gradient:#00008B:#00FFFF>"
    );

    private static final int[] BORDER_SLOTS = {
        0, 1, 2, 3, 4, 5, 6, 7, 8,
        9, 17, 18, 26, 27, 35, 36, 44,
        45, 46, 47, 48, 49, 50, 51, 52, 53
    };

    private static final Map<String, Integer> FACTION_SLOTS = Map.of(
        "Mafia", 20, "Null", 22, "Law", 24
    );

    private final UnstableRemixPlugin plugin;
    private final ElectionManager elections;
    private final Map<UUID, UUID> confirmations = new HashMap<>();

    public VoteGui(UnstableRemixPlugin plugin, ElectionManager elections) {
        this.plugin = plugin;
        this.elections = elections;
    }

    private static final net.kyori.adventure.text.Component VOTE_TITLE = TextUtil.parse("<gradient:#FFD700:#FFAA00>Election Vote</gradient>");

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, VOTE_TITLE);

        var candidates = elections.getStore().getCandidates(elections.getCurrentElectionId());

        for (int slot : BORDER_SLOTS) {
            inv.setItem(slot, ItemBuilder.of(Material.YELLOW_STAINED_GLASS_PANE)
                .name(Component.text(" "))
                .build());
        }

        for (var c : candidates) {
            int slot = FACTION_SLOTS.getOrDefault(c.faction(), -1);
            if (slot < 0) continue;

            String color = FACTION_COLORS.getOrDefault(c.faction(), "<white>");
            String name = Bukkit.getOfflinePlayer(c.uuid()).getName();
            if (name == null) name = c.uuid().toString().substring(0, 8);

            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.displayName(TextUtil.parse(color + "<bold>" + name + "</bold></color>"));

            List<Component> lore = new ArrayList<>();
            lore.add(TextUtil.parse(color + c.faction() + "</color>"));
            if (!c.manifesto().isEmpty()) {
                lore.add(TextUtil.parse("<gray>\"" + c.manifesto() + "\"</gray>"));
            }
            lore.add(TextUtil.parse("<yellow>Votes: " + c.voteCount() + "</yellow>"));
            lore.add(Component.empty());
            lore.add(TextUtil.parse("<green><italic>Click to vote!</italic></green>"));
            meta.lore(lore);
            head.setItemMeta(meta);

            inv.setItem(slot, head);
        }

        player.openInventory(inv);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!event.getView().title().equals(VOTE_TITLE)) return;

        event.setCancelled(true);
        if (event.getCurrentItem() == null || event.getCurrentItem().getType() == Material.AIR) return;
        if (event.getCurrentItem().getType() == Material.YELLOW_STAINED_GLASS_PANE) return;

        int electionId = elections.getCurrentElectionId();
        if (elections.getStore().hasVoted(electionId, player.getUniqueId())) {
            player.sendMessage(TextUtil.parse("<red>You have already voted.</red>"));
            player.closeInventory();
            return;
        }

        var candidates = elections.getStore().getCandidates(electionId);
        for (var c : candidates) {
            int slot = FACTION_SLOTS.getOrDefault(c.faction(), -1);
            if (slot == event.getSlot()) {
                UUID prev = confirmations.get(player.getUniqueId());
                if (prev != null && prev.equals(c.uuid())) {
                    elections.getStore().castVote(electionId, player.getUniqueId(), c.uuid());
                    String name = Bukkit.getOfflinePlayer(c.uuid()).getName();
                    player.sendMessage(TextUtil.parse("<green>You voted for " + name + "!</green>"));
                    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
                    confirmations.remove(player.getUniqueId());
                    player.closeInventory();
                    return;
                }
                confirmations.put(player.getUniqueId(), c.uuid());
                player.sendMessage(TextUtil.parse("<yellow>Click again to confirm your vote!</yellow>"));
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1, 1);
                return;
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player)) return;
        if (!event.getView().title().equals(VOTE_TITLE)) return;
        cleanup(event.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        if (confirmations.containsKey(event.getPlayer().getUniqueId())) {
            cleanup(event.getPlayer().getUniqueId());
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (!event.getView().title().equals(VOTE_TITLE)) return;
        event.setCancelled(true);
    }

    private void cleanup(UUID uuid) {
        confirmations.remove(uuid);
        if (confirmations.isEmpty()) {
            HandlerList.unregisterAll(this);
        }
    }
}
