package lol.folium.unstable.events;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class ArenaEventListener implements Listener {

    private final ArenaEventEngine eventEngine;

    public ArenaEventListener(ArenaEventEngine eventEngine) {
        this.eventEngine = eventEngine;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        
        // Reset player progress if they take any damage during an event
        eventEngine.resetPlayerProgress(player);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        // Reset player progress when they disconnect
        eventEngine.resetPlayerProgress(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerDeath(PlayerDeathEvent event) {
        // Reset player progress when they die
        eventEngine.resetPlayerProgress(event.getEntity());
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getClickedBlock() == null) return;
        Location blockLoc = event.getClickedBlock().getLocation();
        eventEngine.findEventAt(blockLoc).ifPresent(eventType ->
                eventEngine.startPlayerProgress(event.getPlayer(), eventType));
    }
}
