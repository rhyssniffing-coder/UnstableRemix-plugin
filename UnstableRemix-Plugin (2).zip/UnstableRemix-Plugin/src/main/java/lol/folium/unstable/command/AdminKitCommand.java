package lol.folium.unstable.command;

import lol.folium.unstable.kit.KitManager;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class AdminKitCommand implements CommandExecutor, TabCompleter {

    private final KitManager kits;

    public AdminKitCommand(KitManager kits) {
        this.kits = kits;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (!player.hasPermission("unstable.coreadmin")) {
            player.sendMessage(TextUtil.parse("<red>No permission."));
            return true;
        }
        if (args.length < 1) {
            usage(player);
            return true;
        }
        int i = args[0].equalsIgnoreCase("kit") ? 1 : 0;
        String[] rest = Arrays.copyOfRange(args, i, args.length);
        if (rest.length < 1) {
            usage(player);
            return true;
        }
        if (rest[0].equalsIgnoreCase("create") && rest.length >= 2) {
            String kitId = rest[1];
            if (rest.length >= 3) {
                Material mat = Material.matchMaterial(rest[2]);
                kits.createKit(player, kitId, mat != null ? mat : null);
            } else {
                kits.createKit(player, kitId);
            }
            player.sendMessage(TextUtil.parse("<green>Created kit <white>" + kitId + "</white> from your inventory."));
            return true;
        }
        if (rest[0].equalsIgnoreCase("edit") && rest.length >= 4) {
            String value = String.join(" ", Arrays.copyOfRange(rest, 3, rest.length));
            try {
                if (kits.editKit(rest[1], rest[2], value)) {
                    player.sendMessage(TextUtil.parse("<green>Updated kit <white>" + rest[1] + "</white>."));
                } else {
                    player.sendMessage(TextUtil.parse("<red>Could not edit that kit/field.</red>"));
                }
            } catch (RuntimeException ex) {
                player.sendMessage(TextUtil.parse("<red>Invalid value.</red>"));
            }
            return true;
        }
        if (rest[0].equalsIgnoreCase("killeffect") && rest.length >= 4) {
            if (rest[2].equalsIgnoreCase("price")) {
                try {
                    if (kits.editKillEffectPrice(rest[1], Long.parseLong(rest[3]))) {
                        player.sendMessage(TextUtil.parse("<green>Updated kill effect price.</green>"));
                    } else {
                        player.sendMessage(TextUtil.parse("<red>Unknown kill effect.</red>"));
                    }
                } catch (NumberFormatException ex) {
                    player.sendMessage(TextUtil.parse("<red>Invalid price.</red>"));
                }
                return true;
            }
        }
        if (rest[0].equalsIgnoreCase("shop") && rest.length >= 3) {
            String sub = rest[1].toLowerCase();
            if (sub.equals("add") && rest.length >= 6) {
                String kitName = rest[2];
                try {
                    int slot = Integer.parseInt(rest[3]);
                    long price = Long.parseLong(rest[4]);
                    String displayMaterial = rest[5];
                    if (kits.kitIds().contains(kitName.toLowerCase())) {
                        kits.addKitToShop(kitName, slot, price, displayMaterial);
                        player.sendMessage(TextUtil.parse("<green>Added kit <white>" + kitName + "</white> to shop slot " + slot + " for " + price + " Shards.</green>"));
                    } else {
                        player.sendMessage(TextUtil.parse("<red>Unknown kit: " + kitName + "</red>"));
                    }
                } catch (NumberFormatException e) {
                    player.sendMessage(TextUtil.parse("<red>Invalid slot or price.</red>"));
                }
                return true;
            }
            if (sub.equals("remove") && rest.length >= 3) {
                String kitName = rest[2];
                kits.removeKitFromShop(kitName);
                player.sendMessage(TextUtil.parse("<green>Removed kit <white>" + kitName + "</white> from shop.</green>"));
                return true;
            }
            if (sub.equals("setprice") && rest.length >= 4) {
                String kitName = rest[2];
                try {
                    long price = Long.parseLong(rest[3]);
                    kits.setKitShopPrice(kitName, price);
                    player.sendMessage(TextUtil.parse("<green>Set price of kit <white>" + kitName + "</white> to " + price + " Shards.</green>"));
                } catch (NumberFormatException e) {
                    player.sendMessage(TextUtil.parse("<red>Invalid price.</red>"));
                }
                return true;
            }
        }
        usage(player);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        int i = args.length > 0 && args[0].equalsIgnoreCase("kit") ? 1 : 0;
        String[] a = Arrays.copyOfRange(args, i, args.length);
        if (a.length == 0) return List.of();
        if (a.length == 1) return List.of("create", "edit", "killeffect", "shop");
        if (a.length == 2 && a[0].equalsIgnoreCase("edit")) return kits.kitIds();
        if (a.length == 2 && a[0].equalsIgnoreCase("killeffect")) return kits.killEffectIds();
        if (a.length == 2 && a[0].equalsIgnoreCase("shop")) return List.of("add", "remove", "setprice");
        if (a.length == 3 && a[0].equalsIgnoreCase("edit")) {
            return List.of("price", "displayname", "material", "slot", "luckperms-rank", "required-group", "tier");
        }
        if (a.length == 3 && a[0].equalsIgnoreCase("killeffect")) return List.of("price");
        if (a.length == 3 && a[0].equalsIgnoreCase("shop") && !a[1].equalsIgnoreCase("add")) {
            return kits.kitIds();
        }
        if (a.length == 3 && a[0].equalsIgnoreCase("shop") && a[1].equalsIgnoreCase("add")) {
            return kits.kitIds();
        }
        if (a.length == 4 && a[0].equalsIgnoreCase("edit") && a[2].equalsIgnoreCase("material")) {
            return Arrays.stream(Material.values()).map(Material::name).toList();
        }
        if (a.length == 4 && a[2].equalsIgnoreCase("price")) return List.of("1000", "2500", "5000");
        if (a.length == 4 && a[0].equalsIgnoreCase("shop") && a[1].equalsIgnoreCase("add")) {
            return List.of("10", "11", "12", "13", "14", "15", "16");
        }
        if (a.length == 5 && a[0].equalsIgnoreCase("shop") && a[1].equalsIgnoreCase("add")) {
            return List.of("5000", "10000", "25000", "50000");
        }
        if (a.length == 6 && a[0].equalsIgnoreCase("shop") && a[1].equalsIgnoreCase("add")) {
            return List.of("DIAMOND", "IRON_SWORD", "CHEST", "EMERALD", "BOOK", "BOW");
        }
        return Collections.emptyList();
    }

    private void usage(Player player) {
        player.sendMessage(TextUtil.parse("<yellow>/admin kit create <id>"));
        player.sendMessage(TextUtil.parse("<yellow>/admin kit edit <id> <price|displayname|material|slot|luckperms-rank|required-group|tier> <value>"));
        player.sendMessage(TextUtil.parse("<yellow>/admin kit killeffect <id> price <amount>"));
        player.sendMessage(TextUtil.parse("<yellow>/admin kit shop add <kit_name> <slot> <shard_cost> <display_material>"));
        player.sendMessage(TextUtil.parse("<yellow>/admin kit shop remove <kit_name>"));
        player.sendMessage(TextUtil.parse("<yellow>/admin kit shop setprice <kit_name> <new_shard_cost>"));
    }
}
