package lol.folium.unstable.integration;

import lol.folium.unstable.UnstableRemixPlugin;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.types.InheritanceNode;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

public final class LuckPermsHook {

    private static final Map<String, String> KIT_COLORS = Map.ofEntries(
            Map.entry("wemmbu", "#E7E01B"),
            Map.entry("minutetech", "#545B62"),
            Map.entry("lettucek", "#78FF16"),
            Map.entry("theobaldthebird", "#FFC014"),
            Map.entry("manepear", "#FF7C00"),
            Map.entry("inviswemmbu", "#1F82F1"),
            Map.entry("jadenman", "#1684FF"),
            Map.entry("flamefrags", "#FF1F1F"),
            Map.entry("parrotx2", "#B8E287"),
            Map.entry("spokeishere", "#4F95E2"),
            Map.entry("eggchan", "#55FFFF")
    );

    private static final Map<String, String> KIT_DISPLAY_NAMES = Map.ofEntries(
            Map.entry("wemmbu", "WEMMBU"),
            Map.entry("minutetech", "MINUTETECH"),
            Map.entry("lettucek", "LETTUCEK"),
            Map.entry("theobaldthebird", "THEOBALD"),
            Map.entry("manepear", "MANEPEAR"),
            Map.entry("inviswemmbu", "INVISWEMMBU"),
            Map.entry("jadenman", "JADENMAN"),
            Map.entry("flamefrags", "FLAMEFRAGS"),
            Map.entry("parrotx2", "PARROTX2"),
            Map.entry("spokeishere", "SPOKE"),
            Map.entry("eggchan", "EGGCHAN")
    );

    public static String getKitColor(String kitId) {
        return KIT_COLORS.getOrDefault(kitId.toLowerCase(Locale.ROOT), "#FFFFFF");
    }

    public static String coloredKitName(String kitId, String displayName) {
        String color = getKitColor(kitId);
        String stripped = displayName.replaceAll("<[^>]+>", "");
        if (stripped.isEmpty()) stripped = displayName;
        return "<" + color + "><bold>" + stripped + "</bold>";
    }

    public static String getKitDisplayName(String kitId) {
        return KIT_DISPLAY_NAMES.getOrDefault(kitId.toLowerCase(Locale.ROOT),
                kitId.substring(0, 1).toUpperCase() + kitId.substring(1).toLowerCase());
    }

    private final UnstableRemixPlugin plugin;
    private final boolean available;

    public LuckPermsHook(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
        this.available = plugin.getServer().getPluginManager().getPlugin("LuckPerms") != null;
    }

    public boolean isAvailable() {
        return available;
    }

    public LuckPerms getLuckPerms() {
        return LuckPermsProvider.get();
    }

    public Optional<String> highestTokenRank(Player player) {
        if (!available) {
            return Optional.empty();
        }
        LuckPerms api = LuckPermsProvider.get();
        User user = api.getUserManager().getUser(player.getUniqueId());
        if (user == null) {
            return Optional.empty();
        }
        var aliases = plugin.getConfig().getConfigurationSection("luckperms.rank-aliases");
        var tokenRanks = plugin.getConfig().getConfigurationSection("luckperms.token-ranks");
        if (tokenRanks == null) {
            return Optional.empty();
        }
        String best = null;
        int bestTokens = -1;
        for (String rankKey : tokenRanks.getKeys(false)) {
            String group = resolveGroup(rankKey, aliases);
            if (user.getDistinctNodes().stream().anyMatch(node ->
                    node.getKey().equals("group." + group) || node.getKey().equals("group." + rankKey))) {
                int tokens = tokenRanks.getInt(rankKey);
                if (tokens > bestTokens) {
                    bestTokens = tokens;
                    best = rankKey;
                }
            }
        }
        return Optional.ofNullable(best);
    }

    public CompletableFuture<Boolean> grantTemporaryRank(Player player, String group, Duration duration) {
        if (!available) {
            return CompletableFuture.completedFuture(false);
        }
        LuckPerms api = LuckPermsProvider.get();
        return api.getUserManager().modifyUser(player.getUniqueId(), user -> {
            user.data().add(InheritanceNode.builder(group.toLowerCase(Locale.ROOT))
                    .expiry(duration)
                    .build());
        }).thenApply(ignored -> true).exceptionally(ex -> {
            plugin.getLogger().severe("LuckPerms temp rank failed: " + ex.getMessage());
            return false;
        });
    }

    public Optional<String> primaryGroup(Player player) {
        if (!available) return Optional.empty();
        try {
            LuckPerms api = LuckPermsProvider.get();
            User user = api.getUserManager().getUser(player.getUniqueId());
            if (user == null) return Optional.empty();
            return Optional.ofNullable(user.getPrimaryGroup());
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    public Optional<String> getPrefix(Player player) {
        if (!available) return Optional.empty();
        try {
            LuckPerms api = LuckPermsProvider.get();
            User user = api.getUserManager().getUser(player.getUniqueId());
            if (user == null) return Optional.empty();
            String prefix = user.getCachedData().getMetaData().getPrefix();
            return Optional.ofNullable(prefix);
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    public boolean hasGroup(Player player, String group) {
        if (!available || group == null || group.isBlank()) {
            return false;
        }
        LuckPerms api = LuckPermsProvider.get();
        User user = api.getUserManager().getUser(player.getUniqueId());
        if (user == null) {
            return false;
        }
        String normalized = group.toLowerCase(Locale.ROOT);
        return user.getDistinctNodes().stream().anyMatch(node -> node.getKey().equals("group." + normalized));
    }

    public CompletableFuture<Boolean> grantPermanentRank(Player player, String group) {
        if (!available || group == null || group.isBlank()) {
            return CompletableFuture.completedFuture(group == null || group.isBlank());
        }
        LuckPerms api = LuckPermsProvider.get();
        return api.getUserManager().modifyUser(player.getUniqueId(), user -> {
            user.data().add(InheritanceNode.builder(group.toLowerCase(Locale.ROOT)).build());
        }).thenApply(ignored -> true).exceptionally(ex -> {
            plugin.getLogger().severe("LuckPerms permanent rank failed: " + ex.getMessage());
            return false;
        });
    }

    public CompletableFuture<Boolean> swapKitGroup(Player player, String newGroup, java.util.Collection<String> allKitGroups) {
        if (!available || newGroup == null || newGroup.isBlank()) {
            return CompletableFuture.completedFuture(true);
        }
        LuckPerms api = LuckPermsProvider.get();
        return api.getUserManager().modifyUser(player.getUniqueId(), user -> {
            for (String g : allKitGroups) {
                user.data().remove(InheritanceNode.builder(g.toLowerCase(Locale.ROOT)).build());
            }
            user.data().add(InheritanceNode.builder(newGroup.toLowerCase(Locale.ROOT)).build());
        }).thenApply(ignored -> true).exceptionally(ex -> {
            plugin.getLogger().severe("LuckPerms swapKitGroup failed: " + ex.getMessage());
            return false;
        });
    }

    public void createKitGroups() {
        if (!available) return;
        tryCreateGroup(0, KIT_COLORS.entrySet().iterator());
    }

    private void tryCreateGroup(int attempt, java.util.Iterator<Map.Entry<String, String>> iterator) {
        if (attempt >= 5) {
            plugin.getLogger().warning("Giving up creating LuckPerms groups after 5 attempts.");
            return;
        }
        if (!iterator.hasNext()) {
            plugin.getLogger().info("All LuckPerms kit groups created/configured successfully.");
            return;
        }
        Map.Entry<String, String> entry = iterator.next();
        String name = entry.getKey();
        String hexColor = entry.getValue();
        String lpPrefix = "&x" +
                "&" + hexColor.charAt(1) + "&" + hexColor.charAt(2) +
                "&" + hexColor.charAt(3) + "&" + hexColor.charAt(4) +
                "&" + hexColor.charAt(5) + "&" + hexColor.charAt(6);
        String displayName = getKitDisplayName(name);
        String prefix = lpPrefix + "&l" + displayName + "&r" + lpPrefix + " \u25C6 ";

        LuckPerms api = LuckPermsProvider.get();
        Group existing = api.getGroupManager().getGroup(name);
        if (existing != null) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                    "luckperms group " + name + " meta set prefix " + prefix);
            plugin.getLogger().info("Configured LuckPerms group: " + name);
            Bukkit.getScheduler().runTaskLater(plugin,
                    () -> tryCreateGroup(attempt, iterator), 4L);
            return;
        }

        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "luckperms group " + name + " create");
        plugin.getLogger().info("[Attempt " + (attempt + 1) + "] Dispatched create for LuckPerms group: " + name);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                    "luckperms group " + name + " meta set prefix " + prefix);
            plugin.getLogger().info("Set prefix for LuckPerms group: " + name);
            Bukkit.getScheduler().runTaskLater(plugin,
                    () -> tryCreateGroup(attempt, iterator), 4L);
        }, 4L);
    }

    private String resolveGroup(String rankKey, org.bukkit.configuration.ConfigurationSection aliases) {
        if (aliases != null && aliases.contains(rankKey)) {
            return aliases.getString(rankKey, rankKey);
        }
        return rankKey;
    }
}
