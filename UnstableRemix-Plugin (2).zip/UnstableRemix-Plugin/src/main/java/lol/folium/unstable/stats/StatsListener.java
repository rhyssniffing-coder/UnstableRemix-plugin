package lol.folium.unstable.stats;

public final class StatsListener {
}
