package lol.folium.unstable.blackjack;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.entity.Player;

import java.util.List;

public final class BlackjackCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;

    public BlackjackCommand(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length < 1) {
            BlackjackBetGui.open(player, plugin.getEconomyService());
            return;
        }

        long bet;
        try {
            bet = Long.parseLong(args[0]);
        } catch (NumberFormatException e) {
            player.sendMessage(TextUtil.parse("<red>Invalid bet amount.</red>"));
            return;
        }

        if (bet <= 0) {
            player.sendMessage(TextUtil.parse("<red>Bet must be greater than 0.</red>"));
            return;
        }

        if (bet > 1_000_000) {
            player.sendMessage(TextUtil.parse("<red>Max bet is 1,000,000 shards.</red>"));
            return;
        }

        startGameWithBet(player, bet);
    }

    private void startGameWithBet(Player player, long bet) {
        BlackjackGame.startGame(player, plugin.getEconomyService(), bet);
        BlackjackGame game = BlackjackGame.getActive(player.getUniqueId());
        if (game != null) {
            BlackjackGui.open(player, game);
        }
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            return filter(literals("100", "500", "1000", "5000", "10000"), args[0]);
        }
        return List.of();
    }

    @Override
    protected String permission() {
        return null;
    }
}
