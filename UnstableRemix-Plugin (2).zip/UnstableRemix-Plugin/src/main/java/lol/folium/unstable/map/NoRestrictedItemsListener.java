package lol.folium.unstable.map;

import lol.folium.unstable.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.Set;

public class NoRestrictedItemsListener implements Listener {

    private static final Set<Material> RESTRICTED_MATERIALS = Set.of(
            Material.ELYTRA,
            Material.MACE
    );

    private final ArenaManager arenaManager;

    public NoRestrictedItemsListener(ArenaManager arenaManager) {
        this.arenaManager = arenaManager;
    }

    private boolean isRestricted(Arena arena) {
        return arena != null && arena.noElytra();
    }

    private String getRestrictionMessage(Material mat, String context) {
        return switch (mat) {
            case ELYTRA -> "You cannot use elytras in this arena! " + context;
            case MACE -> "You cannot use maces in this arena! " + context;
            default -> "This item is restricted in this arena! " + context;
        };
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onGlideToggle(EntityToggleGlideEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (event.isCancelled()) return;

        Arena arena = arenaManager.getArenaAt(player.getLocation());
        if (!isRestricted(arena)) return;

        if (!event.isGliding()) {
            event.setCancelled(true);
            player.sendMessage(TextUtil.parse("<red>You cannot use elytras in the No-Mace & No-Elytra Arena!</red>"));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteract(PlayerInteractEvent event) {
        if (event.isCancelled()) return;
        Player player = event.getPlayer();
        if (event.getHand() != EquipmentSlot.HAND) return;

        Arena arena = arenaManager.getArenaAt(player.getLocation());
        if (!isRestricted(arena)) return;

        ItemStack item = player.getInventory().getItemInMainHand();
        if (RESTRICTED_MATERIALS.contains(item.getType())) {
            event.setCancelled(true);
            player.sendMessage(TextUtil.parse("<red>" + getRestrictionMessage(item.getType(), "") + "</red>"));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.isCancelled()) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;

        Arena arena = arenaManager.getArenaAt(player.getLocation());
        if (!isRestricted(arena)) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked != null && RESTRICTED_MATERIALS.contains(clicked.getType())) {
            event.setCancelled(true);
            player.sendMessage(TextUtil.parse("<red>" + getRestrictionMessage(clicked.getType(), "") + "</red>"));
        }
    }
}
