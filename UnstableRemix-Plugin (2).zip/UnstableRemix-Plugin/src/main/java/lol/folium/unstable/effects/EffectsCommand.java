package lol.folium.unstable.effects;

import lol.folium.unstable.command.SubCommand;
import org.bukkit.entity.Player;

import java.util.List;

public final class EffectsCommand extends SubCommand {

    private final EffectsManager effects;

    public EffectsCommand(EffectsManager effects) {
        this.effects = effects;
    }

    @Override
    protected void execute(Player player, String[] args) {
        effects.openGui(player);
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        return List.of();
    }

    @Override
    protected String permission() {
        return null;
    }
}
