package lol.folium.unstable.integration;

import lol.folium.unstable.UnstableRemixPlugin;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.types.InheritanceNode;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public final class MediaRankManager {

    private static final String MEDIA_GROUP = "media";
    private static final String MEDIA_PREFIX = "&6&l[MEDIA] &r";
    private static final double SHARD_MULTIPLIER = 1.5;
    private static final double SHOP_DISCOUNT = 0.20;

    private static final String[] MEDIA_PERMISSIONS = {
            "unstable.media.kit.bypass",
            "unstable.media.enderchest.extra",
            "unstable.media.nochatcooldown",
            "unstable.media.sneakpeeks",
            "unstable.media.shop.discount",
            "unstable.media.shard.multiplier"
    };

    private final UnstableRemixPlugin plugin;
    private final boolean available;

    public MediaRankManager(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
        this.available = plugin.getServer().getPluginManager().getPlugin("LuckPerms") != null;
    }

    public boolean isAvailable() {
        return available;
    }

    public void createMediaGroup() {
        if (!available) return;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            try {
                LuckPerms api = LuckPermsProvider.get();
                Group existing = api.getGroupManager().getGroup(MEDIA_GROUP);
                if (existing == null) {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "luckperms group " + MEDIA_GROUP + " create");
                    plugin.getLogger().info("Created LuckPerms group: " + MEDIA_GROUP);
                }
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                        "luckperms group " + MEDIA_GROUP + " meta set prefix " + MEDIA_PREFIX);
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                        "luckperms group " + MEDIA_GROUP + " meta set weight 100");
                for (String perm : MEDIA_PERMISSIONS) {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                            "luckperms group " + MEDIA_GROUP + " permission set " + perm + " true");
                }
                plugin.getLogger().info("Configured LuckPerms media group with all perks.");
            } catch (Exception e) {
                plugin.getLogger().severe("Failed to create media group: " + e.getMessage());
            }
        }, 20L);
    }

    public boolean hasMediaRank(Player player) {
        if (!available) return false;
        try {
            LuckPerms api = LuckPermsProvider.get();
            User user = api.getUserManager().getUser(player.getUniqueId());
            if (user == null) return false;
            return user.getDistinctNodes().stream()
                    .anyMatch(node -> node.getKey().equals("group." + MEDIA_GROUP));
        } catch (Exception e) {
            return false;
        }
    }

    public boolean hasMediaRank(UUID uuid) {
        if (!available) return false;
        try {
            LuckPerms api = LuckPermsProvider.get();
            User user = api.getUserManager().getUser(uuid);
            if (user == null) return false;
            return user.getDistinctNodes().stream()
                    .anyMatch(node -> node.getKey().equals("group." + MEDIA_GROUP));
        } catch (Exception e) {
            return false;
        }
    }

    public CompletableFuture<Boolean> grantMediaRank(Player player) {
        if (!available) return CompletableFuture.completedFuture(false);
        LuckPerms api = LuckPermsProvider.get();
        return api.getUserManager().modifyUser(player.getUniqueId(), user -> {
            user.data().add(InheritanceNode.builder(MEDIA_GROUP).build());
        }).thenApply(ignored -> true).exceptionally(ex -> {
            plugin.getLogger().severe("Failed to grant media rank: " + ex.getMessage());
            return false;
        });
    }

    public CompletableFuture<Boolean> removeMediaRank(Player player) {
        if (!available) return CompletableFuture.completedFuture(false);
        LuckPerms api = LuckPermsProvider.get();
        return api.getUserManager().modifyUser(player.getUniqueId(), user -> {
            user.data().remove(InheritanceNode.builder(MEDIA_GROUP).build());
        }).thenApply(ignored -> true).exceptionally(ex -> {
            plugin.getLogger().severe("Failed to remove media rank: " + ex.getMessage());
            return false;
        });
    }

    public boolean hasKitBypass(Player player) {
        return hasMediaRank(player);
    }

    public boolean hasExtraEnderChest(Player player) {
        return hasMediaRank(player);
    }

    public boolean hasNoChatCooldown(Player player) {
        return hasMediaRank(player);
    }

    public boolean hasSneakPeeks(Player player) {
        return hasMediaRank(player);
    }

    public boolean hasShopDiscount(Player player) {
        return hasMediaRank(player);
    }

    public double getShopDiscountMultiplier(Player player) {
        return hasShopDiscount(player) ? (1.0 - SHOP_DISCOUNT) : 1.0;
    }

    public boolean hasShardMultiplier(Player player) {
        return hasMediaRank(player);
    }

    public double getShardMultiplier(Player player) {
        return hasShardMultiplier(player) ? SHARD_MULTIPLIER : 1.0;
    }

    public String getMediaPrefix() {
        return MEDIA_PREFIX;
    }

    public double getShardMultiplierValue() {
        return SHARD_MULTIPLIER;
    }

    public double getShopDiscountValue() {
        return SHOP_DISCOUNT;
    }
}
