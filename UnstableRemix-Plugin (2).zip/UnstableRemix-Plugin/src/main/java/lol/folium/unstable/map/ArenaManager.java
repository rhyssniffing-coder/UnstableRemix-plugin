package lol.folium.unstable.map;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class ArenaManager {

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final Map<String, Arena> arenas = new LinkedHashMap<>();

    public ArenaManager(UnstableRemixPlugin plugin, ConfigManager configs) {
        this.plugin = plugin;
        this.configs = configs;
    }

    public void loadAll() {
        arenas.clear();
        File dir = new File(plugin.getDataFolder(), "arenas");
        if (!dir.exists()) {
            dir.mkdirs();
            return;
        }
        File[] files = dir.listFiles((d, name) -> name.endsWith(".yml"));
        if (files == null) {
            return;
        }
        for (File file : files) {
            String name = file.getName().replace(".yml", "");
            FileConfiguration yaml = configs.loadArena(name);
            if (yaml == null) {
                continue;
            }
            Arena arena = new Arena(name);
            arena.setMaxPlacedBlocks(plugin.getConfig().getInt("map.max-placed-blocks", 50000));
            arena.setWorldName(yaml.getString("world"));
            arena.setBounds(
                    yaml.getInt("min.x"), yaml.getInt("min.y"), yaml.getInt("min.z"),
                    yaml.getInt("max.x"), yaml.getInt("max.y"), yaml.getInt("max.z")
            );
            arena.setDisplayName(yaml.getString("display-name", name));
            arena.setEnabled(yaml.getBoolean("enabled", true));
            arena.setMinPlayers(yaml.getInt("min-players", 2));
            arena.setMaxPlayers(yaml.getInt("max-players", 20));
            arena.setGameMode(yaml.getString("game-mode", "SURVIVAL"));
            arena.setAllowBuild(yaml.getBoolean("allow-build", false));
            arena.setAllowBreak(yaml.getBoolean("allow-break", false));
            arena.setNaturalRegen(yaml.getBoolean("natural-regen", true));
            arena.setAllowFallDamage(yaml.getBoolean("allow-fall-damage", true));
            arena.setHunger(yaml.getBoolean("hunger", true));
            if (yaml.contains("time-lock")) arena.setTimeLock(yaml.getString("time-lock"));
            if (yaml.contains("weather-lock")) arena.setWeatherLock(yaml.getString("weather-lock"));
            arena.setTeamSpawnMode(yaml.getString("team-spawn-mode", "TEAMS"));
            arena.setNoElytra(yaml.getBoolean("no-elytra", false));
            arena.setPermanent(yaml.getBoolean("permanent", false));
            arena.setLobby(readLocation(yaml, "lobby"));
            arena.setSpawn1(readLocation(yaml, "spawn1"));
            arena.setSpawn2(readLocation(yaml, "spawn2"));
            if (yaml.contains("spawns")) {
                for (String key : yaml.getConfigurationSection("spawns").getKeys(false)) {
                    Location spawn = readLocation(yaml, "spawns." + key);
                    if (spawn != null) {
                        arena.addSpawn(spawn);
                    }
                }
            }
            arenas.put(name.toLowerCase(), arena);
        }
    }

    public Collection<Arena> all() {
        return arenas.values();
    }

    public List<String> names() {
        return new ArrayList<>(arenas.keySet());
    }

    public Optional<Arena> get(String name) {
        return Optional.ofNullable(arenas.get(name.toLowerCase()));
    }

    public Arena getArena(String name) {
        return arenas.get(name.toLowerCase());
    }

    public Arena getArenaAt(Location location) {
        for (Arena arena : arenas.values()) {
            if (arena.contains(location)) {
                return arena;
            }
        }
        return null;
    }

    public Optional<Arena> at(Location location) {
        for (Arena arena : arenas.values()) {
            if (arena.contains(location)) {
                return Optional.of(arena);
            }
        }
        return Optional.empty();
    }

    public boolean exists(String name) {
        return arenas.containsKey(name.toLowerCase());
    }

    public Arena create(String name, WorldEditBridge.RegionSelection selection) throws IOException {
        Arena arena = new Arena(name.toLowerCase());
        arena.setWorldName(selection.world());
        arena.setBounds(selection.minX(), selection.minY(), selection.minZ(), selection.maxX(), selection.maxY(), selection.maxZ());
        arenas.put(name.toLowerCase(), arena);
        save(arena);
        return arena;
    }

    public void save(Arena arena) throws IOException {
        FileConfiguration yaml = configs.loadArena(arena.name());
        if (yaml == null) {
            yaml = new org.bukkit.configuration.file.YamlConfiguration();
        }
        yaml.set("world", arena.worldName());
        yaml.set("min.x", arena.minX());
        yaml.set("min.y", arena.minY());
        yaml.set("min.z", arena.minZ());
        yaml.set("max.x", arena.maxX());
        yaml.set("max.y", arena.maxY());
        yaml.set("max.z", arena.maxZ());
        yaml.set("display-name", arena.displayName());
        yaml.set("enabled", arena.isEnabled());
        yaml.set("min-players", arena.minPlayers());
        yaml.set("max-players", arena.maxPlayers());
        yaml.set("game-mode", arena.gameMode());
        yaml.set("allow-build", arena.allowBuild());
        yaml.set("allow-break", arena.allowBreak());
        yaml.set("natural-regen", arena.naturalRegen());
        yaml.set("allow-fall-damage", arena.allowFallDamage());
        yaml.set("hunger", arena.hunger());
        yaml.set("time-lock", arena.timeLock());
        yaml.set("weather-lock", arena.weatherLock());
        yaml.set("team-spawn-mode", arena.teamSpawnMode());
        yaml.set("no-elytra", arena.noElytra());
        yaml.set("permanent", arena.isPermanent());
        writeLocation(yaml, "lobby", arena.lobby());
        writeLocation(yaml, "spawn1", arena.spawn1());
        writeLocation(yaml, "spawn2", arena.spawn2());
        yaml.set("spawns", null);
        for (int i = 0; i < arena.spawns().size(); i++) {
            writeLocation(yaml, "spawns." + i, arena.spawns().get(i));
        }
        configs.saveArena(arena.name(), yaml);
    }

    public void delete(String name) {
        arenas.remove(name.toLowerCase());
        configs.deleteArena(name.toLowerCase());
    }

    public void copy(String from, String to) throws IOException {
        Arena original = arenas.get(from.toLowerCase());
        if (original == null) throw new IllegalArgumentException("Source arena not found");
        Arena copy = new Arena(to.toLowerCase());
        copy.setWorldName(original.worldName());
        copy.setBounds(original.minX(), original.minY(), original.minZ(),
                original.maxX(), original.maxY(), original.maxZ());
        copy.setDisplayName(original.displayName());
        copy.setEnabled(original.isEnabled());
        copy.setMinPlayers(original.minPlayers());
        copy.setMaxPlayers(original.maxPlayers());
        copy.setGameMode(original.gameMode());
        copy.setAllowBuild(original.allowBuild());
        copy.setAllowBreak(original.allowBreak());
        copy.setNaturalRegen(original.naturalRegen());
        copy.setAllowFallDamage(original.allowFallDamage());
        copy.setHunger(original.hunger());
        copy.setTimeLock(original.timeLock());
        copy.setWeatherLock(original.weatherLock());
        copy.setTeamSpawnMode(original.teamSpawnMode());
        copy.setLobby(original.lobby());
        copy.setSpawn1(original.spawn1());
        copy.setSpawn2(original.spawn2());
        for (Location spawn : original.spawns()) copy.addSpawn(spawn.clone());
        arenas.put(to.toLowerCase(), copy);
        save(copy);
    }

    public void endMatch(Arena arena, ArenaRegenerator regenerator) {
        arena.setStatus(Arena.Status.IDLE);
        arena.players().clear();
        regenerator.regenerate(arena);
    }

    private Location readLocation(FileConfiguration yaml, String path) {
        if (!yaml.contains(path + ".world")) {
            return null;
        }
        return new Location(
                Bukkit.getWorld(yaml.getString(path + ".world")),
                yaml.getDouble(path + ".x"),
                yaml.getDouble(path + ".y"),
                yaml.getDouble(path + ".z"),
                (float) yaml.getDouble(path + ".yaw"),
                (float) yaml.getDouble(path + ".pitch")
        );
    }

    private void writeLocation(FileConfiguration yaml, String path, Location location) {
        if (location == null || location.getWorld() == null) {
            yaml.set(path, null);
            return;
        }
        yaml.set(path + ".world", location.getWorld().getName());
        yaml.set(path + ".x", location.getX());
        yaml.set(path + ".y", location.getY());
        yaml.set(path + ".z", location.getZ());
        yaml.set(path + ".yaw", location.getYaw());
        yaml.set(path + ".pitch", location.getPitch());
    }
}
