package lol.folium.unstable.quest;

public enum QuestType {
    KILLS,
    BLOCKS_PLACED,
    SHUTDOWN,
    TRACKDOWNS,
    DAMAGE_SWORDS,
    BREAK_COBWEBS,
    KILLSTREAK,
    KILLS_LIFETIME,
    MATCH_WINS,
    TRACKDOWNS_LIFETIME
}
