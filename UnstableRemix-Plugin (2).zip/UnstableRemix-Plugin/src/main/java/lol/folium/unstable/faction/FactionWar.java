package lol.folium.unstable.faction;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public final class FactionWar {

    private final String factionA;
    private final String factionB;
    private final long startTime;
    private final long endTime;
    private final ConcurrentMap<UUID, String> killerFactionCache = new ConcurrentHashMap<>();
    private long killsA;
    private long killsB;

    public FactionWar(String factionA, String factionB, long startTime, long endTime) {
        this.factionA = factionA;
        this.factionB = factionB;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public String factionA() { return factionA; }
    public String factionB() { return factionB; }
    public long startTime() { return startTime; }
    public long endTime() { return endTime; }
    public long killsA() { return killsA; }
    public long killsB() { return killsB; }

    public boolean isActive() {
        return System.currentTimeMillis() < endTime;
    }

    public boolean involves(String faction) {
        return factionA.equals(faction) || factionB.equals(faction);
    }

    public String opponent(String faction) {
        return factionA.equals(faction) ? factionB : factionA;
    }

    public long kills(String faction) {
        return factionA.equals(faction) ? killsA : killsB;
    }

    public void addKill(String faction) {
        if (factionA.equals(faction)) killsA++;
        else killsB++;
    }

    public String winningFaction() {
        if (killsA > killsB) return factionA;
        if (killsB > killsA) return factionB;
        return null;
    }

    public boolean isTied() {
        return killsA == killsB;
    }
}
