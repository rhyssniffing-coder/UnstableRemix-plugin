package lol.folium.unstable.command;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.integration.MediaRankManager;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.entity.Player;

import java.util.List;

public final class MediaCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;

    public MediaCommand(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    protected void execute(Player player, String[] args) {
        MediaRankManager mediaManager = plugin.getMediaRankManager();
        boolean hasRank = mediaManager != null && mediaManager.hasMediaRank(player);

        String header = "<gradient:#FFD700:#FFA500><bold>\u2726 MEDIA RANK \u2726</bold></gradient>";
        player.sendMessage(TextUtil.parse(header));
        player.sendMessage(TextUtil.parse("<gray>Get the Media rank by posting clips of UnstableRemix!</gray>"));
        player.sendMessage(TextUtil.parse("<gray>Post on TikTok, YouTube, or Twitter and tag us.</gray>"));
        player.sendMessage(TextUtil.parse(""));

        if (hasRank) {
            player.sendMessage(TextUtil.parse("<green><bold>\u2714 You have the Media rank!</bold></green>"));
        } else {
            player.sendMessage(TextUtil.parse("<red><bold>\u2718 You don't have the Media rank yet.</bold></red>"));
        }

        player.sendMessage(TextUtil.parse(""));
        player.sendMessage(TextUtil.parse("<gradient:#FFD700:#FFA500><bold>Perks:</bold></gradient>"));
        player.sendMessage(TextUtil.parse("  <gold>\u2694</gold> <white>FREE Kit Bypasser</white> <gray>- Skip all kit cooldowns</gray>"));
        player.sendMessage(TextUtil.parse("  <gold>\u2694</gold> <white>Extra Ender Chest Page</white> <gray>- Additional storage</gray>"));
        player.sendMessage(TextUtil.parse("  <gold>\u2694</gold> <white>Exclusive Chat Prefix</white> <gray>- [MEDIA] tag in chat</gray>"));
        player.sendMessage(TextUtil.parse("  <gold>\u2694</gold> <white>No Chat Cooldown</white> <gray>- Instant message sending</gray>"));
        player.sendMessage(TextUtil.parse("  <gold>\u2694</gold> <white>Sneak Peeks & Leaks</white> <gray>- Early access to updates</gray>"));
        player.sendMessage(TextUtil.parse("  <gold>\u2694</gold> <white>20% OFF Shop Purchases</white> <gray>- Discount on all items</gray>"));
        player.sendMessage(TextUtil.parse("  <gold>\u2694</gold> <white>1.5x Shards Per Kill</white> <gray>- Earn more from kills</gray>"));

        player.sendMessage(TextUtil.parse(""));
        player.sendMessage(TextUtil.parse("<dark_gray>Discord: <white>discord.gg/unstableremix</white></dark_gray>"));
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        return List.of();
    }

    @Override
    protected String permission() {
        return "unstable.media";
    }
}
