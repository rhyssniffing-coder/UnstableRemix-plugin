package lol.folium.unstable.vibration;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.map.ArenaManager;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class VibrationManager implements Listener {

    private final UnstableRemixPlugin plugin;
    private final ArenaManager arenas;
    private final Map<UUID, Boolean> emitting = new ConcurrentHashMap<>();
    private Set<String> combatWorlds;
    private BukkitTask particleTask;

    public VibrationManager(UnstableRemixPlugin plugin, ArenaManager arenas) {
        this.plugin = plugin;
        this.arenas = arenas;
    }

    public void start() {
        stop();
        if (!plugin.getConfig().getBoolean("vibration.enabled", true)) {
            return;
        }
        combatWorlds = Set.copyOf(plugin.getConfig().getStringList("vibration.combat-worlds"));
        long interval = plugin.getConfig().getLong("vibration.particle-interval-ticks", 5L);
        particleTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (!Boolean.TRUE.equals(emitting.get(player.getUniqueId()))) {
                    continue;
                }
                if (!inCombatZone(player)) {
                    emitting.put(player.getUniqueId(), false);
                    continue;
                }
                spawnVibration(player);
            }
        }, interval, interval);
    }

    public void stop() {
        if (particleTask != null) {
            particleTask.cancel();
            particleTask = null;
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (event.getFrom().getBlockX() == event.getTo().getBlockX()
                && event.getFrom().getBlockY() == event.getTo().getBlockY()
                && event.getFrom().getBlockZ() == event.getTo().getBlockZ()) {
            return;
        }
        Player player = event.getPlayer();
        if (player.isSneaking() || player.getGameMode() == GameMode.SPECTATOR) {
            emitting.put(player.getUniqueId(), false);
            return;
        }
        if (!inCombatZone(player)) {
            emitting.put(player.getUniqueId(), false);
            return;
        }
        double dx = event.getTo().getX() - event.getFrom().getX();
        double dz = event.getTo().getZ() - event.getFrom().getZ();
        if (Math.hypot(dx, dz) >= 0.15) {
            emitting.put(player.getUniqueId(), true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        emitting.remove(event.getPlayer().getUniqueId());
    }

    private boolean inCombatZone(Player player) {
        if (!combatWorlds.isEmpty()) {
            return combatWorlds.contains(player.getWorld().getName());
        }
        return arenas.at(player.getLocation()).isPresent();
    }

    private void spawnVibration(Player emitter) {
        Location feet = emitter.getLocation();
        Location destination = feet.clone().add(0, 1, 0);
        feet.getWorld().spawnParticle(
                Particle.SCULK_SOUL,
                feet.clone().add(0.5, 0.1, 0.5),
                2,
                0.05,
                0.05,
                0.05,
                0.01
        );
        feet.getWorld().spawnParticle(
                Particle.END_ROD,
                destination,
                1,
                0,
                0,
                0,
                0
        );
    }
}
