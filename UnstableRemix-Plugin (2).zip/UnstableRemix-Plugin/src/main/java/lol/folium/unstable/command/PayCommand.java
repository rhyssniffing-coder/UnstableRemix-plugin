package lol.folium.unstable.command;

import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.economy.TransactionResult;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class PayCommand implements CommandExecutor, TabCompleter {

    private final EconomyService economy;

    public PayCommand(EconomyService economy) {
        this.economy = economy;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<yellow>/pay <player> <amount>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null || target.equals(player)) {
            player.sendMessage(TextUtil.parse("<red>Player not found."));
            return true;
        }
        Long amount = parseAmount(args[1]);
        if (amount == null) {
            player.sendMessage(TextUtil.parse("<red>Enter a positive whole number."));
            return true;
        }
        TransactionResult result = economy.transferShards(player.getUniqueId(), target.getUniqueId(), amount, "pay");
        if (!result.success()) {
            economy.notifyFailure(player, result.messageKey(), amount);
            return true;
        }
        player.sendMessage(TextUtil.parse("<green>Paid <white>" + target.getName() + "</white> <light_purple>" + amount + " Shards</light_purple>."));
        target.sendMessage(TextUtil.parse("<green>Received <light_purple>" + amount + " Shards</light_purple> from <white>" + player.getName() + "</white>."));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(name -> !name.equalsIgnoreCase(sender.getName()))
                    .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(args[0].toLowerCase(Locale.ROOT)))
                    .toList();
        }
        if (args.length == 2) {
            return List.of("100", "500", "1000");
        }
        return Collections.emptyList();
    }

    private Long parseAmount(String raw) {
        try {
            long amount = Long.parseLong(raw);
            return amount > 0 ? amount : null;
        } catch (NumberFormatException ex) {
            return null;
        }
    }
}
