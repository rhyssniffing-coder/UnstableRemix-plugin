package lol.folium.unstable.quest;

public record QuestDefinition(
        String id,
        QuestTier tier,
        String name,
        String description,
        QuestType type,
        int target,
        long rewardShards
) {}
