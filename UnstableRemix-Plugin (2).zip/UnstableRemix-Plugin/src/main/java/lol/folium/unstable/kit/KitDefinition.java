package lol.folium.unstable.kit;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public record KitDefinition(
        String id,
        String displayName,
        Material material,
        int slot,
        String tier,
        long price,
        String luckPermsRank,
        String permission,
        String spawnArena,
        ItemStack[] contents,
        ItemStack[] armor,
        ItemStack offhand,
        String requiredGroup,
        int cooldownSeconds
) {}
