package lol.folium.unstable.kit;

import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.entity.Player;

import java.util.List;

public final class KitCommand extends SubCommand {

    private final KitManager kits;

    public KitCommand(KitManager kits) {
        this.kits = kits;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("shop")) {
            kits.openShop(player, 0);
            return;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("effects")) {
            kits.openKillEffects(player, 0);
            return;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("load")) {
            if (args.length < 2) {
                kits.loadLastKit(player);
                return;
            }
            kits.loadKit(player, args[1]);
            return;
        }
        kits.openSelector(player, 0);
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) return List.of("shop", "effects", "load");
        if (args.length == 2 && args[0].equalsIgnoreCase("load")) return kits.kitIds();
        return List.of();
    }

    @Override
    protected String permission() {
        return null;
    }
}
