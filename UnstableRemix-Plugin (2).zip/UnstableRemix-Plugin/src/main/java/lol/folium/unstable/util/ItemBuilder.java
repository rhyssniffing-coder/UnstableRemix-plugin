package lol.folium.unstable.util;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public final class ItemBuilder {

    private final ItemStack stack;

    private ItemBuilder(Material material) {
        this.stack = new ItemStack(material);
    }

    public static ItemBuilder of(Material material) {
        return new ItemBuilder(material);
    }

    public ItemBuilder amount(int amount) {
        stack.setAmount(amount);
        return this;
    }

    public ItemBuilder name(Component name) {
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(name);
        stack.setItemMeta(meta);
        return this;
    }

    public ItemBuilder lore(List<Component> lore) {
        ItemMeta meta = stack.getItemMeta();
        meta.lore(lore);
        stack.setItemMeta(meta);
        return this;
    }

    public ItemBuilder glow(boolean glow) {
        if (!glow) {
            return this;
        }
        ItemMeta meta = stack.getItemMeta();
        meta.addEnchant(Enchantment.UNBREAKING, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        stack.setItemMeta(meta);
        return this;
    }

    public ItemBuilder customModelData(Integer cmd) {
        if (cmd == null) {
            return this;
        }
        ItemMeta meta = stack.getItemMeta();
        meta.setCustomModelData(cmd);
        stack.setItemMeta(meta);
        return this;
    }

    public ItemStack build() {
        return stack.clone();
    }
}
