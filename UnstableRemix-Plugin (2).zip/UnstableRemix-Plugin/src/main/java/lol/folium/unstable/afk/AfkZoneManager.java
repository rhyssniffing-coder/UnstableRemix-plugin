package lol.folium.unstable.afk;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.map.WorldEditBridge;
import lol.folium.unstable.util.GuiTheme;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class AfkZoneManager {

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final EconomyService economy;
    private final WorldEditBridge worldEdit;
    private final Map<String, AfkZone> zones = new ConcurrentHashMap<>();
    private final Map<UUID, String> playerZones = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastPayout = new ConcurrentHashMap<>();
    private final Map<UUID, BossBar> playerBossBars = new ConcurrentHashMap<>();
    private BukkitTask tickTask;

    public AfkZoneManager(UnstableRemixPlugin plugin, ConfigManager configs, EconomyService economy, WorldEditBridge worldEdit) {
        this.plugin = plugin;
        this.configs = configs;
        this.economy = economy;
        this.worldEdit = worldEdit;
    }

    public void loadZones() {
        zones.clear();
        FileConfiguration config = plugin.getConfig();
        ConfigurationSection section = config.getConfigurationSection("afk-zones");
        if (section == null) return;
        for (String name : section.getKeys(false)) {
            ConfigurationSection zone = section.getConfigurationSection(name);
            if (zone == null) continue;
            String worldName = zone.getString("world", "");
            int minX = zone.getInt("min-x");
            int minY = zone.getInt("min-y");
            int minZ = zone.getInt("min-z");
            int maxX = zone.getInt("max-x");
            int maxY = zone.getInt("max-y");
            int maxZ = zone.getInt("max-z");
            long shardsPerInterval = zone.getLong("shards-per-interval", 1);
            long intervalSeconds = zone.getLong("interval-seconds", 60);
            boolean glow = zone.getBoolean("glow", false);
            zones.put(name.toLowerCase(), new AfkZone(name, worldName, minX, minY, minZ, maxX, maxY, maxZ, shardsPerInterval, intervalSeconds, glow));
        }
    }

    public void saveZones() {
        FileConfiguration config = plugin.getConfig();
        config.set("afk-zones", null);
        for (AfkZone zone : zones.values()) {
            String path = "afk-zones." + zone.name();
            config.set(path + ".world", zone.worldName());
            config.set(path + ".min-x", zone.minX());
            config.set(path + ".min-y", zone.minY());
            config.set(path + ".min-z", zone.minZ());
            config.set(path + ".max-x", zone.maxX());
            config.set(path + ".max-y", zone.maxY());
            config.set(path + ".max-z", zone.maxZ());
            config.set(path + ".shards-per-interval", zone.shardsPerInterval());
            config.set(path + ".interval-seconds", zone.intervalSeconds());
            config.set(path + ".glow", zone.glow());
        }
        plugin.saveConfig();
    }

    public void startTasks() {
        stopTasks();
        loadZones();
        tickTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            processPayouts();
            processGlow();
        }, 20L, 20L);
    }

    public void stopTasks() {
        if (tickTask != null) { tickTask.cancel(); tickTask = null; }
        for (Map.Entry<UUID, BossBar> entry : playerBossBars.entrySet()) {
            Player player = Bukkit.getPlayer(entry.getKey());
            if (player != null && player.isOnline()) {
                player.hideBossBar(entry.getValue());
            }
        }
        playerBossBars.clear();
        playerZones.clear();
        lastPayout.clear();
    }

    public boolean createZone(Player player, String name) {
        if (!worldEdit.isAvailable()) {
            player.sendMessage(TextUtil.parse("<red>WorldEdit is required."));
            return false;
        }
        var selection = worldEdit.getSelection(player);
        if (selection.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>Make a WorldEdit selection first."));
            return false;
        }
        String key = name.toLowerCase();
        if (zones.containsKey(key)) {
            player.sendMessage(TextUtil.parse("<red>Zone already exists."));
            return false;
        }
        var sel = selection.get();
        zones.put(key, new AfkZone(name, sel.world(), sel.minX(), sel.minY(), sel.minZ(), sel.maxX(), sel.maxY(), sel.maxZ(), 1, 60, false));
        saveZones();
        player.sendMessage(TextUtil.parse("<green>Created AFK zone <white>" + name + "</white>."));
        return true;
    }

    public boolean deleteZone(Player player, String name) {
        if (zones.remove(name.toLowerCase()) == null) {
            player.sendMessage(TextUtil.parse("<red>Zone not found."));
            return false;
        }
        saveZones();
        player.sendMessage(TextUtil.parse("<green>Deleted AFK zone <white>" + name + "</white>."));
        return true;
    }

    public boolean setShards(String name, long amount) {
        AfkZone zone = zones.get(name.toLowerCase());
        if (zone == null) return false;
        zones.put(name.toLowerCase(), zone.withShardsPerInterval(amount));
        saveZones();
        return true;
    }

    public boolean setInterval(String name, long seconds) {
        AfkZone zone = zones.get(name.toLowerCase());
        if (zone == null) return false;
        zones.put(name.toLowerCase(), zone.withIntervalSeconds(seconds));
        saveZones();
        return true;
    }

    public boolean toggleGlow(String name) {
        AfkZone zone = zones.get(name.toLowerCase());
        if (zone == null) return false;
        zones.put(name.toLowerCase(), zone.withGlow(!zone.glow()));
        saveZones();
        return true;
    }

    public Map<String, AfkZone> getZones() {
        return Map.copyOf(zones);
    }

    private void processPayouts() {
        long now = System.currentTimeMillis();
        for (Player player : Bukkit.getOnlinePlayers()) {
            String zoneName = null;
            AfkZone zone = null;
            for (AfkZone z : zones.values()) {
                if (isInside(player, z)) {
                    zoneName = z.name();
                    zone = z;
                    break;
                }
            }
            String previous = playerZones.get(player.getUniqueId());
            if (zoneName == null) {
                if (previous != null) {
                    player.sendMessage(TextUtil.parse("<gray>You left the AFK zone.</gray>"));
                    removeBossBar(player);
                }
                playerZones.remove(player.getUniqueId());
                lastPayout.remove(player.getUniqueId());
                continue;
            }
            if (previous == null || !previous.equals(zoneName)) {
                player.sendMessage(TextUtil.parse("<gray>AFK ZONE</gray> <dark_gray>\u00BB</dark_gray> <gray>You are earning idle shards.</gray>"));
                player.sendMessage(TextUtil.parse("<gray>Earn <gold>" + zone.shardsPerInterval() + " shards</gold> every <yellow>" + zone.intervalSeconds() + "s</yellow> while you stay here.</gray>"));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1.0F, 1.2F);
                playerZones.put(player.getUniqueId(), zoneName);
                lastPayout.put(player.getUniqueId(), now);
                showAfkTitle(player, zoneName, zone.shardsPerInterval());
                createBossBar(player, zone);
                continue;
            }
            if (zone == null) continue;
            long last = lastPayout.getOrDefault(player.getUniqueId(), now);
            long intervalMs = zone.intervalSeconds() * 1000L;
            long elapsed = now - last;

            if (elapsed >= intervalMs) {
                economy.grantShards(player.getUniqueId(), zone.shardsPerInterval(), "afk:" + zoneName, null);
                showShardEarnTitle(player, zoneName, zone.shardsPerInterval());
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5F, 1.5F);
                lastPayout.put(player.getUniqueId(), now);
                updateBossBarProgress(player, zone.intervalSeconds(), 0);
            } else {
                long remainingSec = (intervalMs - elapsed) / 1000L;
                updateBossBarProgress(player, zone.intervalSeconds(), remainingSec);
            }
        }
    }

    private void createBossBar(Player player, AfkZone zone) {
        removeBossBar(player);
        BossBar bar = BossBar.bossBar(
                Component.text("\u25C6 AFK ZONE \u25C6 " + zone.name() + " \u25C6 Earn " + zone.shardsPerInterval() + " shards every " + zone.intervalSeconds() + "s \u25C6",
                        NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD),
                1.0f,
                BossBar.Color.PURPLE,
                BossBar.Overlay.PROGRESS
        );
        player.showBossBar(bar);
        playerBossBars.put(player.getUniqueId(), bar);
    }

    private void updateBossBarProgress(Player player, long totalSec, long remainingSec) {
        BossBar bar = playerBossBars.get(player.getUniqueId());
        if (bar == null) return;
        float progress = Math.max(0, Math.min(1, (float) (totalSec - remainingSec) / totalSec));
        bar.progress(progress);
        bar.name(Component.text("\u25C6 AFK ZONE \u25C6 Next shard in " + remainingSec + "s \u25C6",
                NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD));
    }

    private void removeBossBar(Player player) {
        BossBar bar = playerBossBars.remove(player.getUniqueId());
        if (bar != null) {
            player.hideBossBar(bar);
        }
    }

    private void showShardEarnTitle(Player player, String zoneName, long shards) {
        player.showTitle(Title.title(
                Component.text("+" + shards + " SHARDS", NamedTextColor.GOLD, TextDecoration.BOLD),
                Component.text("AFK ZONE \u00BB " + zoneName, NamedTextColor.GRAY),
                Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(1500), Duration.ofMillis(300))
        ));
    }

    private void showAfkTitle(Player player, String zoneName, long shards) {
        player.showTitle(Title.title(
                Component.text("AFK ZONE", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD),
                Component.text("YOU HAVE ENTERED THE AFK ZONE", NamedTextColor.GRAY),
                Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(3000), Duration.ofMillis(500))
        ));
    }

    private void processGlow() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            for (AfkZone zone : zones.values()) {
                if (zone.glow() && isInside(player, zone)) {
                    player.spawnParticle(Particle.END_ROD, player.getLocation().add(0, 0.5, 0), 1, 0.3, 0.3, 0.3, 0.01);
                }
            }
        }
    }

    public boolean isInside(Player player, AfkZone zone) {
        if (player == null || !player.isOnline()) return false;
        Location loc = player.getLocation();
        World world = loc.getWorld();
        if (world == null || !world.getName().equals(zone.worldName())) return false;
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();
        return x >= zone.minX() && x <= zone.maxX()
                && y >= zone.minY() && y <= zone.maxY()
                && z >= zone.minZ() && z <= zone.maxZ();
    }

    public record AfkZone(
            String name,
            String worldName,
            int minX, int minY, int minZ,
            int maxX, int maxY, int maxZ,
            long shardsPerInterval,
            long intervalSeconds,
            boolean glow
    ) {
        public AfkZone withShardsPerInterval(long amount) {
            return new AfkZone(name, worldName, minX, minY, minZ, maxX, maxY, maxZ, amount, intervalSeconds, glow);
        }
        public AfkZone withIntervalSeconds(long seconds) {
            return new AfkZone(name, worldName, minX, minY, minZ, maxX, maxY, maxZ, shardsPerInterval, seconds, glow);
        }
        public AfkZone withGlow(boolean g) {
            return new AfkZone(name, worldName, minX, minY, minZ, maxX, maxY, maxZ, shardsPerInterval, intervalSeconds, g);
        }
    }
}