package lol.folium.unstable.command;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.combat.CombatTagManager;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.map.Arena;
import lol.folium.unstable.map.ArenaManager;
import lol.folium.unstable.map.MapVoteManager;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class LobbyCommand implements CommandExecutor {

    private final UnstableRemixPlugin plugin;
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();

    public LobbyCommand(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        CombatTagManager combatTag = plugin.getCombatTagManager();
        if (combatTag != null && combatTag.isTagged(player)) {
            long remaining = combatTag.remainingSeconds(player);
            player.sendMessage(TextUtil.parse(
                    "<red>You are combat-tagged for <yellow>" + remaining + "s</yellow>. Cannot use /lobby.</red>"));
            return true;
        }

        long now = System.currentTimeMillis();
        Long lastUse = cooldowns.get(player.getUniqueId());
        if (lastUse != null && now - lastUse < 3000) {
            long remaining = (3000 - (now - lastUse)) / 1000 + 1;
            player.sendMessage(TextUtil.parse("<red>Please wait <yellow>" + remaining + "s</yellow> before using /lobby again.</red>"));
            return true;
        }

        // Remove player from active arena
        ArenaManager arenaManager = plugin.getArenaManager();
        MapVoteManager mapVotes = plugin.getMapVoteManager();
        if (arenaManager != null) {
            for (Arena arena : arenaManager.all()) {
                if (arena.players().remove(player.getUniqueId())) {
                    break;
                }
            }
        }

        // Clear combat tag
        if (combatTag != null) {
            combatTag.untag(player);
        }

        Location target = null;
        ConfigManager cfg = plugin.getConfigManager();
        if (cfg != null) {
            target = cfg.readLobby();
        }
        if (target == null || target.getWorld() == null) {
            World world = plugin.getServer().getWorlds().get(0);
            if (world != null) {
                target = world.getSpawnLocation();
            }
        }

        if (target == null || target.getWorld() == null) {
            player.sendMessage(TextUtil.parse("<red>Lobby location not set. Use /map setlobby to configure it.</red>"));
            return true;
        }

        cooldowns.put(player.getUniqueId(), now);
        player.teleport(target);
        player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0F, 1.0F);
        player.sendMessage(TextUtil.parse("<green>Teleported to lobby!</green>"));
        return true;
    }
}
