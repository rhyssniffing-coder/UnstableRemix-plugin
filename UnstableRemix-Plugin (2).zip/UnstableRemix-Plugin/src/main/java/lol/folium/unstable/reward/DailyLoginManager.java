package lol.folium.unstable.reward;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.data.PlayerDataStore;
import lol.folium.unstable.data.PlayerProfile;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class DailyLoginManager {

    private static final List<String> TRACKS = List.of("daily", "weekly", "monthly", "lifetime");
    private static final int DAYS = 5;
    private static final int COLLECT_ALL_SLOT = 40;

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final PlayerDataStore store;
    private final EconomyService economy;

    public DailyLoginManager(UnstableRemixPlugin plugin, ConfigManager configs, PlayerDataStore store, EconomyService economy) {
        this.plugin = plugin;
        this.configs = configs;
        this.store = store;
        this.economy = economy;
    }

    public void processLogin(Player player) {
        FileConfiguration cfg = plugin.getConfig();
        if (!cfg.getBoolean("daily-login.enabled", true)) return;
        PlayerProfile profile = store.get(player.getUniqueId());
        String today = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
        String lastLogin = profile.lastLoginDate();
        if (today.equals(lastLogin)) return;
        if (lastLogin != null) {
            LocalDate last = LocalDate.parse(lastLogin);
            LocalDate yesterday = LocalDate.now().minusDays(1);
            if (last.equals(yesterday)) {
                profile.setLoginStreak(profile.loginStreak() + 1);
            } else {
                profile.setLoginStreak(1);
            }
        } else {
            profile.setLoginStreak(1);
        }
        profile.setLastLoginDate(today);
        store.saveProfile(profile);
    }

    public void openGui(Player player) {
        ConfigurationSection guiCfg = plugin.getConfig().getConfigurationSection("daily-login.gui");
        String title = guiCfg != null ? guiCfg.getString("title", "<gradient:#FFD700:#FFAA00>Login Rewards</gradient>") : "<gradient:#FFD700:#FFAA00>Login Rewards</gradient>";
        int rows = guiCfg != null ? guiCfg.getInt("rows", 6) : 6;

        DailyLoginHolder holder = new DailyLoginHolder(player);
        Inventory inventory = Bukkit.createInventory(holder, rows * 9, TextUtil.parse(title));
        holder.bind(inventory);
        paintAll(player, inventory, holder, "daily");
        player.openInventory(inventory);
    }

    private void paintAll(Player player, Inventory inventory, DailyLoginHolder holder, String selectedTrack) {
        PlayerProfile profile = store.get(player.getUniqueId());
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE).name(Component.empty()).build());
        }
        paintTabs(inventory, holder, selectedTrack);
        paintDays(player, inventory, holder, selectedTrack, profile);
        paintCollectAll(inventory, holder, selectedTrack, profile);
    }

    private void paintTabs(Inventory inventory, DailyLoginHolder holder, String selectedTrack) {
        int[] tabSlots = {2, 3, 4, 5};
        for (int i = 0; i < TRACKS.size(); i++) {
            String track = TRACKS.get(i);
            int slot = i < tabSlots.length ? tabSlots[i] : (i + 10);
            boolean selected = track.equals(selectedTrack);
            Material mat = switch (track) {
                case "weekly" -> Material.SUNFLOWER;
                case "monthly" -> Material.AMETHYST_SHARD;
                case "lifetime" -> Material.NETHER_STAR;
                default -> Material.CLOCK;
            };
            String name = selected
                    ? "<gradient:#FF4444:#FF8800:#FFD700><bold>\u25B6 " + capitalize(track) + " \u25C0</bold></gradient>"
                    : "<dark_gray>" + capitalize(track) + "</dark_gray>";
            inventory.setItem(slot, ItemBuilder.of(mat).name(TextUtil.parse(name)).build());
            holder.tabSlots.put(slot, track);
        }
    }

    private void paintDays(Player player, Inventory inventory, DailyLoginHolder holder, String track, PlayerProfile profile) {
        int streak = track.equals("daily") ? Math.min(profile.loginStreak(), DAYS) : DAYS;
        int[] daySlots = {19, 20, 21, 22, 23, 24, 25};

        for (int day = 1; day <= DAYS; day++) {
            int slot = day <= daySlots.length ? daySlots[day - 1] : (day + 18);
            String claimKey = "dailylogin:" + track + ":" + day;
            boolean claimed = profile.claimedQuests().contains(claimKey);
            boolean claimable = day <= streak && !claimed;

            long shards = getTrackReward(track, day, "shards", 0L);
            long tokens = getTrackReward(track, day, "tokens", 0L);

            Material mat;
            String name;
            List<Component> lore = new ArrayList<>();

            if (claimed) {
                mat = Material.LIME_DYE;
                name = "<gradient:#FF4444:#FF8800:#FFD700><bold>\u2714 Day " + day + "</bold></gradient>";
                lore.add(TextUtil.parse("<gray>Claimed!</gray>"));
            } else if (claimable) {
                mat = Material.GOLD_NUGGET;
                name = "<gradient:#FF4444:#FF8800:#FFD700><bold>Day " + day + "</bold></gradient>";
                lore.add(TextUtil.parse("<green>Click to claim!</green>"));
            } else if (!track.equals("daily")) {
                mat = Material.GOLD_NUGGET;
                name = "<gradient:#FF4444:#FF8800:#FFD700><bold>Day " + day + "</bold></gradient>";
                lore.add(TextUtil.parse("<green>Click to claim!</green>"));
                claimable = true;
            } else {
                mat = Material.GRAY_DYE;
                name = "<dark_gray>Day " + day + "</dark_gray>";
                lore.add(TextUtil.parse("<gray>Login streak " + profile.loginStreak() + "/" + day + "</gray>"));
            }

            if (shards > 0) lore.add(TextUtil.parse("<light_purple>" + shards + " Shards</light_purple>"));
            if (tokens > 0) lore.add(TextUtil.parse("<aqua>" + tokens + " Tokens</aqua>"));

            inventory.setItem(slot, ItemBuilder.of(mat).name(TextUtil.parse(name)).lore(lore).build());
            if (claimable) holder.claimableSlots.put(slot, new ClaimInfo(track, day, shards, tokens));
        }
    }

    private void paintCollectAll(Inventory inventory, DailyLoginHolder holder, String track, PlayerProfile profile) {
        int streak = track.equals("daily") ? Math.min(profile.loginStreak(), DAYS) : DAYS;
        int claimable = 0;
        for (int day = 1; day <= DAYS; day++) {
            if (day > streak) continue;
            String claimKey = "dailylogin:" + track + ":" + day;
            if (!profile.claimedQuests().contains(claimKey)) claimable++;
        }
        if (claimable > 0) {
            inventory.setItem(COLLECT_ALL_SLOT, ItemBuilder.of(Material.HOPPER)
                    .name(TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700><bold>\u2714 COLLECT ALL (" + claimable + ")</bold></gradient>"))
                    .lore(List.of(TextUtil.parse("<gray>Claim all available rewards</gray>")))
                    .build());
            holder.collectAllTrack = track;
        }
    }

    private void claimDay(Player player, String track, int day, long shards, long tokens) {
        String claimKey = "dailylogin:" + track + ":" + day;
        PlayerProfile profile = store.get(player.getUniqueId());
        if (profile.claimedQuests().contains(claimKey)) {
            player.sendMessage(TextUtil.parse("<red>Already claimed.</red>"));
            return;
        }
        if (shards > 0) economy.grantShards(player.getUniqueId(), shards, "daily-login:" + track + ":" + day, null);
        if (tokens > 0) economy.grantTokens(player.getUniqueId(), tokens, "daily-login:" + track + ":" + day, "dailylogin-token:" + player.getUniqueId() + ":" + claimKey);
        profile.claimedQuests().add(claimKey);
        store.saveProfile(profile);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
        openGui(player);
    }

    private void claimAll(Player player, String track) {
        PlayerProfile profile = store.get(player.getUniqueId());
        int streak = track.equals("daily") ? Math.min(profile.loginStreak(), DAYS) : DAYS;
        long totalShards = 0;
        long totalTokens = 0;
        int count = 0;
        for (int day = 1; day <= DAYS && day <= streak; day++) {
            String claimKey = "dailylogin:" + track + ":" + day;
            if (profile.claimedQuests().contains(claimKey)) continue;
            totalShards += getTrackReward(track, day, "shards", 0L);
            totalTokens += getTrackReward(track, day, "tokens", 0L);
            profile.claimedQuests().add(claimKey);
            count++;
        }
        if (count == 0) {
            player.sendMessage(TextUtil.parse("<red>Nothing to claim.</red>"));
            return;
        }
        if (totalShards > 0) economy.grantShards(player.getUniqueId(), totalShards, "daily-login:" + track + ":collect-all", null);
        if (totalTokens > 0) economy.grantTokens(player.getUniqueId(), totalTokens, "daily-login:" + track + ":collect-all", null);
        store.saveProfile(profile);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
        player.sendMessage(TextUtil.parse("<green>Claimed " + count + " rewards!</green>"));
        openGui(player);
    }

    private long getTrackReward(String track, int day, String key, long fallback) {
        return plugin.getConfig().getLong("daily-login.tracks." + track + ".day" + day + "." + key, fallback);
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private final class DailyLoginHolder extends GuiHolder {
        private final Player player;
        private final Map<Integer, String> tabSlots = new HashMap<>();
        private final Map<Integer, ClaimInfo> claimableSlots = new HashMap<>();
        private String collectAllTrack;

        DailyLoginHolder(Player player) {
            this.player = player;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            if (slot < 0 || slot >= event.getInventory().getSize()) return;

            String tab = tabSlots.get(slot);
            if (tab != null) {
                paintAll(player, event.getInventory(), this, tab);
                return;
            }

            ClaimInfo info = claimableSlots.get(slot);
            if (info != null) {
                claimDay(player, info.track, info.day, info.shards, info.tokens);
                return;
            }

            if (slot == COLLECT_ALL_SLOT && collectAllTrack != null) {
                claimAll(player, collectAllTrack);
            }
        }
    }

    private record ClaimInfo(String track, int day, long shards, long tokens) {}
}
