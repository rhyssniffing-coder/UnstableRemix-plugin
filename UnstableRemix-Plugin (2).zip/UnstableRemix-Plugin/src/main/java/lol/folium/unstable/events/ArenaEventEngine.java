package lol.folium.unstable.events;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.faction.FactionManager;
import lol.folium.unstable.map.Arena;
import lol.folium.unstable.map.ArenaManager;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ArenaEventEngine {

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final ArenaManager arenaManager;
    private final FactionManager factionManager;
    private final Map<String, ActiveEvent> activeEvents = new ConcurrentHashMap<>();
    private final Map<UUID, PlayerEventProgress> playerProgress = new ConcurrentHashMap<>();
    private final Map<UUID, String> ctfZoneHolder = new ConcurrentHashMap<>();
    private final Random random = new Random();
    private BukkitTask schedulerTask;
    private BossBar ctfBossBar;

    public ArenaEventEngine(UnstableRemixPlugin plugin, ConfigManager configs, ArenaManager arenaManager, FactionManager factionManager) {
        this.plugin = plugin;
        this.configs = configs;
        this.arenaManager = arenaManager;
        this.factionManager = factionManager;
    }

    public void startAutomaticSchedule() {
        if (!configs.main().getBoolean("arena-events.enabled", true)) {
            plugin.getLogger().info("[ArenaEvents] Arena events disabled in config.");
            return;
        }

        long intervalTicks = configs.main().getLong("arena-events.check-interval-ticks", 200L);
        plugin.getLogger().info("[ArenaEvents] Starting automatic schedule, check interval: " + intervalTicks + " ticks");
        schedulerTask = Bukkit.getScheduler().runTaskTimer(plugin, this::checkAndTriggerEvents, intervalTicks, intervalTicks);
    }

    private void checkAndTriggerEvents() {
        if (arenaManager.all().isEmpty()) {
            return;
        }

        if (!activeEvents.isEmpty()) {
            return;
        }

        List<EventType> candidates = new ArrayList<>();
        for (EventType eventType : EventType.values()) {
            if (!isEventEnabled(eventType)) continue;
            if (!hasAvailableArena(eventType)) continue;

            long intervalMinutes = configs.main().getLong("arena-events." + eventType.configKey() + ".interval-minutes", 30L);
            long lastTrigger = getLastTriggerTime(eventType);
            long elapsedMinutes = (System.currentTimeMillis() - lastTrigger) / (60 * 1000);

            if (elapsedMinutes >= intervalMinutes) {
                candidates.add(eventType);
            }
        }

        if (!candidates.isEmpty()) {
            Collections.shuffle(candidates, random);
            triggerEvent(candidates.get(0));
        }
    }

    private boolean hasAvailableArena(EventType eventType) {
        String arenaName = configs.main().getString("arena-events." + eventType.configKey() + ".arena", "");
        if (arenaName != null && !arenaName.isBlank() && arenaManager.exists(arenaName)) {
            return true;
        }
        return !arenaManager.all().isEmpty();
    }

    public void triggerEvent(EventType eventType) {
        if (activeEvents.containsKey(eventType.id())) {
            return;
        }

        Location location = selectRandomLocation(eventType);
        if (location == null) {
            plugin.getLogger().warning("[ArenaEvents] Cannot trigger " + eventType.displayName() + ": no arenas available");
            return;
        }

        ActiveEvent activeEvent = new ActiveEvent(eventType, location, System.currentTimeMillis());
        activeEvents.put(eventType.id(), activeEvent);
        setLastTriggerTime(eventType, System.currentTimeMillis());

        spawnEventBlock(activeEvent);
        broadcastEventStart(eventType, location);
        startEventVisuals(activeEvent);
        startEventTracking(activeEvent);

        long durationSeconds = configs.main().getLong("arena-events." + eventType.configKey() + ".duration-seconds", 120L);
        Bukkit.getScheduler().runTaskLater(plugin, () -> endEvent(eventType), durationSeconds * 20L);

        plugin.getLogger().info("[ArenaEvents] Triggered " + eventType.displayName() + " at " + location.getBlockX() + "," + location.getBlockY() + "," + location.getBlockZ());
    }

    private void spawnEventBlock(ActiveEvent activeEvent) {
        if (activeEvent.type() == EventType.OBELISK_OVERLOAD) {
            activeEvent.location().getBlock().setType(Material.END_ROD);
            activeEvent.location().add(0, 1, 0).getBlock().setType(Material.BEACON);
        } else if (activeEvent.type() == EventType.SUPPLY_DROP) {
            activeEvent.location().getBlock().setType(Material.CHEST);
        }
    }

    private Location selectRandomLocation(EventType eventType) {
        String arenaName = configs.main().getString("arena-events." + eventType.configKey() + ".arena", "");
        Arena arena;

        if (arenaName != null && !arenaName.isBlank() && arenaManager.exists(arenaName)) {
            arena = arenaManager.get(arenaName).orElse(null);
        } else {
            var arenas = new java.util.ArrayList<>(arenaManager.all());
            if (arenas.isEmpty()) return null;
            arena = arenas.get(random.nextInt(arenas.size()));
        }

        if (arena == null) return null;

        int minX = arena.minX();
        int maxX = arena.maxX();
        int minZ = arena.minZ();
        int maxZ = arena.maxZ();
        int minY = arena.minY();
        int maxY = arena.maxY();

        if (maxX <= minX || maxZ <= minZ || maxY <= minY) return null;

        int randomX = minX + random.nextInt(maxX - minX + 1);
        int randomZ = minZ + random.nextInt(maxZ - minZ + 1);
        int randomY = minY + random.nextInt(maxY - minY + 1);

        return new Location(arena.world(), randomX, randomY, randomZ);
    }

    private void broadcastEventStart(EventType eventType, Location location) {
        String prefix = "arena-events." + eventType.configKey() + ".";
        String title = configs.main().getString(prefix + "title",
                "<yellow><bold>" + eventType.displayName() + "</bold></yellow>");
        String subtitle = configs.main().getString(prefix + "subtitle",
                "<gray>Hold the zone for 30 seconds!</gray>");
        String actionBar = configs.main().getString(prefix + "action-bar",
                "<gold>" + eventType.displayName() + " has spawned!</gold>");
        String soundKey = configs.main().getString(prefix + "start-sound", "BLOCK_NOTE_BLOCK_PLING");
        float volume = (float) configs.main().getDouble(prefix + "sound-volume", 1.0);
        float pitch = (float) configs.main().getDouble(prefix + "sound-pitch", 1.0);
        Sound sound;
        try {
            sound = Sound.valueOf(soundKey);
        } catch (IllegalArgumentException e) {
            sound = Sound.BLOCK_NOTE_BLOCK_PLING;
        }

        Title titleObj = Title.title(
                TextUtil.parse(title),
                TextUtil.parse(subtitle),
                Title.Times.times(Duration.ofSeconds(1), Duration.ofSeconds(5), Duration.ofSeconds(1))
        );

        String broadcastMsg = configs.main().getString(prefix + "broadcast",
                "<gold><bold>" + eventType.displayName() + "</bold></gold> <gray>has spawned in the arena! Go hold the zone!</gray>");

        for (Player player : Bukkit.getOnlinePlayers()) {
            player.showTitle(titleObj);
            player.sendActionBar(TextUtil.parse(actionBar));
            player.playSound(player.getLocation(), sound, volume, pitch);
        }
        Bukkit.broadcast(TextUtil.parse(broadcastMsg));
    }

    private void startEventVisuals(ActiveEvent activeEvent) {
        String particleType = configs.main().getString("arena-events." + activeEvent.type().configKey() + ".particle", "DRAGON_BREATH");
        int particleCount = configs.main().getInt("arena-events." + activeEvent.type().configKey() + ".particle-count", 10);
        double offsetX = configs.main().getDouble("arena-events." + activeEvent.type().configKey() + ".offset-x", 1.5);
        double offsetY = configs.main().getDouble("arena-events." + activeEvent.type().configKey() + ".offset-y", 1.5);
        double offsetZ = configs.main().getDouble("arena-events." + activeEvent.type().configKey() + ".offset-z", 1.5);

        Particle particle;
        try {
            particle = Particle.valueOf(particleType);
        } catch (IllegalArgumentException e) {
            particle = Particle.DRAGON_BREATH;
        }

        final Particle finalParticle = particle;
        activeEvent.visualTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!activeEvents.containsKey(activeEvent.type().id())) return;
            Location loc = activeEvent.location();
            org.bukkit.World world = loc.getWorld();
            if (world == null) return;

            switch (activeEvent.type()) {
                case JACKPOT_HOTSPOT -> {
                    int baseX = loc.getBlockX();
                    int baseY = loc.getBlockY();
                    int baseZ = loc.getBlockZ();
                    for (int x = -1; x <= 1; x++) {
                        for (int z = -1; z <= 1; z++) {
                            world.spawnParticle(finalParticle, baseX + x + 0.5, baseY, baseZ + z + 0.5, particleCount, offsetX, offsetY, offsetZ, 0.01);
                        }
                    }
                }
                case SUPPLY_DROP -> {
                    world.spawnParticle(finalParticle, loc, particleCount, 0.5, 5, 0.5, 0.05);
                    world.spawnParticle(Particle.SMOKE, loc, 20, 1, 0, 1, 0.02);
                }
                case OBELISK_OVERLOAD -> {
                    world.spawnParticle(finalParticle, loc, particleCount, 1, 2, 1, 0.05);
                    world.spawnParticle(Particle.ENCHANT, loc.clone().add(0, 1, 0), 30, 0.5, 1, 0.5, 0.5);
                }
                case CAPTURE_THE_FLAG -> {
                    int baseX = loc.getBlockX();
                    int baseY = loc.getBlockY();
                    int baseZ = loc.getBlockZ();
                    for (int x = -2; x <= 2; x++) {
                        for (int z = -2; z <= 2; z++) {
                            world.spawnParticle(Particle.ENCHANT, baseX + x + 0.5, baseY + 0.1, baseZ + z + 0.5, 3, 0.5, 0.3, 0.5, 0.1);
                        }
                    }
                    world.spawnParticle(Particle.REVERSE_PORTAL, loc.clone().add(0, 3, 0), 50, 1.5, 1.5, 1.5, 0.1);
                }
            }
        }, 0L, 10L);
    }

    private void startEventTracking(ActiveEvent activeEvent) {
        long checkInterval = configs.main().getLong("arena-events.tracking-interval-ticks", 10L);
        double radius = configs.main().getDouble("arena-events." + activeEvent.type().configKey() + ".radius", 5.0);
        double radiusSq = radius * radius;

        if (activeEvent.type() == EventType.CAPTURE_THE_FLAG) {
            startCtfTracking(activeEvent, checkInterval, radius, radiusSq);
            return;
        }

        activeEvent.trackingTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!activeEvents.containsKey(activeEvent.type().id())) return;

            boolean anyoneInZone = false;
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (activeEvent.location().distanceSquared(player.getLocation()) > radiusSq) {
                    continue;
                }
                anyoneInZone = true;

                PlayerEventProgress progress = playerProgress.get(player.getUniqueId());
                if (progress == null || !progress.eventType().equals(activeEvent.type())) {
                    startPlayerProgress(player, activeEvent.type());
                    progress = playerProgress.get(player.getUniqueId());
                    if (progress == null) continue;
                }

                progress.incrementProgress(checkInterval / 20.0);
                if (progress.progressSeconds() >= 30) {
                    completeEvent(player, activeEvent);
                    return;
                }
            }

            if (!anyoneInZone) {
                activeEvent.setNoOneInZone(true);
            } else {
                activeEvent.setNoOneInZone(false);
            }
        }, checkInterval, checkInterval);
    }

    private void startCtfTracking(ActiveEvent activeEvent, long checkInterval, double radius, double radiusSq) {
        ctfZoneHolder.clear();
        float[] smoothProgress = {0f};
        String[] leadingFactionHolder = {null};

        ctfBossBar = BossBar.bossBar(
                Component.empty(), 0.0f, BossBar.Color.PURPLE, BossBar.Overlay.PROGRESS);
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.showBossBar(ctfBossBar);
        }

        activeEvent.trackingTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!activeEvents.containsKey(activeEvent.type().id())) return;

            Map<String, Double> factionPresence = new ConcurrentHashMap<>();
            double totalPresence = 0;

            for (Player player : Bukkit.getOnlinePlayers()) {
                if (activeEvent.location().distanceSquared(player.getLocation()) > radiusSq) {
                    ctfZoneHolder.remove(player.getUniqueId());
                    continue;
                }

                String faction = factionManager != null ? factionManager.getFactionName(player) : null;
                if (faction == null) continue;

                factionPresence.merge(faction, 1.0, Double::sum);
                totalPresence += 1.0;
                ctfZoneHolder.put(player.getUniqueId(), faction);
            }

            if (totalPresence == 0) {
                smoothProgress[0] = Math.max(0f, smoothProgress[0] - 0.02f);
                ctfBossBar.progress(smoothProgress[0]);
                ctfBossBar.name(TextUtil.parse("<dark_purple><bold>Capture the Zone</bold></dark_purple> <gray>|</gray> <white>No one in zone</white>"));
                for (Player p : Bukkit.getOnlinePlayers()) {
                    p.showBossBar(ctfBossBar);
                }
                return;
            }

            String leadingFaction = null;
            double leadingPresence = 0;
            for (Map.Entry<String, Double> entry : factionPresence.entrySet()) {
                if (entry.getValue() > leadingPresence) {
                    leadingPresence = entry.getValue();
                    leadingFaction = entry.getKey();
                }
            }

            if (leadingFaction == null) return;

            double pct = leadingPresence / totalPresence;
            float targetProgress = (float) Math.min(1.0, pct);

            float speed = 0.05f;
            if (targetProgress > smoothProgress[0]) {
                smoothProgress[0] = Math.min(targetProgress, smoothProgress[0] + speed);
            } else if (targetProgress < smoothProgress[0]) {
                smoothProgress[0] = Math.max(targetProgress, smoothProgress[0] - speed);
            }
            leadingFactionHolder[0] = leadingFaction;

            ctfBossBar.progress(smoothProgress[0]);
            ctfBossBar.name(TextUtil.parse(
                    "<dark_purple><bold>Capture the Zone</bold></dark_purple> <gray>|</gray> "
                            + "<white>" + capitalize(leadingFactionHolder[0]) + "</white> <gray>control: </gray>"
                            + "<light_purple>" + String.format("%.0f", smoothProgress[0] * 100) + "%</light_purple> <gray>|</gray> "
                            + "<aqua>" + (int) leadingPresence + " players</aqua>"
            ));

            for (Player p : Bukkit.getOnlinePlayers()) {
                p.showBossBar(ctfBossBar);
            }

            if (smoothProgress[0] >= 0.8f) {
                String winFaction = leadingFactionHolder[0];
                completeCtfEvent(activeEvent, winFaction);
            }
        }, checkInterval, checkInterval);
    }

    private void completeCtfEvent(ActiveEvent activeEvent, String winningFaction) {
        endEvent(activeEvent.type());
        long reward = configs.main().getLong("arena-events.capture_the_flag.shard-reward", 50);

        int membersRewarded = 0;
        if (factionManager != null) {
            var factionOpt = factionManager.getFaction(winningFaction);
            if (factionOpt.isPresent()) {
                for (var member : factionOpt.get().members()) {
                    Player p = Bukkit.getPlayer(member.uuid());
                    if (p != null && p.isOnline()) {
                        plugin.getEconomyService().grantShards(p.getUniqueId(), reward, "ctf_win", null);
                        p.sendMessage(TextUtil.parse("<gold><bold>Capture the Zone</bold></gold> <gray>Your faction won! +" + reward + " shards</gray>"));
                        membersRewarded++;
                    }
                }
            }
        }

        Bukkit.broadcast(TextUtil.parse("<gold><bold>" + capitalize(winningFaction) + "</bold></gold> <gray>won the Capture the Zone event! +" + reward + " shards to all members.</gray>"));
        spawnCompletionParticles(activeEvent.location());
    }

    private void resetCtfBossBar() {
        if (ctfBossBar != null) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.hideBossBar(ctfBossBar);
            }
            ctfBossBar = null;
        }
    }

    public void startPlayerProgress(Player player, EventType eventType) {
        playerProgress.put(player.getUniqueId(), new PlayerEventProgress(eventType, 0));
    }

    public void resetPlayerProgress(Player player) {
        playerProgress.remove(player.getUniqueId());
    }

    private void completeEvent(Player player, ActiveEvent activeEvent) {
        resetPlayerProgress(player);
        endEvent(activeEvent.type());

        long reward = configs.main().getLong("arena-events." + activeEvent.type().configKey() + ".shard-reward", 50);
        plugin.getEconomyService().grantShards(player.getUniqueId(), reward,
                "arena_event:" + activeEvent.type().id(), null);

        String message = configs.main().getString("arena-events." + activeEvent.type().configKey() + ".completion-message",
                "<green><bold>" + player.getName() + " completed " + activeEvent.type().displayName() + "!</bold></green>");
        Bukkit.broadcast(TextUtil.parse(message.replace("{player}", player.getName())));

        spawnCompletionParticles(activeEvent.location());
    }

    private void spawnCompletionParticles(Location location) {
        if (location.getWorld() == null) return;
        location.getWorld().spawnParticle(Particle.EXPLOSION, location, 5, 0, 0, 0, 0);
        location.getWorld().spawnParticle(Particle.END_ROD, location, 30, 2, 2, 2, 0.1);
    }

    public void endEvent(EventType eventType) {
        ActiveEvent activeEvent = activeEvents.remove(eventType.id());
        if (activeEvent == null) return;

        if (activeEvent.visualTask != null) activeEvent.visualTask.cancel();
        if (activeEvent.trackingTask != null) activeEvent.trackingTask.cancel();

        restoreEventState(activeEvent);
        resetCtfBossBar();

        for (Map.Entry<UUID, PlayerEventProgress> entry : playerProgress.entrySet()) {
            if (entry.getValue().eventType().equals(eventType)) {
                playerProgress.remove(entry.getKey());
            }
        }
    }

    private void restoreEventState(ActiveEvent activeEvent) {
        if (activeEvent.type() == EventType.OBELISK_OVERLOAD) {
            activeEvent.location().getBlock().setType(activeEvent.originalBlock());
            activeEvent.location().add(0, 1, 0).getBlock().setType(Material.AIR);
        } else if (activeEvent.type() == EventType.SUPPLY_DROP) {
            activeEvent.location().getBlock().setType(activeEvent.originalBlock());
        }
    }

    public void stop() {
        if (schedulerTask != null) {
            schedulerTask.cancel();
            schedulerTask = null;
        }
        for (EventType eventType : EventType.values()) {
            endEvent(eventType);
        }
        activeEvents.clear();
        playerProgress.clear();
        ctfZoneHolder.clear();
        resetCtfBossBar();
    }

    public void reload() {
        stop();
        startAutomaticSchedule();
    }

    private long getLastTriggerTime(EventType eventType) {
        return plugin.getConfig().getLong("arena-events.last-trigger." + eventType.id(), 0L);
    }

    private void setLastTriggerTime(EventType eventType, long time) {
        plugin.getConfig().set("arena-events.last-trigger." + eventType.id(), time);
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> plugin.saveConfig());
    }

    public Map<String, ActiveEvent> getActiveEvents() {
        return new ConcurrentHashMap<>(activeEvents);
    }

    public Optional<EventType> findEventAt(Location location) {
        for (ActiveEvent ae : activeEvents.values()) {
            if (ae.location().getBlockX() == location.getBlockX()
                    && ae.location().getBlockY() == location.getBlockY()
                    && ae.location().getBlockZ() == location.getBlockZ()
                    && ae.location().getWorld() != null
                    && ae.location().getWorld().equals(location.getWorld())) {
                return Optional.of(ae.type());
            }
        }
        return Optional.empty();
    }

    public boolean isEventActive(EventType eventType) {
        return activeEvents.containsKey(eventType.id());
    }

    public boolean isEventEnabled(EventType eventType) {
        return configs.main().getBoolean("arena-events." + eventType.configKey() + ".enabled", true);
    }

    public void toggleEvent(EventType eventType) {
        boolean current = isEventEnabled(eventType);
        configs.main().set("arena-events." + eventType.configKey() + ".enabled", !current);
        plugin.saveConfig();
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }

    private static class ActiveEvent {
        private final EventType type;
        private final Location location;
        private final long startTime;
        private BukkitTask visualTask;
        private BukkitTask trackingTask;
        private final Material originalBlock;
        private boolean noOneInZone = true;

        ActiveEvent(EventType type, Location location, long startTime) {
            this.type = type;
            this.location = location;
            this.startTime = startTime;
            this.originalBlock = location.getBlock().getType();
        }

        EventType type() { return type; }
        Location location() { return location; }
        long startTime() { return startTime; }
        Material originalBlock() { return originalBlock; }
        boolean isNoOneInZone() { return noOneInZone; }
        void setNoOneInZone(boolean v) { this.noOneInZone = v; }
    }

    private static class PlayerEventProgress {
        private final EventType eventType;
        private double progressSeconds;

        PlayerEventProgress(EventType eventType, double progressSeconds) {
            this.eventType = eventType;
            this.progressSeconds = progressSeconds;
        }

        void incrementProgress(double seconds) { progressSeconds += seconds; }
        EventType eventType() { return eventType; }
        double progressSeconds() { return progressSeconds; }
    }

    public enum EventType {
        JACKPOT_HOTSPOT("jackpot_hotspot", "Shard Jackpot Hot Spot"),
        SUPPLY_DROP("supply_drop", "Supply Drop"),
        OBELISK_OVERLOAD("obelisk_overload", "Obelisk Overload"),
        CAPTURE_THE_FLAG("capture_the_flag", "Capture the Zone");

        private final String id;
        private final String displayName;

        EventType(String id, String displayName) {
            this.id = id;
            this.displayName = displayName;
        }

        public String id() { return id; }
        public String displayName() { return displayName; }
        public String configKey() { return id; }
    }
}
