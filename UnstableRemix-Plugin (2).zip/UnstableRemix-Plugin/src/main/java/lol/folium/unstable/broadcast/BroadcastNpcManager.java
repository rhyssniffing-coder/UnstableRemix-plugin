package lol.folium.unstable.broadcast;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class BroadcastNpcManager {

    private static final String CONFIG_FILE = "broadcastnpc.yml";

    private final UnstableRemixPlugin plugin;
    private final Map<String, BroadcastNpc> npcs = new LinkedHashMap<>();
    private final Map<String, Object> citizensNpcs = new LinkedHashMap<>();
    private int taskId = -1;
    private boolean citizensAvailable;

    private Method npcGetId;
    private Method npcGetEntity;
    private Method npcDestroy;
    private Method registryCreateNpc;
    private Method registryGetNpc;
    private Method npcSpawn;
    private Method npcSetName;
    private Object npcRegistry;

    public BroadcastNpcManager(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    public void init() {
        citizensAvailable = plugin.getServer().getPluginManager().getPlugin("Citizens") != null;
        if (citizensAvailable) {
            try {
                Class<?> apiClass = Class.forName("net.citizensnpcs.api.CitizensAPI");
                npcRegistry = apiClass.getMethod("getNPCRegistry").invoke(null);
                Class<?> registryClass = Class.forName("net.citizensnpcs.api.npc.NPCRegistry");
                Class<?> npcClass = Class.forName("net.citizensnpcs.api.npc.NPC");
                registryCreateNpc = registryClass.getMethod("createNPC", org.bukkit.entity.EntityType.class, String.class);
                registryGetNpc = registryClass.getMethod("getById", int.class);
                npcGetId = npcClass.getMethod("getId");
                npcGetEntity = npcClass.getMethod("getEntity");
                npcDestroy = npcClass.getMethod("destroy");
                npcSpawn = npcClass.getMethod("spawn", org.bukkit.Location.class);
                npcSetName = npcClass.getMethod("setName", String.class);
            } catch (ReflectiveOperationException e) {
                plugin.getLogger().warning("Citizens reflection failed: " + e.getMessage());
                citizensAvailable = false;
            }
        }
        loadAll();
        spawnAll();
        startBroadcastTask();
    }

    public void shutdown() {
        if (taskId >= 0) {
            Bukkit.getScheduler().cancelTask(taskId);
            taskId = -1;
        }
        despawnAll();
        npcs.clear();
        citizensNpcs.clear();
    }

    public void loadAll() {
        npcs.clear();
        FileConfiguration config = plugin.getConfigManager().get(CONFIG_FILE);
        ConfigurationSection section = config.getConfigurationSection("npcs");
        if (section == null) return;
        for (String id : section.getKeys(false)) {
            ConfigurationSection entry = section.getConfigurationSection(id);
            if (entry == null) continue;
            String worldName = entry.getString("world");
            if (worldName == null) continue;
            World world = Bukkit.getWorld(worldName);
            if (world == null) continue;
            BroadcastNpc npc = new BroadcastNpc(
                    id,
                    new Location(world, entry.getDouble("x"), entry.getDouble("y"), entry.getDouble("z"),
                            (float) entry.getDouble("yaw"), (float) entry.getDouble("pitch")),
                    entry.getString("message", "<gold>Welcome!</gold>"),
                    entry.getInt("interval", 120),
                    entry.getInt("citizens_npc_id", -1)
            );
            npcs.put(id, npc);
        }
    }

    public void saveAll() {
        FileConfiguration config = plugin.getConfigManager().get(CONFIG_FILE);
        config.set("npcs", null);
        for (BroadcastNpc npc : npcs.values()) {
            String path = "npcs." + npc.id + ".";
            config.set(path + "world", npc.location.getWorld().getName());
            config.set(path + "x", npc.location.getX());
            config.set(path + "y", npc.location.getY());
            config.set(path + "z", npc.location.getZ());
            config.set(path + "yaw", (double) npc.location.getYaw());
            config.set(path + "pitch", (double) npc.location.getPitch());
            config.set(path + "message", npc.message);
            config.set(path + "interval", npc.interval);
            config.set(path + "citizens_npc_id", npc.citizensNpcId);
        }
        try {
            plugin.getConfigManager().save(CONFIG_FILE);
        } catch (java.io.IOException e) {
            plugin.getLogger().severe("Failed to save broadcast NPCs: " + e.getMessage());
        }
    }

    public void spawnAll() {
        if (!citizensAvailable) return;
        for (BroadcastNpc npc : npcs.values()) {
            spawnCitizensNpc(npc);
        }
    }

    public void despawnAll() {
        if (!citizensAvailable) return;
        for (Object citizensNpc : citizensNpcs.values()) {
            try {
                npcDestroy.invoke(citizensNpc);
            } catch (ReflectiveOperationException e) {
                plugin.getLogger().warning("Failed to despawn NPC: " + e.getMessage());
            }
        }
        citizensNpcs.clear();
    }

    public String createNpc(Player player, int interval, String message) {
        String id = UUID.randomUUID().toString().substring(0, 8);
        Location loc = player.getLocation();
        BroadcastNpc npc = new BroadcastNpc(id, loc, message, interval, -1);
        if (citizensAvailable) {
            spawnCitizensNpc(npc);
        }
        npcs.put(id, npc);
        saveAll();
        return id;
    }

    public boolean removeNpc(String id) {
        BroadcastNpc npc = npcs.remove(id);
        if (npc == null) return false;
        if (citizensAvailable) {
            Object citizensNpc = citizensNpcs.remove(id);
            if (citizensNpc != null) {
                try {
                    npcDestroy.invoke(citizensNpc);
                } catch (ReflectiveOperationException e) {
                    plugin.getLogger().warning("Failed to destroy NPC: " + e.getMessage());
                }
            }
        }
        saveAll();
        return true;
    }

    public boolean removeNpcAt(Player player) {
        for (Iterator<Map.Entry<String, BroadcastNpc>> it = npcs.entrySet().iterator(); it.hasNext();) {
            Map.Entry<String, BroadcastNpc> entry = it.next();
            BroadcastNpc npc = entry.getValue();
            Location npcLoc = npc.location;
            Location playerLoc = player.getLocation();
            if (npcLoc.getWorld().equals(playerLoc.getWorld()) && npcLoc.distanceSquared(playerLoc) < 9) {
                it.remove();
                if (citizensAvailable) {
                    Object citizensNpc = citizensNpcs.remove(entry.getKey());
                    if (citizensNpc != null) {
                        try {
                            npcDestroy.invoke(citizensNpc);
                        } catch (ReflectiveOperationException e) {
                            plugin.getLogger().warning("Failed to destroy NPC: " + e.getMessage());
                        }
                    }
                }
                saveAll();
                return true;
            }
        }
        return false;
    }

    public boolean setMessage(String id, String message) {
        BroadcastNpc npc = npcs.get(id);
        if (npc == null) return false;
        npc.message = message;
        saveAll();
        return true;
    }

    public boolean setInterval(String id, int interval) {
        BroadcastNpc npc = npcs.get(id);
        if (npc == null) return false;
        npc.interval = Math.max(10, interval);
        saveAll();
        return true;
    }

    public List<BroadcastNpc> getNpcs() {
        return new ArrayList<>(npcs.values());
    }

    public BroadcastNpc getNpc(String id) {
        return npcs.get(id);
    }

    public boolean isCitizensAvailable() {
        return citizensAvailable;
    }

    private void startBroadcastTask() {
        taskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, () -> {
            long now = System.currentTimeMillis();
            for (BroadcastNpc npc : npcs.values()) {
                if (now - npc.lastBroadcast >= npc.interval * 1000L) {
                    npc.lastBroadcast = now;
                    Bukkit.broadcast(TextUtil.parse(npc.message));
                }
            }
        }, 20L, 20L);
    }

    private void spawnCitizensNpc(BroadcastNpc npc) {
        try {
            Object citizensNpc = registryCreateNpc.invoke(npcRegistry, org.bukkit.entity.EntityType.PLAYER, npc.id);
            npcSpawn.invoke(citizensNpc, npc.location);
            npcSetName.invoke(citizensNpc, "<aqua>Announcer");
            int citizensId = (int) npcGetId.invoke(citizensNpc);
            npc.citizensNpcId = citizensId;
            citizensNpcs.put(npc.id, citizensNpc);
        } catch (ReflectiveOperationException e) {
            plugin.getLogger().warning("Failed to spawn broadcast NPC: " + e.getMessage());
        }
    }

    public static final class BroadcastNpc {
        public final String id;
        public final Location location;
        public String message;
        public int interval;
        public int citizensNpcId;
        public long lastBroadcast;

        public BroadcastNpc(String id, Location location, String message, int interval, int citizensNpcId) {
            this.id = id;
            this.location = location;
            this.message = message;
            this.interval = interval;
            this.citizensNpcId = citizensNpcId;
            this.lastBroadcast = 0;
        }
    }
}
