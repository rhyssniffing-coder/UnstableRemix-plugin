package lol.folium.unstable.map;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public final class ArenaAdminCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;
    private final ArenaManager arenas;
    private final WorldEditBridge worldEdit;

    public ArenaAdminCommand(UnstableRemixPlugin plugin, ArenaManager arenas, WorldEditBridge worldEdit) {
        this.plugin = plugin;
        this.arenas = arenas;
        this.worldEdit = worldEdit;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length == 0) {
            showHelp(player);
            return;
        }
        switch (args[0].toLowerCase()) {
            case "create" -> create(player, args);
            case "delete" -> delete(player, args);
            case "list" -> list(player);
            case "info" -> info(player, args);
            case "rename" -> rename(player, args);
            case "copy" -> copy(player, args);
            case "setlobby" -> setLobby(player, args);
            case "setspawn" -> setSpawn(player, args);
            case "addspawn" -> addSpawn(player, args);
            case "removespawn" -> removeSpawn(player, args);
            case "clearspawns" -> clearSpawns(player, args);
            case "setbounds" -> setBounds(player, args);
            case "schematic" -> schematic(player, args);
            case "paste" -> paste(player, args);
            case "setworld" -> setWorld(player, args);
            case "setdisplayname" -> setDisplayName(player, args);
            case "setminplayers" -> setMinPlayers(player, args);
            case "setmaxplayers" -> setMaxPlayers(player, args);
            case "setgamemode" -> setGameMode(player, args);
            case "setspawnmode" -> setSpawnMode(player, args);
            case "togglespawnmode" -> toggleSpawnMode(player, args);
            case "enable" -> enable(player, args);
            case "disable" -> disable(player, args);
            case "set" -> setOption(player, args);
            case "barriers" -> placeBarriers(player, args);
            case "removebarriers" -> removeBarriers(player, args);
            default -> showHelp(player);
        }
    }

    private void showHelp(Player player) {
        player.sendMessage(TextUtil.parse("<gold><bold>Arena Admin Commands:</bold></gold>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin create <name> [displayName]</yellow> <dark_gray>-</dark_gray> <gray>Create arena from WorldEdit selection</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin delete <name></yellow> <dark_gray>-</dark_gray> <gray>Delete arena and schematic</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin list</yellow> <dark_gray>-</dark_gray> <gray>List all arenas</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin info <name></yellow> <dark_gray>-</dark_gray> <gray>Show detailed arena configuration</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin rename <old> <new></yellow> <dark_gray>-</dark_gray> <gray>Rename arena</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin copy <from> <to></yellow> <dark_gray>-</dark_gray> <gray>Copy arena configuration</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin setlobby <name></yellow> <dark_gray>-</dark_gray> <gray>Set lobby spawn to your location</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin setspawn <name> <1|2></yellow> <dark_gray>-</dark_gray> <gray>Set team spawn</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin addspawn <name></yellow> <dark_gray>-</dark_gray> <gray>Add FFA spawn at your location</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin removespawn <name> <index></yellow> <dark_gray>-</dark_gray> <gray>Remove spawn by index</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin clearspawns <name></yellow> <dark_gray>-</dark_gray> <gray>Remove all spawns</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin setbounds <name></yellow> <dark_gray>-</dark_gray> <gray>Update bounds from WorldEdit selection</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin schematic <name></yellow> <dark_gray>-</dark_gray> <gray>(Re-)save schematic from WorldEdit selection</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin paste <name></yellow> <dark_gray>-</dark_gray> <gray>Paste arena schematic at your location</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin setworld <name> [world]</yellow> <dark_gray>-</dark_gray> <gray>Set arena world</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin setdisplayname <name> <display...></yellow> <dark_gray>-</dark_gray> <gray>Set arena display name</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin setminplayers <name> <count></yellow> <dark_gray>-</dark_gray> <gray>Set minimum players</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin setmaxplayers <name> <count></yellow> <dark_gray>-</dark_gray> <gray>Set maximum players</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin setgamemode <name> <mode></yellow> <dark_gray>-</dark_gray> <gray>Set game mode (SURVIVAL/ADVENTURE/CREATIVE)</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin setspawnmode <name> <TEAMS|FFA></yellow> <dark_gray>-</dark_gray> <gray>Set spawn mode</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin togglespawnmode <name></yellow> <dark_gray>-</dark_gray> <gray>Toggle between TEAMS/FFA spawn mode</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin enable <name></yellow> <dark_gray>-</dark_gray> <gray>Enable arena</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin disable <name></yellow> <dark_gray>-</dark_gray> <gray>Disable arena</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin set <name> <option> <value></yellow> <dark_gray>-</dark_gray> <gray>Set any boolean option (allow-build, allow-break, natural-regen, fall-damage, hunger)</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin barriers <name></yellow> <dark_gray>-</dark_gray> <gray>Place barriers around arena</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/arenaadmin removebarriers <name></yellow> <dark_gray>-</dark_gray> <gray>Remove barriers around arena</gray>"));
    }

    private Optional<Arena> requireArena(Player player, String name) {
        Optional<Arena> opt = arenas.get(name);
        if (opt.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>Arena not found.</red>"));
        }
        return opt;
    }

    private void saveOrError(Player player, Arena arena) {
        try {
            arenas.save(arena);
            player.sendMessage(TextUtil.parse("<green>Saved arena <white>" + arena.name() + "</white>.</green>"));
        } catch (IOException ex) {
            player.sendMessage(TextUtil.parse("<red>Save failed: " + ex.getMessage() + "</red>"));
        }
    }

    private void create(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin create <name> [displayName]</red>"));
            return;
        }
        if (!worldEdit.isAvailable()) {
            player.sendMessage(TextUtil.parse("<red>WorldEdit is required for arena creation.</red>"));
            return;
        }
        String name = args[1].toLowerCase();
        if (arenas.exists(name)) {
            player.sendMessage(TextUtil.parse("<red>Arena already exists.</red>"));
            return;
        }
        var selection = worldEdit.getSelection(player);
        if (selection.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>Select an area with the WorldEdit wand first.</red>"));
            return;
        }
        try {
            Arena arena = arenas.create(name, selection.get());
            if (args.length >= 3) {
                arena.setDisplayName(String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length)));
            }
            if (!worldEdit.saveSchematic(player, name, selection.get())) {
                arenas.delete(name);
                player.sendMessage(TextUtil.parse("<red>Failed to save schematic.</red>"));
                return;
            }
            arenas.save(arena);
            player.sendMessage(TextUtil.parse("<green>Created arena <white>" + name + "</white>.</green>"));
        } catch (Exception ex) {
            player.sendMessage(TextUtil.parse("<red>Failed: " + ex.getMessage() + "</red>"));
        }
    }

    private void delete(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin delete <name></red>"));
            return;
        }
        String name = args[1].toLowerCase();
        if (!arenas.exists(name)) {
            player.sendMessage(TextUtil.parse("<red>Arena not found.</red>"));
            return;
        }
        worldEdit.deleteSchematic(name);
        arenas.delete(name);
        player.sendMessage(TextUtil.parse("<green>Deleted arena <white>" + name + "</white>.</green>"));
    }

    private void list(Player player) {
        if (arenas.all().isEmpty()) {
            player.sendMessage(TextUtil.parse("<gray>No arenas registered.</gray>"));
            return;
        }
        player.sendMessage(TextUtil.parse("<gold><bold>Arenas</bold></gold>"));
        for (Arena arena : arenas.all()) {
            String status = (arena.isEnabled() ? "<green>ENABLED" : "<red>DISABLED") + "</red></green>";
            player.sendMessage(TextUtil.parse(
                    "<gray>- <white>" + arena.name() + "</white>"
                            + " <dark_gray>|</dark_gray> " + status
                            + " <dark_gray>|</dark_gray> <aqua>" + arena.teamSpawnMode() + "</aqua>"
                            + " <dark_gray>|</dark_gray> <gray>" + arena.players().size() + " players</gray>"
                            + (worldEdit.hasSchematic(arena.name()) ? " <dark_green>[schem]</dark_green>" : "")
            ));
        }
    }

    private void info(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin info <name></red>"));
            return;
        }
        requireArena(player, args[1]).ifPresent(arena -> {
            player.sendMessage(TextUtil.parse("<gold><bold>=== " + arena.name() + " ===</bold></gold>"));
            player.sendMessage(TextUtil.parse("<gray>Display Name:</gray> <white>" + arena.displayName() + "</white>"));
            player.sendMessage(TextUtil.parse("<gray>World:</gray> <white>" + (arena.worldName() != null ? arena.worldName() : "<none>") + "</white>"));
            player.sendMessage(TextUtil.parse("<gray>Bounds:</gray> <white>" + arena.minX() + "," + arena.minY() + "," + arena.minZ() + " → " + arena.maxX() + "," + arena.maxY() + "," + arena.maxZ() + "</white>"));
            player.sendMessage(TextUtil.parse("<gray>Status:</gray> " + (arena.isEnabled() ? "<green>Enabled" : "<red>Disabled") + "</red></green>"));
            player.sendMessage(TextUtil.parse("<gray>Team Spawn Mode:</gray> <aqua>" + arena.teamSpawnMode() + "</aqua>"));
            player.sendMessage(TextUtil.parse("<gray>Players:</gray> <white>" + arena.minPlayers() + "–" + arena.maxPlayers() + "</white>"));
            player.sendMessage(TextUtil.parse("<gray>Game Mode:</gray> <white>" + arena.gameMode() + "</white>"));
            player.sendMessage(TextUtil.parse("<gray>Allow Build:</gray> " + (arena.allowBuild() ? "<green>true" : "<red>false") + "</red></green>"));
            player.sendMessage(TextUtil.parse("<gray>Allow Break:</gray> " + (arena.allowBreak() ? "<green>true" : "<red>false") + "</red></green>"));
            player.sendMessage(TextUtil.parse("<gray>Natural Regen:</gray> " + (arena.naturalRegen() ? "<green>true" : "<red>false") + "</red></green>"));
            player.sendMessage(TextUtil.parse("<gray>Fall Damage:</gray> " + (arena.allowFallDamage() ? "<green>true" : "<red>false") + "</red></green>"));
            player.sendMessage(TextUtil.parse("<gray>Hunger:</gray> " + (arena.hunger() ? "<green>true" : "<red>false") + "</red></green>"));
            player.sendMessage(TextUtil.parse("<gray>Time Lock:</gray> <white>" + (arena.timeLock() != null ? arena.timeLock() : "world default") + "</white>"));
            player.sendMessage(TextUtil.parse("<gray>Weather Lock:</gray> <white>" + (arena.weatherLock() != null ? arena.weatherLock() : "world default") + "</white>"));
            player.sendMessage(TextUtil.parse("<gray>Schematic:</gray> " + (worldEdit.hasSchematic(arena.name()) ? "<green>saved" : "<red>missing") + "</red></green>"));
            player.sendMessage(TextUtil.parse("<gray>Lobby:</gray> " + (arena.lobby() != null ? "<white>" + fmtLoc(arena.lobby()) : "<red>not set") + "</red></white>"));
            player.sendMessage(TextUtil.parse("<gray>Spawn 1:</gray> " + (arena.spawn1() != null ? "<white>" + fmtLoc(arena.spawn1()) : "<red>not set") + "</red></white>"));
            player.sendMessage(TextUtil.parse("<gray>Spawn 2:</gray> " + (arena.spawn2() != null ? "<white>" + fmtLoc(arena.spawn2()) : "<red>not set") + "</red></white>"));
            player.sendMessage(TextUtil.parse("<gray>Spawns:</gray> <white>" + arena.spawns().size() + "</white>"));
        });
    }

    private static String fmtLoc(Location loc) {
        return String.format("%.0f,%.0f,%.0f", loc.getX(), loc.getY(), loc.getZ());
    }

    private void rename(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin rename <old> <new></red>"));
            return;
        }
        String oldName = args[1].toLowerCase();
        String newName = args[2].toLowerCase();
        if (!arenas.exists(oldName)) {
            player.sendMessage(TextUtil.parse("<red>Arena not found.</red>"));
            return;
        }
        if (arenas.exists(newName)) {
            player.sendMessage(TextUtil.parse("<red>An arena with that name already exists.</red>"));
            return;
        }
        try {
            arenas.copy(oldName, newName);
            arenas.delete(oldName);
            File oldSchem = worldEdit.schematicFile(oldName);
            File newSchem = worldEdit.schematicFile(newName);
            if (oldSchem.exists()) {
                oldSchem.renameTo(newSchem);
            } else {
                worldEdit.deleteSchematic(newName);
            }
            player.sendMessage(TextUtil.parse("<green>Renamed arena <white>" + oldName + "</white> → <white>" + newName + "</white>.</green>"));
        } catch (Exception ex) {
            player.sendMessage(TextUtil.parse("<red>Failed: " + ex.getMessage() + "</red>"));
        }
    }

    private void copy(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin copy <from> <to></red>"));
            return;
        }
        String from = args[1].toLowerCase();
        String to = args[2].toLowerCase();
        if (!arenas.exists(from)) {
            player.sendMessage(TextUtil.parse("<red>Source arena not found.</red>"));
            return;
        }
        if (arenas.exists(to)) {
            player.sendMessage(TextUtil.parse("<red>An arena with that name already exists.</red>"));
            return;
        }
        try {
            arenas.copy(from, to);
            player.sendMessage(TextUtil.parse("<green>Copied arena <white>" + from + "</white> → <white>" + to + "</white>.</green>"));
        } catch (Exception ex) {
            player.sendMessage(TextUtil.parse("<red>Failed: " + ex.getMessage() + "</red>"));
        }
    }

    private void setLobby(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin setlobby <name></red>")); return; }
        requireArena(player, args[1]).ifPresent(arena -> {
            arena.setLobby(player.getLocation());
            saveOrError(player, arena);
        });
    }

    private void setSpawn(Player player, String[] args) {
        if (args.length < 3) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin setspawn <name> <1|2></red>")); return; }
        int team;
        try { team = Integer.parseInt(args[2]); } catch (NumberFormatException ex) { player.sendMessage(TextUtil.parse("<red>Team must be 1 or 2.</red>")); return; }
        if (team != 1 && team != 2) { player.sendMessage(TextUtil.parse("<red>Team must be 1 or 2.</red>")); return; }
        int finalTeam = team;
        requireArena(player, args[1]).ifPresent(arena -> {
            if (finalTeam == 1) arena.setSpawn1(player.getLocation());
            else arena.setSpawn2(player.getLocation());
            saveOrError(player, arena);
        });
    }

    private void addSpawn(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin addspawn <name></red>")); return; }
        requireArena(player, args[1]).ifPresent(arena -> {
            arena.addSpawn(player.getLocation());
            saveOrError(player, arena);
        });
    }

    private void removeSpawn(Player player, String[] args) {
        if (args.length < 3) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin removespawn <name> <index></red>")); return; }
        int index;
        try { index = Integer.parseInt(args[2]); } catch (NumberFormatException ex) { player.sendMessage(TextUtil.parse("<red>Index must be a number.</red>")); return; }
        int finalIndex = index;
        requireArena(player, args[1]).ifPresent(arena -> {
            if (finalIndex < 0 || finalIndex >= arena.spawns().size()) {
                player.sendMessage(TextUtil.parse("<red>Invalid spawn index. Valid range: 0–" + (arena.spawns().size() - 1) + "</red>"));
                return;
            }
            arena.removeSpawn(finalIndex);
            saveOrError(player, arena);
        });
    }

    private void clearSpawns(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin clearspawns <name></red>")); return; }
        requireArena(player, args[1]).ifPresent(arena -> {
            arena.clearSpawns();
            saveOrError(player, arena);
        });
    }

    private void setBounds(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin setbounds <name></red>")); return; }
        if (!worldEdit.isAvailable()) { player.sendMessage(TextUtil.parse("<red>WorldEdit is required.</red>")); return; }
        var selection = worldEdit.getSelection(player);
        if (selection.isEmpty()) { player.sendMessage(TextUtil.parse("<red>Select an area with the WorldEdit wand first.</red>")); return; }
        requireArena(player, args[1]).ifPresent(arena -> {
            var sel = selection.get();
            arena.setWorldName(sel.world());
            arena.setBounds(sel.minX(), sel.minY(), sel.minZ(), sel.maxX(), sel.maxY(), sel.maxZ());
            saveOrError(player, arena);
        });
    }

    private void schematic(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin schematic <name></red>")); return; }
        if (!worldEdit.isAvailable()) { player.sendMessage(TextUtil.parse("<red>WorldEdit is required.</red>")); return; }
        var selection = worldEdit.getSelection(player);
        if (selection.isEmpty()) { player.sendMessage(TextUtil.parse("<red>Select an area with the WorldEdit wand first.</red>")); return; }
        String name = args[1].toLowerCase();
        if (!arenas.exists(name)) { player.sendMessage(TextUtil.parse("<red>Arena not found.</red>")); return; }
        if (worldEdit.saveSchematic(player, name, selection.get())) {
            player.sendMessage(TextUtil.parse("<green>Schematic saved for <white>" + name + "</white>.</green>"));
        } else {
            player.sendMessage(TextUtil.parse("<red>Failed to save schematic.</red>"));
        }
    }

    private void paste(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin paste <name></red>")); return; }
        String name = args[1].toLowerCase();
        if (!worldEdit.isAvailable()) { player.sendMessage(TextUtil.parse("<red>WorldEdit is required.</red>")); return; }
        if (!worldEdit.hasSchematic(name)) { player.sendMessage(TextUtil.parse("<red>No schematic found for " + name + ".</red>")); return; }
        if (worldEdit.pasteSchematic(name, player.getLocation())) {
            player.sendMessage(TextUtil.parse("<green>Pasted schematic for <white>" + name + "</white>.</green>"));
        } else {
            player.sendMessage(TextUtil.parse("<red>Failed to paste schematic.</red>"));
        }
    }

    private void setWorld(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin setworld <name> [world]</red>")); return; }
        requireArena(player, args[1]).ifPresent(arena -> {
            String world = args.length >= 3 ? args[2] : player.getWorld().getName();
            arena.setWorldName(world);
            saveOrError(player, arena);
        });
    }

    private void setDisplayName(Player player, String[] args) {
        if (args.length < 3) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin setdisplayname <name> <display...></red>")); return; }
        requireArena(player, args[1]).ifPresent(arena -> {
            arena.setDisplayName(String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length)));
            saveOrError(player, arena);
        });
    }

    private void setMinPlayers(Player player, String[] args) {
        if (args.length < 3) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin setminplayers <name> <count></red>")); return; }
        try {
            int count = Integer.parseInt(args[2]);
            requireArena(player, args[1]).ifPresent(arena -> {
                arena.setMinPlayers(count);
                saveOrError(player, arena);
            });
        } catch (NumberFormatException ex) {
            player.sendMessage(TextUtil.parse("<red>Count must be a number.</red>"));
        }
    }

    private void setMaxPlayers(Player player, String[] args) {
        if (args.length < 3) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin setmaxplayers <name> <count></red>")); return; }
        try {
            int count = Integer.parseInt(args[2]);
            requireArena(player, args[1]).ifPresent(arena -> {
                arena.setMaxPlayers(count);
                saveOrError(player, arena);
            });
        } catch (NumberFormatException ex) {
            player.sendMessage(TextUtil.parse("<red>Count must be a number.</red>"));
        }
    }

    private void setGameMode(Player player, String[] args) {
        if (args.length < 3) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin setgamemode <name> <mode></red>")); return; }
        String mode = args[2].toUpperCase();
        try {
            GameMode.valueOf(mode);
        } catch (IllegalArgumentException ex) {
            player.sendMessage(TextUtil.parse("<red>Invalid game mode. Valid: SURVIVAL, CREATIVE, ADVENTURE, SPECTATOR</red>"));
            return;
        }
        String finalMode = mode;
        requireArena(player, args[1]).ifPresent(arena -> {
            arena.setGameMode(finalMode);
            saveOrError(player, arena);
        });
    }

    private void setSpawnMode(Player player, String[] args) {
        if (args.length < 3) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin setspawnmode <name> <TEAMS|FFA></red>")); return; }
        String mode = args[2].toUpperCase();
        if (!mode.equals("TEAMS") && !mode.equals("FFA")) {
            player.sendMessage(TextUtil.parse("<red>Mode must be TEAMS or FFA.</red>"));
            return;
        }
        String finalMode = mode;
        requireArena(player, args[1]).ifPresent(arena -> {
            arena.setTeamSpawnMode(finalMode);
            saveOrError(player, arena);
        });
    }

    private void toggleSpawnMode(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin togglespawnmode <name></red>")); return; }
        requireArena(player, args[1]).ifPresent(arena -> {
            String current = arena.teamSpawnMode();
            arena.setTeamSpawnMode(current.equals("TEAMS") ? "FFA" : "TEAMS");
            player.sendMessage(TextUtil.parse("<green>Spawn mode toggled to <aqua>" + arena.teamSpawnMode() + "</aqua>.</green>"));
            saveOrError(player, arena);
        });
    }

    private void enable(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin enable <name></red>")); return; }
        requireArena(player, args[1]).ifPresent(arena -> {
            arena.setEnabled(true);
            saveOrError(player, arena);
        });
    }

    private void disable(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin disable <name></red>")); return; }
        requireArena(player, args[1]).ifPresent(arena -> {
            arena.setEnabled(false);
            saveOrError(player, arena);
        });
    }

    private void placeBarriers(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin barriers <name></red>"));
            return;
        }
        if (!worldEdit.isAvailable()) {
            player.sendMessage(TextUtil.parse("<red>WorldEdit is required.</red>"));
            return;
        }

        Optional<Arena> opt = arenas.get(args[1].toLowerCase());
        if (opt.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>Arena not found.</red>"));
            return;
        }

        Arena arena = opt.get();
        org.bukkit.World world = Bukkit.getWorld(arena.worldName());
        if (world == null) {
            player.sendMessage(TextUtil.parse("<red>Arena world not found.</red>"));
            return;
        }

        var selection = worldEdit.getSelection(player);
        if (selection.isEmpty()) {
            selection = Optional.of(new WorldEditBridge.RegionSelection(
                    arena.worldName(), arena.minX(), arena.minY(), arena.minZ(), arena.maxX(), arena.maxY(), arena.maxZ()));
        }

        if (worldEdit.placeBarriers(world, selection.get(), 5)) {
            player.sendMessage(TextUtil.parse("<green>Barriers placed around arena.</green>"));
        } else {
            player.sendMessage(TextUtil.parse("<red>Failed to place barriers.</red>"));
        }
    }

    private void removeBarriers(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin removebarriers <name></red>"));
            return;
        }
        if (!worldEdit.isAvailable()) {
            player.sendMessage(TextUtil.parse("<red>WorldEdit is required.</red>"));
            return;
        }

        Optional<Arena> opt = arenas.get(args[1].toLowerCase());
        if (opt.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>Arena not found.</red>"));
            return;
        }

        Arena arena = opt.get();
        org.bukkit.World world = Bukkit.getWorld(arena.worldName());
        if (world == null) {
            player.sendMessage(TextUtil.parse("<red>Arena world not found.</red>"));
            return;
        }

        var selection = worldEdit.getSelection(player);
        if (selection.isEmpty()) {
            selection = Optional.of(new WorldEditBridge.RegionSelection(
                    arena.worldName(), arena.minX(), arena.minY(), arena.minZ(), arena.maxX(), arena.maxY(), arena.maxZ()));
        }

        if (worldEdit.removeBarriers(world, selection.get(), 5)) {
            player.sendMessage(TextUtil.parse("<green>Barriers removed from arena.</green>"));
        } else {
            player.sendMessage(TextUtil.parse("<red>Failed to remove barriers.</red>"));
        }
    }

    private void setOption(Player player, String[] args) {
        if (args.length < 4) {
            player.sendMessage(TextUtil.parse("<red>Usage: /arenaadmin set <name> <option> <value></red>"));
            player.sendMessage(TextUtil.parse("<gray>Options: allow-build, allow-break, natural-regen, fall-damage, hunger</gray>"));
            return;
        }
        String name = args[1].toLowerCase();
        String option = args[2].toLowerCase();
        boolean value;
        if (args[3].equalsIgnoreCase("true") || args[3].equals("1") || args[3].equalsIgnoreCase("yes")) {
            value = true;
        } else if (args[3].equalsIgnoreCase("false") || args[3].equals("0") || args[3].equalsIgnoreCase("no")) {
            value = false;
        } else {
            player.sendMessage(TextUtil.parse("<red>Value must be true/false, 1/0, or yes/no.</red>"));
            return;
        }
        boolean finalValue = value;
        requireArena(player, name).ifPresent(arena -> {
            switch (option) {
                case "allow-build" -> arena.setAllowBuild(finalValue);
                case "allow-break" -> arena.setAllowBreak(finalValue);
                case "natural-regen" -> arena.setNaturalRegen(finalValue);
                case "fall-damage" -> arena.setAllowFallDamage(finalValue);
                case "hunger" -> arena.setHunger(finalValue);
                default -> {
                    player.sendMessage(TextUtil.parse("<red>Unknown option: " + option + "</red>"));
                    player.sendMessage(TextUtil.parse("<gray>Options: allow-build, allow-break, natural-regen, fall-damage, hunger</gray>"));
                    return;
                }
            }
            saveOrError(player, arena);
        });
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            return filter(literals(
                    "create", "delete", "list", "info", "rename", "copy",
                    "setlobby", "setspawn", "addspawn", "removespawn", "clearspawns",
                    "setbounds", "schematic", "paste",
                    "setworld", "setdisplayname", "setminplayers", "setmaxplayers",
                    "setgamemode", "setspawnmode", "togglespawnmode",
                    "enable", "disable", "set", "barriers", "removebarriers"
            ), args[0]);
        }
        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if (List.of("delete", "info", "rename", "copy", "setlobby", "setspawn", "addspawn",
                    "removespawn", "clearspawns", "setbounds", "schematic",
                    "paste", "setworld", "setdisplayname", "setminplayers",
                    "setmaxplayers", "setgamemode", "setspawnmode",
                    "togglespawnmode", "enable", "disable", "set", "barriers", "removebarriers").contains(sub)) {
                return filter(arenas.names(), args[1]);
            }
        }
        if (args.length == 3) {
            String sub = args[0].toLowerCase();
            if (sub.equals("setspawn")) {
                return filter(literals("1", "2"), args[2]);
            }
            if (sub.equals("setgamemode")) {
                return filter(literals("SURVIVAL", "ADVENTURE", "CREATIVE", "SPECTATOR"), args[2]);
            }
            if (sub.equals("setspawnmode")) {
                return filter(literals("TEAMS", "FFA"), args[2]);
            }
            if (sub.equals("set")) {
                return filter(literals("allow-build", "allow-break", "natural-regen", "fall-damage", "hunger"), args[2]);
            }
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("set")) {
            return filter(literals("true", "false"), args[3]);
        }
        return List.of();
    }

    @Override
    protected String permission() {
        return "unstable.map.admin";
    }
}
