package lol.folium.unstable.civ;

import java.util.*;

public class Civilization {

    private final UUID id;
    private String name;
    private String prefix;
    private String prefixColor;
    private boolean gradientPrefix;
    private final UUID owner;
    private final Set<UUID> members = new HashSet<>();
    private final Set<UUID> invited = new HashSet<>();
    private long balance;
    private String description;
    private final List<String> todoList = new ArrayList<>();
    private final Set<String> targets = new HashSet<>();
    private final Set<String> enemies = new HashSet<>();

    public Civilization(UUID id, String name, String prefix, String prefixColor, boolean gradientPrefix, UUID owner) {
        this.id = id;
        this.name = name;
        this.prefix = prefix;
        this.prefixColor = prefixColor;
        this.gradientPrefix = gradientPrefix;
        this.owner = owner;
        this.members.add(owner);
    }

    public UUID getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPrefix() { return prefix; }
    public void setPrefix(String prefix) { this.prefix = prefix; }
    public String getPrefixColor() { return prefixColor; }
    public void setPrefixColor(String prefixColor) { this.prefixColor = prefixColor; }
    public boolean isGradientPrefix() { return gradientPrefix; }
    public void setGradientPrefix(boolean gradientPrefix) { this.gradientPrefix = gradientPrefix; }
    public UUID getOwner() { return owner; }
    public Set<UUID> getMembers() { return members; }
    public Set<UUID> getInvited() { return invited; }
    public long getBalance() { return balance; }
    public void setBalance(long balance) { this.balance = balance; }
    public void deposit(long amount) { this.balance += amount; }
    public boolean withdraw(long amount) {
        if (this.balance >= amount) {
            this.balance -= amount;
            return true;
        }
        return false;
    }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public List<String> getTodoList() { return todoList; }
    public Set<String> getTargets() { return targets; }
    public Set<String> getEnemies() { return enemies; }

    public boolean isMember(UUID uuid) { return members.contains(uuid); }
    public boolean isOwner(UUID uuid) { return owner.equals(uuid); }
    public boolean isInvited(UUID uuid) { return invited.contains(uuid); }
    public void addMember(UUID uuid) { members.add(uuid); invited.remove(uuid); }
    public void removeMember(UUID uuid) { members.remove(uuid); }
    public void invite(UUID uuid) { invited.add(uuid); }
    public void revokeInvite(UUID uuid) { invited.remove(uuid); }

    public String getFormattedPrefix() {
        if (gradientPrefix) {
            return prefixColor + "&l" + prefix + " &r";
        }
        return prefixColor + "&l" + prefix + " &r";
    }
}
