package lol.folium.unstable.command;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.data.PlayerProfile;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.entity.Player;

import java.util.List;

public final class DiscordCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;

    public DiscordCommand(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    protected void execute(Player player, String[] args) {
        String link = plugin.getConfig().getString("social.discord-link", "https://discord.gg/unstableremix");
        long reward = plugin.getConfig().getLong("social.discord-reward", 100L);

        player.sendMessage(TextUtil.parse("<gold><bold>DISCORD</bold></gold>"));
        player.sendMessage(TextUtil.parse("<gray>Join our Discord community!</gray>"));
        player.sendMessage(TextUtil.parse("<aqua><underlined>" + link + "</underlined></aqua>"));

        PlayerProfile profile = plugin.getPlayerDataStore().get(player.getUniqueId());
        if (profile.socialDiscordClaimed()) {
            player.sendMessage(TextUtil.parse("<dark_gray>You have already claimed the Discord reward.</dark_gray>"));
            return;
        }

        profile.setSocialDiscordClaimed(true);
        plugin.getPlayerDataStore().saveProfile(profile);
        plugin.getEconomyService().grantShards(player.getUniqueId(), reward, "social:discord", null);
        player.sendMessage(TextUtil.parse("<green><bold>+100 Shards</bold></green> <gray>Thanks for joining!</gray>"));
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        return List.of();
    }

    @Override
    protected String permission() {
        return null;
    }
}
