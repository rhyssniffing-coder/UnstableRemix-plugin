package lol.folium.unstable.map;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public final class ArenaSetupCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;
    private final ArenaManager arenas;
    private final WorldEditBridge worldEdit;
    private final ConcurrentHashMap<String, ArenaSetupSession> sessions = new ConcurrentHashMap<>();

    public ArenaSetupCommand(UnstableRemixPlugin plugin, ArenaManager arenas, WorldEditBridge worldEdit) {
        this.plugin = plugin;
        this.arenas = arenas;
        this.worldEdit = worldEdit;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length == 0) {
            showHelp(player);
            return;
        }
        switch (args[0].toLowerCase()) {
            case "start" -> startSetup(player, args);
            case "setspawn" -> setSpawn(player);
            case "setlobby" -> setLobby(player);
            case "addspawn" -> addSpawn(player);
            case "done" -> finishSetup(player);
            case "cancel" -> cancelSetup(player);
            case "quick" -> quickSetup(player, args);
            default -> showHelp(player);
        }
    }

    private void showHelp(Player player) {
        player.sendMessage(TextUtil.parse("<gold><bold>Arena Setup Wizard</bold></gold>"));
        player.sendMessage(TextUtil.parse("<yellow>/setup quick <name> [displayName]</yellow> <dark_gray>-</dark_gray> <gray>Quick setup from WorldEdit selection</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/setup start <name> [displayName]</yellow> <dark_gray>-</dark_gray> <gray>Start guided arena setup</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/setup setlobby</yellow> <dark_gray>-</dark_gray> <gray>Set lobby spawn at your location</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/setup setspawn</yellow> <dark_gray>-</dark_gray> <gray>Add spawn point at your location</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/setup addspawn</yellow> <dark_gray>-</dark_gray> <gray>Add another spawn point</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/setup done</yellow> <dark_gray>-</dark_gray> <gray>Finish and save arena</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/setup cancel</yellow> <dark_gray>-</dark_gray> <gray>Cancel setup</gray>"));
        player.sendMessage(TextUtil.parse(""));
        player.sendMessage(TextUtil.parse("<green><bold>Quick Setup:</bold></green>"));
        player.sendMessage(TextUtil.parse("<gray>1. Select area with WorldEdit wand</gray>"));
        player.sendMessage(TextUtil.parse("<gray>2. Stand where you want spawns</gray>"));
        player.sendMessage(TextUtil.parse("<gray>3. Run /setup quick <name></gray>"));
    }

    private void startSetup(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /setup start <name> [displayName]</red>"));
            return;
        }
        if (!worldEdit.isAvailable()) {
            player.sendMessage(TextUtil.parse("<red>WorldEdit is required for arena creation.</red>"));
            return;
        }
        String name = args[1].toLowerCase();
        if (arenas.exists(name)) {
            player.sendMessage(TextUtil.parse("<red>Arena already exists.</red>"));
            return;
        }
        var selection = worldEdit.getSelection(player);
        if (selection.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>Select an area with the WorldEdit wand first.</red>"));
            return;
        }

        String displayName = args.length >= 3 ? String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length)) : name;
        ArenaSetupSession session = new ArenaSetupSession(name, displayName, selection.get());
        sessions.put(player.getUniqueId().toString(), session);

        player.sendMessage(TextUtil.parse("<gold><bold>Arena Setup Started!</bold></gold>"));
        player.sendMessage(TextUtil.parse("<gray>Arena: <white>" + displayName + "</white></gray>"));
        player.sendMessage(TextUtil.parse(""));
        player.sendMessage(TextUtil.parse("<green>Step 1: Stand where you want the lobby and run <white>/setup setlobby</white></green>"));
        player.sendMessage(TextUtil.parse("<green>Step 2: Stand at spawn points and run <white>/setup setspawn</white></green>"));
        player.sendMessage(TextUtil.parse("<green>Step 3: Run <white>/setup done</white> when finished</green>"));
    }

    private void setLobby(Player player) {
        ArenaSetupSession session = getSession(player);
        if (session == null) return;

        session.lobby = player.getLocation().clone();
        player.sendMessage(TextUtil.parse("<green>Lobby set! Now add spawn points with <white>/setup setspawn</white></green>"));
        showProgress(player, session);
    }

    private void setSpawn(Player player) {
        ArenaSetupSession session = getSession(player);
        if (session == null) return;

        session.spawns.add(player.getLocation().clone());
        player.sendMessage(TextUtil.parse("<green>Spawn " + session.spawns.size() + " added! Add more or run <white>/setup done</white></green>"));
        showProgress(player, session);
    }

    private void addSpawn(Player player) {
        setSpawn(player);
    }

    private void finishSetup(Player player) {
        ArenaSetupSession session = getSession(player);
        if (session == null) return;

        if (session.lobby == null) {
            player.sendMessage(TextUtil.parse("<red>Set the lobby first with <white>/setup setlobby</white></red>"));
            return;
        }
        if (session.spawns.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>Add at least one spawn with <white>/setup setspawn</white></red>"));
            return;
        }

        try {
            Arena arena = arenas.create(session.name, session.selection);
            arena.setDisplayName(session.displayName);
            arena.setLobby(session.lobby);
            arena.setWorldName(session.selection.world());
            arena.setBounds(
                    session.selection.minX(), session.selection.minY(), session.selection.minZ(),
                    session.selection.maxX(), session.selection.maxY(), session.selection.maxZ()
            );
            arena.setTeamSpawnMode("FFA");

            for (Location spawn : session.spawns) {
                arena.addSpawn(spawn);
            }

            if (!worldEdit.saveSchematic(player, session.name, session.selection)) {
                arenas.delete(session.name);
                player.sendMessage(TextUtil.parse("<red>Failed to save schematic.</red>"));
                return;
            }

            arenas.save(arena);

            org.bukkit.World world = player.getWorld();
            if (worldEdit.placeBarriers(world, session.selection, 5)) {
                player.sendMessage(TextUtil.parse("<green>Barriers placed around arena!</green>"));
            }

            sessions.remove(player.getUniqueId().toString());

            player.sendMessage(TextUtil.parse("<gold><bold>Arena Created!</bold></gold>"));
            player.sendMessage(TextUtil.parse("<green>Name: <white>" + session.displayName + "</white></green>"));
            player.sendMessage(TextUtil.parse("<green>Spawns: <white>" + session.spawns.size() + "</white></green>"));
            player.sendMessage(TextUtil.parse("<green>Barriers: <white>Placed</white></green>"));
            player.sendMessage(TextUtil.parse("<gray>Run <white>/arenaadmin info " + session.name + "</gray> to customize</gray>"));
        } catch (Exception ex) {
            player.sendMessage(TextUtil.parse("<red>Failed: " + ex.getMessage() + "</red>"));
        }
    }

    private void cancelSetup(Player player) {
        sessions.remove(player.getUniqueId().toString());
        player.sendMessage(TextUtil.parse("<red>Arena setup cancelled.</red>"));
    }

    private void quickSetup(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /setup quick <name> [displayName]</red>"));
            return;
        }
        if (!worldEdit.isAvailable()) {
            player.sendMessage(TextUtil.parse("<red>WorldEdit is required for arena creation.</red>"));
            return;
        }
        String name = args[1].toLowerCase();
        if (arenas.exists(name)) {
            player.sendMessage(TextUtil.parse("<red>Arena already exists.</red>"));
            return;
        }
        var selection = worldEdit.getSelection(player);
        if (selection.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>Select an area with the WorldEdit wand first.</red>"));
            return;
        }

        String displayName = args.length >= 3 ? String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length)) : name;

        try {
            Arena arena = arenas.create(name, selection.get());
            arena.setDisplayName(displayName);
            arena.setLobby(player.getLocation().clone());
            arena.setWorldName(selection.get().world());
            arena.setBounds(
                    selection.get().minX(), selection.get().minY(), selection.get().minZ(),
                    selection.get().maxX(), selection.get().maxY(), selection.get().maxZ()
            );
            arena.setTeamSpawnMode("FFA");
            arena.addSpawn(player.getLocation().clone());

            if (!worldEdit.saveSchematic(player, name, selection.get())) {
                arenas.delete(name);
                player.sendMessage(TextUtil.parse("<red>Failed to save schematic.</red>"));
                return;
            }

            arenas.save(arena);

            org.bukkit.World world = player.getWorld();
            if (worldEdit.placeBarriers(world, selection.get(), 5)) {
                player.sendMessage(TextUtil.parse("<green>Barriers placed around arena!</green>"));
            }

            player.sendMessage(TextUtil.parse("<gold><bold>Arena Created!</bold></gold>"));
            player.sendMessage(TextUtil.parse("<green>Name: <white>" + displayName + "</white></green>"));
            player.sendMessage(TextUtil.parse("<green>Barriers: <white>Placed</white></green>"));
            player.sendMessage(TextUtil.parse("<gray>Run <white>/arenaadmin info " + name + "</gray> to customize</gray>"));
        } catch (Exception ex) {
            player.sendMessage(TextUtil.parse("<red>Failed: " + ex.getMessage() + "</red>"));
        }
    }

    private ArenaSetupSession getSession(Player player) {
        ArenaSetupSession session = sessions.get(player.getUniqueId().toString());
        if (session == null) {
            player.sendMessage(TextUtil.parse("<red>No active arena setup. Run <white>/setup start <name></white> first.</red>"));
            return null;
        }
        return session;
    }

    private void showProgress(Player player, ArenaSetupSession session) {
        player.sendMessage(TextUtil.parse("<gray>Progress:</gray>"));
        player.sendMessage(TextUtil.parse("<gray>Lobby: " + (session.lobby != null ? "<green>Set" : "<red>Not set") + "</gray>"));
        player.sendMessage(TextUtil.parse("<gray>Spawns: <aqua>" + session.spawns.size() + "</aqua></gray>"));
        player.sendMessage(TextUtil.parse("<gray>Run <white>/setup done</white> when ready</gray>"));
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            return filter(literals("start", "quick", "setspawn", "setlobby", "addspawn", "done", "cancel"), args[0]);
        }
        return List.of();
    }

    @Override
    protected String permission() {
        return "unstable.map.admin";
    }

    private static class ArenaSetupSession {
        final String name;
        final String displayName;
        final WorldEditBridge.RegionSelection selection;
        Location lobby;
        final List<Location> spawns = new ArrayList<>();

        ArenaSetupSession(String name, String displayName, WorldEditBridge.RegionSelection selection) {
            this.name = name;
            this.displayName = displayName;
            this.selection = selection;
        }
    }
}
