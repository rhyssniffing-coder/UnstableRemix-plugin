package lol.folium.unstable.shop;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class AdminShopGui {

    private final UnstableRemixPlugin plugin;
    private final ShopManager shop;

    public AdminShopGui(UnstableRemixPlugin plugin, ShopManager shop) {
        this.plugin = plugin;
        this.shop = shop;
    }

    public void open(Player player) {
        openPage(player, 0);
    }

    private void openPage(Player player, int pageIndex) {
        List<ShopManager.ShopPage> pages = shop.getPages();
        if (pages.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>No shop pages configured.</red>"));
            return;
        }
        pageIndex = Math.max(0, Math.min(pageIndex, pages.size() - 1));
        ShopManager.ShopPage page = pages.get(pageIndex);

        int rows = 6;
        AdminShopHolder holder = new AdminShopHolder(player, pageIndex);
        Inventory inventory = Bukkit.createInventory(holder, rows * 9,
                TextUtil.parse("<gradient:#FF4444:#FF8800>Edit: " + page.id + "</gradient>"));
        holder.bind(inventory);

        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE).name(Component.empty()).build());
        }

        if (pageIndex > 0) {
            inventory.setItem(45, ItemBuilder.of(Material.ARROW)
                    .name(TextUtil.parse("<yellow>← " + pages.get(pageIndex - 1).id + "</yellow>"))
                    .build());
        }
        if (pageIndex < pages.size() - 1) {
            inventory.setItem(53, ItemBuilder.of(Material.ARROW)
                    .name(TextUtil.parse("<yellow>" + pages.get(pageIndex + 1).id + " →</yellow>"))
                    .build());
        }

        inventory.setItem(49, ItemBuilder.of(Material.BARRIER)
                .name(TextUtil.parse("<red><bold>Close</bold></red>"))
                .build());

        inventory.setItem(4, ItemBuilder.of(Material.CHEST)
                .name(TextUtil.parse("<gold><bold>" + page.id + "</bold></gold>"))
                .lore(List.of(
                        TextUtil.parse("<gray>Hold item + click empty slot = add</gray>"),
                        TextUtil.parse("<gray>Left-click item = cycle price</gray>"),
                        TextUtil.parse("<gray>Shift+click item = remove</gray>")))
                .build());

        for (ShopManager.ShopItem item : page.items) {
            String priceStr = item.effect != null
                    ? "<light_purple>" + item.price + " Shards <aqua>[" + item.effect + "]</aqua>"
                    : "<light_purple>" + item.price + " Shards</light_purple>";

            List<Component> lore = new ArrayList<>();
            lore.add(TextUtil.parse(priceStr));
            lore.add(Component.empty());
            lore.add(TextUtil.parse("<yellow>Left-click: cycle price</yellow>"));
            lore.add(TextUtil.parse("<red>Shift+click: remove</red>"));

            ItemStack display = ItemBuilder.of(item.material)
                    .amount(item.amount)
                    .name(TextUtil.parse("<gold>Slot " + item.slot + "</gold>"))
                    .lore(lore)
                    .build();
            inventory.setItem(item.slot, display);
            holder.editableSlots.put(item.slot, item);
        }

        player.openInventory(inventory);
    }

    private static final long[] PRICE_CYCLES = {1000, 2500, 5000, 10000, 25000, 50000, 100000};

    private final class AdminShopHolder extends GuiHolder {
        private final Player player;
        private final int pageIndex;
        private final Map<Integer, ShopManager.ShopItem> editableSlots = new HashMap<>();

        AdminShopHolder(Player player, int pageIndex) {
            this.player = player;
            this.pageIndex = pageIndex;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            if (slot < 0 || slot >= event.getInventory().getSize()) return;

            if (slot == 49) {
                player.closeInventory();
                return;
            }
            if (slot == 45 && pageIndex > 0) {
                openPage(player, pageIndex - 1);
                return;
            }
            if (slot == 53 && pageIndex < shop.getPages().size() - 1) {
                openPage(player, pageIndex + 1);
                return;
            }

            ShopManager.ShopItem existing = editableSlots.get(slot);
            ItemStack held = player.getInventory().getItemInMainHand();

            if (existing != null && event.isShiftClick()) {
                shop.removeItem(pageIndex, slot);
                player.sendMessage(TextUtil.parse("<green>Removed item from slot " + slot + ".</green>"));
                openPage(player, pageIndex);
            } else if (existing != null) {
                long newPrice = nextPrice(existing.price);
                shop.setCost(pageIndex, slot, newPrice);
                player.sendMessage(TextUtil.parse("<gray>Slot " + slot + " price: <light_purple>" + newPrice + " Shards</light_purple></gray>"));
                openPage(player, pageIndex);
            } else if (held.getType() != Material.AIR) {
                long price = plugin.getConfig().getLong("shop.default-add-price", 5000);
                shop.addItem(pageIndex, slot, held, price);
                player.sendMessage(TextUtil.parse("<green>Added " + held.getType().name() + " for " + price + " Shards.</green>"));
                openPage(player, pageIndex);
            }
        }

        private long nextPrice(long current) {
            for (long p : PRICE_CYCLES) {
                if (p > current) return p;
            }
            return PRICE_CYCLES[0];
        }
    }
}
