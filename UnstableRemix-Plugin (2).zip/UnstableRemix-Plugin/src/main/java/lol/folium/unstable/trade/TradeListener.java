package lol.folium.unstable.trade;

import lol.folium.unstable.util.GuiTheme;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.List;

public final class TradeListener implements Listener {

    private final TradeManager tradeManager;

    public TradeListener(TradeManager tradeManager) {
        this.tradeManager = tradeManager;
    }

    private Component parse(String text) {
        return TextUtil.parse(text);
    }

    private ItemStack pane(Material mat) {
        return ItemBuilder.of(mat).name(Component.empty()).build();
    }

    public void openTradeGUI(Player player, TradeManager.ActiveTrade trade) {
        Inventory inv = Bukkit.createInventory(null, 54,
                parse(GuiTheme.primary("TRADE: " + getOtherPlayerName(player, trade))));

        // Frame
        for (int i = 0; i < 54; i++) inv.setItem(i, pane(Material.BLACK_STAINED_GLASS_PANE));
        for (int i = 0; i < 9; i++) inv.setItem(i, pane(Material.PURPLE_STAINED_GLASS_PANE));
        for (int i = 45; i < 54; i++) inv.setItem(i, pane(Material.PURPLE_STAINED_GLASS_PANE));

        // Separator columns
        for (int row = 1; row < 5; row++) {
            inv.setItem(row * 9 + 4, pane(Material.PURPLE_STAINED_GLASS_PANE));
        }

        // Player info headers
        inv.setItem(4, ItemBuilder.of(Material.PLAYER_HEAD)
                .name(parse(GuiTheme.secondary("&e&lYOUR ITEMS"))
                ).lore(List.of(parse("&7Place items in the left section"))).build());

        // Trade items display labels
        inv.setItem(22, ItemBuilder.of(Material.EMERALD_BLOCK)
                .name(parse(GuiTheme.secondary("&a&lCONFIRM TRADE"))
                ).lore(List.of(
                        parse(""),
                        parse("&7Both players must confirm"),
                        parse("&7to complete the trade")
                )).build());

        // Put player's items in their section (left side: rows 1-4, cols 0-3)
        int slot = 10;
        for (int row = 1; row < 5; row++) {
            for (int col = 0; col < 4; col++) {
                int s = row * 9 + col;
                if (slot < trade.getItemsFor(player.getUniqueId()).length) {
                    ItemStack item = trade.getItemsFor(player.getUniqueId())[slot - 10];
                    if (item != null) inv.setItem(s, item);
                }
                slot++;
            }
        }

        // Put other player's items in right section (rows 1-4, cols 5-8)
        slot = 0;
        for (int row = 1; row < 5; row++) {
            for (int col = 5; col < 9; col++) {
                int s = row * 9 + col;
                if (slot < trade.getOtherItems(player.getUniqueId()).length) {
                    ItemStack item = trade.getOtherItems(player.getUniqueId())[slot];
                    if (item != null) inv.setItem(s, item);
                }
                slot++;
            }
        }

        // Confirm/Cancel buttons
        inv.setItem(49, ItemBuilder.of(Material.RED_WOOL)
                .name(parse("<red><bold>CANCEL</bold></red>"))
                .lore(List.of(parse("&7Click to cancel the trade"))).build());

        inv.setItem(50, ItemBuilder.of(Material.LIME_WOOL)
                .name(parse("<green><bold>CONFIRM</bold></green>"))
                .lore(List.of(parse("&7Click when ready"))).build());

        player.openInventory(inv);
        startCountdownTask(player, trade);
    }

    private String getOtherPlayerName(Player player, TradeManager.ActiveTrade trade) {
        Player other = Bukkit.getPlayer(player.getUniqueId().equals(trade.sender()) ? trade.receiver() : trade.sender());
        return other != null ? other.getName() : "Unknown";
    }

    private void startCountdownTask(Player player, TradeManager.ActiveTrade trade) {
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (trade.isCompleted() || !player.isOnline() || player.getOpenInventory().getTopInventory() == null) {
                    cancel();
                    return;
                }

                Player other = Bukkit.getPlayer(player.getUniqueId().equals(trade.sender()) ? trade.receiver() : trade.sender());
                if (other == null || !other.isOnline()) {
                    cancel();
                    return;
                }

                if (trade.bothConfirmed() && trade.isCountdownStarted()) {
                    long remaining = trade.getCountdownRemaining();
                    if (remaining <= 0) {
                        tradeManager.confirmTrade(trade.sender());
                        cancel();
                        return;
                    }

                    String bar = buildCountdownBar(remaining, 5);
                    player.sendActionBar(parse(
                            "<green><bold>CONFIRMED</bold></green> <dark_gray>|</dark_gray> <gold>Trade executing in <yellow>" + remaining + "s</yellow></gold> " + bar
                    ));
                    other.sendActionBar(parse(
                            "<green><bold>CONFIRMED</bold></green> <dark_gray>|</dark_gray> <gold>Trade executing in <yellow>" + remaining + "s</yellow></gold> " + bar
                    ));
                }

                ticks++;
            }
        }.runTaskTimer(lol.folium.unstable.UnstableRemixPlugin.getInstance(), 0L, 20L);
    }

    private String buildCountdownBar(long remaining, long total) {
        int barLength = 20;
        int filled = (int) Math.round((double) (total - remaining) / total * barLength);
        int empty = barLength - filled;
        StringBuilder bar = new StringBuilder("<dark_gray>[</dark_gray>");
        for (int i = 0; i < filled; i++) bar.append("<green>\u2588</green>");
        for (int i = 0; i < empty; i++) bar.append("<dark_gray>\u2592</dark_gray>");
        bar.append("<dark_gray>]</dark_gray>");
        return bar.toString();
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;
        String title = e.getView().getTitle();
        if (title == null) return;
        if (!title.startsWith("TRADE: ")) return;

        e.setCancelled(true);

        TradeManager.ActiveTrade trade = tradeManager.getActiveTrade(player.getUniqueId());
        if (trade == null) return;

        int slot = e.getRawSlot();

        // Player's item section (left side: rows 1-4, cols 0-3)
        if (slot >= 10 && slot < 45 && (slot % 9) < 4) {
            if (trade.isSenderConfirmed() || trade.isReceiverConfirmed()) return;

            int itemIndex = 0;
            int count = 0;
            for (int row = 1; row < 5; row++) {
                for (int col = 0; col < 4; col++) {
                    int s = row * 9 + col;
                    if (s == slot) {
                        itemIndex = count;
                        break;
                    }
                    count++;
                }
            }

            ItemStack[] playerItems = trade.getItemsFor(player.getUniqueId());

            if (e.getCursor() != null && e.getCursor().getType() != Material.AIR) {
                // Check if blocked
                if (tradeManager.isBlocked(e.getCursor().getType())) {
                    player.sendMessage(parse("<red>You cannot trade shulker boxes or bundles!"));
                    return;
                }

                // Place item in trade
                ItemStack placed = e.getCursor().clone();
                placed.setAmount(1);
                if (itemIndex < playerItems.length) {
                    playerItems[itemIndex] = placed;
                    player.getInventory().setItem(e.getSlot(), null);
                }
            } else if (e.isRightClick()) {
                // Remove item from trade
                if (itemIndex < playerItems.length && playerItems[itemIndex] != null) {
                    ItemStack removed = playerItems[itemIndex];
                    playerItems[itemIndex] = null;
                    player.getInventory().addItem(removed);
                }
            }

            trade.resetConfirmations();
            refreshGUI(player, trade);
        }

        // Confirm button
        if (slot == 50) {
            tradeManager.confirmTrade(player.getUniqueId());
            if (!trade.isCountdownStarted() && trade.bothConfirmed()) {
                trade.startCountdown();
            }
            refreshGUI(player, trade);
        }

        // Cancel button
        if (slot == 49) {
            tradeManager.cancelTrade(player.getUniqueId());
            player.closeInventory();
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTitle() == null) return;
        if (!e.getView().getTitle().startsWith("TRADE: ")) return;
        e.setCancelled(true);
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player player)) return;
        if (e.getView().getTitle() == null) return;
        if (!e.getView().getTitle().startsWith("TRADE: ")) return;

        TradeManager.ActiveTrade trade = tradeManager.getActiveTrade(player.getUniqueId());
        if (trade != null) {
            tradeManager.cancelTrade(player.getUniqueId());
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        TradeManager.ActiveTrade trade = tradeManager.getActiveTrade(e.getPlayer().getUniqueId());
        if (trade != null) {
            tradeManager.cancelTrade(e.getPlayer().getUniqueId());
        }
        tradeManager.clearRequest(e.getPlayer().getUniqueId());
    }

    private void refreshGUI(Player player, TradeManager.ActiveTrade trade) {
        Inventory inv = player.getOpenInventory().getTopInventory();
        if (inv == null) return;

        // Clear trade sections
        for (int row = 1; row < 5; row++) {
            for (int col = 0; col < 4; col++) {
                inv.setItem(row * 9 + col, pane(Material.BLACK_STAINED_GLASS_PANE));
            }
            for (int col = 5; col < 9; col++) {
                inv.setItem(row * 9 + col, pane(Material.BLACK_STAINED_GLASS_PANE));
            }
        }

        // Put items back
        int slot = 0;
        for (int row = 1; row < 5; row++) {
            for (int col = 0; col < 4; col++) {
                if (slot < trade.getItemsFor(player.getUniqueId()).length) {
                    ItemStack item = trade.getItemsFor(player.getUniqueId())[slot];
                    if (item != null) inv.setItem(row * 9 + col, item);
                }
                slot++;
            }
        }

        slot = 0;
        for (int row = 1; row < 5; row++) {
            for (int col = 5; col < 9; col++) {
                if (slot < trade.getOtherItems(player.getUniqueId()).length) {
                    ItemStack item = trade.getOtherItems(player.getUniqueId())[slot];
                    if (item != null) inv.setItem(row * 9 + col, item);
                }
                slot++;
            }
        }

        // Status indicators
        boolean senderReady = trade.isSenderConfirmed();
        boolean receiverReady = trade.isReceiverConfirmed();

        inv.setItem(46, ItemBuilder.of(senderReady ? Material.LIME_DYE : Material.GRAY_DYE)
                .name(parse(senderReady ? "<green><bold>READY</bold></green>" : "<gray>NOT READY</gray>")).build());
        inv.setItem(52, ItemBuilder.of(receiverReady ? Material.LIME_DYE : Material.GRAY_DYE)
                .name(parse(receiverReady ? "<green><bold>READY</bold></green>" : "<gray>NOT READY</gray>")).build());
    }
}
