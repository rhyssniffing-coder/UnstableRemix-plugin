package lol.folium.unstable.civ;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.faction.FactionManager;
import lol.folium.unstable.util.GuiTheme;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class CivCommand implements CommandExecutor, TabCompleter {

    private final EconomyService economy;

    public CivCommand(EconomyService economy) {
        this.economy = economy;
    }

    private Component parse(String text) {
        return TextUtil.parse(text);
    }

    private ItemStack pane(Material mat) {
        return ItemBuilder.of(mat).name(Component.empty()).build();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        if (args.length == 0) {
            openMainMenu(player);
            return true;
        }

        String sub = args[0].toLowerCase();
        switch (sub) {
            case "create" -> {
                if (args.length < 2) {
                    player.sendMessage(parse("&cUsage: /civ create <name>"));
                    return true;
                }
                createCiv(player, args[1]);
            }
            case "invite" -> {
                if (args.length < 2) {
                    player.sendMessage(parse("&cUsage: /civ invite <player>"));
                    return true;
                }
                invitePlayer(player, args[1]);
            }
            case "accept" -> {
                if (args.length < 2) {
                    player.sendMessage(parse("&cUsage: /civ accept <civ name>"));
                    return true;
                }
                acceptInvite(player, args[1]);
            }
            case "leave" -> leaveCiv(player);
            case "disband" -> disbandCiv(player);
            case "prefix" -> {
                if (args.length < 2) {
                    player.sendMessage(parse("&cUsage: /civ prefix <new prefix>"));
                    return true;
                }
                changePrefix(player, args[1]);
            }
            case "deposit" -> {
                if (args.length < 2) {
                    player.sendMessage(parse("&cUsage: /civ deposit <amount>"));
                    return true;
                }
                deposit(player, args[1]);
            }
            case "withdraw" -> {
                if (args.length < 2) {
                    player.sendMessage(parse("&cUsage: /civ withdraw <amount>"));
                    return true;
                }
                withdraw(player, args[1]);
            }
            default -> openMainMenu(player);
        }
        return true;
    }

    private void openMainMenu(Player player) {
        UUID uuid = player.getUniqueId();
        Civilization civ = CivManager.getInstance().getPlayerCiv(uuid);
        Inventory inv = Bukkit.createInventory(null, 54, parse(GuiTheme.primary("CIVILIZATIONS")));

        for (int i = 0; i < 54; i++) inv.setItem(i, pane(Material.BLACK_STAINED_GLASS_PANE));
        for (int i = 0; i < 9; i++) {
            inv.setItem(i, pane(Material.PURPLE_STAINED_GLASS_PANE));
            inv.setItem(45 + i, pane(Material.PURPLE_STAINED_GLASS_PANE));
        }

        if (civ != null) {
            boolean isOwner = civ.isOwner(uuid);
            long civBalance = civ.getBalance();

            inv.setItem(13, ItemBuilder.of(Material.BEACON)
                    .name(parse(GuiTheme.secondary("&b&l" + civ.getName())))
                    .lore(List.of(
                            parse(""),
                            parse("&7Prefix: " + civ.getFormattedPrefix()),
                            parse("&7Members: &f" + civ.getMembers().size()),
                            parse("&7Balance: &6" + civBalance + " shards"),
                            parse("")
                    )).build());

            inv.setItem(20, ItemBuilder.of(Material.ENDER_CHEST)
                    .name(parse(GuiTheme.secondary("&d&lCIV VAULT")))
                    .lore(List.of(parse(""), parse("&7Shared storage for your civ"))).build());

            inv.setItem(22, ItemBuilder.of(Material.PAPER)
                    .name(parse(GuiTheme.secondary("&e&lTODO LIST")))
                    .lore(List.of(parse(""), parse("&7Tasks: &f" + civ.getTodoList().size()))).build());

            inv.setItem(24, ItemBuilder.of(Material.RED_BANNER)
                    .name(parse(GuiTheme.secondary("&c&lTARGETS")))
                    .lore(List.of(parse(""), parse("&7Count: &f" + civ.getTargets().size()))).build());

            inv.setItem(29, ItemBuilder.of(Material.PLAYER_HEAD)
                    .name(parse(GuiTheme.secondary("&a&lMEMBERS")))
                    .lore(List.of(parse(""), parse("&7View and manage members"))).build());

            if (isOwner) {
                inv.setItem(31, ItemBuilder.of(Material.WRITABLE_BOOK)
                        .name(parse(GuiTheme.secondary("&6&lINVITES")))
                        .lore(List.of(parse(""), parse("&7Manage pending invites"))).build());
            }

            inv.setItem(33, ItemBuilder.of(Material.GOLD_BLOCK)
                    .name(parse(GuiTheme.secondary("&6&lDEPOSIT SHARDS")))
                    .lore(List.of(parse(""), parse("&7Deposit shards into civ vault"))).build());

            if (isOwner) {
                inv.setItem(35, ItemBuilder.of(Material.IRON_BLOCK)
                        .name(parse(GuiTheme.secondary("&f&lWITHDRAW SHARDS")))
                        .lore(List.of(parse(""), parse("&7Withdraw shards from civ vault"))).build());
            }

            inv.setItem(49, ItemBuilder.of(Material.BARRIER)
                    .name(parse(GuiTheme.secondary("&c&lLEAVE CIV")))
                    .lore(List.of(parse(""), parse("&7Leave this civilization"))).build());
        } else {
            inv.setItem(20, ItemBuilder.of(Material.NETHER_STAR)
                    .name(parse(GuiTheme.primary("&b&lCREATE CIVILIZATION")))
                    .lore(List.of(
                            parse(""),
                            parse("&7Cost: &6" + CivManager.getInstance().getCreateCost() + " shards"),
                            parse(""),
                            parse("&7Create your own civilization"),
                            parse("&7with custom prefix and color!")
                    )).build());

            inv.setItem(24, ItemBuilder.of(Material.BOOK)
                    .name(parse(GuiTheme.secondary("&e&lALL CIVILIZATIONS")))
                    .lore(List.of(parse(""), parse("&7Browse existing civilizations"))).build());
        }

        player.openInventory(inv);
    }

    public void openPrefixSetup(Player player, String civName) {
        Inventory inv = Bukkit.createInventory(null, 45, parse(GuiTheme.primary("SETUP: " + civName)));

        for (int i = 0; i < 45; i++) inv.setItem(i, pane(Material.BLACK_STAINED_GLASS_PANE));
        for (int i = 0; i < 9; i++) {
            inv.setItem(i, pane(Material.PURPLE_STAINED_GLASS_PANE));
            inv.setItem(36 + i, pane(Material.PURPLE_STAINED_GLASS_PANE));
        }

        inv.setItem(4, ItemBuilder.of(Material.BOOK)
                .name(parse(GuiTheme.secondary("&e&lSETUP YOUR PREFIX")))
                .lore(List.of(
                        parse(""),
                        parse("&7Step 1: Click a color below"),
                        parse("&7Step 2: Type your prefix (" + CivManager.getInstance().getMaxPrefixLength() + " chars max)"),
                        parse(""),
                        parse("&7Gradient: &6" + CivManager.getInstance().getGradientCost() + " extra shards")
                )).build());

        int slot = 10;
        for (Map.Entry<String, String> color : CivManager.getInstance().getPresetColors().entrySet()) {
            inv.setItem(slot, ItemBuilder.of(Material.BONE_MEAL)
                    .name(parse(color.getValue() + color.getKey()))
                    .lore(List.of(parse(""), parse("&7Click to select this color"))).build());
            slot++;
            if (slot == 15) slot = 19;
        }

        inv.setItem(25, ItemBuilder.of(Material.PRISMARINE_CRYSTALS)
                .name(parse(GuiTheme.primary("&6&lGRADIENT")))
                .lore(List.of(
                        parse(""),
                        parse("&7Extra cost: &6" + CivManager.getInstance().getGradientCost() + " shards"),
                        parse("&7Makes your prefix a rainbow gradient!")
                )).build());

        pendingSetups.put(player.getUniqueId(), new PendingCivSetup(civName));
        player.openInventory(inv);
    }

    private final Map<UUID, PendingCivSetup> pendingSetups = new HashMap<>();

    public PendingCivSetup getPendingSetup(UUID uuid) {
        return pendingSetups.get(uuid);
    }

    public void removePendingSetup(UUID uuid) {
        pendingSetups.remove(uuid);
    }

    public void createCiv(Player player, String name) {
        UUID uuid = player.getUniqueId();
        CivManager civManager = CivManager.getInstance();

        if (civManager.isPlayerInCiv(uuid)) {
            player.sendMessage(parse("&cYou are already in a civilization! Leave first."));
            return;
        }
        if (name.length() > civManager.getMaxNameLength()) {
            player.sendMessage(parse("&cCiv name must be " + civManager.getMaxNameLength() + " characters or less!"));
            return;
        }
        if (civManager.getCivByName(name) != null) {
            player.sendMessage(parse("&cA civilization with that name already exists!"));
            return;
        }
        long balance = economy.getShards(uuid);
        if (balance < civManager.getCreateCost()) {
            player.sendMessage(parse("&cYou need " + civManager.getCreateCost() + " shards to create a civ!"));
            return;
        }
        openPrefixSetup(player, name);
    }

    public void completeCivCreation(Player player, String prefix) {
        String civName = pendingPrefixInput.remove(player.getUniqueId());
        String color = pendingColorSelection.remove(player.getUniqueId());
        if (civName == null || color == null) return;

        CivManager civManager = CivManager.getInstance();
        boolean gradient = color.equals("gradient");
        long cost = civManager.getCreateCost() + (gradient ? civManager.getGradientCost() : 0);

        long balance = economy.getShards(player.getUniqueId());
        if (balance < cost) {
            player.sendMessage(parse("&cYou need " + cost + " shards!"));
            return;
        }

        economy.removeShards(player.getUniqueId(), cost, "civ-create");
        Civilization civ = civManager.createCiv(civName, prefix, gradient ? "&" : color, gradient, player.getUniqueId());

        // Leave faction when creating a civ
        FactionManager factionManager = UnstableRemixPlugin.getInstance().getFactionManager();
        if (factionManager != null) {
            String factionName = factionManager.getFactionName(player);
            if (factionName != null) {
                factionManager.removePlayerFromFaction(player.getUniqueId());
                player.sendMessage(TextUtil.parse("<gray>You left your faction to create a civilization.</gray>"));
            }
        }

        player.sendMessage(parse("&a&lCIVILIZATION CREATED!"));
        player.sendMessage(parse("&7Name: &f" + civName));
        player.sendMessage(parse("&7Prefix: " + civ.getFormattedPrefix()));
        player.sendMessage(parse("&7Cost: &6" + cost + " shards"));
    }

    final Map<UUID, String> pendingPrefixInput = new HashMap<>();
    final Map<UUID, String> pendingColorSelection = new HashMap<>();

    public record PendingCivSetup(String civName) {}

    private void invitePlayer(Player player, String targetName) {
        Civilization civ = CivManager.getInstance().getPlayerCiv(player.getUniqueId());
        if (civ == null) { player.sendMessage(parse("&cYou are not in a civilization!")); return; }
        if (!civ.isOwner(player.getUniqueId())) { player.sendMessage(parse("&cOnly the owner can invite players!")); return; }

        Player target = Bukkit.getPlayer(targetName);
        if (target == null) { player.sendMessage(parse("&cPlayer not found!")); return; }
        if (CivManager.getInstance().isPlayerInCiv(target.getUniqueId())) { player.sendMessage(parse("&cThat player is already in a civilization!")); return; }

        civ.invite(target.getUniqueId());
        CivManager.getInstance().saveAll();
        player.sendMessage(parse("&aInvited " + target.getName() + " to " + civ.getName() + "!"));
        target.sendMessage(parse("&aYou've been invited to " + civ.getName() + "!"));
        target.sendMessage(parse("&7Type &f/civ accept " + civ.getName() + " &7to join."));
    }

    private void acceptInvite(Player player, String civName) {
        Civilization civ = CivManager.getInstance().getCivByName(civName);
        if (civ == null) { player.sendMessage(parse("&cCivilization not found!")); return; }
        if (!civ.isInvited(player.getUniqueId())) { player.sendMessage(parse("&cYou haven't been invited!")); return; }
        CivManager.getInstance().joinCiv(player.getUniqueId(), civ);
        player.sendMessage(parse("&aWelcome to " + civ.getName() + "!"));
    }

    private void leaveCiv(Player player) {
        Civilization civ = CivManager.getInstance().getPlayerCiv(player.getUniqueId());
        if (civ == null) { player.sendMessage(parse("&cYou are not in a civilization!")); return; }
        CivManager.getInstance().leaveCiv(player.getUniqueId());
        player.sendMessage(parse("&aYou left " + civ.getName() + "."));
    }

    private void disbandCiv(Player player) {
        Civilization civ = CivManager.getInstance().getPlayerCiv(player.getUniqueId());
        if (civ == null || !civ.isOwner(player.getUniqueId())) { player.sendMessage(parse("&cOnly the owner can disband!")); return; }
        CivManager.getInstance().disbandCiv(civ.getId());
        player.sendMessage(parse("&c" + civ.getName() + " has been disbanded."));
    }

    private void changePrefix(Player player, String newPrefix) {
        Civilization civ = CivManager.getInstance().getPlayerCiv(player.getUniqueId());
        if (civ == null || !civ.isOwner(player.getUniqueId())) { player.sendMessage(parse("&cOnly the owner can change the prefix!")); return; }
        if (newPrefix.length() > CivManager.getInstance().getMaxPrefixLength()) { player.sendMessage(parse("&cPrefix must be " + CivManager.getInstance().getMaxPrefixLength() + " chars or less!")); return; }
        if (CivManager.getInstance().getCivByPrefix(newPrefix) != null) { player.sendMessage(parse("&cThat prefix is already taken!")); return; }
        civ.setPrefix(newPrefix);
        CivManager.getInstance().saveAll();
        player.sendMessage(parse("&aPrefix changed to " + newPrefix + "!"));
    }

    private void deposit(Player player, String amountStr) {
        Civilization civ = CivManager.getInstance().getPlayerCiv(player.getUniqueId());
        if (civ == null) { player.sendMessage(parse("&cYou are not in a civilization!")); return; }
        try {
            long amount = Long.parseLong(amountStr);
            if (amount <= 0) { player.sendMessage(parse("&cAmount must be positive!")); return; }
            if (economy.getShards(player.getUniqueId()) < amount) { player.sendMessage(parse("&cYou don't have enough shards!")); return; }
            economy.removeShards(player.getUniqueId(), amount, "civ-deposit");
            civ.deposit(amount);
            CivManager.getInstance().saveAll();
            player.sendMessage(parse("&aDeposited " + amount + " shards to " + civ.getName() + "!"));
        } catch (NumberFormatException e) {
            player.sendMessage(parse("&cInvalid amount!"));
        }
    }

    private void withdraw(Player player, String amountStr) {
        Civilization civ = CivManager.getInstance().getPlayerCiv(player.getUniqueId());
        if (civ == null || !civ.isOwner(player.getUniqueId())) { player.sendMessage(parse("&cOnly the owner can withdraw!")); return; }
        try {
            long amount = Long.parseLong(amountStr);
            if (amount <= 0) { player.sendMessage(parse("&cAmount must be positive!")); return; }
            if (!civ.withdraw(amount)) { player.sendMessage(parse("&cThe civ vault doesn't have enough shards!")); return; }
            economy.grantShards(player.getUniqueId(), amount, "civ-withdraw", null);
            CivManager.getInstance().saveAll();
            player.sendMessage(parse("&aWithdrew " + amount + " shards from " + civ.getName() + "!"));
        } catch (NumberFormatException e) {
            player.sendMessage(parse("&cInvalid amount!"));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            completions.addAll(List.of("create", "invite", "accept", "leave", "disband", "prefix", "deposit", "withdraw"));
        } else if (args.length == 2) {
            switch (args[0].toLowerCase()) {
                case "invite" -> { for (Player p : Bukkit.getOnlinePlayers()) completions.add(p.getName()); }
                case "accept" -> { for (Civilization civ : CivManager.getInstance().getAllCivs()) completions.add(civ.getName()); }
            }
        }
        String last = args[args.length - 1].toLowerCase();
        completions.removeIf(s -> !s.toLowerCase().startsWith(last));
        return completions;
    }
}
