package lol.folium.unstable.cooldown;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class CooldownItemListener implements Listener {

    private final UnstableRemixPlugin plugin;
    private final CooldownItemManager itemManager;
    private final KitCooldownManager cooldownManager;

    public CooldownItemListener(UnstableRemixPlugin plugin, CooldownItemManager itemManager, KitCooldownManager cooldownManager) {
        this.plugin = plugin;
        this.itemManager = itemManager;
        this.cooldownManager = cooldownManager;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (item == null || item.getType().isAir()) return;

        String itemId = itemManager.getItemId(item);
        if (itemId == null) return;

        CooldownItem cooldownItem = itemManager.getItem(itemId);
        if (cooldownItem == null) return;

        event.setCancelled(true);
        Player player = event.getPlayer();

        applyEffect(player, cooldownItem);
        itemManager.removeOne(player, item);

        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.2F);
    }

    private void applyEffect(Player player, CooldownItem item) {
        long expires = item.durationSeconds() > 0
                ? System.currentTimeMillis() + item.durationSeconds() * 1000L
                : -1;

        switch (item.effect()) {
            case "no-cooldown" -> {
                cooldownManager.setBypass(player.getUniqueId(), expires);
                player.sendMessage(TextUtil.parse("<green>You now have kit cooldown bypass"
                        + (item.durationSeconds() > 0 ? " for " + (item.durationSeconds() / 60) + " minutes." : " permanently.")));
            }
            case "skip-cooldown" -> {
                cooldownManager.removeAllCooldowns(player.getUniqueId());
                player.sendMessage(TextUtil.parse("<green>All kit cooldowns have been reset.</green>"));
            }
            case "shard-boost" -> {
                cooldownManager.setShardBoost(player.getUniqueId(), expires, item.shardMultiplier());
                player.sendMessage(TextUtil.parse("<gold>" + String.format("%.1f", item.shardMultiplier()) + "x Shard Boost active for "
                        + (item.durationSeconds() / 60) + " minutes!</gold>"));
            }
            case "firework-bypass" -> {
                cooldownManager.setFireworkBypass(player.getUniqueId(), expires);
                player.sendMessage(TextUtil.parse("<green>Firework cooldown bypassed"
                        + (item.durationSeconds() > 0 ? " for " + (item.durationSeconds() / 60) + " minutes." : " permanently.")));
            }
            default -> player.sendMessage(TextUtil.parse("<red>Unknown effect: " + item.effect()));
        }
    }
}
