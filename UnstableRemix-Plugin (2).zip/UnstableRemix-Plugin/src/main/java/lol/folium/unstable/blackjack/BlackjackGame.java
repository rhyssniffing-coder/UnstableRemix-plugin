package lol.folium.unstable.blackjack;

import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.economy.TransactionResult;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class BlackjackGame {

    public enum State {
        BETTING, PLAYER_TURN, DEALER_TURN, RESOLVED
    }

    public enum Result {
        PLAYER_BLACKJACK, PLAYER_WIN, PLAYER_BUST, DEALER_WIN, DEALER_BLACKJACK, PUSH
    }

    private static final ConcurrentHashMap<UUID, BlackjackGame> activeGames = new ConcurrentHashMap<>();

    private final UUID playerId;
    private final EconomyService economy;
    private final Deck deck;
    private final Hand playerHand;
    private final Hand dealerHand;
    private State state;
    private long bet;
    private Result result;
    private boolean doubledDown;

    public BlackjackGame(UUID playerId, EconomyService economy) {
        this.playerId = playerId;
        this.economy = economy;
        this.deck = new Deck();
        this.playerHand = new Hand();
        this.dealerHand = new Hand();
        this.state = State.BETTING;
        this.bet = 0;
        this.result = null;
        this.doubledDown = false;
    }

    public static BlackjackGame getActive(UUID uuid) {
        return activeGames.get(uuid);
    }

    public static void removeActive(UUID uuid) {
        activeGames.remove(uuid);
    }

    public boolean placeBet(long amount) {
        if (state != State.BETTING) return false;
        if (amount <= 0) return false;

        TransactionResult spend = economy.spendShards(playerId, amount, "blackjack-bet");
        if (!spend.success()) return false;

        this.bet = amount;
        dealInitial();
        return true;
    }

    private void dealInitial() {
        playerHand.add(deck.draw());
        dealerHand.add(deck.draw());
        playerHand.add(deck.draw());
        dealerHand.add(deck.draw());

        if (playerHand.isBlackjack()) {
            if (dealerHand.isBlackjack()) {
                result = Result.PUSH;
                state = State.RESOLVED;
                economy.grantShards(playerId, bet, "blackjack-push", "push:" + System.nanoTime());
            } else {
                result = Result.PLAYER_BLACKJACK;
                state = State.RESOLVED;
                long payout = bet + (bet * 3 / 2);
                economy.grantShards(playerId, payout, "blackjack-bj", "bj:" + System.nanoTime());
            }
        } else {
            state = State.PLAYER_TURN;
        }
    }

    public void hit() {
        if (state != State.PLAYER_TURN) return;
        playerHand.add(deck.draw());
        if (playerHand.isBust()) {
            result = Result.PLAYER_BUST;
            state = State.RESOLVED;
        } else if (playerHand.value() == 21) {
            stand();
        }
    }

    public void stand() {
        if (state != State.PLAYER_TURN) return;
        dealerPlay();
    }

    public boolean doubleDown() {
        if (state != State.PLAYER_TURN) return false;
        if (playerHand.size() != 2) return false;

        TransactionResult spend = economy.spendShards(playerId, bet, "blackjack-double");
        if (!spend.success()) return false;

        bet *= 2;
        doubledDown = true;
        playerHand.add(deck.draw());

        if (playerHand.isBust()) {
            result = Result.PLAYER_BUST;
            state = State.RESOLVED;
        } else {
            dealerPlay();
        }
        return true;
    }

    private void dealerPlay() {
        state = State.DEALER_TURN;

        while (dealerHand.value() < 17) {
            dealerHand.add(deck.draw());
        }

        resolve();
    }

    private void resolve() {
        if (dealerHand.isBlackjack()) {
            result = Result.DEALER_BLACKJACK;
        } else if (playerHand.isBust()) {
            result = Result.PLAYER_BUST;
        } else if (dealerHand.isBust()) {
            result = Result.PLAYER_WIN;
        } else if (playerHand.value() > dealerHand.value()) {
            result = Result.PLAYER_WIN;
        } else if (dealerHand.value() > playerHand.value()) {
            result = Result.DEALER_WIN;
        } else {
            result = Result.PUSH;
        }

        state = State.RESOLVED;

        switch (result) {
            case PLAYER_BLACKJACK -> {
                long payout = bet + (bet * 3 / 2);
                economy.grantShards(playerId, payout, "blackjack-win", "win:" + System.nanoTime());
            }
            case PLAYER_WIN -> {
                economy.grantShards(playerId, bet * 2, "blackjack-win", "win:" + System.nanoTime());
            }
            case PUSH -> {
                economy.grantShards(playerId, bet, "blackjack-push", "push:" + System.nanoTime());
            }
            default -> {}
        }
    }

    public static void startGame(Player player, EconomyService economy, long betAmount) {
        BlackjackGame existing = activeGames.get(player.getUniqueId());
        if (existing != null && existing.state != State.RESOLVED) {
            player.sendMessage("§cYou already have an active game!");
            return;
        }

        BlackjackGame game = new BlackjackGame(player.getUniqueId(), economy);
        if (!game.placeBet(betAmount)) {
            player.sendMessage("§cInsufficient shards! Need " + betAmount + " shards.");
            return;
        }

        activeGames.put(player.getUniqueId(), game);
    }

    public UUID playerId() { return playerId; }
    public Hand playerHand() { return playerHand; }
    public Hand dealerHand() { return dealerHand; }
    public State state() { return state; }
    public long bet() { return bet; }
    public Result result() { return result; }
    public boolean doubledDown() { return doubledDown; }
    public Deck deck() { return deck; }
    public EconomyService economy() { return economy; }
}
