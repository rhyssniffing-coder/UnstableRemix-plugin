package lol.folium.unstable.listener;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.bounty.BountyManager;
import lol.folium.unstable.combat.CombatTagManager;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.faction.FactionManager;
import lol.folium.unstable.kit.KitManager;
import lol.folium.unstable.kit.KillCounterManager;
import lol.folium.unstable.quest.QuestService;
import lol.folium.unstable.settings.SettingsManager;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.util.List;

public final class CombatListener implements Listener {

    private static final long KILL_SHARD_REWARD = 10L;

    private final QuestService quests;
    private final CombatTagManager combatTags;
    private final KitManager kits;
    private final BountyManager bounties;
    private final KillCounterManager killCounters;
    private final FactionManager factions;
    private final EconomyService economy;
    private final UnstableRemixPlugin plugin;

    public CombatListener(QuestService quests, CombatTagManager combatTags, KitManager kits,
                          BountyManager bounties, KillCounterManager killCounters,
                          FactionManager factions, EconomyService economy, UnstableRemixPlugin plugin) {
        this.quests = quests;
        this.combatTags = combatTags;
        this.kits = kits;
        this.bounties = bounties;
        this.killCounters = killCounters;
        this.factions = factions;
        this.economy = economy;
        this.plugin = plugin;
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        if (killer == null || killer.equals(victim)) {
            return;
        }

        combatTags.untagOpponents(victim);
        combatTags.untagOpponents(killer);

        quests.trackKill(killer, victim);
        kits.handleKill(killer, victim);
        bounties.claim(killer, victim);
        if (bounties.bounty(victim.getUniqueId()) > 0) {
            quests.trackTrackdown(killer);
        }
        killCounters.handleKill(killer, victim);
        if (factions != null) {
            factions.handleFactionKill(killer);
            factions.handleWarKill(killer);
        }

        int streak = quests.activeKillstreak(killer);
        double multiplier = 1.0D + (streak / 3) * 0.1D;
        multiplier = Math.min(2.0D, multiplier);
        long reward = Math.round(KILL_SHARD_REWARD * multiplier);
        economy.grantShards(killer.getUniqueId(), reward, "kill:" + victim.getName(), null);
        killer.playSound(killer.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5F, 1.5F);
        if (multiplier > 1.0D) {
            killer.sendMessage(TextUtil.parse("<green>+<white>" + reward + "</white> Shards <dark_gray>(<gold>" + String.format("%.1f", multiplier) + "x</gold>)</dark_gray></green>"));
        } else {
            killer.sendMessage(TextUtil.parse("<green>+<white>" + reward + "</white> Shards</green>"));
        }

        handleStreakRewards(killer, streak);

        event.deathMessage(null);
        int victimStreak = quests.activeKillstreak(victim);
        String deathMsg = plugin.getConfig().getString("kill-messages.death",
                "<gray>[<gradient:#00d4ff:#7b2ff7>UnstableRemix</gradient>]</gray> <white>{victim}</white> <gray>died to</gray> <white>{killer}</white>");
        Component msg = TextUtil.parse(deathMsg
                .replace("{victim}", victim.getName())
                .replace("{killer}", killer.getName()));
        if (victimStreak > 5) {
            String streakMsg = plugin.getConfig().getString("kill-messages.killstreak-lost",
                    "<gray>[<gradient:#00d4ff:#7b2ff7>UnstableRemix</gradient>]</gray> <white>{victim}</white> <red>lost their killstreak of</red> <yellow>{streak}</yellow> <red>to</red> <white>{killer}</white>");
            Component streakComp = TextUtil.parse(streakMsg
                    .replace("{victim}", victim.getName())
                    .replace("{killer}", killer.getName())
                    .replace("{streak}", String.valueOf(victimStreak)));
            for (Player online : victim.getServer().getOnlinePlayers()) {
                online.sendMessage(streakComp);
            }
        } else {
            for (Player online : victim.getServer().getOnlinePlayers()) {
                online.sendMessage(msg);
            }
        }
    }

    private void handleStreakRewards(Player killer, int streak) {
        var streakSection = plugin.getConfig().getConfigurationSection("kill-messages.streak-rewards");
        if (streakSection == null || !streakSection.getBoolean("enabled", true)) return;

        var thresholds = streakSection.getConfigurationSection("thresholds");
        if (thresholds == null) return;

        boolean killstreakAlertsEnabled = SettingsManager.getInstance().getSettings(killer.getUniqueId())
                .isEnabled(lol.folium.unstable.settings.PlayerSettings.Setting.KILLSTREAK_ALERTS);

        for (String key : thresholds.getKeys(false)) {
            int threshold;
            try {
                threshold = Integer.parseInt(key);
            } catch (NumberFormatException e) {
                continue;
            }

            if (streak == threshold) {
                var section = thresholds.getConfigurationSection(key);
                if (section == null) continue;

                String message = section.getString("message", "");
                String title = section.getString("title", "");
                String subtitle = section.getString("subtitle", "");
                String soundName = section.getString("sound", "ENTITY_PLAYER_LEVELUP");
                long rewardShards = section.getLong("reward-shards", 0);

                if (!message.isEmpty()) {
                    killer.sendMessage(TextUtil.parse(message));
                }

                if (!title.isEmpty() && killstreakAlertsEnabled) {
                    killer.sendTitlePart(net.kyori.adventure.title.TitlePart.TITLE, TextUtil.parse(title));
                    killer.sendTitlePart(net.kyori.adventure.title.TitlePart.SUBTITLE, TextUtil.parse(subtitle));
                    killer.sendTitlePart(net.kyori.adventure.title.TitlePart.TIMES,
                            net.kyori.adventure.title.Title.Times.times(
                                    java.time.Duration.ofMillis(500),
                                    java.time.Duration.ofSeconds(3),
                                    java.time.Duration.ofMillis(1000)));
                }

                try {
                    Sound sound = Sound.valueOf(soundName.toUpperCase());
                    killer.playSound(killer.getLocation(), sound, 1.0F, 1.0F);
                } catch (IllegalArgumentException e) {
                    killer.playSound(killer.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.0F);
                }

                if (rewardShards > 0) {
                    economy.grantShards(killer.getUniqueId(), rewardShards, "streak:" + streak, null);
                    killer.sendMessage(TextUtil.parse("<gold>+" + rewardShards + " Shards bonus!</gold>"));
                }

                for (Player online : killer.getServer().getOnlinePlayers()) {
                    online.sendMessage(TextUtil.parse("<yellow>" + killer.getName() + " has a " + streak + " kill streak!</yellow>"));
                }

                break;
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker) || !(event.getEntity() instanceof Player)) {
            return;
        }
        combatTags.tag(attacker, (Player) event.getEntity());
        Material weapon = attacker.getInventory().getItemInMainHand().getType();
        if (!weapon.name().endsWith("_SWORD")) {
            return;
        }
        quests.trackSwordDamage(attacker, event.getFinalDamage());
    }
}