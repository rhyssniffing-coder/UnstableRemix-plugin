package lol.folium.unstable.civ;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import lol.folium.unstable.UnstableRemixPlugin;
import org.bukkit.Bukkit;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class CivVault {

    private static CivVault instance;
    private final Map<UUID, Inventory> vaultCache = new ConcurrentHashMap<>();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final Path dataFolder;
    private final File vaultFile;

    private static final int VAULT_SIZE = 54; // 6 rows

    public CivVault() {
        this.dataFolder = UnstableRemixPlugin.getInstance().getDataFolder().toPath();
        this.vaultFile = dataFolder.resolve("civ-vaults.json").toFile();
    }

    public static CivVault getInstance() {
        if (instance == null) {
            instance = new CivVault();
        }
        return instance;
    }

    public Inventory getVault(Civilization civ) {
        return vaultCache.computeIfAbsent(civ.getId(), id -> {
            Inventory inv = Bukkit.createInventory(null, VAULT_SIZE,
                    lol.folium.unstable.util.GuiTheme.primary(civ.getName() + " VAULT"));

            if (vaultFile.exists()) {
                try {
                    String json = new String(Files.readAllBytes(vaultFile.toPath()), StandardCharsets.UTF_8);
                    JsonObject root = JsonParser.parseString(json).getAsJsonObject();
                    if (root.has(id.toString())) {
                        String itemJson = root.get(id.toString()).getAsString();
                        ItemStack[] items = gson.fromJson(itemJson, ItemStack[].class);
                        for (int i = 0; i < Math.min(items.length, VAULT_SIZE); i++) {
                            if (items[i] != null) inv.setItem(i, items[i]);
                        }
                    }
                } catch (Exception e) {
                    UnstableRemixPlugin.getInstance().getLogger().severe("Failed to load vault for " + id + ": " + e.getMessage());
                }
            }
            return inv;
        });
    }

    public void saveVault(UUID civId) {
        Inventory inv = vaultCache.get(civId);
        if (inv == null) return;

        try {
            JsonObject root = readRoot();
            ItemStack[] contents = inv.getContents();
            root.add(civId.toString(), gson.toJsonTree(contents));
            writeRoot(root);
        } catch (IOException e) {
            UnstableRemixPlugin.getInstance().getLogger().severe("Failed to save vault for " + civId + ": " + e.getMessage());
        }
    }

    public void saveAll() {
        for (UUID civId : vaultCache.keySet()) {
            saveVault(civId);
        }
    }

    private JsonObject readRoot() throws IOException {
        if (!vaultFile.exists()) {
            vaultFile.getParentFile().mkdirs();
            vaultFile.createNewFile();
            return new JsonObject();
        }
        String json = new String(Files.readAllBytes(vaultFile.toPath()), StandardCharsets.UTF_8);
        if (json.trim().isEmpty()) return new JsonObject();
        return JsonParser.parseString(json).getAsJsonObject();
    }

    private void writeRoot(JsonObject root) throws IOException {
        vaultFile.getParentFile().mkdirs();
        try (Writer writer = new OutputStreamWriter(new FileOutputStream(vaultFile), StandardCharsets.UTF_8)) {
            gson.toJson(root, writer);
        }
    }
}
