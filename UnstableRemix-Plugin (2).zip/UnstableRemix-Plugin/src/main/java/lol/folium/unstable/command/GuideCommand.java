package lol.folium.unstable.command;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

import java.util.ArrayList;
import java.util.List;

public final class GuideCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;

    public GuideCommand(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    protected void execute(Player player, String[] args) {
        openGui(player);
    }

    public void openGui(Player player) {
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("guide");
        String title = section != null ? section.getString("title", "<gradient:#FF4444:#FF8800:#FFD700><bold>GUIDE</bold></gradient>") : "<gradient:#FF4444:#FF8800:#FFD700><bold>GUIDE</bold></gradient>";
        int rows = section != null ? section.getInt("rows", 4) : 4;

        GuideHolder holder = new GuideHolder();
        Inventory inv = Bukkit.createInventory(holder, rows * 9, TextUtil.parse(title));
        holder.bind(inv);

        for (int i = 0; i < rows * 9; i++) {
            inv.setItem(i, ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE).name(Component.empty()).build());
        }

        ConfigurationSection pages = section != null ? section.getConfigurationSection("pages") : null;
        if (pages != null) {
            for (String key : pages.getKeys(false)) {
                ConfigurationSection page = pages.getConfigurationSection(key);
                if (page == null) continue;

                String materialName = page.getString("material", "KNOWLEDGE_BOOK");
                Material mat = Material.matchMaterial(materialName);
                if (mat == null) mat = Material.KNOWLEDGE_BOOK;

                int slot = page.getInt("slot", 10);
                String name = page.getString("name", "<gradient:#FF4444:#FF8800:#FFD700><bold>" + key.toUpperCase() + "</bold></gradient>");
                List<String> rawLore = page.getStringList("lore");
                List<Component> lore = new ArrayList<>();
                for (String line : rawLore) {
                    lore.add(TextUtil.parse(line));
                }

                String command = page.getString("command", "");

                inv.setItem(slot, ItemBuilder.of(mat)
                        .name(TextUtil.parse(name))
                        .lore(lore)
                        .build());
                holder.pageSlots.put(slot, command);
            }
        }

        int closeSlot = rows * 9 - 5;
        inv.setItem(closeSlot, ItemBuilder.of(Material.BARRIER)
                .name(TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700><bold>\u2718 CLOSE</bold></gradient>"))
                .build());

        player.openInventory(inv);
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
    }

    public Listener createListener() {
        return new Listener() {
            @EventHandler
            public void onInventoryClick(InventoryClickEvent event) {
                if (!(event.getWhoClicked() instanceof Player p)) return;
                if (!(event.getInventory().getHolder() instanceof GuideHolder holder)) return;
                event.setCancelled(true);

                int slot = event.getRawSlot();
                if (slot < 0 || slot >= event.getInventory().getSize()) return;

                if (event.getCurrentItem() == null || event.getCurrentItem().getType() == Material.BARRIER) {
                    p.closeInventory();
                    return;
                }

                String command = holder.pageSlots.get(slot);
                if (command != null && !command.isEmpty()) {
                    p.closeInventory();
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        for (String cmd : command.split("\\|")) {
                            String trimmed = cmd.trim();
                            if (trimmed.startsWith("/")) {
                                p.performCommand(trimmed.substring(1));
                            } else {
                                Bukkit.dispatchCommand(p, trimmed);
                            }
                        }
                    }, 2L);
                }
            }

            @EventHandler
            public void onInventoryDrag(InventoryDragEvent event) {
                if (event.getInventory().getHolder() instanceof GuideHolder) {
                    event.setCancelled(true);
                }
            }
        };
    }

    private static final class GuideHolder extends GuiHolder {
        private final java.util.Map<Integer, String> pageSlots = new java.util.HashMap<>();

        @Override
        public void handleClick(InventoryClickEvent event) {
        }
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        return List.of();
    }

    @Override
    protected String permission() {
        return null;
    }
}
