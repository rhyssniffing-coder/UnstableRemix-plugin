package lol.folium.unstable.rent;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.data.PlayerDataStore;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.economy.TransactionResult;
import lol.folium.unstable.effects.EffectsManager;
import lol.folium.unstable.integration.LuckPermsHook;
import lol.folium.unstable.util.ConfigItems;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;

import java.util.HashMap;
import java.util.Map;

import java.time.Duration;
import java.util.Map;

public final class RentRankManager {

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final EconomyService economy;
    private final LuckPermsHook luckPerms;
    private final EffectsManager effects;
    private final PlayerDataStore store;

    public RentRankManager(UnstableRemixPlugin plugin, ConfigManager configs, EconomyService economy,
                           LuckPermsHook luckPerms, EffectsManager effects, PlayerDataStore store) {
        this.plugin = plugin;
        this.configs = configs;
        this.economy = economy;
        this.luckPerms = luckPerms;
        this.effects = effects;
        this.store = store;
    }

    public void openShop(Player player) {
        FileConfiguration config = configs.get("rent-ranks.yml");
        ConfigurationSection gui = config.getConfigurationSection("gui");
        int rows = gui.getInt("rows", 3);
        RankShopGui holder = new RankShopGui(player);
        Inventory inventory = Bukkit.createInventory(holder, rows * 9, TextUtil.parse(gui.getString("title")));
        holder.bind(inventory);
        fill(inventory, gui.getConfigurationSection("filler"));
        ConfigurationSection ranks = config.getConfigurationSection("ranks");
        if (ranks != null) {
            for (String rankId : ranks.getKeys(false)) {
                ConfigurationSection rank = ranks.getConfigurationSection(rankId);
                if (rank == null) {
                    continue;
                }
                int slot = rank.getInt("slot");
                inventory.setItem(slot, buildRankItem(rank, rankId));
                holder.slotToRank.put(slot, rankId);
            }
        }
        player.openInventory(inventory);
    }

    private void openDurationSelector(Player player, String rankId) {
        FileConfiguration config = configs.get("rent-ranks.yml");
        ConfigurationSection rank = config.getConfigurationSection("ranks." + rankId);
        ConfigurationSection selector = config.getConfigurationSection("duration-selector");
        if (rank == null || selector == null) {
            return;
        }
        String title = selector.getString("title", "Select Duration").replace("{rank}", rank.getString("display-name", rankId));
        DurationGui holder = new DurationGui(player, rankId);
        Inventory inventory = Bukkit.createInventory(holder, selector.getInt("rows", 3) * 9, TextUtil.parse(title));
        holder.bind(inventory);
        ConfigurationSection durations = rank.getConfigurationSection("durations");
        ConfigurationSection slots = selector.getConfigurationSection("duration-slots");
        if (durations != null && slots != null) {
            for (String durationKey : durations.getKeys(false)) {
                int slot = slots.getInt(durationKey, -1);
                if (slot < 0) {
                    continue;
                }
                holder.slotToDuration.put(slot, durationKey);
                long cost = durations.getConfigurationSection(durationKey).getLong("shard-cost");
                inventory.setItem(slot, ItemBuilder.of(Material.CLOCK)
                        .name(TextUtil.parse("<yellow>" + durationKey + "</yellow>"))
                        .lore(java.util.List.of(
                                TextUtil.parse("<gray>Cost: <light_purple>" + cost + " Shards</light_purple>"),
                                TextUtil.parse("<green>Click to purchase")
                        ))
                        .build());
            }
        }
        player.openInventory(inventory);
    }

    private org.bukkit.inventory.ItemStack buildRankItem(ConfigurationSection rank, String rankId) {
        ConfigurationSection template = configs.get("rent-ranks.yml").getConfigurationSection("gui.rank-item");
        Material material = ConfigItems.material(template, "material", Material.PLAYER_HEAD);
        Map<String, String> placeholders = Map.of("rank_display", rank.getString("display-name", rankId), "duration", "...", "cost", "...");
        return ItemBuilder.of(material)
                .name(TextUtil.parse(TextUtil.apply(template.getString("name", rankId), placeholders)))
                .lore(TextUtil.lore(template, "lore", placeholders))
                .customModelData(ConfigItems.customModelData(template, "custom-model-data"))
                .build();
    }

    private void purchase(Player player, String rankId, String durationKey) {
        if (!economy.isClickReady(player.getUniqueId())) {
            return;
        }
        FileConfiguration config = configs.get("rent-ranks.yml");
        ConfigurationSection rank = config.getConfigurationSection("ranks." + rankId);
        if (rank == null) {
            return;
        }
        ConfigurationSection duration = rank.getConfigurationSection("durations." + durationKey);
        if (duration == null) {
            return;
        }
        long cost = duration.getLong("shard-cost");
        TransactionResult spend = economy.spendShards(player.getUniqueId(), cost, "rent-rank:" + rankId + ":" + durationKey);
        if (!spend.success()) {
            economy.notifyFailure(player, spend.messageKey(), cost);
            return;
        }
        String group = rank.getString("luckperms-group", rankId);
        Duration parsed = parseDuration(durationKey);
        luckPerms.grantTemporaryRank(player, group, parsed).thenAccept(success -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (!success) {
                economy.grantShards(player.getUniqueId(), cost, "rent-rank-refund:" + rankId, "refund:" + player.getUniqueId() + ":" + System.nanoTime());
                player.sendMessage(TextUtil.parse("<red>Rank purchase failed. Shards refunded."));
                return;
            }
            player.sendMessage(TextUtil.parse(plugin.getConfig().getString("messages.purchase-success", "<green>Purchase successful!")));
            effects.processTokenClaims(player);
            store.saveProfile(store.get(player.getUniqueId()));
        }));
    }

    private Duration parseDuration(String key) {
        return switch (key.toLowerCase()) {
            case "1d" -> Duration.ofDays(1);
            case "7d" -> Duration.ofDays(7);
            case "30d" -> Duration.ofDays(30);
            default -> Duration.parse("PT" + key.toUpperCase());
        };
    }

    private void fill(Inventory inventory, ConfigurationSection filler) {
        if (filler == null) {
            return;
        }
        var item = ItemBuilder.of(ConfigItems.material(filler, "material", Material.BLACK_STAINED_GLASS_PANE))
                .name(TextUtil.parse(" "))
                .build();
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, item);
        }
    }

    private final class RankShopGui extends GuiHolder {
        private final Player player;
        private final Map<Integer, String> slotToRank = new HashMap<>();

        private RankShopGui(Player player) {
            this.player = player;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            String rankId = slotToRank.get(event.getRawSlot());
            if (rankId != null) {
                openDurationSelector(player, rankId);
            }
        }
    }

    private final class DurationGui extends GuiHolder {
        private final Player player;
        private final String rankId;
        private final Map<Integer, String> slotToDuration = new HashMap<>();

        private DurationGui(Player player, String rankId) {
            this.player = player;
            this.rankId = rankId;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            String durationKey = slotToDuration.get(event.getRawSlot());
            if (durationKey != null) {
                purchase(player, rankId, durationKey);
                player.closeInventory();
            }
        }
    }
}
