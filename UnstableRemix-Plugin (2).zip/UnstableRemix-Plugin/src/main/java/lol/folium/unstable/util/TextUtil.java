package lol.folium.unstable.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;
import org.bukkit.configuration.ConfigurationSection;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class TextUtil {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private static final Pattern LEGACY_HEX_PATTERN = Pattern.compile("(?i)&x&([0-9a-f])&([0-9a-f])&([0-9a-f])&([0-9a-f])&([0-9a-f])&([0-9a-f])");
    private static final Pattern SHARP_HEX_PATTERN = Pattern.compile("(?i)&#([0-9a-f]{6})");

    private TextUtil() {}

    public static Component parse(String input) {
        if (input == null || input.isEmpty()) {
            return Component.empty();
        }

        String s = input;

        Matcher hexMatcher = LEGACY_HEX_PATTERN.matcher(s);
        StringBuilder hexBuilder = new StringBuilder();
        while (hexMatcher.find()) {
            String hex = "#" + hexMatcher.group(1) + hexMatcher.group(2) + hexMatcher.group(3)
                    + hexMatcher.group(4) + hexMatcher.group(5) + hexMatcher.group(6);
            hexMatcher.appendReplacement(hexBuilder, "<" + hex + ">");
        }
        hexMatcher.appendTail(hexBuilder);
        s = hexBuilder.toString();

        Matcher sharpMatcher = SHARP_HEX_PATTERN.matcher(s);
        StringBuilder sharpBuilder = new StringBuilder();
        while (sharpMatcher.find()) {
            String hex = "#" + sharpMatcher.group(1);
            sharpMatcher.appendReplacement(sharpBuilder, "<" + hex + ">");
        }
        sharpMatcher.appendTail(sharpBuilder);
        s = sharpBuilder.toString();

        if (s.contains("&")) {
            s = ChatColor.translateAlternateColorCodes('&', s);
        }

        if (s.contains("<")) {
            s = s.replaceAll("\u00a7[0-9a-fk-orA-FK-OR]", "");
            return MM.deserialize(s);
        }

        return LegacyComponentSerializer.legacySection().deserialize(s);
    }

    public static String apply(String input, Map<String, String> placeholders) {
        String result = input;
        for (Map.Entry<String, String> entry : placeholders.entrySet()) {
            result = result.replace("{" + entry.getKey() + "}", entry.getValue());
        }
        return result;
    }

    public static List<Component> lore(ConfigurationSection section, String path, Map<String, String> placeholders) {
        List<String> raw = section.getStringList(path);
        return loreRaw(raw, placeholders);
    }

    public static List<Component> loreRaw(List<String> raw, Map<String, String> placeholders) {
        List<Component> lore = new ArrayList<>(raw.size());
        for (String line : raw) {
            lore.add(parse(apply(line, placeholders)));
        }
        return lore;
    }
}
