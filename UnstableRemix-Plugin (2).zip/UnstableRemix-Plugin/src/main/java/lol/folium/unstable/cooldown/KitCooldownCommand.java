package lol.folium.unstable.cooldown;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class KitCooldownCommand implements CommandExecutor, TabCompleter {

    private final UnstableRemixPlugin plugin;
    private final KitCooldownManager cooldownManager;

    public KitCooldownCommand(UnstableRemixPlugin plugin, KitCooldownManager cooldownManager) {
        this.plugin = plugin;
        this.cooldownManager = cooldownManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("unstable.coreadmin")) {
            sender.sendMessage(TextUtil.parse("<red>No permission."));
            return true;
        }
        if (args.length < 1) {
            usage(sender);
            return true;
        }
        if (args[0].equalsIgnoreCase("bypass")) {
            if (args.length < 3) {
                sender.sendMessage(TextUtil.parse("<red>Usage: /kitcooldown bypass <player> <duration|permanent></red>"));
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(TextUtil.parse("<red>Player not found.</red>"));
                return true;
            }
            if (args[2].equalsIgnoreCase("permanent") || args[2].equalsIgnoreCase("perm")) {
                cooldownManager.setBypass(target.getUniqueId(), -1L);
                sender.sendMessage(TextUtil.parse("<green>Granted permanent cooldown bypass to <white>" + target.getName() + "</white>.</green>"));
                target.sendMessage(TextUtil.parse("<green>You have been granted permanent kit cooldown bypass by an admin.</green>"));
            } else {
                try {
                    long seconds = parseDuration(args[2]);
                    long expires = System.currentTimeMillis() + (seconds * 1000L);
                    cooldownManager.setBypass(target.getUniqueId(), expires);
                    sender.sendMessage(TextUtil.parse("<green>Granted cooldown bypass to <white>" + target.getName()
                            + "</white> for <white>" + formatDuration(seconds) + "</white>.</green>"));
                    target.sendMessage(TextUtil.parse("<green>You have been granted kit cooldown bypass for " + formatDuration(seconds) + ".</green>"));
                } catch (NumberFormatException e) {
                    sender.sendMessage(TextUtil.parse("<red>Invalid duration. Use <seconds>, <m>minutes, <h>hours, or <d>days.</red>"));
                }
            }
            return true;
        }
        if (args[0].equalsIgnoreCase("set")) {
            if (args.length < 4) {
                sender.sendMessage(TextUtil.parse("<red>Usage: /kitcooldown set <player> <kit_name> <time_in_seconds></red>"));
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(TextUtil.parse("<red>Player not found.</red>"));
                return true;
            }
            try {
                long seconds = Long.parseLong(args[3]);
                cooldownManager.setCooldown(target.getUniqueId(), args[2].toLowerCase(), seconds);
                sender.sendMessage(TextUtil.parse("<green>Set cooldown for kit <white>" + args[2] + "</white> on <white>"
                        + target.getName() + "</white> to <white>" + seconds + "s</white>.</green>"));
            } catch (NumberFormatException e) {
                sender.sendMessage(TextUtil.parse("<red>Invalid time in seconds.</red>"));
            }
            return true;
        }
        if (args[0].equalsIgnoreCase("remove")) {
            if (args.length < 3) {
                sender.sendMessage(TextUtil.parse("<red>Usage: /kitcooldown remove <player> <kit_name></red>"));
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(TextUtil.parse("<red>Player not found.</red>"));
                return true;
            }
            cooldownManager.removeCooldown(target.getUniqueId(), args[2].toLowerCase());
            sender.sendMessage(TextUtil.parse("<green>Removed cooldown for kit <white>" + args[2] + "</white> on <white>"
                    + target.getName() + "</white>.</green>"));
            return true;
        }
        if (args[0].equalsIgnoreCase("status")) {
            if (args.length < 2) {
                if (!(sender instanceof Player)) {
                    sender.sendMessage(TextUtil.parse("<red>Usage: /kitcooldown status <player></red>"));
                    return true;
                }
                showStatus(sender, ((Player) sender).getUniqueId());
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(TextUtil.parse("<red>Player not found.</red>"));
                return true;
            }
            showStatus(sender, target.getUniqueId());
            return true;
        }
        usage(sender);
        return true;
    }

    private void showStatus(CommandSender sender, UUID uuid) {
        Player target = Bukkit.getPlayer(uuid);
        String name = target != null ? target.getName() : uuid.toString().substring(0, 8);
        sender.sendMessage(TextUtil.parse("<gold>--- Kit Cooldown Status: <white>" + name + "</white> ---</gold>"));
        boolean bypass = cooldownManager.hasBypass(uuid);
        sender.sendMessage(TextUtil.parse("<gray>Bypass: " + (bypass ? "<green>Active</green>" : "<red>None</red>")));
        Map<String, Long> active = cooldownManager.getCooldownsForPlayer(uuid);
        if (active.isEmpty()) {
            sender.sendMessage(TextUtil.parse("<gray>No active kit cooldowns.</gray>"));
        } else {
            active.forEach((kit, remaining) -> {
                long secs = remaining / 1000;
                sender.sendMessage(TextUtil.parse("<gray>  <white>" + kit + "</white>: <yellow>"
                        + formatDuration(secs) + "</yellow> remaining</gray>"));
            });
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return List.of("bypass", "set", "remove", "status");
        if (args.length == 2) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("bypass")) {
            return List.of("permanent", "1h", "6h", "12h", "24h", "7d");
        }
        if (args.length == 3 && (args[0].equalsIgnoreCase("set") || args[0].equalsIgnoreCase("remove"))) {
            return plugin.getKitManager().kitIds();
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("set")) {
            return List.of("60", "300", "600", "1800", "3600");
        }
        return Collections.emptyList();
    }

    private long parseDuration(String input) throws NumberFormatException {
        input = input.toLowerCase();
        if (input.endsWith("d")) return Long.parseLong(input.substring(0, input.length() - 1)) * 86400L;
        if (input.endsWith("h")) return Long.parseLong(input.substring(0, input.length() - 1)) * 3600L;
        if (input.endsWith("m")) return Long.parseLong(input.substring(0, input.length() - 1)) * 60L;
        if (input.endsWith("s")) return Long.parseLong(input.substring(0, input.length() - 1));
        return Long.parseLong(input);
    }

    private String formatDuration(long seconds) {
        if (seconds < 60) return seconds + "s";
        if (seconds < 3600) return (seconds / 60) + "m " + (seconds % 60) + "s";
        if (seconds < 86400) return (seconds / 3600) + "h " + ((seconds % 3600) / 60) + "m";
        return (seconds / 86400) + "d " + ((seconds % 86400) / 3600) + "h";
    }

    private void usage(CommandSender sender) {
        sender.sendMessage(TextUtil.parse("<yellow>/kitcooldown bypass <player> <duration|permanent>"));
        sender.sendMessage(TextUtil.parse("<yellow>/kitcooldown set <player> <kit> <time_in_seconds>"));
        sender.sendMessage(TextUtil.parse("<yellow>/kitcooldown remove <player> <kit>"));
        sender.sendMessage(TextUtil.parse("<yellow>/kitcooldown status [player]"));
    }
}
