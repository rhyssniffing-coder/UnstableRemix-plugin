package lol.folium.unstable.prestige;

import lol.folium.unstable.util.TextUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;

public final class PrestigeCommand implements CommandExecutor, TabCompleter {

    private final PrestigeManager manager;

    public PrestigeCommand(PrestigeManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        if (args.length == 1 && args[0].equalsIgnoreCase("confirm")) {
            if (!manager.canPrestige(player)) {
                player.sendMessage(TextUtil.parse("<red>You do not meet the prestige requirements!"));
                return true;
            }
            if (manager.prestigeRank(player) >= 50) {
                player.sendMessage(TextUtil.parse("<red>You have reached the maximum prestige rank!"));
                return true;
            }
            manager.prestige(player);
            return true;
        }

        manager.openConfirmationGui(player);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1 && "confirm".startsWith(args[0].toLowerCase())) {
            return List.of("confirm");
        }
        return Collections.emptyList();
    }
}
