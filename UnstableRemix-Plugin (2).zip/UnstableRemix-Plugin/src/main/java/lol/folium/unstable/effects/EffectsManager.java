package lol.folium.unstable.effects;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.data.PlayerDataStore;
import lol.folium.unstable.data.PlayerProfile;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.economy.TransactionResult;
import lol.folium.unstable.integration.LuckPermsHook;
import lol.folium.unstable.util.ConfigItems;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class EffectsManager {

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final PlayerDataStore store;
    private final EconomyService economy;
    private final LuckPermsHook luckPerms;
    private final Map<String, EffectDefinition> effects = new HashMap<>();
    private BukkitTask applyTask;

    public EffectsManager(UnstableRemixPlugin plugin, ConfigManager configs, PlayerDataStore store,
                          EconomyService economy, LuckPermsHook luckPerms) {
        this.plugin = plugin;
        this.configs = configs;
        this.store = store;
        this.economy = economy;
        this.luckPerms = luckPerms;
    }

    public void reload() {
        effects.clear();
        FileConfiguration config = configs.get("effects.yml");
        ConfigurationSection section = config.getConfigurationSection("effects");
        if (section == null) {
            return;
        }
        for (String id : section.getKeys(false)) {
            ConfigurationSection effect = section.getConfigurationSection(id);
            if (effect == null) {
                continue;
            }
            PotionEffectType type = resolvePotion(effect.getString("potion", "speed"));
            if (type == null) {
                continue;
            }
            effects.put(id, new EffectDefinition(
                    id,
                    effect.getInt("slot"),
                    effect.getString("display-name", id),
                    type,
                    effect.getInt("amplifier", 0),
                    effect.getInt("cost", 1)
            ));
        }
    }

    public void startTasks() {
        stopTasks();
        long interval = plugin.getConfig().getLong("effects.apply-interval-ticks", 60L);
        boolean hidden = plugin.getConfig().getBoolean("effects.particles-hidden", true);
        applyTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                applyEffects(player, hidden);
            }
        }, interval, interval);
    }

    private PotionEffectType resolvePotion(String raw) {
        String key = raw.toLowerCase().replace(' ', '_');
        PotionEffectType type = Registry.POTION_EFFECT_TYPE.get(NamespacedKey.minecraft(key));
        if (type == null) {
            type = Registry.POTION_EFFECT_TYPE.get(NamespacedKey.minecraft(raw.toLowerCase()));
        }
        return type;
    }

    public void stopTasks() {
        if (applyTask != null) {
            applyTask.cancel();
            applyTask = null;
        }
    }

    public void openGui(Player player) {
        FileConfiguration config = configs.get("effects.yml");
        ConfigurationSection gui = config.getConfigurationSection("gui");
        int rows = gui != null ? gui.getInt("rows", 6) : 6;
        String title = gui != null ? gui.getString("title", "Effects") : "Effects";
        EffectsGui holder = new EffectsGui(player);
        Inventory inventory = Bukkit.createInventory(holder, rows * 9, TextUtil.parse(title));
        holder.bind(inventory);
        fill(inventory, gui);

        // Header decoration
        inventory.setItem(4, ItemBuilder.of(Material.NETHER_STAR)
                .name(TextUtil.parse("<gradient:#9B59B6:#8E44AD><bold>Choose Your Effects</bold></gradient>"))
                .lore(java.util.List.of(
                        TextUtil.parse(""),
                        TextUtil.parse("<gray>Spend tokens to unlock permanent</gray>"),
                        TextUtil.parse("<gray>potion effects for your character.</gray>"),
                        TextUtil.parse(""),
                        TextUtil.parse("<dark_gray>Your tokens: <gold>" + store.get(player.getUniqueId()).tokens() + "</gold></dark_gray>")
                ))
                .glow(true)
                .build());

        // Decorative divider
        for (int slot : new int[]{10, 16, 37, 43}) {
            inventory.setItem(slot, ItemBuilder.of(Material.PURPLE_STAINED_GLASS_PANE)
                    .name(Component.empty())
                    .build());
        }

        PlayerProfile profile = store.get(player.getUniqueId());
        for (EffectDefinition effect : effects.values()) {
            inventory.setItem(effect.slot(), buildItem(effect, profile, gui));
        }
        player.openInventory(inventory);
    }

    private void fill(Inventory inventory, ConfigurationSection gui) {
        if (gui == null || !gui.contains("filler")) {
            return;
        }
        ConfigurationSection filler = gui.getConfigurationSection("filler");
        Material material = ConfigItems.material(filler, "material", Material.GRAY_STAINED_GLASS_PANE);
        var item = ItemBuilder.of(material)
                .name(TextUtil.parse(filler.getString("name", " ")))
                .customModelData(ConfigItems.customModelData(filler, "custom-model-data"))
                .build();
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, item);
        }
    }

    private org.bukkit.inventory.ItemStack buildItem(EffectDefinition effect, PlayerProfile profile, ConfigurationSection gui) {
        boolean unlocked = profile.unlockedEffects().contains(effect.id());
        boolean enabled = profile.enabledEffects().contains(effect.id());
        ConfigurationSection state;
        Map<String, String> placeholders = Map.of(
                "display_name", effect.displayName(),
                "cost", String.valueOf(effect.tokenCost()),
                "balance", String.valueOf(profile.tokens())
        );
        if (!unlocked) {
            state = profile.tokens() >= effect.tokenCost()
                    ? gui.getConfigurationSection("states.locked-affordable")
                    : gui.getConfigurationSection("states.locked-expensive");
        } else if (enabled) {
            state = gui.getConfigurationSection("states.unlocked-enabled");
        } else {
            state = gui.getConfigurationSection("states.unlocked-disabled");
        }
        Material material = ConfigItems.material(state, "material", Material.PAPER);
        return ItemBuilder.of(material)
                .name(TextUtil.parse(TextUtil.apply(state.getString("name", effect.displayName()), placeholders)))
                .lore(TextUtil.lore(state, "lore", placeholders))
                .glow(state.getBoolean("glow", false))
                .customModelData(ConfigItems.customModelData(state, "custom-model-data"))
                .build();
    }

    private void applyEffects(Player player, boolean hidden) {
        PlayerProfile profile = store.get(player.getUniqueId());
        for (String effectId : profile.enabledEffects()) {
            EffectDefinition def = effects.get(effectId);
            if (def == null) {
                continue;
            }
            player.addPotionEffect(new PotionEffect(
                    def.potion(),
                    80,
                    def.amplifier(),
                    false,
                    !hidden,
                    hidden
            ));
        }
    }

    public void processTokenClaims(Player player) {
        if (!luckPerms.isAvailable()) {
            return;
        }
        luckPerms.highestTokenRank(player).ifPresent(rank -> {
            int amount = plugin.getConfig().getInt("luckperms.token-ranks." + rank, 0);
            if (amount <= 0) {
                return;
            }
            PlayerProfile profile = store.get(player.getUniqueId());
            if (profile.claimedTokenRanks().contains(rank)) {
                return;
            }
            String key = "token-rank:" + player.getUniqueId() + ":" + rank;
            TransactionResult result = economy.grantTokens(player.getUniqueId(), amount, "rank:" + rank, key);
            if (result.success()) {
                profile.claimedTokenRanks().add(rank);
                store.saveProfile(profile);
                economy.notifyGrant(player, lol.folium.unstable.economy.CurrencyType.TOKENS, amount, rank);
            }
        });
    }

    private final class EffectsGui extends GuiHolder {
        private final Player player;

        private EffectsGui(Player player) {
            this.player = player;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            if (!economy.isClickReady(player.getUniqueId())) {
                return;
            }
            int slot = event.getRawSlot();
            EffectDefinition clicked = effects.values().stream()
                    .filter(effect -> effect.slot() == slot)
                    .findFirst()
                    .orElse(null);
            if (clicked == null) {
                return;
            }
            PlayerProfile profile = store.get(player.getUniqueId());
            if (!profile.unlockedEffects().contains(clicked.id())) {
                TransactionResult spend = economy.spendTokens(player.getUniqueId(), clicked.tokenCost(), "effect-unlock:" + clicked.id());
                if (!spend.success()) {
                    economy.notifyFailure(player, spend.messageKey(), clicked.tokenCost());
                    return;
                }
                profile.unlockedEffects().add(clicked.id());
                profile.enabledEffects().add(clicked.id());
                store.saveProfile(profile);
            } else if (profile.enabledEffects().contains(clicked.id())) {
                profile.enabledEffects().remove(clicked.id());
                store.saveProfile(profile);
            } else {
                profile.enabledEffects().add(clicked.id());
                store.saveProfile(profile);
            }
            openGui(player);
        }
    }
}
