package lol.folium.unstable.quest;

import lol.folium.unstable.UnstableRemixPlugin;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.Locale;

public final class QuestPlaceholderExpansion extends PlaceholderExpansion {

    private final String identifier;
    private final UnstableRemixPlugin plugin;
    private final QuestService quests;

    public QuestPlaceholderExpansion(String identifier, UnstableRemixPlugin plugin, QuestService quests) {
        this.identifier = identifier;
        this.plugin = plugin;
        this.quests = quests;
    }

    @Override
    public String getIdentifier() {
        return identifier;
    }

    @Override
    public String getAuthor() {
        return String.join(", ", plugin.getPluginMeta().getAuthors());
    }

    @Override
    public String getVersion() {
        return plugin.getPluginMeta().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onPlaceholderRequest(Player player, String params) {
        if (player == null || params == null) {
            return "";
        }
        String normalized = params.toLowerCase(Locale.ROOT);
        if (normalized.equals("quests_claimable")) {
            return String.valueOf(quests.claimableCount(player));
        }
        if (normalized.equals("time_until_vote")) {
            Duration duration = plugin.getMapVoteManager() == null ? Duration.ZERO : plugin.getMapVoteManager().timeUntilNextVote();
            return formatDuration(duration);
        }
        if (normalized.equals("active_arena")) {
            return plugin.getMapVoteManager() == null ? "None" : plugin.getMapVoteManager().activeArenaName();
        }
        if (normalized.equals("streak")) {
            return String.valueOf(quests.activeKillstreak(player));
        }
        if (normalized.equals("shards_formatted")) {
            return formatNumber(plugin.getEconomyService().getShards(player.getUniqueId()));
        }
        if (normalized.equals("shard_multiplier")) {
            return String.format(Locale.ROOT, "%.2fx", quests.shardMultiplier(player));
        }
        if (normalized.equals("combat_tag_remaining")) {
            return plugin.getCombatTagManager() == null ? "0" : String.valueOf(plugin.getCombatTagManager().remainingSeconds(player));
        }
        if (normalized.equals("achievements_unlocked")) {
            return String.valueOf(quests.achievementsUnlocked(player));
        }
        if (normalized.startsWith("quests_completed_")) {
            QuestTier tier = parseTier(normalized.substring("quests_completed_".length()));
            return tier == null ? "" : String.valueOf(quests.completedCount(player, tier));
        }
        if (normalized.startsWith("quest_")) {
            return handleQuestPlaceholder(player, normalized.substring("quest_".length()));
        }
        return "";
    }

    private String handleQuestPlaceholder(Player player, String params) {
        String[] parts = params.split("_");
        if (parts.length < 2) {
            return "";
        }
        QuestTier tier = parseTier(parts[0]);
        if (tier == null) {
            return "";
        }
        String endpoint = parts[parts.length - 1];
        if (endpoint.equals("progress")) {
            return quests.activeProgressText(player, tier);
        }
        if (endpoint.equals("name")) {
            return quests.activeQuestName(player, tier);
        }
        if (parts.length >= 2 && params.endsWith("time_left")) {
            return quests.timeLeftText(tier);
        }
        return "";
    }

    private QuestTier parseTier(String raw) {
        if (raw.equals("achievement") || raw.equals("achievements") || raw.equals("milestone") || raw.equals("milestones")) {
            return QuestTier.MILESTONE;
        }
        return QuestTier.from(raw);
    }

    private String formatDuration(Duration duration) {
        long seconds = Math.max(0L, duration.getSeconds());
        long minutes = seconds / 60L;
        long remainder = seconds % 60L;
        return minutes + "m " + remainder + "s";
    }

    private String formatNumber(long value) {
        if (value >= 1_000_000L) {
            return String.format(Locale.ROOT, "%.1fm", value / 1_000_000.0D);
        }
        if (value >= 1_000L) {
            return String.format(Locale.ROOT, "%.1fk", value / 1_000.0D);
        }
        return String.valueOf(value);
    }
}
