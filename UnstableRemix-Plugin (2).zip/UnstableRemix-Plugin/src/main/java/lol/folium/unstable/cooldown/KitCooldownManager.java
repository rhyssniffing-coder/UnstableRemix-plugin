package lol.folium.unstable.cooldown;

import lol.folium.unstable.UnstableRemixPlugin;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class KitCooldownManager {

    private final UnstableRemixPlugin plugin;
    private Connection connection;
    private final ExecutorService dbExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "UnstableRemix-CD-DB");
        t.setDaemon(true);
        return t;
    });
    private final Map<UUID, Long> bypasses = new ConcurrentHashMap<>();
    private final Map<UUID, Map<String, Long>> cooldowns = new ConcurrentHashMap<>();
    private final Map<UUID, Long> shardBoosts = new ConcurrentHashMap<>();
    private final Map<UUID, Double> shardBoostMultipliers = new ConcurrentHashMap<>();
    private final Map<UUID, Long> fireworkBypasses = new ConcurrentHashMap<>();

    public KitCooldownManager(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    public void init() throws SQLException {
        File file = new File(plugin.getDataFolder(), "kitcooldowns.db");
        connection = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
        try (Statement stmt = connection.createStatement()) {
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS kit_bypasses (
                    uuid TEXT PRIMARY KEY,
                    expires_at INTEGER NOT NULL
                )
                """);
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS kit_cooldowns (
                    uuid TEXT NOT NULL,
                    kit_id TEXT NOT NULL,
                    expires_at INTEGER NOT NULL,
                    PRIMARY KEY (uuid, kit_id)
                )
                """);
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS shard_boosts (
                    uuid TEXT PRIMARY KEY,
                    expires_at INTEGER NOT NULL
                )
                """);
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS firework_bypasses (
                    uuid TEXT PRIMARY KEY,
                    expires_at INTEGER NOT NULL
                )
                """);
        }
        loadAll();
    }

    public void loadAll() {
        bypasses.clear();
        cooldowns.clear();
        shardBoosts.clear();
        fireworkBypasses.clear();
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery("SELECT uuid, expires_at FROM kit_bypasses");
            while (rs.next()) {
                UUID uuid = UUID.fromString(rs.getString("uuid"));
                long expires = rs.getLong("expires_at");
                if (expires < 0 || expires > System.currentTimeMillis()) {
                    bypasses.put(uuid, expires);
                }
            }
            rs = stmt.executeQuery("SELECT uuid, kit_id, expires_at FROM kit_cooldowns");
            while (rs.next()) {
                UUID uuid = UUID.fromString(rs.getString("uuid"));
                long expires = rs.getLong("expires_at");
                if (expires > System.currentTimeMillis()) {
                    cooldowns.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>())
                            .put(rs.getString("kit_id"), expires);
                }
            }
            rs = stmt.executeQuery("SELECT uuid, expires_at FROM shard_boosts");
            while (rs.next()) {
                UUID uuid = UUID.fromString(rs.getString("uuid"));
                long expires = rs.getLong("expires_at");
                if (expires > System.currentTimeMillis()) {
                    shardBoosts.put(uuid, expires);
                }
            }
            rs = stmt.executeQuery("SELECT uuid, expires_at FROM firework_bypasses");
            while (rs.next()) {
                UUID uuid = UUID.fromString(rs.getString("uuid"));
                long expires = rs.getLong("expires_at");
                if (expires < 0 || expires > System.currentTimeMillis()) {
                    fireworkBypasses.put(uuid, expires);
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to load kit cooldowns: " + e.getMessage());
        }
    }

    public boolean hasBypass(UUID uuid) {
        Long expires = bypasses.get(uuid);
        if (expires != null) {
            if (expires < 0) return true;
            if (System.currentTimeMillis() > expires) {
                bypasses.remove(uuid);
                removeBypassDb(uuid);
                return false;
            }
            return true;
        }
        if (plugin.getMediaRankManager() != null && plugin.getMediaRankManager().hasMediaRank(uuid)) {
            return true;
        }
        return false;
    }

    public void setBypass(UUID uuid, long expiresAt) {
        if (expiresAt < 0) {
            bypasses.put(uuid, -1L);
        } else {
            bypasses.put(uuid, expiresAt);
        }
        try (PreparedStatement ps = connection.prepareStatement(
                "INSERT OR REPLACE INTO kit_bypasses (uuid, expires_at) VALUES (?, ?)")) {
            ps.setString(1, uuid.toString());
            ps.setLong(2, expiresAt);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to save bypass: " + e.getMessage());
        }
    }

    public void removeBypass(UUID uuid) {
        bypasses.remove(uuid);
        removeBypassDb(uuid);
    }

    private void removeBypassDb(UUID uuid) {
        dbExecutor.execute(() -> {
            try (PreparedStatement ps = connection.prepareStatement("DELETE FROM kit_bypasses WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to remove bypass: " + e.getMessage());
            }
        });
    }

    public long getCooldown(UUID uuid, String kitId) {
        Map<String, Long> playerCooldowns = cooldowns.get(uuid);
        if (playerCooldowns == null) return 0;
        Long expires = playerCooldowns.get(kitId);
        if (expires == null) return 0;
        long remaining = expires - System.currentTimeMillis();
        if (remaining <= 0) {
            playerCooldowns.remove(kitId);
            removeCooldownDb(uuid, kitId);
            return 0;
        }
        return remaining;
    }

    public void setCooldown(UUID uuid, String kitId, long seconds) {
        long expires = System.currentTimeMillis() + (seconds * 1000L);
        cooldowns.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>()).put(kitId, expires);
        try (PreparedStatement ps = connection.prepareStatement(
                "INSERT OR REPLACE INTO kit_cooldowns (uuid, kit_id, expires_at) VALUES (?, ?, ?)")) {
            ps.setString(1, uuid.toString());
            ps.setString(2, kitId);
            ps.setLong(3, expires);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to save cooldown: " + e.getMessage());
        }
    }

    public void removeCooldown(UUID uuid, String kitId) {
        Map<String, Long> playerCooldowns = cooldowns.get(uuid);
        if (playerCooldowns != null) {
            playerCooldowns.remove(kitId);
        }
        removeCooldownDb(uuid, kitId);
    }

    public void removeAllCooldowns(UUID uuid) {
        cooldowns.remove(uuid);
        dbExecutor.execute(() -> {
            try (PreparedStatement ps = connection.prepareStatement("DELETE FROM kit_cooldowns WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to remove all cooldowns: " + e.getMessage());
            }
        });
    }

    private void removeCooldownDb(UUID uuid, String kitId) {
        dbExecutor.execute(() -> {
            try (PreparedStatement ps = connection.prepareStatement(
                    "DELETE FROM kit_cooldowns WHERE uuid = ? AND kit_id = ?")) {
                ps.setString(1, uuid.toString());
                ps.setString(2, kitId);
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("Failed to remove cooldown: " + e.getMessage());
            }
        });
    }

    public boolean hasShardBoost(UUID uuid) {
        Long expires = shardBoosts.get(uuid);
        if (expires == null) return false;
        if (System.currentTimeMillis() > expires) {
            shardBoosts.remove(uuid);
            shardBoostMultipliers.remove(uuid);
            dbExecutor.execute(() -> {
                try (PreparedStatement ps = connection.prepareStatement("DELETE FROM shard_boosts WHERE uuid = ?")) {
                    ps.setString(1, uuid.toString());
                    ps.executeUpdate();
                } catch (SQLException e) {
                    plugin.getLogger().severe("Failed to remove expired shard boost: " + e.getMessage());
                }
            });
            return false;
        }
        return true;
    }

    public double getShardBoostMultiplier(UUID uuid) {
        return shardBoostMultipliers.getOrDefault(uuid, 2.0);
    }

    public void setShardBoost(UUID uuid, long expiresAt) {
        setShardBoost(uuid, expiresAt, 2.0);
    }

    public void setShardBoost(UUID uuid, long expiresAt, double multiplier) {
        shardBoosts.put(uuid, expiresAt);
        shardBoostMultipliers.put(uuid, multiplier);
        try (PreparedStatement ps = connection.prepareStatement(
                "INSERT OR REPLACE INTO shard_boosts (uuid, expires_at) VALUES (?, ?)")) {
            ps.setString(1, uuid.toString());
            ps.setLong(2, expiresAt);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to save shard boost: " + e.getMessage());
        }
    }

    public boolean hasFireworkBypass(UUID uuid) {
        Long expires = fireworkBypasses.get(uuid);
        if (expires == null) return false;
        if (expires < 0) return true;
        if (System.currentTimeMillis() > expires) {
            fireworkBypasses.remove(uuid);
            dbExecutor.execute(() -> {
                try (PreparedStatement ps = connection.prepareStatement("DELETE FROM firework_bypasses WHERE uuid = ?")) {
                    ps.setString(1, uuid.toString());
                    ps.executeUpdate();
                } catch (SQLException e) {
                    plugin.getLogger().severe("Failed to remove expired firework bypass: " + e.getMessage());
                }
            });
            return false;
        }
        return true;
    }

    public void setFireworkBypass(UUID uuid, long expiresAt) {
        fireworkBypasses.put(uuid, expiresAt);
        try (PreparedStatement ps = connection.prepareStatement(
                "INSERT OR REPLACE INTO firework_bypasses (uuid, expires_at) VALUES (?, ?)")) {
            ps.setString(1, uuid.toString());
            ps.setLong(2, expiresAt);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to save firework bypass: " + e.getMessage());
        }
    }

    public void removeFireworkBypass(UUID uuid) {
        fireworkBypasses.remove(uuid);
        try (PreparedStatement ps = connection.prepareStatement("DELETE FROM firework_bypasses WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to remove firework bypass: " + e.getMessage());
        }
    }

    public Map<String, Long> getCooldownsForPlayer(UUID uuid) {
        Map<String, Long> playerCooldowns = cooldowns.get(uuid);
        if (playerCooldowns == null) return Map.of();
        long now = System.currentTimeMillis();
        Map<String, Long> active = new HashMap<>();
        playerCooldowns.forEach((kit, expires) -> {
            long remaining = expires - now;
            if (remaining > 0) active.put(kit, remaining);
        });
        return active;
    }
}
