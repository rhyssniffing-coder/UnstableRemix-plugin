package lol.folium.unstable.election;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.faction.FactionManager;
import lol.folium.unstable.util.TextUtil;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public final class CampaignCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;
    private final ElectionManager elections;
    private final FactionManager factions;

    public CampaignCommand(UnstableRemixPlugin plugin, ElectionManager elections, FactionManager factions) {
        this.plugin = plugin;
        this.elections = elections;
        this.factions = factions;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length == 0) {
            sendUsage(player);
            return;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "start" -> handleStart(player, args);
            case "withdraw" -> handleWithdraw(player);
            case "status" -> handleStatus(player);
            default -> sendUsage(player);
        }
    }

    private void sendUsage(Player player) {
        player.sendMessage(TextUtil.parse("<yellow>/campaign start <manifesto></yellow> <gray>- Register as a candidate</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/campaign withdraw</yellow> <gray>- Withdraw from the election</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/campaign status</yellow> <gray>- View your campaign</gray>"));
    }

    private void handleStart(Player player, String[] args) {
        var phase = elections.getPhase();
        if (!phase.equals("REGISTRATION")) {
            player.sendMessage(TextUtil.parse("<red>Registration is not currently open.</red>"));
            return;
        }
        var factionOpt = factions.getFaction(player);
        if (factionOpt.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>You must be in a faction to run for election.</red>"));
            return;
        }
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /campaign start <manifesto>"));
            return;
        }
        String manifesto = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
        if (manifesto.length() > 100) {
            player.sendMessage(TextUtil.parse("<red>Manifesto too long (max 100 characters).</red>"));
            return;
        }
        var store = elections.getStore();
        int electionId = elections.getCurrentElectionId();
        if (store.hasCandidate(electionId, player.getUniqueId())) {
            player.sendMessage(TextUtil.parse("<red>You are already registered as a candidate.</red>"));
            return;
        }
        store.registerCandidate(electionId, player.getUniqueId(), factionOpt.get().name(), manifesto);
        Bukkit.broadcast(TextUtil.parse("<gold><bold>" + player.getName() + "</bold></gold> <gray>has entered the election!</gray>"));
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
    }

    private void handleWithdraw(Player player) {
        if (!elections.isActive()) {
            player.sendMessage(TextUtil.parse("<red>No election is currently active.</red>"));
            return;
        }
        var store = elections.getStore();
        int electionId = elections.getCurrentElectionId();
        if (!store.hasCandidate(electionId, player.getUniqueId())) {
            player.sendMessage(TextUtil.parse("<red>You are not a candidate.</red>"));
            return;
        }
        store.removeCandidate(electionId, player.getUniqueId());
        player.sendMessage(TextUtil.parse("<green>You have withdrawn from the election.</green>"));
    }

    private void handleStatus(Player player) {
        if (!elections.isActive()) {
            player.sendMessage(TextUtil.parse("<gray>No election is currently active.</gray>"));
            return;
        }
        var store = elections.getStore();
        int electionId = elections.getCurrentElectionId();
        var candidates = store.getCandidates(electionId);
        int totalVotes = store.getTotalVotes(electionId);

        long elapsed = System.currentTimeMillis() - elections.getPhaseStartTime();
        long totalDuration;
        if (elections.isRegistration()) {
            totalDuration = plugin.getConfig().getLong("elections.registration-duration-hours", 48) * 3600 * 1000;
        } else {
            totalDuration = plugin.getConfig().getLong("elections.voting-duration-hours", 120) * 3600 * 1000;
        }
        long remaining = Math.max(0, totalDuration - elapsed);
        long hours = remaining / 3600000;
        long minutes = (remaining % 3600000) / 60000;

        player.sendMessage(TextUtil.parse("<gold>=== Election Status ==="));
        player.sendMessage(TextUtil.parse("<gray>Phase: <yellow>" + elections.getPhase() + "</yellow></gray>"));
        player.sendMessage(TextUtil.parse("<gray>Time Left: <yellow>" + hours + "h " + minutes + "m</yellow></gray>"));
        player.sendMessage(TextUtil.parse("<gray>Candidates: <white>" + candidates.size() + "</white></gray>"));
        if (elections.isVoting()) {
            player.sendMessage(TextUtil.parse("<gray>Total Votes: <yellow>" + totalVotes + "</yellow></gray>"));
        }

        if (store.hasCandidate(electionId, player.getUniqueId())) {
            var data = candidates.stream()
                .filter(c -> c.uuid().equals(player.getUniqueId()))
                .findFirst();
            data.ifPresent(c ->
                player.sendMessage(TextUtil.parse("<green>Your votes: <yellow>" + c.voteCount() + "</yellow></green>"))
            );
        }
    }

    @Override
    protected String permission() {
        return null;
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            return filter(literals("start", "withdraw", "status"), args[0]);
        }
        return List.of();
    }
}
