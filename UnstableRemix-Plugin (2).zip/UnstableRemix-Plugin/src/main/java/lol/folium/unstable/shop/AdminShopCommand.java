package lol.folium.unstable.shop;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class AdminShopCommand implements CommandExecutor, TabCompleter {

    private final ShopManager shop;
    private AdminShopGui gui;

    public AdminShopCommand(ShopManager shop) {
        this.shop = shop;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (!player.hasPermission("unstable.coreadmin")) {
            player.sendMessage(TextUtil.parse("<red>No permission."));
            return true;
        }
        if (args.length < 1) {
            if (gui == null) {
                gui = new AdminShopGui(UnstableRemixPlugin.getInstance(), shop);
            }
            gui.open(player);
            return true;
        }
        if (args[0].equalsIgnoreCase("item") && args.length >= 2) {
            String sub = args[1].toLowerCase();
            if (sub.equals("add") && args.length >= 5) {
                int pageIdx;
                try {
                    pageIdx = Integer.parseInt(args[2]) - 1;
                } catch (NumberFormatException e) {
                    pageIdx = shop.pageIds().indexOf(args[2].toLowerCase());
                }
                int slot;
                try {
                    slot = Integer.parseInt(args[3]);
                } catch (NumberFormatException e) {
                    player.sendMessage(TextUtil.parse("<red>Invalid slot number.</red>"));
                    return true;
                }
                long price;
                try {
                    price = Long.parseLong(args[4]);
                } catch (NumberFormatException e) {
                    player.sendMessage(TextUtil.parse("<red>Invalid price.</red>"));
                    return true;
                }
                ItemStack held = player.getInventory().getItemInMainHand();
                if (held.getType() == Material.AIR) {
                    player.sendMessage(TextUtil.parse("<red>Hold an item in your hand.</red>"));
                    return true;
                }
                shop.addItem(pageIdx, slot, held, price);
                player.sendMessage(TextUtil.parse("<green>Added item to shop page " + (pageIdx + 1) + " slot " + slot + " for " + price + " Shards.</green>"));
                return true;
            }
            if (sub.equals("addeffect") && args.length >= 6) {
                int pageIdx;
                try {
                    pageIdx = Integer.parseInt(args[2]) - 1;
                } catch (NumberFormatException e) {
                    pageIdx = shop.pageIds().indexOf(args[2].toLowerCase());
                }
                int slot;
                try {
                    slot = Integer.parseInt(args[3]);
                } catch (NumberFormatException e) {
                    player.sendMessage(TextUtil.parse("<red>Invalid slot number.</red>"));
                    return true;
                }
                long price;
                try {
                    price = Long.parseLong(args[4]);
                } catch (NumberFormatException e) {
                    player.sendMessage(TextUtil.parse("<red>Invalid price.</red>"));
                    return true;
                }
                String effect = args[5].toLowerCase();
                int duration;
                try {
                    duration = args.length >= 7 ? Integer.parseInt(args[6]) : 0;
                } catch (NumberFormatException e) {
                    player.sendMessage(TextUtil.parse("<red>Invalid duration.</red>"));
                    return true;
                }
                shop.addEffectItem(pageIdx, slot, price, effect, duration);
                player.sendMessage(TextUtil.parse("<green>Added effect item to shop page " + (pageIdx + 1) + " slot " + slot + " (" + effect + ") for " + price + " Shards.</green>"));
                return true;
            }
            if (sub.equals("remove") && args.length >= 4) {
                int pageIdx;
                try {
                    pageIdx = Integer.parseInt(args[2]) - 1;
                } catch (NumberFormatException e) {
                    pageIdx = shop.pageIds().indexOf(args[2].toLowerCase());
                }
                int slot;
                try {
                    slot = Integer.parseInt(args[3]);
                } catch (NumberFormatException e) {
                    player.sendMessage(TextUtil.parse("<red>Invalid slot number.</red>"));
                    return true;
                }
                shop.removeItem(pageIdx, slot);
                player.sendMessage(TextUtil.parse("<green>Removed item from shop page " + (pageIdx + 1) + " slot " + slot + ".</green>"));
                return true;
            }
            if (sub.equals("setcost") && args.length >= 5) {
                int pageIdx;
                try {
                    pageIdx = Integer.parseInt(args[2]) - 1;
                } catch (NumberFormatException e) {
                    pageIdx = shop.pageIds().indexOf(args[2].toLowerCase());
                }
                int slot;
                try {
                    slot = Integer.parseInt(args[3]);
                } catch (NumberFormatException e) {
                    player.sendMessage(TextUtil.parse("<red>Invalid slot number.</red>"));
                    return true;
                }
                long price;
                try {
                    price = Long.parseLong(args[4]);
                } catch (NumberFormatException e) {
                    player.sendMessage(TextUtil.parse("<red>Invalid price.</red>"));
                    return true;
                }
                shop.setCost(pageIdx, slot, price);
                player.sendMessage(TextUtil.parse("<green>Set cost of shop page " + (pageIdx + 1) + " slot " + slot + " to " + price + " Shards.</green>"));
                return true;
            }
            if (sub.equals("seteffect") && args.length >= 5) {
                int pageIdx;
                try {
                    pageIdx = Integer.parseInt(args[2]) - 1;
                } catch (NumberFormatException e) {
                    pageIdx = shop.pageIds().indexOf(args[2].toLowerCase());
                }
                int slot;
                try {
                    slot = Integer.parseInt(args[3]);
                } catch (NumberFormatException e) {
                    player.sendMessage(TextUtil.parse("<red>Invalid slot number.</red>"));
                    return true;
                }
                String effect = args[4].toLowerCase();
                int duration;
                try {
                    duration = args.length >= 6 ? Integer.parseInt(args[5]) : 0;
                } catch (NumberFormatException e) {
                    player.sendMessage(TextUtil.parse("<red>Invalid duration.</red>"));
                    return true;
                }
                shop.setEffect(pageIdx, slot, effect, duration);
                player.sendMessage(TextUtil.parse("<green>Set effect of shop page " + (pageIdx + 1) + " slot " + slot + " to " + effect + ".</green>"));
                return true;
            }
            if (sub.equals("setduration") && args.length >= 5) {
                int pageIdx;
                try {
                    pageIdx = Integer.parseInt(args[2]) - 1;
                } catch (NumberFormatException e) {
                    pageIdx = shop.pageIds().indexOf(args[2].toLowerCase());
                }
                int slot;
                try {
                    slot = Integer.parseInt(args[3]);
                } catch (NumberFormatException e) {
                    player.sendMessage(TextUtil.parse("<red>Invalid slot number.</red>"));
                    return true;
                }
                int duration;
                try {
                    duration = Integer.parseInt(args[4]);
                } catch (NumberFormatException e) {
                    player.sendMessage(TextUtil.parse("<red>Invalid duration.</red>"));
                    return true;
                }
                shop.setDuration(pageIdx, slot, duration);
                player.sendMessage(TextUtil.parse("<green>Set duration of shop page " + (pageIdx + 1) + " slot " + slot + " to " + duration + "s.</green>"));
                return true;
            }
        }
        usage(player);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return List.of("item");
        if (args.length == 2 && args[0].equalsIgnoreCase("item")) {
            return List.of("add", "addeffect", "remove", "setcost", "seteffect", "setduration");
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("item") && !args[1].equalsIgnoreCase("add")) {
            List<String> ids = shop.pageIds();
            List<String> result = new ArrayList<>();
            for (int i = 0; i < ids.size(); i++) {
                result.add(String.valueOf(i + 1));
            }
            result.addAll(ids);
            return result;
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("item") && args[1].equalsIgnoreCase("add")) {
            List<String> ids = shop.pageIds();
            List<String> result = new ArrayList<>();
            for (int i = 0; i < ids.size(); i++) {
                result.add(String.valueOf(i + 1));
            }
            result.addAll(ids);
            return result;
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("item")) {
            return List.of("10", "11", "12", "13", "14", "15", "16", "19", "20", "21", "22", "23", "24", "25");
        }
        if (args.length == 5 && args[0].equalsIgnoreCase("item") && (args[1].equalsIgnoreCase("add") || args[1].equalsIgnoreCase("setcost"))) {
            return List.of("1000", "5000", "10000", "25000");
        }
        if (args.length == 6 && args[0].equalsIgnoreCase("item") && (args[1].equalsIgnoreCase("addeffect") || args[1].equalsIgnoreCase("seteffect"))) {
            return List.of("no-cooldown", "skip-cooldown", "shard-boost", "firework-bypass");
        }
        if (args.length == 6 && args[0].equalsIgnoreCase("item") && args[1].equalsIgnoreCase("setduration")) {
            return List.of("3600", "1800", "600", "0");
        }
        if (args.length == 7 && args[0].equalsIgnoreCase("item") && args[1].equalsIgnoreCase("addeffect")) {
            return List.of("3600", "1800", "600", "0");
        }
        return Collections.emptyList();
    }

    private void usage(Player player) {
        player.sendMessage(TextUtil.parse("<yellow>/adminshop item add <page> <slot> <shard_cost>"));
        player.sendMessage(TextUtil.parse("<yellow>/adminshop item addeffect <page> <slot> <shard_cost> <effect> [duration_secs]"));
        player.sendMessage(TextUtil.parse("<yellow>/adminshop item remove <page> <slot>"));
        player.sendMessage(TextUtil.parse("<yellow>/adminshop item setcost <page> <slot> <new_shard_cost>"));
        player.sendMessage(TextUtil.parse("<yellow>/adminshop item seteffect <page> <slot> <effect> [duration_secs]"));
        player.sendMessage(TextUtil.parse("<yellow>/adminshop item setduration <page> <slot> <duration_secs>"));
    }
}
