package lol.folium.unstable.command;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

import java.util.ArrayList;
import java.util.List;

public final class RulesCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;

    public RulesCommand(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    protected void execute(Player player, String[] args) {
        openGui(player);
    }

    public void openGui(Player player) {
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("rules");
        String title = section != null ? section.getString("title", "<gradient:#FF4444:#FF8800:#FFD700><bold>RULES</bold></gradient>") : "<gradient:#FF4444:#FF8800:#FFD700><bold>RULES</bold></gradient>";
        int rows = section != null ? section.getInt("rows", 3) : 3;

        RulesHolder holder = new RulesHolder();
        Inventory inv = Bukkit.createInventory(holder, rows * 9, TextUtil.parse(title));
        holder.bind(inv);

        for (int i = 0; i < rows * 9; i++) {
            inv.setItem(i, ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE).name(Component.empty()).build());
        }

        ConfigurationSection rulesSection = section != null ? section.getConfigurationSection("list") : null;
        if (rulesSection != null) {
            int slotOffset = section != null ? section.getInt("slot-offset", 9) : 9;
            int idx = 0;
            for (String key : rulesSection.getKeys(false)) {
                ConfigurationSection rule = rulesSection.getConfigurationSection(key);
                if (rule == null) continue;

                String materialName = rule.getString("material", "KNOWLEDGE_BOOK");
                Material mat = Material.matchMaterial(materialName);
                if (mat == null) mat = Material.KNOWLEDGE_BOOK;

                String name = rule.getString("name", "<gradient:#FF4444:#FF8800:#FFD700><bold>RULE " + key + "</bold></gradient>");
                List<String> rawLore = rule.getStringList("lore");
                List<Component> lore = new ArrayList<>();
                for (String line : rawLore) {
                    lore.add(TextUtil.parse(line));
                }

                int slot = slotOffset + (idx % 7);
                if (slot < rows * 9) {
                    inv.setItem(slot, ItemBuilder.of(mat)
                            .name(TextUtil.parse(name))
                            .lore(lore)
                            .build());
                }
                idx++;
            }
        }

        int closeSlot = rows * 9 - 5;
        inv.setItem(closeSlot, ItemBuilder.of(Material.BARRIER)
                .name(TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700><bold>\u2718 CLOSE</bold></gradient>"))
                .build());

        player.openInventory(inv);
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
    }

    public Listener createListener() {
        return new Listener() {
            @EventHandler
            public void onInventoryClick(InventoryClickEvent event) {
                if (!(event.getWhoClicked() instanceof Player p)) return;
                if (!(event.getInventory().getHolder() instanceof RulesHolder)) return;
                event.setCancelled(true);
                int slot = event.getRawSlot();
                if (slot < 0 || slot >= event.getInventory().getSize()) return;
                if (event.getCurrentItem() == null || event.getCurrentItem().getType() == Material.BARRIER) {
                    p.closeInventory();
                }
            }

            @EventHandler
            public void onInventoryDrag(InventoryDragEvent event) {
                if (event.getInventory().getHolder() instanceof RulesHolder) {
                    event.setCancelled(true);
                }
            }
        };
    }

    private static final class RulesHolder extends GuiHolder {
        @Override
        public void handleClick(InventoryClickEvent event) {
        }
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        return List.of();
    }

    @Override
    protected String permission() {
        return null;
    }
}
