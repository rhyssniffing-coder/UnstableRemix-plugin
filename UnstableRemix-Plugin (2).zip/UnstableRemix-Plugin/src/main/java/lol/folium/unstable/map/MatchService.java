package lol.folium.unstable.map;

import org.bukkit.entity.Player;

import java.util.UUID;

public final class MatchService {

    private final ArenaManager arenas;
    private final ArenaRegenerator regenerator;

    public MatchService(ArenaManager arenas, ArenaRegenerator regenerator) {
        this.arenas = arenas;
        this.regenerator = regenerator;
    }

    public boolean startMatch(String arenaName, Player... players) {
        return arenas.get(arenaName).map(arena -> {
            if (arena.status() == Arena.Status.IN_GAME) {
                return false;
            }
            arena.setStatus(Arena.Status.IN_GAME);
            arena.players().clear();
            for (Player player : players) {
                arena.players().add(player.getUniqueId());
            }
            if ("FFA".equals(arena.teamSpawnMode()) && !arena.spawns().isEmpty()) {
                java.util.Random rng = new java.util.Random();
                for (Player player : players) {
                    player.teleport(arena.spawns().get(rng.nextInt(arena.spawns().size())));
                }
            } else {
                if (arena.spawn1() != null && players.length > 0) {
                    players[0].teleport(arena.spawn1());
                }
                if (arena.spawn2() != null && players.length > 1) {
                    players[1].teleport(arena.spawn2());
                }
            }
            return true;
        }).orElse(false);
    }

    public void endMatch(String arenaName) {
        arenas.get(arenaName).ifPresent(arena -> arenas.endMatch(arena, regenerator));
    }

    public boolean isInMatch(UUID uuid) {
        for (Arena arena : arenas.all()) {
            if (arena.status() == Arena.Status.IN_GAME && arena.players().contains(uuid)) {
                return true;
            }
        }
        return false;
    }
}
