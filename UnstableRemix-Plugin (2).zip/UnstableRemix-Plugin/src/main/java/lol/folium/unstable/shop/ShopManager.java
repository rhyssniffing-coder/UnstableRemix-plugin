package lol.folium.unstable.shop;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.economy.TransactionResult;
import lol.folium.unstable.util.ConfigItems;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ShopManager {

    private final UnstableRemixPlugin plugin;
    private final EconomyService economy;
    private final List<ShopPage> pages = new ArrayList<>();

    public ShopManager(UnstableRemixPlugin plugin, EconomyService economy) {
        this.plugin = plugin;
        this.economy = economy;
    }

    public void reload() {
        pages.clear();
        FileConfiguration config = plugin.getConfigManager().get("shops.yml");
        ConfigurationSection pagesSection = config.getConfigurationSection("shop.pages");
        if (pagesSection == null) return;
        for (String key : pagesSection.getKeys(false)) {
            ConfigurationSection pageSection = pagesSection.getConfigurationSection(key);
            if (pageSection == null) continue;
            ShopPage page = new ShopPage(key);
            page.title = pageSection.getString("title", "<dark_gray>Shop");
            page.rows = Math.max(1, Math.min(6, pageSection.getInt("rows", 6)));
            page.headerSlot = pageSection.getInt("header-slot", 4);
            page.headerMaterial = ConfigItems.material(pageSection, "header-material", Material.CHEST);
            page.headerName = pageSection.getString("header-name", "<white>Shop");
            ConfigurationSection itemsSection = pageSection.getConfigurationSection("items");
            if (itemsSection != null) {
                for (String itemKey : itemsSection.getKeys(false)) {
                    ConfigurationSection itemSection = itemsSection.getConfigurationSection(itemKey);
                    if (itemSection == null) continue;
                    ShopItem item = new ShopItem();
                    item.slot = itemSection.getInt("slot", 0);
                    item.material = ConfigItems.material(itemSection, "material", Material.STONE);
                    item.amount = itemSection.getInt("amount", 1);
                    item.name = itemSection.getString("name", "<white>Item");
                    item.lore = itemSection.getStringList("lore");
                    item.price = itemSection.getLong("price", 0);
                    item.effect = itemSection.getString("effect");
                    item.effectDuration = itemSection.getInt("effect-duration", 0);
                    page.items.add(item);
                }
            } else {
                List<?> rawList = pageSection.getList("items");
                if (rawList != null) {
                    for (Object entry : rawList) {
                        if (entry instanceof Map) {
                            @SuppressWarnings("unchecked")
                            Map<String, Object> map = (Map<String, Object>) entry;
                            ShopItem item = new ShopItem();
                            item.slot = getInt(map, "slot", 0);
                            item.material = getMaterial(map, "material", Material.STONE);
                            item.amount = getInt(map, "amount", 1);
                            item.name = getString(map, "name", "<white>Item");
                            item.lore = getStringList(map, "lore");
                            item.price = getLong(map, "price", 0);
                            item.effect = getString(map, "effect", null);
                            item.effectDuration = getInt(map, "effect-duration", 0);
                            page.items.add(item);
                        }
                    }
                }
            }
            pages.add(page);
        }
    }

    public void openShop(Player player, int pageIndex) {
        if (pages.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>Shop is not configured.</red>"));
            return;
        }
        pageIndex = Math.max(0, Math.min(pageIndex, pages.size() - 1));
        ShopPage page = pages.get(pageIndex);
        ConfigurationSection gui = plugin.getConfigManager().get("shops.yml").getConfigurationSection("shop.gui");
        int rows = page.rows;
        ShopHolder holder = new ShopHolder(player, pageIndex);
        Inventory inventory = Bukkit.createInventory(holder, rows * 9, TextUtil.parse(page.title));
        holder.bind(inventory);

        ItemStack filler = configuredItem(gui, "filler", Material.BLACK_STAINED_GLASS_PANE, "<dark_gray> ");
        ItemStack frame = configuredItem(gui, "frame", Material.BLACK_STAINED_GLASS_PANE, "<dark_gray> ");
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            inventory.setItem(slot, filler);
        }
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            int row = slot / 9;
            int col = slot % 9;
            if (row == 0 || row == rows - 1 || col == 0 || col == 8) {
                inventory.setItem(slot, frame);
            }
        }

        ItemStack header = ItemBuilder.of(page.headerMaterial)
                .name(TextUtil.parse(page.headerName))
                .lore(pageIndex == 0 && pages.size() > 1
                        ? List.of(TextUtil.parse("<gray>Click to switch to " + pages.get(1).headerName + "</gray>"))
                        : List.of())
                .build();
        inventory.setItem(page.headerSlot, header);

        if (pageIndex > 0) {
            inventory.setItem(gui != null ? gui.getInt("navigation-slots.previous", 45) : 45,
                    pageNavItem("<gradient:#FF4444:#FF8800:#FFD700>\u2190 Back</gradient>"));
        }
        if (pageIndex < pages.size() - 1) {
            inventory.setItem(gui != null ? gui.getInt("navigation-slots.next", 53) : 53,
                    pageNavItem("<gradient:#FF4444:#FF8800:#FFD700>Next \u2192</gradient>"));
        }

        for (ShopItem item : page.items) {
            Map<String, String> placeholders = Map.of("price", String.valueOf(item.price));
            ItemStack display = ItemBuilder.of(item.material)
                    .amount(item.amount)
                    .name(TextUtil.parse(TextUtil.apply(item.name, placeholders)))
                    .lore(TextUtil.loreRaw(item.lore, placeholders))
                    .build();
            inventory.setItem(item.slot, display);
            holder.itemSlots.put(item.slot, item);
        }
        player.openInventory(inventory);
    }

    public boolean purchase(Player player, ShopItem item, int pageIndex) {
        if (item.price <= 0) {
            player.sendMessage(TextUtil.parse("<gray>This item is free.</gray>"));
            return false;
        }
        long finalPrice = item.price;
        if (plugin.getMediaRankManager() != null && plugin.getMediaRankManager().hasShopDiscount(player)) {
            finalPrice = Math.round(item.price * plugin.getMediaRankManager().getShopDiscountMultiplier(player));
            if (finalPrice < item.price) {
                player.sendMessage(TextUtil.parse("<green>Media rank discount applied! <white>" + finalPrice + " Shards</white></green>"));
            }
        }
        String source = "shop:" + pages.get(pageIndex).id + ":" + item.material.name().toLowerCase();
        TransactionResult result = economy.spendShards(player.getUniqueId(), finalPrice, source);
        if (!result.success()) {
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0F, 0.6F);
            player.sendMessage(TextUtil.parse("<red>✖ Not enough shards</red>"));
            return false;
        }
        if (item.effect != null) {
            applyEffect(player, item);
        } else {
            ItemStack product = new ItemStack(item.material, item.amount);
            Map<String, String> placeholders = Map.of("price", String.valueOf(item.price));
            product.editMeta(meta -> {
                meta.displayName(TextUtil.parse(TextUtil.apply(item.name, placeholders)));
                meta.lore(TextUtil.loreRaw(item.lore, placeholders));
            });
            player.getInventory().addItem(product).values().forEach(extra ->
                    player.getWorld().dropItemNaturally(player.getLocation(), extra));
        }
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.2F);
        return true;
    }

    private void applyEffect(Player player, ShopItem item) {
        switch (item.effect) {
            case "no-cooldown" -> {
                long expires = item.effectDuration > 0 ? System.currentTimeMillis() + item.effectDuration * 1000L : -1;
                plugin.getKitCooldownManager().setBypass(player.getUniqueId(), expires);
                player.sendMessage(TextUtil.parse("<green>You now have kit cooldown bypass"
                        + (item.effectDuration > 0 ? " for " + (item.effectDuration / 60) + " minutes." : " permanently.")));
            }
            case "skip-cooldown" -> {
                plugin.getKitCooldownManager().removeAllCooldowns(player.getUniqueId());
                player.sendMessage(TextUtil.parse("<green>All kit cooldowns have been reset.</green>"));
            }
            case "shard-boost" -> {
                long expires = System.currentTimeMillis() + item.effectDuration * 1000L;
                plugin.getKitCooldownManager().setShardBoost(player.getUniqueId(), expires);
                player.sendMessage(TextUtil.parse("<gold>2x Shard Boost active for " + (item.effectDuration / 60) + " minutes!</gold>"));
            }
            case "firework-bypass" -> {
                long expires = item.effectDuration > 0 ? System.currentTimeMillis() + item.effectDuration * 1000L : -1;
                plugin.getKitCooldownManager().setFireworkBypass(player.getUniqueId(), expires);
                player.sendMessage(TextUtil.parse("<green>Firework cooldown bypassed"
                        + (item.effectDuration > 0 ? " for " + (item.effectDuration / 60) + " minutes." : " permanently.")));
            }
        }
    }

    public List<String> pageIds() {
        return pages.stream().map(p -> p.id).toList();
    }

    public int pageCount() {
        return pages.size();
    }

    public List<ShopPage> getPages() {
        return pages;
    }

    public ShopPage getPage(int index) {
        return index >= 0 && index < pages.size() ? pages.get(index) : null;
    }

    public void addItem(int pageIndex, int slot, ItemStack held, long price) {
        ShopPage page = getPage(pageIndex);
        if (page == null) return;
        FileConfiguration config = plugin.getConfigManager().get("shops.yml");
        String path = "shop.pages." + page.id + ".items." + slot;
        config.set(path + ".slot", slot);
        config.set(path + ".material", held.getType().name());
        config.set(path + ".amount", held.getAmount());
        config.set(path + ".name", "<white>" + held.getType().name());
        config.set(path + ".lore", List.of("<light_purple>Price: {price} Shards</light_purple>"));
        config.set(path + ".price", price);
        save();
        reload();
    }

    public void removeItem(int pageIndex, int slot) {
        ShopPage page = getPage(pageIndex);
        if (page == null) return;
        FileConfiguration config = plugin.getConfigManager().get("shops.yml");
        config.set("shop.pages." + page.id + ".items." + slot, null);
        save();
        reload();
    }

    public void addEffectItem(int pageIndex, int slot, long price, String effect, int duration) {
        ShopPage page = getPage(pageIndex);
        if (page == null) return;
        FileConfiguration config = plugin.getConfigManager().get("shops.yml");
        String path = "shop.pages." + page.id + ".items." + slot;
        config.set(path + ".slot", slot);
        config.set(path + ".material", "BEACON");
        config.set(path + ".amount", 1);
        config.set(path + ".name", "<yellow>" + formatEffectName(effect) + "</yellow>");
        config.set(path + ".lore", List.of(
                "<gray>" + formatEffectLore(effect) + "</gray>",
                duration > 0 ? "<green>Duration: " + (duration / 60) + " minutes</green>" : "<green>Permanent</green>",
                "<light_purple>Price: {price} Shards</light_purple>"));
        config.set(path + ".price", price);
        config.set(path + ".effect", effect);
        if (duration > 0) config.set(path + ".effect-duration", duration);
        save();
        reload();
    }

    public void setEffect(int pageIndex, int slot, String effect, int duration) {
        ShopPage page = getPage(pageIndex);
        if (page == null) return;
        FileConfiguration config = plugin.getConfigManager().get("shops.yml");
        String path = "shop.pages." + page.id + ".items." + slot;
        config.set(path + ".effect", effect);
        if (duration > 0) config.set(path + ".effect-duration", duration);
        save();
        reload();
    }

    public void setDuration(int pageIndex, int slot, int duration) {
        ShopPage page = getPage(pageIndex);
        if (page == null) return;
        FileConfiguration config = plugin.getConfigManager().get("shops.yml");
        String path = "shop.pages." + page.id + ".items." + slot;
        if (duration > 0) {
            config.set(path + ".effect-duration", duration);
        } else {
            config.set(path + ".effect-duration", null);
        }
        save();
        reload();
    }

    private String formatEffectName(String effect) {
        return switch (effect) {
            case "no-cooldown" -> "No Cooldown";
            case "skip-cooldown" -> "Skip Cooldown";
            case "shard-boost" -> "2x Shard Boost";
            case "firework-bypass" -> "Firework Bypass";
            default -> effect;
        };
    }

    private String formatEffectLore(String effect) {
        return switch (effect) {
            case "no-cooldown" -> "Bypass all kit cooldowns";
            case "skip-cooldown" -> "Reset all kit cooldowns instantly";
            case "shard-boost" -> "Earn double shards";
            case "firework-bypass" -> "Bypass firework use cooldown";
            default -> effect;
        };
    }

    public void setCost(int pageIndex, int slot, long price) {
        ShopPage page = getPage(pageIndex);
        if (page == null) return;
        FileConfiguration config = plugin.getConfigManager().get("shops.yml");
        config.set("shop.pages." + page.id + ".items." + slot + ".price", price);
        save();
        reload();
    }

    private void save() {
        try {
            plugin.getConfigManager().save("shops.yml");
        } catch (java.io.IOException e) {
            plugin.getLogger().severe("Failed to save shops.yml: " + e.getMessage());
        }
    }

    private static int getInt(Map<String, Object> map, String key, int def) {
        Object v = map.get(key);
        if (v instanceof Number n) return n.intValue();
        return def;
    }

    private static long getLong(Map<String, Object> map, String key, long def) {
        Object v = map.get(key);
        if (v instanceof Number n) return n.longValue();
        return def;
    }

    private static String getString(Map<String, Object> map, String key, String def) {
        Object v = map.get(key);
        return v != null ? v.toString() : def;
    }

    @SuppressWarnings("unchecked")
    private static List<String> getStringList(Map<String, Object> map, String key) {
        Object v = map.get(key);
        if (v instanceof List<?> list) {
            List<String> result = new ArrayList<>();
            for (Object o : list) {
                if (o != null) result.add(o.toString());
            }
            return result;
        }
        return List.of();
    }

    private static Material getMaterial(Map<String, Object> map, String key, Material def) {
        String name = getString(map, key, null);
        if (name == null) return def;
        try {
            return Material.valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            return def;
        }
    }

    private ItemStack pageNavItem(String name) {
        return ItemBuilder.of(Material.ARROW).name(TextUtil.parse(name)).build();
    }

    private ItemStack configuredItem(ConfigurationSection gui, String path, Material fallbackMaterial, String fallbackName) {
        if (gui == null) return ItemBuilder.of(fallbackMaterial).name(TextUtil.parse(fallbackName)).build();
        ConfigurationSection section = gui.getConfigurationSection(path);
        Material mat = section != null ? ConfigItems.material(section, "material", fallbackMaterial) : fallbackMaterial;
        String name = section != null ? section.getString("name", fallbackName) : fallbackName;
        return ItemBuilder.of(mat).name(TextUtil.parse(name)).build();
    }

    public static final class ShopPage {
        public final String id;
        public String title;
        public int rows;
        public int headerSlot;
        public Material headerMaterial;
        public String headerName;
        public final List<ShopItem> items = new ArrayList<>();

        public ShopPage(String id) {
            this.id = id;
        }
    }

    public static final class ShopItem {
        public int slot;
        public Material material;
        public int amount;
        public String name;
        public List<String> lore;
        public long price;
        public String effect;
        public int effectDuration;
    }

    private final class ShopHolder extends GuiHolder {
        private final Player player;
        private final int pageIndex;
        private final Map<Integer, ShopItem> itemSlots = new HashMap<>();

        ShopHolder(Player player, int pageIndex) {
            this.player = player;
            this.pageIndex = pageIndex;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            if (slot < 0 || slot >= event.getInventory().getSize()) return;

            ShopItem shopItem = itemSlots.get(slot);
            if (shopItem != null) {
                openConfirmGui(player, shopItem, pageIndex);
                return;
            }

            int prevSlot = 45;
            int nextSlot = 53;
            if (slot == prevSlot && pageIndex > 0) {
                openShop(player, pageIndex - 1);
            } else if (slot == nextSlot && pageIndex < pages.size() - 1) {
                openShop(player, pageIndex + 1);
            } else if (slot == pages.get(pageIndex).headerSlot && pages.size() > 1) {
                openShop(player, (pageIndex + 1) % pages.size());
            }
        }
    }

    private void openConfirmGui(Player player, ShopItem item, int pageIndex) {
        ConfirmHolder holder = new ConfirmHolder(player, item, pageIndex);
        Inventory inv = Bukkit.createInventory(holder, 27, TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700><bold>CONFIRM PURCHASE</bold></gradient>"));
        holder.bind(inv);

        ItemStack filler = ItemBuilder.of(Material.BLACK_STAINED_GLASS_PANE).name(Component.text("")).build();
        for (int i = 0; i < 27; i++) {
            inv.setItem(i, filler);
        }

        long finalPrice = item.price;
        boolean hasDiscount = plugin.getMediaRankManager() != null && plugin.getMediaRankManager().hasShopDiscount(player);
        if (hasDiscount) {
            finalPrice = Math.round(item.price * plugin.getMediaRankManager().getShopDiscountMultiplier(player));
        }

        Map<String, String> placeholders = Map.of("price", String.valueOf(finalPrice));
        ItemStack display = ItemBuilder.of(item.material)
                .amount(item.amount)
                .name(TextUtil.parse(TextUtil.apply(item.name, placeholders)))
                .lore(TextUtil.loreRaw(item.lore, placeholders))
                .build();
        inv.setItem(13, display);

        List<Component> buyLore = new ArrayList<>();
        if (hasDiscount && finalPrice < item.price) {
            buyLore.add(TextUtil.parse("<gray>Cost: <light_purple>" + finalPrice + " Shards</light_purple> <strikethrough><white>" + item.price + "</white></strikethrough></gray>"));
            buyLore.add(TextUtil.parse("<green>Media rank discount (-20%)!</green>"));
        } else {
            buyLore.add(TextUtil.parse("<gray>Cost: <light_purple>" + item.price + " Shards</light_purple></gray>"));
        }

        inv.setItem(11, ItemBuilder.of(Material.LIME_DYE)
                .name(TextUtil.parse("<gradient:#FF4444:#FF8800:#FFD700><bold>\u2714 BUY</bold></gradient>"))
                .lore(buyLore)
                .build());

        inv.setItem(15, ItemBuilder.of(Material.RED_DYE)
                .name(TextUtil.parse("<dark_gray><bold>\u2718 CANCEL</bold></dark_gray>"))
                .lore(List.of(TextUtil.parse("<gray>Go back to the shop</gray>")))
                .build());

        player.openInventory(inv);
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
    }

    private final class ConfirmHolder extends GuiHolder {
        private final Player player;
        private final ShopItem item;
        private final int pageIndex;

        ConfirmHolder(Player player, ShopItem item, int pageIndex) {
            this.player = player;
            this.item = item;
            this.pageIndex = pageIndex;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            int slot = event.getRawSlot();

            if (slot == 11) {
                player.closeInventory();
                purchase(player, item, pageIndex);
            } else if (slot == 15) {
                player.closeInventory();
                openShop(player, pageIndex);
            }
        }
    }
}
