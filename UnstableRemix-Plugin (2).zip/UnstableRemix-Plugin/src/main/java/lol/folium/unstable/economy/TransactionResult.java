package lol.folium.unstable.economy;

public record TransactionResult(boolean success, String messageKey, long balanceAfter) {
    public static TransactionResult ok(long balanceAfter) {
        return new TransactionResult(true, null, balanceAfter);
    }

    public static TransactionResult fail(String messageKey, long balanceAfter) {
        return new TransactionResult(false, messageKey, balanceAfter);
    }
}
