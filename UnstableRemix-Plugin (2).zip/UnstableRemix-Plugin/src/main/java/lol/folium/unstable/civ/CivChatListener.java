package lol.folium.unstable.civ;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.util.GuiTheme;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class CivChatListener implements Listener {

    private final CivCommand civCommand;
    private final EconomyService economy;
    private final Map<UUID, ChatInputType> pendingInputs = new ConcurrentHashMap<>();

    public enum ChatInputType {
        CIV_PREFIX,
        CIV_TODO,
        CIV_TARGET,
        CIV_INVITE
    }

    public CivChatListener(CivCommand civCommand, EconomyService economy) {
        this.civCommand = civCommand;
        this.economy = economy;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        if (!pendingInputs.containsKey(uuid)) return;

        event.setCancelled(true);

        String message = event.getMessage().trim();
        ChatInputType type = pendingInputs.remove(uuid);

        Bukkit.getScheduler().runTask(UnstableRemixPlugin.getInstance(), () -> {
            switch (type) {
                case CIV_PREFIX -> handlePrefixInput(player, message);
                case CIV_TODO -> handleTodoInput(player, message);
                case CIV_TARGET -> handleTargetInput(player, message);
                case CIV_INVITE -> handleInviteInput(player, message);
            }
        });
    }

    private void handlePrefixInput(Player player, String prefix) {
        CivManager civManager = CivManager.getInstance();

        if (prefix.length() > civManager.getMaxPrefixLength()) {
            player.sendMessage(TextUtil.parse("&cPrefix must be " + civManager.getMaxPrefixLength() + " characters or less!"));
            pendingInputs.put(player.getUniqueId(), ChatInputType.CIV_PREFIX);
            return;
        }

        if (civManager.getCivByPrefix(prefix) != null) {
            player.sendMessage(TextUtil.parse("&cThat prefix is already taken!"));
            pendingInputs.put(player.getUniqueId(), ChatInputType.CIV_PREFIX);
            return;
        }

        civCommand.completeCivCreation(player, prefix);
    }

    private void handleTodoInput(Player player, String todo) {
        Civilization civ = CivManager.getInstance().getPlayerCiv(player.getUniqueId());
        if (civ == null) {
            player.sendMessage(TextUtil.parse("&cYou are not in a civilization!"));
            return;
        }

        if (todo.length() > 50) {
            player.sendMessage(TextUtil.parse("&cTodo item must be 50 characters or less!"));
            pendingInputs.put(player.getUniqueId(), ChatInputType.CIV_TODO);
            return;
        }

        civ.getTodoList().add(todo);
        CivManager.getInstance().saveAll();
        player.sendMessage(TextUtil.parse("&aAdded to todo list: &f" + todo));
    }

    private void handleTargetInput(Player player, String target) {
        Civilization civ = CivManager.getInstance().getPlayerCiv(player.getUniqueId());
        if (civ == null) {
            player.sendMessage(TextUtil.parse("&cYou are not in a civilization!"));
            return;
        }

        if (!civ.isOwner(player.getUniqueId())) {
            player.sendMessage(TextUtil.parse("&cOnly the owner can add targets!"));
            return;
        }

        if (target.length() > 30) {
            player.sendMessage(TextUtil.parse("&cTarget name must be 30 characters or less!"));
            pendingInputs.put(player.getUniqueId(), ChatInputType.CIV_TARGET);
            return;
        }

        civ.getTargets().add(target);
        CivManager.getInstance().saveAll();
        player.sendMessage(TextUtil.parse("&aAdded target: &f" + target));
    }

    private void handleInviteInput(Player player, String targetName) {
        Civilization civ = CivManager.getInstance().getPlayerCiv(player.getUniqueId());
        if (civ == null) {
            player.sendMessage(TextUtil.parse("&cYou are not in a civilization!"));
            return;
        }

        if (!civ.isOwner(player.getUniqueId())) {
            player.sendMessage(TextUtil.parse("&cOnly the owner can invite players!"));
            return;
        }

        Player target = Bukkit.getPlayer(targetName);
        if (target == null) {
            player.sendMessage(TextUtil.parse("&cPlayer not found!"));
            return;
        }

        if (CivManager.getInstance().isPlayerInCiv(target.getUniqueId())) {
            player.sendMessage(TextUtil.parse("&cThat player is already in a civilization!"));
            return;
        }

        civ.invite(target.getUniqueId());
        CivManager.getInstance().saveAll();
        player.sendMessage(TextUtil.parse("&aInvited " + target.getName() + " to " + civ.getName() + "!"));
        target.sendMessage(TextUtil.parse("&aYou've been invited to " + civ.getName() + "!"));
        target.sendMessage(TextUtil.parse("&7Type &f/civ accept " + civ.getName() + " &7to join."));
    }

    public void startInput(Player player, ChatInputType type) {
        pendingInputs.put(player.getUniqueId(), type);
    }

    public void cancelInput(Player player) {
        pendingInputs.remove(player.getUniqueId());
    }

    public boolean hasPendingInput(Player player) {
        return pendingInputs.containsKey(player.getUniqueId());
    }
}
