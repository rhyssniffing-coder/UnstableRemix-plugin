package lol.folium.unstable.command;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.effects.EffectsManager;
import lol.folium.unstable.map.ArenaManager;
import lol.folium.unstable.quest.QuestService;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.Collections;
import java.util.List;

public final class UnstableAdminCommand implements CommandExecutor, TabCompleter {

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final ArenaManager arenas;
    private final EffectsManager effects;
    private final QuestService quests;

    public UnstableAdminCommand(UnstableRemixPlugin plugin, ConfigManager configs, ArenaManager arenas,
                                EffectsManager effects, QuestService quests) {
        this.plugin = plugin;
        this.configs = configs;
        this.arenas = arenas;
        this.effects = effects;
        this.quests = quests;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("unstable.admin")) {
            sender.sendMessage(TextUtil.parse("<red>No permission."));
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            plugin.reloadConfig();
            configs.reloadAll();
            arenas.loadAll();
            effects.reload();
            quests.reload();
            plugin.getKitManager().reload();
            if (plugin.getCooldownItemManager() != null) plugin.getCooldownItemManager().reload();
            plugin.refreshPlaceholderExpansions();
            sender.sendMessage(TextUtil.parse("<green>UnstableRemix reloaded."));
            return true;
        }
        sender.sendMessage(TextUtil.parse("<yellow>/unstable reload"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("reload");
        }
        return Collections.emptyList();
    }
}
