package lol.folium.unstable.map;

import lol.folium.unstable.util.TextUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.ItemStack;

public final class MapVoteListener implements Listener {

    private final MapVoteManager mapVoteManager;

    public MapVoteListener(MapVoteManager mapVoteManager) {
        this.mapVoteManager = mapVoteManager;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (!(event.getInventory().getHolder() instanceof MapVoteManager.MapVoteGui)) {
            return;
        }

        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) {
            return;
        }

        String displayName = clicked.getItemMeta().getDisplayName();
        if (displayName == null) {
            return;
        }

        for (MapVoteManager.MapVoteOption option : mapVoteManager.getVoteOptions().values()) {
            String optionName = net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection()
                .serialize(TextUtil.parse(option.displayName()));
            if (displayName.equals(optionName)) {
                mapVoteManager.handleVote(player, option.id());
                return;
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) {
            return;
        }
        if (!(event.getInventory().getHolder() instanceof MapVoteManager.MapVoteGui)) {
            return;
        }
        if (mapVoteManager.isVotingActive() && mapVoteManager.getVotedOption(player.getUniqueId()) == null) {
            org.bukkit.Bukkit.getScheduler().runTaskLater(mapVoteManager.getPlugin(), () -> {
                if (player.isOnline() && mapVoteManager.isVotingActive() && mapVoteManager.getVotedOption(player.getUniqueId()) == null) {
                    mapVoteManager.openVoteGUI(player);
                }
            }, 1L);
        }
    }
}
