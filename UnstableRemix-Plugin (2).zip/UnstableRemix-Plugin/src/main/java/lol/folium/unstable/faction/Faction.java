package lol.folium.unstable.faction;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class Faction {

    private final String name;
    private String displayName;
    private String description;
    private int level;
    private long xp;
    private long totalKills;
    private long totalShardsEarned;
    private final Set<FactionMember> members = new HashSet<>();

    public Faction(String name) {
        this.name = name.toLowerCase();
        this.displayName = name;
        this.level = 1;
    }

    public String name() { return name; }
    public String displayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }
    public String description() { return description; }
    public void setDescription(String description) { this.description = description; }
    public int level() { return level; }
    public void setLevel(int level) { this.level = level; }
    public long xp() { return xp; }
    public void setXp(long xp) { this.xp = xp; }
    public long totalKills() { return totalKills; }
    public void setTotalKills(long totalKills) { this.totalKills = totalKills; }
    public long totalShardsEarned() { return totalShardsEarned; }
    public void setTotalShardsEarned(long totalShardsEarned) { this.totalShardsEarned = totalShardsEarned; }
    public Set<FactionMember> members() { return members; }

    public long xpToNextLevel() {
        return level * 1000L + (level - 1L) * 500L;
    }

    public double shardBonus() {
        if (level >= 3) return 1.0 + (level - 2) * 0.05;
        return 1.0;
    }

    public enum Role {
        LEADER, COMMANDER, MEMBER
    }

    public record FactionMember(UUID uuid, String playerName, Role role, long joinedAt, long kills) {}
}
