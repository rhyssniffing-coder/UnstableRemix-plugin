package lol.folium.unstable.faction;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.util.TextUtil;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.Node;
import net.luckperms.api.node.types.PrefixNode;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import net.kyori.adventure.text.Component;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public final class FactionSelectionManager {

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final LuckPerms luckPerms;
    private final FactionManager factionManager;
    private final Set<UUID> lockedPlayers = ConcurrentHashMap.newKeySet();
    private final Set<UUID> selectingPlayers = ConcurrentHashMap.newKeySet();
    private final Map<String, UUID> factionLeaders = new ConcurrentHashMap<>();

    public FactionSelectionManager(UnstableRemixPlugin plugin, ConfigManager configs, LuckPerms luckPerms, FactionManager factionManager) {
        this.plugin = plugin;
        this.configs = configs;
        this.luckPerms = luckPerms;
        this.factionManager = factionManager;
    }

    public void setupGroups() {
        // Base faction groups
        setupFactionGroup("mafia", "<black><bold>Mafia</bold></black>");
        setupFactionGroup("law", "<yellow><bold>Law</bold></yellow>");
        setupFactionGroup("null-faction", "<gradient:#00FF00:#000000><bold>Null</bold></gradient>");

        // Commander groups (same prefix as base)
        setupFactionGroup("mafia-commander", "<black><bold>Mafia</bold></black>");
        setupFactionGroup("law-commander", "<yellow><bold>Law</bold></yellow>");
        setupFactionGroup("null-commander", "<gradient:#00FF00:#000000><bold>Null</bold></gradient>");

        // Leader groups (crown prefix/suffix)
        setupFactionGroup("mafia-leader", "<gold>\u26BD <black><bold>Mafia</bold></black> \u26BD</gold>");
        setupFactionGroup("law-leader", "<gold>\u26BD <yellow><bold>Law</bold></yellow> \u26BD</gold>");
        setupFactionGroup("null-faction-leader", "<gold>\u26BD <gradient:#00FF00:#000000><bold>Null</bold></gradient> \u26BD</gold>");
    }

    private void setupFactionGroup(String groupName, String prefix) {
        Group group = luckPerms.getGroupManager().getGroup(groupName);
        if (group == null) {
            group = luckPerms.getGroupManager().createAndLoadGroup(groupName).join();
        }

        group.data().add(PrefixNode.builder(prefix, 100).build());
        group.data().add(Node.builder("group.default").build());

        luckPerms.getGroupManager().saveGroup(group);
    }

    public void handlePlayerJoin(Player player) {
        luckPerms.getUserManager().loadUser(player.getUniqueId()).thenAcceptAsync(user -> {
            if (user == null) {
                return;
            }

            boolean hasFaction = user.getNodes().stream()
                .anyMatch(node -> {
                    String key = node.getKey();
                    if (!key.startsWith("group.")) return false;
                    String groupName = key.substring(6);
                    return groupName.equals("mafia") || groupName.equals("mafia-commander") || groupName.equals("mafia-leader") ||
                           groupName.equals("law") || groupName.equals("law-commander") || groupName.equals("law-leader") ||
                           groupName.equals("null-faction") || groupName.equals("null-commander") || groupName.equals("null-faction-leader");
                });

            if (!hasFaction && !factionManager.hasEverBeenInFaction(player.getUniqueId())) {
                Bukkit.getScheduler().runTask(plugin, () -> {
                    lockPlayer(player);
                    openFactionGUI(player);
                });
            }
        });
    }

    public void openFactionGUI(Player player) {
        String title = configs.main().getString("faction-selection.gui-title", "<aqua><bold>Pick Your Faction</bold></aqua>");
        Inventory gui = Bukkit.createInventory(null, 27, TextUtil.parse(title));

        gui.setItem(11, createFactionItem("mafia", 11));
        gui.setItem(13, createFactionItem("null-faction", 13));
        gui.setItem(15, createFactionItem("law", 15));

        player.openInventory(gui);
        selectingPlayers.add(player.getUniqueId());
    }

    private ItemStack createFactionItem(String faction, int slot) {
        Material material = Material.valueOf(configs.main().getString("faction-selection." + faction + ".material", "RED_DYE"));
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();

        String displayName = configs.main().getString("faction-selection." + faction + ".display-name", faction);
        meta.displayName(TextUtil.parse(displayName));

        String lore = configs.main().getString("faction-selection." + faction + ".lore",
            "<gray>Join this faction</gray>\n<gold>5% chance to become Commander!</gold>");
        String[] loreLines = lore.split("\n");
        List<Component> loreComponents = new ArrayList<>();
        for (String line : loreLines) {
            loreComponents.add(TextUtil.parse(line));
        }
        meta.lore(loreComponents);

        item.setItemMeta(meta);
        return item;
    }

    public void handleInventoryClick(Player player, int slot) {
        if (!selectingPlayers.contains(player.getUniqueId())) {
            return;
        }

        if (slot == 11) {
            selectFaction(player, "mafia");
        } else if (slot == 13) {
            selectFaction(player, "null-faction");
        } else if (slot == 15) {
            selectFaction(player, "law");
        }
    }

    private void selectFaction(Player player, String faction) {
        selectingPlayers.remove(player.getUniqueId());
        player.closeInventory();

        double commanderChance = configs.main().getDouble("faction-selection.commander-chance", 0.05);
        boolean isCommander = ThreadLocalRandom.current().nextDouble() < commanderChance;

        String groupName = isCommander ? faction + "-commander" : faction;
        assignFactionAsync(player, groupName, isCommander);
    }

    private void assignFactionAsync(Player player, String groupName, boolean isCommander) {
        String raw = groupName.replace("-commander", "").replace("-faction", "");
        String dbFaction = raw.equals("null") ? "null-faction" : raw;
        final String baseFaction = dbFaction;

        luckPerms.getUserManager().loadUser(player.getUniqueId()).thenAcceptAsync(user -> {
            if (user == null) {
                plugin.getLogger().warning("Could not load LuckPerms user for " + player.getName() + " during faction assignment.");
                Bukkit.getScheduler().runTask(plugin, () -> unlockPlayer(player));
                return;
            }

            removeAllFactionGroups(user);

            Group targetGroup = luckPerms.getGroupManager().getGroup(groupName);
            if (targetGroup != null) {
                user.data().add(Node.builder("group." + groupName).build());
            } else {
                plugin.getLogger().warning("LuckPerms group '" + groupName + "' not found for faction assignment.");
            }

            luckPerms.getUserManager().saveUser(user).thenRun(() -> {
                if (factionManager != null) {
                    factionManager.addPlayerToFaction(player.getUniqueId(), player.getName(), baseFaction);
                }

                Bukkit.getScheduler().runTask(plugin, () -> {
                    unlockPlayer(player);
                    broadcastFactionSelection(player, groupName, isCommander);
                    playSelectionEffects(player, isCommander);
                });
            });
        });
    }

    public void assignLeaderGroup(UUID playerUuid, String faction, Runnable callback) {
        String leaderGroup = faction.equals("null") ? "null-faction-leader" : faction + "-leader";
        String baseGroup = faction.equals("null") ? "null-faction" : faction;

        UUID prevLeader = factionLeaders.get(faction);

        if (prevLeader != null && !prevLeader.equals(playerUuid)) {
            luckPerms.getUserManager().loadUser(prevLeader).thenAcceptAsync(prevUser -> {
                if (prevUser != null) {
                    prevUser.data().remove(Node.builder("group." + leaderGroup).build());
                    prevUser.data().add(Node.builder("group." + baseGroup).build());
                    luckPerms.getUserManager().saveUser(prevUser);
                }
                assignLeaderToUser(playerUuid, leaderGroup, callback);
            });
        } else {
            assignLeaderToUser(playerUuid, leaderGroup, callback);
        }
    }

    private void assignLeaderToUser(UUID playerUuid, String leaderGroup, Runnable callback) {
        luckPerms.getUserManager().loadUser(playerUuid).thenAcceptAsync(user -> {
            if (user == null) {
                if (callback != null) Bukkit.getScheduler().runTask(plugin, callback);
                return;
            }

            removeAllFactionGroups(user);
            user.data().add(Node.builder("group." + leaderGroup).build());

            luckPerms.getUserManager().saveUser(user).thenRun(() -> {
                String faction = leaderGroup.equals("null-faction-leader") ? "null" : leaderGroup.replace("-leader", "");
                factionLeaders.put(faction, playerUuid);
                if (callback != null) {
                    Bukkit.getScheduler().runTask(plugin, callback);
                }
            });
        });
    }

    private void removeAllFactionGroups(User user) {
        for (String g : new String[]{"mafia", "mafia-commander", "mafia-leader",
                                       "law", "law-commander", "law-leader",
                                       "null-faction", "null-commander", "null-faction-leader"}) {
            Group group = luckPerms.getGroupManager().getGroup(g);
            if (group != null) {
                user.data().remove(Node.builder("group." + g).build());
            }
        }
    }

    private void broadcastFactionSelection(Player player, String groupName, boolean isCommander) {
        String factionName = groupName.replace("-commander", "").replace("-faction", "");
        factionName = factionName.substring(0, 1).toUpperCase() + factionName.substring(1);

        String message;
        if (isCommander) {
            message = configs.main().getString("faction-selection.broadcast-commander",
                "<gold><bold>{player}</bold> has joined <gradient:#FF0000:#FF6600>{faction}</gradient> as a <red><bold>COMMANDER</bold></red>!")
                .replace("{player}", player.getName())
                .replace("{faction}", factionName);
        } else {
            message = configs.main().getString("faction-selection.broadcast-member",
                "<yellow>{player} has joined <gradient:#FF0000:#FF6600>{faction}</gradient>!")
                .replace("{player}", player.getName())
                .replace("{faction}", factionName);
        }

        Bukkit.broadcast(TextUtil.parse(message));
    }

    private void playSelectionEffects(Player player, boolean isCommander) {
        if (isCommander) {
            String soundKey = configs.main().getString("faction-selection.commander-sound", "ENTITY_ENDER_DRAGON_GROWL");
            float volume = (float) configs.main().getDouble("faction-selection.commander-sound-volume", 1.0);
            float pitch = (float) configs.main().getDouble("faction-selection.commander-sound-pitch", 1.0);

            try {
                Sound sound = Sound.valueOf(soundKey);
                player.playSound(player.getLocation(), sound, volume, pitch);
            } catch (IllegalArgumentException ignored) {
                player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, volume, pitch);
            }

            org.bukkit.entity.Firework firework = player.getWorld().spawn(player.getLocation(), org.bukkit.entity.Firework.class);
            firework.setShotAtAngle(false);
            org.bukkit.inventory.meta.FireworkMeta meta = (org.bukkit.inventory.meta.FireworkMeta) firework.getFireworkMeta();
            meta.addEffect(org.bukkit.FireworkEffect.builder()
                .withColor(org.bukkit.Color.RED)
                .withFade(org.bukkit.Color.ORANGE)
                .with(org.bukkit.FireworkEffect.Type.BALL_LARGE)
                .build());
            firework.setFireworkMeta(meta);
        } else {
            String soundKey = configs.main().getString("faction-selection.member-sound", "ENTITY_PLAYER_LEVELUP");
            float volume = (float) configs.main().getDouble("faction-selection.member-sound-volume", 1.0);
            float pitch = (float) configs.main().getDouble("faction-selection.member-sound-pitch", 1.0);

            try {
                Sound sound = Sound.valueOf(soundKey);
                player.playSound(player.getLocation(), sound, volume, pitch);
            } catch (IllegalArgumentException ignored) {
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, volume, pitch);
            }
        }
    }

    public void lockPlayer(Player player) {
        lockedPlayers.add(player.getUniqueId());
        player.setWalkSpeed(0);
        player.setFlySpeed(0);
    }

    public void unlockPlayer(Player player) {
        lockedPlayers.remove(player.getUniqueId());
        player.setWalkSpeed(0.2f);
        player.setFlySpeed(0.1f);
    }

    public boolean isPlayerLocked(UUID uuid) {
        return lockedPlayers.contains(uuid);
    }

    public boolean isPlayerSelecting(UUID uuid) {
        return selectingPlayers.contains(uuid);
    }

    public void forceOpenGUI(Player player) {
        lockPlayer(player);
        openFactionGUI(player);
    }
}
