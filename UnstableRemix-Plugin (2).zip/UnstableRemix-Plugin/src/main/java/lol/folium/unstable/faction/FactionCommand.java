package lol.folium.unstable.faction;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public final class FactionCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;
    private final FactionManager factions;
    private final FactionSelectionManager selectionManager;

    public FactionCommand(UnstableRemixPlugin plugin, FactionManager factions, FactionSelectionManager selectionManager) {
        this.plugin = plugin;
        this.factions = factions;
        this.selectionManager = selectionManager;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length == 0) {
            showInfo(player);
            return;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "info" -> handleInfo(player, args);
            case "list" -> handleList(player);
            case "top" -> handleTop(player);
            case "gui" -> handleGui(player, args);
            case "admin" -> handleAdmin(player, args);
            case "war" -> handleWar(player, args);
            default -> showInfo(player);
        }
    }

    private void showInfo(Player player) {
        var opt = factions.getFaction(player);
        if (opt.isEmpty()) {
            player.sendMessage(TextUtil.parse("<gray>You are not in a faction.</gray>"));
            player.sendMessage(TextUtil.parse("<yellow>/faction list</yellow> <gray>- List all factions</gray>"));
            player.sendMessage(TextUtil.parse("<yellow>/faction top</yellow> <gray>- Top factions by level</gray>"));
            return;
        }
        var f = opt.get();
        player.sendMessage(TextUtil.parse("<gold>=== " + f.displayName() + " ==="));
        player.sendMessage(TextUtil.parse("<gray>Level: <white>" + f.level() + "</white> <dark_gray>|</dark_gray> XP: <yellow>" + f.xp() + "/" + f.xpToNextLevel() + "</yellow>"));
        player.sendMessage(TextUtil.parse("<gray>Members: <white>" + f.members().size() + "</white></gray>"));
        player.sendMessage(TextUtil.parse("<gray>Kills: <white>" + f.totalKills() + "</white></gray>"));
        String memberList = f.members().stream()
                .sorted((a, b) -> a.role().compareTo(b.role()))
                .map(m -> (m.role() == Faction.Role.COMMANDER ? "<aqua>\u2726 </aqua>" : "<gray>- </gray>") + "<white>" + m.playerName() + "</white>")
                .collect(Collectors.joining("\n"));
        player.sendMessage(TextUtil.parse("<gray>Members:</gray>\n" + memberList));
    }

    private void handleInfo(Player player, String[] args) {
        String name = args.length >= 2 ? args[1] : factions.getFactionName(player);
        if (name == null) {
            player.sendMessage(TextUtil.parse("<red>Usage: /faction info <name>"));
            return;
        }
        var opt = factions.getFaction(name);
        if (opt.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>Faction not found.</red>"));
            return;
        }
        var f = opt.get();
        player.sendMessage(TextUtil.parse("<gold>=== " + f.displayName() + " ==="));
        player.sendMessage(TextUtil.parse("<gray>Level: <white>" + f.level() + "</white> <dark_gray>|</dark_gray> XP: <yellow>" + f.xp() + "/" + f.xpToNextLevel() + "</yellow>"));
        player.sendMessage(TextUtil.parse("<gray>Members: <white>" + f.members().size() + "</white></gray>"));
        player.sendMessage(TextUtil.parse("<gray>Kills: <white>" + f.totalKills() + "</white></gray>"));
        String memberList = f.members().stream()
                .sorted((a, b) -> a.role().compareTo(b.role()))
                .map(m -> (m.role() == Faction.Role.COMMANDER ? "<aqua>\u2726 </aqua>" : "<gray>- </gray>") + "<white>" + m.playerName() + "</white>")
                .collect(Collectors.joining("\n"));
        player.sendMessage(TextUtil.parse("<gray>Members:</gray>\n" + memberList));
    }

    private void handleList(Player player) {
        if (factions.allFactions().isEmpty()) {
            player.sendMessage(TextUtil.parse("<gray>No factions exist yet.</gray>"));
            return;
        }
        player.sendMessage(TextUtil.parse("<gold><bold>Factions (" + factions.allFactions().size() + ")</bold></gold>"));
        for (var f : factions.allFactions()) {
            player.sendMessage(TextUtil.parse("<gray>- <white>" + f.displayName() + "</white> <dark_gray>|</dark_gray> Level <yellow>" + f.level() + "</yellow> <dark_gray>|</dark_gray> <white>" + f.members().size() + "</white> members"));
        }
    }

    private void handleTop(Player player) {
        var sorted = factions.allFactions().stream()
                .sorted((a, b) -> Integer.compare(b.level(), a.level()))
                .limit(10)
                .toList();
        if (sorted.isEmpty()) {
            player.sendMessage(TextUtil.parse("<gray>No factions yet.</gray>"));
            return;
        }
        player.sendMessage(TextUtil.parse("<gold><bold>Top Factions</bold></gold>"));
        int i = 1;
        for (var f : sorted) {
            player.sendMessage(TextUtil.parse("<gray>" + i++ + ". <white>" + f.displayName() + "</white> <dark_gray>|</dark_gray> Level <yellow>" + f.level() + "</yellow> <dark_gray>|</dark_gray> <light_purple>" + f.totalShardsEarned() + " earned</light_purple>"));
        }
    }

    private void handleGui(Player player, String[] args) {
        if (!player.hasPermission("unstable.admin")) {
            player.sendMessage(TextUtil.parse("<red>No permission.</red>"));
            return;
        }
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /faction gui <player>"));
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            player.sendMessage(TextUtil.parse("<red>Player not found.</red>"));
            return;
        }
        selectionManager.forceOpenGUI(target);
        player.sendMessage(TextUtil.parse("<green>Opened faction selection GUI for " + target.getName() + ".</green>"));
    }

    private void handleWar(Player player, String[] args) {
        var opt = factions.getFaction(player);
        if (opt.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>You are not in a faction.</red>"));
            return;
        }
        var f = opt.get();
        boolean isLeader = f.members().stream()
                .anyMatch(m -> m.uuid().equals(player.getUniqueId()) && m.role() == Faction.Role.LEADER);
        if (!isLeader) {
            player.sendMessage(TextUtil.parse("<red>Only the faction leader can declare war.</red>"));
            return;
        }
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /faction war <faction></red>"));
            return;
        }
        String targetName = args[1];
        var targetOpt = factions.getFaction(targetName);
        if (targetOpt.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>Faction not found.</red>"));
            return;
        }
        String myName = f.name();
        String targetFaction = targetOpt.get().name();
        if (myName.equals(targetFaction)) {
            player.sendMessage(TextUtil.parse("<red>You cannot declare war on your own faction.</red>"));
            return;
        }
        if (factions.getActiveWarFor(myName) != null) {
            player.sendMessage(TextUtil.parse("<red>Your faction is already at war!</red>"));
            return;
        }
        if (factions.getActiveWarFor(targetFaction) != null) {
            player.sendMessage(TextUtil.parse("<red>That faction is already at war with someone else.</red>"));
            return;
        }
        long cd = factions.warCooldownRemaining(myName, targetFaction);
        if (cd > 0) {
            player.sendMessage(TextUtil.parse("<red>War is on cooldown! " + (cd / 1000) + "s remaining.</red>"));
            return;
        }
        factions.startWar(myName, targetFaction, player);
    }

    private void handleAdmin(Player player, String[] args) {
        if (!player.hasPermission("unstable.admin")) {
            player.sendMessage(TextUtil.parse("<red>No permission.</red>"));
            return;
        }
        if (args.length >= 2 && args[1].equalsIgnoreCase("reload")) {
            factions.loadAll();
            player.sendMessage(TextUtil.parse("<green>Factions reloaded.</green>"));
        }
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            List<String> subs = new ArrayList<>(List.of("info", "list", "top", "war"));
            if (player.hasPermission("unstable.admin")) {
                subs.add("gui");
                subs.add("admin");
            }
            return filter(subs, args[0]);
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2) {
            if (sub.equals("info") || sub.equals("war")) {
                return filter(factions.factionNames(), args[1]);
            }
            if (sub.equals("gui") && player.hasPermission("unstable.admin")) {
                return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[1]);
            }
            if (sub.equals("admin")) return List.of("reload");
        }
        return Collections.emptyList();
    }

    @Override
    protected String permission() {
        return null;
    }
}
