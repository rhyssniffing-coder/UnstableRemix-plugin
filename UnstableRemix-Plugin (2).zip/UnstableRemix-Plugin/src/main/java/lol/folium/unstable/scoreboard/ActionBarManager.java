package lol.folium.unstable.scoreboard;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.ffa.FFAWeaponManager;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;



public final class ActionBarManager implements org.bukkit.event.Listener {

    private final UnstableRemixPlugin plugin;
    private BukkitTask task;
    private boolean enabled;
    private FFAWeaponManager weaponManager;

    public ActionBarManager(UnstableRemixPlugin plugin) {
        this.plugin = plugin;
    }

    public void setWeaponManager(FFAWeaponManager weaponManager) {
        this.weaponManager = weaponManager;
    }

    public void start() {
        enabled = plugin.getConfig().getBoolean("action-bar.enabled", true);
        if (!enabled) return;

        int interval = plugin.getConfig().getInt("action-bar.update-interval-ticks", 20);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 0L, interval);
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    public void stop() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    private void tick() {
        if (weaponManager != null) {
            weaponManager.tickCooldowns();
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendActionBar(TextUtil.parse(resolve(player)));
        }
    }

    private String resolve(Player player) {
        String parts = resolveStreak(player) + " <dark_gray>\u23D0</dark_gray> " + resolveMultiplier(player);
        String combat = resolveCombat(player);
        if (!combat.isEmpty()) {
            parts += " <dark_gray>\u23D0</dark_gray> " + combat;
        }
        String booster = resolveBooster(player);
        if (!booster.isEmpty()) {
            parts += " <dark_gray>\u23D0</dark_gray> " + booster;
        }
        String weapons = resolveWeapons(player);
        if (!weapons.isEmpty()) {
            parts += " <dark_gray>\u23D0</dark_gray> " + weapons;
        }
        return "<gradient:#FF4444:#FF8800><bold>\u2694</bold></gradient> " + parts;
    }

    @org.bukkit.event.EventHandler
    public void onJoin(org.bukkit.event.player.PlayerJoinEvent event) {
        if (!enabled) return;
        event.getPlayer().sendActionBar(TextUtil.parse(resolve(event.getPlayer())));
    }

    private String resolveStreak(Player player) {
        if (plugin.getQuestService() == null) return "0";
        int streak = plugin.getQuestService().activeKillstreak(player);
        if (streak >= 30) return "<gradient:#FF4444:#FF8800><bold>" + streak + "</bold></gradient>";
        if (streak >= 10) return "<gradient:#FFAA00:#FFFF00>" + streak + "</gradient>";
        if (streak >= 5) return "<yellow>" + streak + "</yellow>";
        return "<gray>" + streak + "</gray>";
    }

    private String resolveMultiplier(Player player) {
        double mult = 1.0;
        if (plugin.getQuestService() != null) {
            int streak = plugin.getQuestService().activeKillstreak(player);
            mult = 1.0D + (streak / 3) * 0.1D;
            mult = Math.min(2.0D, mult);
        }
        String formatted = String.format("%.1fx", mult);
        if (mult >= 2.0) return "<gradient:#FF4444:#FF8800><bold>" + formatted + "</bold></gradient>";
        if (mult >= 1.5) return "<gradient:#FFAA00:#FFFF00>" + formatted + "</gradient>";
        if (mult > 1.0) return "<yellow>" + formatted + "</yellow>";
        return "<gray>" + formatted + "</gray>";
    }

    private String resolveCombat(Player player) {
        if (plugin.getCombatTagManager() == null) return "";
        return plugin.getCombatTagManager().combatBar(player);
    }

    private String resolveBooster(Player player) {
        if (plugin.getKitCooldownManager() == null) return "";
        lol.folium.unstable.cooldown.KitCooldownManager cd = plugin.getKitCooldownManager();
        java.util.UUID uuid = player.getUniqueId();
        String result = "";
        if (cd.hasShardBoost(uuid)) {
            result += "<gradient:#FFD700:#FF8C00><bold>2x Shards</bold></gradient>";
        }
        if (cd.hasBypass(uuid)) {
            if (!result.isEmpty()) result += " <dark_gray>|</dark_gray> ";
            result += "<gradient:#00FF88:#00CCFF><bold>No CD</bold></gradient>";
        }
        if (cd.hasFireworkBypass(uuid)) {
            if (!result.isEmpty()) result += " <dark_gray>|</dark_gray> ";
            result += "<gradient:#FF69B4:#FF1493><bold>No FW CD</bold></gradient>";
        }
        return result;
    }

    private String resolveWeapons(Player player) {
        if (weaponManager == null) return "";
        return weaponManager.getWeaponCooldownBar(player.getUniqueId());
    }
}
