package lol.folium.unstable.integration;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.map.Arena;
import lol.folium.unstable.map.ArenaManager;
import lol.folium.unstable.map.MapVoteManager;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MapNpcListener implements Listener {

    private static final Component JOIN_TITLE = Component.text("Enter Map", NamedTextColor.GOLD, TextDecoration.BOLD);
    private static final Component PERM_JOIN_TITLE = Component.text("No-Mace & No-Elytra Arena", NamedTextColor.AQUA, TextDecoration.BOLD);

    private final UnstableRemixPlugin plugin;
    private final ArenaManager arenas;
    private final CitizensHook citizens;
    private final MapVoteManager mapVotes;
    private final Map<UUID, Long> joinCooldowns = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> pendingTeleport = new ConcurrentHashMap<>();
    private final Map<UUID, String> pendingPermanentJoin = new ConcurrentHashMap<>();

    public MapNpcListener(UnstableRemixPlugin plugin, ArenaManager arenas, CitizensHook citizens, MapVoteManager mapVotes) {
        this.plugin = plugin;
        this.arenas = arenas;
        this.citizens = citizens;
        this.mapVotes = mapVotes;

        // Register NPC click handler via CitizensHook
        citizens.setNpcClickHandler(this::handleNpcClick);
    }

    private void handleNpcClick(Player player, String arenaName) {
        // Permanent arena NPCs open a direct join GUI
        Arena arena = arenas.getArena(arenaName);
        if (arena != null && arena.isPermanent()) {
            openPermanentArenaJoinGui(player, arena);
            return;
        }

        openJoinGui(player);
    }

    @EventHandler
    public void onEntityInteract(PlayerInteractEntityEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!citizens.isAvailable()) return;

        // Fallback: try to detect NPC via reflection if CitizensHook click handler didn't fire
        Player player = event.getPlayer();
        int npcId = citizens.getNpcId(event.getRightClicked());
        if (npcId < 0) return;

        String arenaName = citizens.getArenaForNpc(npcId);
        if (arenaName == null) return;

        handleNpcClick(player, arenaName);
    }

    private void openPermanentArenaJoinGui(Player player, Arena arena) {
        int playerCount = arena.players().size();
        String arenaStatus = arena.status() == Arena.Status.IN_GAME ? "\u00A7cIn Game" : "\u00A7aIdle";

        Inventory inv = Bukkit.createInventory(null, 27, PERM_JOIN_TITLE);

        // Fill with cyan stained glass
        ItemStack filler = new ItemStack(Material.CYAN_STAINED_GLASS_PANE);
        var fillerMeta = filler.getItemMeta();
        fillerMeta.displayName(Component.empty());
        filler.setItemMeta(fillerMeta);
        for (int i = 0; i < 27; i++) {
            inv.setItem(i, filler);
        }

        ItemStack clock = new ItemStack(Material.CLOCK);
        var clockMeta = clock.getItemMeta();
        clockMeta.displayName(TextUtil.parse("<aqua><bold>No-Mace & No-Elytra Arena</bold></aqua>"));
        java.util.List<Component> lore = new java.util.ArrayList<>();
        lore.add(TextUtil.parse("<gray>Maces and elytras are <red>disabled</red> in this arena.</gray>"));
        lore.add(TextUtil.parse("<gray>Balanced PvP without dive-bomb or rocket mace.</gray>"));
        lore.add(TextUtil.parse(""));
        lore.add(TextUtil.parse("<gray>Status: " + arenaStatus));
        lore.add(TextUtil.parse("<gray>Players: <aqua>" + playerCount + "</aqua>"));
        lore.add(TextUtil.parse(""));
        lore.add(TextUtil.parse("<green>Click to join in 3 seconds!"));
        clockMeta.lore(lore);
        clock.setItemMeta(clockMeta);
        inv.setItem(13, clock);

        inv.setItem(11, ItemBuilder.of(Material.SHIELD)
                .name(TextUtil.parse("<yellow><bold>Arena Rules</bold></yellow>"))
                .lore(java.util.List.of(
                        TextUtil.parse("<red>No elytras</red>"),
                        TextUtil.parse("<red>No maces</red>"),
                        TextUtil.parse("<gray>Everything else is allowed</gray>")
                ))
                .build());

        inv.setItem(15, ItemBuilder.of(Material.MAP)
                .name(TextUtil.parse("<aqua><bold>View Arena Info</bold></aqua>"))
                .lore(java.util.List.of(
                        TextUtil.parse("<gray>Arena: <white>" + arena.displayName() + "</white></gray>"),
                        TextUtil.parse("<gray>Mode: <green>FFA</green></gray>"),
                        TextUtil.parse("<gray>Spawns: <aqua>" + arena.spawns().size() + "</aqua></gray>")
                ))
                .build());

        player.openInventory(inv);
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
    }

    private void startPermanentJoinCountdown(Player player, String arenaName) {
        long now = System.currentTimeMillis();
        Long lastJoin = joinCooldowns.get(player.getUniqueId());
        if (lastJoin != null && now - lastJoin < 3000) {
            long remaining = (3000 - (now - lastJoin)) / 1000 + 1;
            player.sendMessage(TextUtil.parse("<red>Please wait <yellow>" + remaining + "s</yellow> before joining again.</red>"));
            return;
        }

        if (pendingPermanentJoin.containsKey(player.getUniqueId())) return;

        Arena arena = arenas.getArena(arenaName);
        if (arena == null || !arena.isEnabled()) {
            player.sendMessage(TextUtil.parse("<red>The arena is not available.</red>"));
            return;
        }

        pendingPermanentJoin.put(player.getUniqueId(), arenaName);

        new BukkitRunnable() {
            int remaining = 3;

            @Override
            public void run() {
                if (!player.isOnline() || !pendingPermanentJoin.containsKey(player.getUniqueId())) {
                    pendingPermanentJoin.remove(player.getUniqueId());
                    cancel();
                    return;
                }

                if (remaining > 0) {
                    Component msg = Component.text("Joining " + arena.displayName() + " in " + remaining + "...", NamedTextColor.AQUA, TextDecoration.BOLD);
                    player.sendActionBar(msg);
                    player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5F, 1.0F);
                    remaining--;
                } else {
                    pendingPermanentJoin.remove(player.getUniqueId());
                    joinCooldowns.put(player.getUniqueId(), System.currentTimeMillis());
                    java.util.List<org.bukkit.Location> spawns = arena.spawns();
                    if (!spawns.isEmpty()) {
                        org.bukkit.Location randomSpawn = spawns.get(new java.util.Random().nextInt(spawns.size()));
                        player.teleport(randomSpawn);
                    } else if (arena.lobby() != null) {
                        player.teleport(arena.lobby());
                    }
                    player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0F, 1.0F);
                    player.sendMessage(TextUtil.parse("<green>Teleported to <white>" + arena.displayName() + "</white>!</green>"));
                    player.sendMessage(TextUtil.parse("<gray>Maces and elytras are disabled in this arena.</gray>"));
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private void openJoinGui(Player player) {
        String pending = mapVotes.pendingArenaName();
        String activeName = mapVotes.activeArenaName();
        String joinTarget = pending.isEmpty() ? activeName : pending;

        Arena arena = arenas.get(joinTarget).orElse(null);
        String displayName = arena != null ? arena.displayName() : (joinTarget.equals("None") ? "No map voted" : joinTarget);
        int playerCount = arena != null ? arena.players().size() : 0;
        String arenaStatus = arena != null ? (arena.status() == Arena.Status.IN_GAME ? "\u00A7cIn Game" : "\u00A7aIdle") : "\u00A77Unknown";

        String votedFor = mapVotes.getVotedOption(player.getUniqueId());
        String votedDisplayName = votedFor != null && mapVotes.getVoteOptions().containsKey(votedFor)
                ? mapVotes.getVoteOptions().get(votedFor).displayName() : null;
        boolean hasVoted = votedDisplayName != null;

        Inventory inv = Bukkit.createInventory(null, 27, JOIN_TITLE);

        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        var fillerMeta = filler.getItemMeta();
        fillerMeta.displayName(Component.empty());
        filler.setItemMeta(fillerMeta);
        for (int i = 0; i < 27; i++) {
            inv.setItem(i, filler);
        }

        ItemStack clock = new ItemStack(Material.CLOCK);
        var clockMeta = clock.getItemMeta();
        clockMeta.displayName(TextUtil.parse("<gold><bold>Join Map</bold></gold>"));
        java.util.List<Component> lore = new java.util.ArrayList<>();
        lore.add(TextUtil.parse("<gray>Current map: <white>" + displayName + "</white>"));
        lore.add(TextUtil.parse("<gray>Status: " + arenaStatus));
        lore.add(TextUtil.parse("<gray>Players: <aqua>" + playerCount + "</aqua>"));
        if (!pending.isEmpty() && !pending.equals(activeName)) {
            String pendingDisplay = arenas.get(pending).map(Arena::displayName).orElse(pending);
            lore.add(TextUtil.parse("<gray>Next map: <aqua>" + pendingDisplay + "</aqua>"));
        }
        if (hasVoted) {
            lore.add(TextUtil.parse("<gray>You voted: <green>" + votedDisplayName + "</green>"));
        }
        lore.add(TextUtil.parse(""));
        lore.add(TextUtil.parse("<green>Click to join in 3 seconds!"));
        clockMeta.lore(lore);
        clock.setItemMeta(clockMeta);
        inv.setItem(13, clock);

        inv.setItem(11, ItemBuilder.of(Material.NETHER_STAR)
                .name(TextUtil.parse("<yellow><bold>Queue Priority</bold></yellow>"))
                .lore(java.util.List.of(
                        TextUtil.parse("<gray>Your shard count affects</gray>"),
                        TextUtil.parse("<gray>join priority during busy times.</gray>")
                ))
                .build());

        inv.setItem(15, ItemBuilder.of(Material.MAP)
                .name(TextUtil.parse("<aqua><bold>View Map Info</bold></aqua>"))
                .lore(java.util.List.of(
                        TextUtil.parse("<gray>Arena: <white>" + displayName + "</white></gray>"),
                        TextUtil.parse("<gray>Mode: <green>FFA</green></gray>"),
                        TextUtil.parse("<gray>Spawns: <aqua>" + (arena != null ? arena.spawns().size() : 0) + "</aqua></gray>")
                ))
                .build());

        player.openInventory(inv);
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
    }

    private void startJoinCountdown(Player player) {
        long now = System.currentTimeMillis();
        Long lastJoin = joinCooldowns.get(player.getUniqueId());
        if (lastJoin != null && now - lastJoin < 3000) {
            long remaining = (3000 - (now - lastJoin)) / 1000 + 1;
            player.sendMessage(TextUtil.parse("<red>Please wait <yellow>" + remaining + "s</yellow> before joining again.</red>"));
            return;
        }

        if (pendingTeleport.containsKey(player.getUniqueId())) return;

        String pending = mapVotes.pendingArenaName();
        String activeName = mapVotes.activeArenaName();
        String targetName = pending.isEmpty() ? activeName : pending;
        if (targetName.equals("None") || targetName.isEmpty()) {
            player.sendMessage(TextUtil.parse("<red>No map has been voted in yet.</red>"));
            return;
        }

        Arena arena = arenas.get(targetName).orElse(null);
        if (arena == null || !arena.isEnabled()) {
            player.sendMessage(TextUtil.parse("<red>The current map is not available.</red>"));
            return;
        }

        pendingTeleport.put(player.getUniqueId(), true);

        new BukkitRunnable() {
            int remaining = 3;

            @Override
            public void run() {
                if (!player.isOnline() || !pendingTeleport.containsKey(player.getUniqueId())) {
                    pendingTeleport.remove(player.getUniqueId());
                    cancel();
                    return;
                }

                if (remaining > 0) {
                    Component msg = Component.text("Joining " + arena.displayName() + " in " + remaining + "...", NamedTextColor.AQUA, TextDecoration.BOLD);
                    player.sendActionBar(msg);
                    player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5F, 1.0F);
                    remaining--;
                } else {
                    pendingTeleport.remove(player.getUniqueId());
                    joinCooldowns.put(player.getUniqueId(), System.currentTimeMillis());
                    java.util.List<org.bukkit.Location> spawns = arena.spawns();
                    if (!spawns.isEmpty()) {
                        org.bukkit.Location randomSpawn = spawns.get(new java.util.Random().nextInt(spawns.size()));
                        player.teleport(randomSpawn);
                    } else if (arena.lobby() != null) {
                        player.teleport(arena.lobby());
                    }
                    player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0F, 1.0F);
                    player.sendMessage(TextUtil.parse("<green>Teleported to <white>" + arena.displayName() + "</white>!</green>"));
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    public final class JoinGuiListener implements Listener {

        @EventHandler
        public void onInventoryClick(InventoryClickEvent event) {
            if (!(event.getWhoClicked() instanceof Player player)) return;
            if (event.getView().title() == null) return;

            boolean isPermTitle = event.getView().title().equals(PERM_JOIN_TITLE);
            boolean isJoinTitle = event.getView().title().equals(JOIN_TITLE);
            if (!isJoinTitle && !isPermTitle) return;

            event.setCancelled(true);

            int slot = event.getRawSlot();

            if (isPermTitle) {
                if (slot == 13) {
                    player.closeInventory();
                    // Find the permanent arena name
                    String arenaName = pendingPermanentJoin.get(player.getUniqueId());
                    if (arenaName == null) {
                        // Find first permanent arena
                        for (String name : arenas.names()) {
                            Arena a = arenas.getArena(name);
                            if (a != null && a.isPermanent()) {
                                arenaName = name;
                                break;
                            }
                        }
                    }
                    if (arenaName != null) {
                        startPermanentJoinCountdown(player, arenaName);
                    }
                } else if (slot == 11) {
                    player.closeInventory();
                    player.sendMessage(TextUtil.parse("<aqua><bold>ARENA RULES</bold></aqua>"));
                    player.sendMessage(TextUtil.parse("<red>No elytras</red>"));
                    player.sendMessage(TextUtil.parse("<red>No maces</red>"));
                    player.sendMessage(TextUtil.parse("<gray>Everything else is allowed.</gray>"));
                } else if (slot == 15) {
                    // Find permanent arena info
                    for (String name : arenas.names()) {
                        Arena a = arenas.getArena(name);
                        if (a != null && a.isPermanent()) {
                            player.closeInventory();
                            player.sendMessage(TextUtil.parse("<aqua><bold>ARENA INFO</bold></aqua>"));
                            player.sendMessage(TextUtil.parse("<gray>Arena: <white>" + a.displayName() + "</white></gray>"));
                            player.sendMessage(TextUtil.parse("<gray>Mode: <green>FFA</green></gray>"));
                            player.sendMessage(TextUtil.parse("<gray>Players: <aqua>" + a.players().size() + "</aqua></gray>"));
                            player.sendMessage(TextUtil.parse("<gray>Spawns: <aqua>" + a.spawns().size() + "</aqua></gray>"));
                            break;
                        }
                    }
                }
                return;
            }

            // Regular join GUI
            if (slot == 13) {
                player.closeInventory();
                startJoinCountdown(player);
            } else if (slot == 11) {
                player.closeInventory();
                player.sendMessage(TextUtil.parse("<yellow><bold>QUEUE PRIORITY</bold></yellow>"));
                player.sendMessage(TextUtil.parse("<gray>Your shard count affects join priority during busy times.</gray>"));
                player.sendMessage(TextUtil.parse("<gray>Current balance: <light_purple>" + plugin.getEconomyService().getShards(player.getUniqueId()) + " Shards</light_purple></gray>"));
            } else if (slot == 15) {
                String activeName = mapVotes.activeArenaName();
                Arena arena = arenas.get(activeName).orElse(null);
                if (arena != null) {
                    player.closeInventory();
                    player.sendMessage(TextUtil.parse("<aqua><bold>MAP INFO</bold></aqua>"));
                    player.sendMessage(TextUtil.parse("<gray>Arena: <white>" + arena.displayName() + "</white></gray>"));
                    player.sendMessage(TextUtil.parse("<gray>Mode: <green>" + arena.teamSpawnMode() + "</green></gray>"));
                    player.sendMessage(TextUtil.parse("<gray>Players: <aqua>" + arena.players().size() + "</aqua></gray>"));
                    player.sendMessage(TextUtil.parse("<gray>Spawns: <aqua>" + arena.spawns().size() + "</aqua></gray>"));
                    player.sendMessage(TextUtil.parse("<gray>Status: " + (arena.status() == Arena.Status.IN_GAME ? "<red>In Game</red>" : "<green>Idle</green>")));
                }
            }
        }

        @EventHandler
        public void onDrag(InventoryDragEvent event) {
            if (event.getView().getTitle() == null) return;
            String title = event.getView().getTitle();
            if (title.equals(JOIN_TITLE) || title.equals(PERM_JOIN_TITLE)) {
                event.setCancelled(true);
            }
        }
    }
}
