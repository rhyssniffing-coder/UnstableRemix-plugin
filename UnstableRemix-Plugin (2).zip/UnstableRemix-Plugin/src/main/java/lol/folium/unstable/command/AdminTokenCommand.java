package lol.folium.unstable.command;

import lol.folium.unstable.economy.CurrencyType;
import lol.folium.unstable.economy.EconomyService;
import lol.folium.unstable.economy.TransactionResult;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class AdminTokenCommand implements CommandExecutor, TabCompleter {

    private final EconomyService economy;

    public AdminTokenCommand(EconomyService economy) {
        this.economy = economy;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("unstable.economy.admin")) {
            sender.sendMessage(TextUtil.parse("<red>No permission."));
            return true;
        }
        if (args.length < 3) {
            sender.sendMessage(TextUtil.parse("<yellow>/admintoken <give|remove|set> <player> <amount>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(TextUtil.parse("<red>Player not found."));
            return true;
        }
        Long amount = parseAmount(args[2], args[0].equalsIgnoreCase("set"));
        if (amount == null) {
            sender.sendMessage(TextUtil.parse("<red>Enter a valid whole number."));
            return true;
        }
        TransactionResult result = switch (args[0].toLowerCase(Locale.ROOT)) {
            case "give" -> economy.grantTokens(target.getUniqueId(), amount, "admin:" + sender.getName(), null);
            case "remove" -> economy.removeTokens(target.getUniqueId(), amount, "admin:" + sender.getName());
            case "set" -> economy.setTokens(target.getUniqueId(), amount, "admin:" + sender.getName());
            default -> TransactionResult.fail("invalid-subcommand", economy.getTokens(target.getUniqueId()));
        };
        if (!result.success()) {
            sender.sendMessage(TextUtil.parse("<red>Transaction failed: " + result.messageKey()));
            return true;
        }
        if (sender instanceof Player admin) {
            admin.playSound(admin.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.2F);
        }
        sender.sendMessage(TextUtil.parse("<green>Updated <white>" + target.getName() + "</white> tokens to <gold>"
                + result.balanceAfter() + " Tokens</gold>."));
        economy.notifyGrant(target, CurrencyType.TOKENS, amount,
                args[0].equalsIgnoreCase("set") ? "Admin Set" : "Admin " + args[0].substring(0, 1).toUpperCase() + args[0].substring(1));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("unstable.economy.admin")) {
            return Collections.emptyList();
        }
        if (args.length == 1) {
            return filter(List.of("give", "remove", "set"), args[0]);
        }
        if (args.length == 2) {
            return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[1]);
        }
        if (args.length == 3) {
            return List.of("100", "500", "1000");
        }
        return Collections.emptyList();
    }

    private Long parseAmount(String raw, boolean allowZero) {
        try {
            long amount = Long.parseLong(raw);
            return amount > 0 || (allowZero && amount == 0) ? amount : null;
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private List<String> filter(List<String> options, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        return options.stream().filter(option -> option.toLowerCase(Locale.ROOT).startsWith(lower)).toList();
    }
}