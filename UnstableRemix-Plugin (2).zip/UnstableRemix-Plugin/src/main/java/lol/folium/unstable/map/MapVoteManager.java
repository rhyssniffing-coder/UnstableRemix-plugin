package lol.folium.unstable.map;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.config.ConfigManager;
import lol.folium.unstable.util.ConfigItems;
import lol.folium.unstable.util.GuiHolder;
import lol.folium.unstable.util.ItemBuilder;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MapVoteManager {

    private static final List<Integer> DEFAULT_OPTION_SLOTS = List.of(20, 21, 22, 23, 24);

    private final UnstableRemixPlugin plugin;
    private final ConfigManager configs;
    private final ArenaManager arenaManager;
    private final Map<UUID, String> votes = new ConcurrentHashMap<>();
    private final Map<String, MapVoteOption> voteOptions = new LinkedHashMap<>();
    private int endTaskId = -1;
    private int scheduleTaskId = -1;
    private int doubleShardsTaskId = -1;
    private int voteStartTaskId = -1;
    private boolean votingActive = false;
    private boolean doubleShardsActive = false;
    private double doubleShardsMultiplier = 2.0;
    private int voteDurationSeconds = 60;
    private int mapChangeIntervalMinutes = 60;
    private long nextVoteAtMillis = 0L;
    private long voteEndsAtMillis = 0L;
    private String activeArenaName = "";
    private String pendingArenaName = "";

    public MapVoteManager(UnstableRemixPlugin plugin, ConfigManager configs, ArenaManager arenaManager) {
        this.plugin = plugin;
        this.configs = configs;
        this.arenaManager = arenaManager;
        loadVoteOptions();
    }

    public void loadVoteOptions() {
        voteOptions.clear();
        ConfigurationSection section = configs.main().getConfigurationSection("map-vote.options");
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            ConfigurationSection option = section.getConfigurationSection(key);
            if (option == null) {
                continue;
            }
            String arenaName = option.getString("arena");
            // Skip permanent arenas (no-mace zone, etc.) — they're accessed via NPC, not voting
            Arena arena = arenaManager.getArena(arenaName);
            if (arena != null && arena.isPermanent()) {
                continue;
            }
            String displayName = option.getString("display-name", arenaName);
            Material material = Material.matchMaterial(option.getString("material", "GRASS_BLOCK"));
            if (material == null) {
                material = Material.GRASS_BLOCK;
            }
            voteOptions.put(key, new MapVoteOption(key, arenaName, displayName, material));
        }
    }

    private int countdownTaskId = -1;

    public void startVoting() {
        if (votingActive) {
            return;
        }
        cancelEndTask();
        loadVoteOptions();
        if (voteOptions.isEmpty()) {
            Bukkit.broadcast(TextUtil.parse("<red>Map vote could not start: no vote options configured."));
            return;
        }
        votingActive = true;
        votes.clear();
        voteEndsAtMillis = System.currentTimeMillis() + voteDurationSeconds * 1000L;
        nextVoteAtMillis = voteEndsAtMillis;
        broadcastVoteGUI();
        endTaskId = Bukkit.getScheduler().runTaskLater(plugin, this::endVoting, voteDurationSeconds * 20L).getTaskId();
        startCountdownDisplay();
    }

    private void startCountdownDisplay() {
        cancelTask(countdownTaskId);
        countdownTaskId = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!votingActive) {
                cancelTask(countdownTaskId);
                return;
            }
            long remaining = Math.max(0, (voteEndsAtMillis - System.currentTimeMillis()) / 1000);
            String timeStr = String.format("%d:%02d", remaining / 60, remaining % 60);
            String bar = generateCountBar(remaining, voteDurationSeconds);
            for (Player player : Bukkit.getOnlinePlayers()) {
                player.sendActionBar(net.kyori.adventure.text.Component.text(
                        "\u25C6 Map Vote: " + timeStr + " \u25C6 " + totalVotes() + " vote(s) " + bar,
                        net.kyori.adventure.text.format.NamedTextColor.GOLD
                ));
            }
            if (remaining <= 10 && remaining > 0) {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.3F, 1.2F);
                }
            }
        }, 0L, 20L).getTaskId();
    }

    private String generateCountBar(long remaining, long total) {
        int segments = 20;
        int filled = (int) ((remaining * segments) / total);
        StringBuilder bar = new StringBuilder("\u00A77[");
        for (int i = 0; i < segments; i++) {
            if (i < filled) {
                bar.append("\u00A7a\u2588");
            } else {
                bar.append("\u00A78\u2588");
            }
        }
        bar.append("\u00A77]");
        return bar.toString();
    }

    private void cancelEndTask() {
        if (endTaskId != -1) {
            Bukkit.getScheduler().cancelTask(endTaskId);
            endTaskId = -1;
        }
    }

    private void broadcastVoteGUI() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            openVoteGUI(player);
        }
        Bukkit.broadcast(TextUtil.parse(configs.main().getString("map-vote.messages.started",
                "<yellow><bold>Map Vote Started!</bold></yellow> <gray>Vote for the next map!</gray>")));
    }

    public void openVoteGUI(Player player) {
        if (!votingActive) {
            player.sendMessage(TextUtil.parse(configs.main().getString("map-vote.messages.inactive",
                    "<red>No vote is currently active.")));
            return;
        }
        ConfigurationSection gui = configs.main().getConfigurationSection("map-vote.gui");
        int rows = gui == null ? 5 : gui.getInt("rows", 5);
        rows = Math.max(1, Math.min(6, rows));
        MapVoteGui holder = new MapVoteGui(player);
        Inventory inventory = Bukkit.createInventory(holder, rows * 9,
                TextUtil.parse(gui == null ? "<gradient:#FF4444:#FF8800:#FFD700><bold>ARENA VOTE</bold></gradient>" :
                        gui.getString("title", "<gradient:#FF4444:#FF8800:#FFD700><bold>ARENA VOTE</bold></gradient>")));
        holder.bind(inventory);
        paintFrame(inventory, gui);
        paintTitle(inventory, gui);
        paintOptions(player, inventory, holder, gui);
        player.openInventory(inventory);
    }

    public void handleVote(Player player, String optionId) {
        if (!votingActive || !voteOptions.containsKey(optionId)) {
            return;
        }
        votes.put(player.getUniqueId(), optionId);
        player.playSound(player.getLocation(), configuredSound("map-vote.sounds.click", Sound.UI_BUTTON_CLICK), 1.0F, 1.0F);
        player.sendMessage(TextUtil.parse(TextUtil.apply(configs.main().getString("map-vote.messages.voted",
                "<green>Voted for <white>{map}</white>!"), Map.of("map", voteOptions.get(optionId).displayName()))));
        player.closeInventory();
        refreshOpenVoteGuis();
    }

    private void refreshOpenVoteGuis() {
        Bukkit.getScheduler().runTask(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getOpenInventory().getTopInventory().getHolder() instanceof MapVoteGui) {
                    openVoteGUI(player);
                }
            }
        });
    }

    private void endVoting() {
        if (!votingActive) {
            return;
        }
        votingActive = false;
        voteEndsAtMillis = 0L;
        endTaskId = -1;
        cancelTask(countdownTaskId);
        countdownTaskId = -1;

        String winner = determineWinner();
        if (winner != null) {
            MapVoteOption winningOption = voteOptions.get(winner);
            String targetArena = winningOption.arenaName();
            Bukkit.broadcast(TextUtil.parse(TextUtil.apply(configs.main().getString("map-vote.messages.ended",
                    "<green><bold>\u2714 Vote Ended!</bold></green> <gray>Winner: <white>{map}</white> — changing map now!</gray>"),
                    Map.of("map", winningOption.displayName()))));
            votes.clear();
            forceMapChange(targetArena);
        } else {
            Bukkit.broadcast(TextUtil.parse(configs.main().getString("map-vote.messages.no-votes",
                    "<red>No votes were cast. Map will keep current arena.")));
            votes.clear();
            nextVoteAtMillis = System.currentTimeMillis() + mapChangeIntervalMinutes * 60L * 1000L;
        }
    }

    private String determineWinner() {
        if (votes.isEmpty()) {
            return null;
        }
        Map<String, Integer> counts = new HashMap<>();
        for (String vote : votes.values()) {
            counts.put(vote, counts.getOrDefault(vote, 0) + 1);
        }
        return counts.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
    }

    public void forceMapChange(String arenaName) {
        doubleShardsActive = false;
        doubleShardsMultiplier = 2.0;
        if (doubleShardsTaskId != -1) {
            Bukkit.getScheduler().cancelTask(doubleShardsTaskId);
            doubleShardsTaskId = -1;
        }
        nextVoteAtMillis = System.currentTimeMillis() + mapChangeIntervalMinutes * 60L * 1000L;
        arenaManager.get(arenaName).ifPresentOrElse(arena -> {
            activeArenaName = arena.name();
            org.bukkit.Location lobby = configs.readLobby();
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (lobby != null) {
                    player.teleport(lobby);
                } else if (arena.lobby() != null) {
                    player.teleport(arena.lobby());
                }
                player.sendTitlePart(net.kyori.adventure.title.TitlePart.TITLE,
                        TextUtil.parse("<gradient:#FFD700:#FFA500><bold>" + arena.displayName() + "</bold></gradient>"));
                player.sendTitlePart(net.kyori.adventure.title.TitlePart.SUBTITLE,
                        TextUtil.parse("<gray>New map loaded!</gray>"));
                player.sendTitlePart(net.kyori.adventure.title.TitlePart.TIMES,
                        net.kyori.adventure.title.Title.Times.times(
                                java.time.Duration.ofMillis(500),
                                java.time.Duration.ofSeconds(3),
                                java.time.Duration.ofMillis(1000)));
                player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5F, 1.2F);
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.3F, 1.5F);
                spawnMapChangeParticles(player);
            }

            arenaManager.all().forEach(a -> {
                a.setStatus(Arena.Status.IDLE);
                a.players().clear();
            });

            Bukkit.broadcast(TextUtil.parse("<gradient:#FFD700:#FFA500><bold>MAP CHANGE</bold></gradient> <gray>All players sent to</gray> <white>" + arena.displayName() + "</white> <gray>lobby.</gray>"));
        }, () -> Bukkit.broadcast(TextUtil.parse("<red>Failed to change map: Arena not found.")));
    }

    private void spawnMapChangeParticles(Player player) {
        try {
            player.spawnParticle(org.bukkit.Particle.FIREWORK, player.getLocation().add(0, 1, 0), 30, 0.5, 0.5, 0.5, 0.1);
            player.spawnParticle(org.bukkit.Particle.ENCHANT, player.getLocation().add(0, 2, 0), 50, 1, 1, 1, 0.5);
        } catch (Exception ignored) {
        }
    }

    public void startAutomaticSchedule() {
        stopAutomaticSchedule();
        mapChangeIntervalMinutes = configs.main().getInt("map-vote.interval-minutes", 60);
        voteDurationSeconds = configs.main().getInt("map-vote.vote-duration-seconds", 60);
        long intervalTicks = Math.max(1L, mapChangeIntervalMinutes) * 60L * 20L;

        var names = arenaManager.names();
        if (!names.isEmpty()) {
            pendingArenaName = names.get(0);
        }

        // Schedule events for the first interval
        if (mapChangeIntervalMinutes > 5) {
            scheduleDoubleShards();
        }
        if (mapChangeIntervalMinutes > 2) {
            scheduleVoteStart();
            nextVoteAtMillis = System.currentTimeMillis() + (mapChangeIntervalMinutes - 2) * 60 * 1000L;
        } else {
            nextVoteAtMillis = System.currentTimeMillis() + Math.max(1L, mapChangeIntervalMinutes) * 60L * 1000L;
        }

        scheduleTaskId = Bukkit.getScheduler().runTaskTimer(plugin, this::onInterval, intervalTicks, intervalTicks).getTaskId();
    }

    private void onInterval() {
        // Force-end any active vote (this also triggers map change)
        if (votingActive) {
            cancelEndTask();
            endVoting();
        } else if (!activeArenaName.isEmpty() && !activeArenaName.equals("None")) {
            // Vote already ended, just apply any pending map
            String target = pendingArenaName;
            pendingArenaName = "";
            if (!target.isEmpty() && arenaManager.exists(target)) {
                forceMapChange(target);
            }
        }
        cancelTask(voteStartTaskId);

        // Schedule events for the next interval
        nextVoteAtMillis = System.currentTimeMillis() + (mapChangeIntervalMinutes - 2) * 60 * 1000L;
        scheduleDoubleShards();
        scheduleVoteStart();
    }

    private void scheduleDoubleShards() {
        doubleShardsActive = false;
        doubleShardsMultiplier = 2.0;
        cancelTask(doubleShardsTaskId);
        long minutesUntilActivation = Math.max(0L, mapChangeIntervalMinutes - 5L);
        if (minutesUntilActivation <= 0) {
            return;
        }
        long activateInTicks = minutesUntilActivation * 60L * 20L;
        doubleShardsTaskId = Bukkit.getScheduler().runTaskLater(plugin, this::playSlotMachineAnimation, activateInTicks).getTaskId();
    }

    private void playSlotMachineAnimation() {
        String[] options = {"1.5x", "2x", "3x"};
        int totalFrames = 20;
        final int[] frame = {0};
        final int[] lastIndex = {-1};

        BukkitTask spinTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (frame[0] >= totalFrames) {
                return;
            }
            int idx = frame[0] % options.length;
            for (Player player : Bukkit.getOnlinePlayers()) {
                player.sendTitlePart(net.kyori.adventure.title.TitlePart.TITLE,
                        TextUtil.parse("<gradient:#FFD700:#FF8C00><bold>" + options[idx] + " SHARDS</bold></gradient>"));
                player.sendTitlePart(net.kyori.adventure.title.TitlePart.SUBTITLE,
                        TextUtil.parse("<gray>Rolling your bonus...</gray>"));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0F, 0.8F + (frame[0] * 0.05F));
            }
            lastIndex[0] = idx;
            frame[0]++;
        }, 0L, 2L);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            spinTask.cancel();
            rollSlotMachineResult();
        }, totalFrames * 2L + 2L);
    }

    private void rollSlotMachineResult() {
        double roll = Math.random() * 100;
        double multiplier;
        String display;
        if (roll < 1.0) {
            multiplier = 3.0;
            display = "<gradient:#FF4500:#FFD700><bold>3x SHARDS!</bold></gradient>";
        } else if (roll < 30.0) {
            multiplier = 1.5;
            display = "<gradient:#00BFFF:#1E90FF><bold>1.5x SHARDS!</bold></gradient>";
        } else {
            multiplier = 2.0;
            display = "<gradient:#FFD700:#FF8C00><bold>2x SHARDS!</bold></gradient>";
        }
        doubleShardsMultiplier = multiplier;
        doubleShardsActive = true;

        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendTitlePart(net.kyori.adventure.title.TitlePart.TITLE, TextUtil.parse(display));
            player.sendTitlePart(net.kyori.adventure.title.TitlePart.SUBTITLE,
                    TextUtil.parse("<gray>Earn <white>" + String.format("%.1f", multiplier) + "x</white> shards until the next map change!</gray>"));
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.5F);
        }
        Bukkit.broadcast(TextUtil.parse("<gradient:#FFD700:#FF8C00><bold>" + String.format("%.1f", multiplier) + "x SHARDS ACTIVE!</bold></gradient> <gray>Earn " + String.format("%.1f", multiplier) + "x shards until the next map change!</gray>"));
    }

    public double getDoubleShardsMultiplier() {
        return doubleShardsActive ? doubleShardsMultiplier : 1.0;
    }

    private void scheduleVoteStart() {
        cancelTask(voteStartTaskId);
        long minutesUntilVote = Math.max(0L, mapChangeIntervalMinutes - 2L);
        if (minutesUntilVote <= 0) {
            return;
        }
        long delayTicks = minutesUntilVote * 60L * 20L;
        voteStartTaskId = Bukkit.getScheduler().runTaskLater(plugin, this::startVoting, delayTicks).getTaskId();
    }

    private void cancelTask(int taskId) {
        if (taskId != -1) {
            Bukkit.getScheduler().cancelTask(taskId);
        }
    }

    private void stopAutomaticSchedule() {
        cancelTask(scheduleTaskId);
        scheduleTaskId = -1;
    }

    public void stop() {
        cancelTask(endTaskId);
        endTaskId = -1;
        cancelTask(doubleShardsTaskId);
        doubleShardsTaskId = -1;
        cancelTask(voteStartTaskId);
        voteStartTaskId = -1;
        cancelTask(countdownTaskId);
        countdownTaskId = -1;
        stopAutomaticSchedule();
        votingActive = false;
        doubleShardsActive = false;
        votes.clear();
    }

    public boolean isVotingActive() {
        return votingActive;
    }

    public boolean isDoubleShardsActive() {
        return doubleShardsActive;
    }

    public Map<String, MapVoteOption> getVoteOptions() {
        return new LinkedHashMap<>(voteOptions);
    }

    public int totalVotes() {
        return votes.size();
    }

    public int voteCount(String optionId) {
        return (int) votes.values().stream().filter(optionId::equals).count();
    }

    public String getVotedOption(UUID uuid) {
        return votes.get(uuid);
    }

    public UnstableRemixPlugin getPlugin() {
        return plugin;
    }

    public Duration timeUntilNextVote() {
        long target = votingActive ? voteEndsAtMillis : nextVoteAtMillis;
        if (target <= 0L) {
            return Duration.ZERO;
        }
        return Duration.ofMillis(Math.max(0L, target - System.currentTimeMillis()));
    }

    public String activeArenaName() {
        return activeArenaName == null || activeArenaName.isBlank() ? "None" : activeArenaName;
    }

    public String pendingArenaName() {
        return pendingArenaName == null || pendingArenaName.isBlank() ? "" : pendingArenaName;
    }

    public void addVoteOption(String id, String arenaName, String displayName, Material material) {
        voteOptions.put(id, new MapVoteOption(id, arenaName, displayName, material));
        saveVoteOptions();
    }

    public void removeVoteOption(String id) {
        voteOptions.remove(id);
        saveVoteOptions();
    }

    public void updateVoteOptionMaterial(String id, Material material) {
        MapVoteOption old = voteOptions.get(id);
        if (old == null) return;
        voteOptions.put(id, new MapVoteOption(id, old.arenaName(), old.displayName(), material));
        saveVoteOptions();
    }

    public void updateVoteOptionDisplayName(String id, String displayName) {
        MapVoteOption old = voteOptions.get(id);
        if (old == null) return;
        voteOptions.put(id, new MapVoteOption(id, old.arenaName(), displayName, old.material()));
        saveVoteOptions();
    }

    public void updateVoteOptionArena(String id, String arenaName) {
        MapVoteOption old = voteOptions.get(id);
        if (old == null) return;
        voteOptions.put(id, new MapVoteOption(id, arenaName, old.displayName(), old.material()));
        saveVoteOptions();
    }

    private void saveVoteOptions() {
        ConfigurationSection section = configs.main().createSection("map-vote.options");
        for (MapVoteOption option : voteOptions.values()) {
            ConfigurationSection optionSection = section.createSection(option.id());
            optionSection.set("arena", option.arenaName());
            optionSection.set("display-name", option.displayName());
            optionSection.set("material", option.material().name());
        }
        plugin.saveConfig();
    }

    private void paintFrame(Inventory inventory, ConfigurationSection gui) {
        ItemStack filler = configuredItem(gui == null ? null : gui.getConfigurationSection("filler"),
                Material.BLACK_STAINED_GLASS_PANE, "<dark_gray> ", Map.of());
        ItemStack frame = configuredItem(gui == null ? null : gui.getConfigurationSection("frame"),
                Material.PURPLE_STAINED_GLASS_PANE, "<dark_gray> ", Map.of());
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            inventory.setItem(slot, filler);
        }
        int rows = inventory.getSize() / 9;
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            int row = slot / 9;
            int column = slot % 9;
            if (row == 0 || row == rows - 1 || column == 0 || column == 8) {
                inventory.setItem(slot, frame);
            }
        }
    }

    private void paintTitle(Inventory inventory, ConfigurationSection gui) {
        ConfigurationSection title = gui == null ? null : gui.getConfigurationSection("title-item");
        int slot = title == null ? 4 : title.getInt("slot", 4);
        if (slot >= 0 && slot < inventory.getSize()) {
            inventory.setItem(slot, configuredItem(title, Material.NETHER_STAR,
                    "<gradient:#FF4444:#FF8800:#FFD700><bold>\u2726 CAST YOUR VOTE \u2726</bold></gradient>", Map.of()));
        }
    }

    private void paintOptions(Player player, Inventory inventory, MapVoteGui holder, ConfigurationSection gui) {
        List<Integer> slots = gui == null ? List.of() : gui.getIntegerList("option-slots");
        if (slots.isEmpty()) {
            slots = DEFAULT_OPTION_SLOTS;
        }
        List<MapVoteOption> options = new ArrayList<>(voteOptions.values());
        for (int i = 0; i < options.size() && i < slots.size(); i++) {
            int slot = slots.get(i);
            if (slot < 0 || slot >= inventory.getSize()) {
                continue;
            }
            MapVoteOption option = options.get(i);
            inventory.setItem(slot, optionItem(player, option, gui));
            holder.options.put(slot, option.id());
        }
    }

    private ItemStack optionItem(Player player, MapVoteOption option, ConfigurationSection gui) {
        ConfigurationSection section = gui == null ? null : gui.getConfigurationSection("option-item");
        int mapVotes = voteCount(option.id());
        int totalVotes = Math.max(1, totalVotes());
        int percentage = (int) Math.round(mapVotes * 100.0D / totalVotes);
        boolean selected = option.id().equals(votes.get(player.getUniqueId()));
        String bar = voteBar(percentage);

        Arena arena = arenaManager.get(option.arenaName()).orElse(null);
        int playerCount = arena != null ? arena.players().size() : 0;
        String arenaStatus = arena != null ? (arena.status() == Arena.Status.IN_GAME ? "<red>In Game</red>" : "<green>Idle</green>") : "<gray>Unknown</gray>";

        Map<String, String> placeholders = Map.of(
                "map_name", option.displayName(),
                "map_votes", String.valueOf(mapVotes),
                "total_server_votes", String.valueOf(totalVotes()),
                "vote_percentage", String.valueOf(percentage),
                "vote_bar", bar,
                "selected", selected ? "<green>\u2714 Locked in</green>" : "<yellow>CLICK to lock in</yellow>",
                "player_count", String.valueOf(playerCount),
                "arena_status", arenaStatus
        );
        Material fallback = option.material();
        return configuredItem(section, fallback, option.displayName(), placeholders);
    }

    private static String voteBar(int percentage) {
        int filled = Math.min(10, Math.max(0, percentage / 10));
        return "\u2588".repeat(Math.max(0, filled)) + "\u2591".repeat(Math.max(0, 10 - filled));
    }

    private ItemStack configuredItem(ConfigurationSection section, Material fallback, String fallbackName,
                                     Map<String, String> placeholders) {
        Material material = section == null ? fallback : ConfigItems.material(section, "material", fallback);
        String name = section == null ? fallbackName : section.getString("name", fallbackName);
        return ItemBuilder.of(material)
                .name(TextUtil.parse(TextUtil.apply(name, placeholders)))
                .lore(section == null ? List.of() : TextUtil.lore(section, "lore", placeholders))
                .glow(section != null && section.getBoolean("glow", false))
                .customModelData(section == null ? null : ConfigItems.customModelData(section, "custom-model-data"))
                .build();
    }

    private Sound configuredSound(String path, Sound fallback) {
        String raw = configs.main().getString(path, "UI_BUTTON_CLICK");
        try {
            return Sound.valueOf(raw.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            return fallback;
        }
    }

    public record MapVoteOption(String id, String arenaName, String displayName, Material material) {}

    final class MapVoteGui extends GuiHolder {
        private final Player player;
        private final Map<Integer, String> options = new HashMap<>();

        private MapVoteGui(Player player) {
            this.player = player;
        }

        @Override
        public void handleClick(InventoryClickEvent event) {
            event.setCancelled(true);
            String option = options.get(event.getRawSlot());
            if (option != null) {
                handleVote(player, option);
            }
        }
    }
}
