package lol.folium.unstable.kit;

import lol.folium.unstable.UnstableRemixPlugin;
import lol.folium.unstable.command.SubCommand;
import lol.folium.unstable.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.List;

public final class KitEditorCommand extends SubCommand {

    private final UnstableRemixPlugin plugin;
    private final KitManager kitManager;

    public KitEditorCommand(UnstableRemixPlugin plugin, KitManager kitManager) {
        this.plugin = plugin;
        this.kitManager = kitManager;
    }

    @Override
    protected void execute(Player player, String[] args) {
        if (args.length == 0) {
            showHelp(player);
            return;
        }
        switch (args[0].toLowerCase()) {
            case "create" -> createKit(player, args);
            case "edit" -> editKit(player, args);
            case "preview" -> previewKit(player, args);
            case "list" -> listKits(player);
            case "help" -> showHelp(player);
            default -> showHelp(player);
        }
    }

    private void showHelp(Player player) {
        player.sendMessage(TextUtil.parse("<gold><bold>Kit Editor Commands</bold></gold>"));
        player.sendMessage(TextUtil.parse("<yellow>/kiteditor create <name></yellow> <dark_gray>-</dark_gray> <gray>Create kit from your inventory</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/kiteditor edit <name></yellow> <dark_gray>-</dark_gray> <gray>Edit kit layout in GUI</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/kiteditor preview <name></yellow> <dark_gray>-</dark_gray> <gray>Preview kit contents</gray>"));
        player.sendMessage(TextUtil.parse("<yellow>/kiteditor list</yellow> <dark_gray>-</dark_gray> <gray>List all available kits</gray>"));
        player.sendMessage(TextUtil.parse(""));
        player.sendMessage(TextUtil.parse("<green><bold>Quick Create:</bold></green>"));
        player.sendMessage(TextUtil.parse("<gray>1. Equip the items you want in the kit</gray>"));
        player.sendMessage(TextUtil.parse("<gray>2. Run /kiteditor create <name></gray>"));
        player.sendMessage(TextUtil.parse("<gray>3. Kit is saved with your current loadout!</gray>"));
    }

    private void createKit(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /kiteditor create <name></red>"));
            return;
        }
        String kitId = args[1].toLowerCase();

        kitManager.createKit(player, kitId);
        player.sendMessage(TextUtil.parse("<green>Kit <white>" + kitId + "</white> created from your current inventory!</green>"));
        player.sendMessage(TextUtil.parse("<gray>Run <white>/kiteditor edit " + kitId + "</gray> to customize further</gray>"));
    }

    private void editKit(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /kiteditor edit <name></red>"));
            return;
        }
        String kitId = args[1].toLowerCase();
        kitManager.openLayoutEditor(player, kitId);
    }

    private void previewKit(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<red>Usage: /kiteditor preview <name></red>"));
            return;
        }
        String kitId = args[1].toLowerCase();
        kitManager.openPreview(player, kitId);
    }

    private void listKits(Player player) {
        player.sendMessage(TextUtil.parse("<gold><bold>Available Kits</bold></gold>"));
        for (String kitId : kitManager.kitIds()) {
            player.sendMessage(TextUtil.parse("<gray>- <white>" + kitId + "</white></gray>"));
        }
    }

    @Override
    protected List<String> tabComplete(Player player, String[] args) {
        if (args.length == 1) {
            return filter(literals("create", "edit", "preview", "list", "help"), args[0]);
        }
        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if (sub.equals("edit") || sub.equals("preview")) {
                return filter(kitManager.kitIds(), args[1]);
            }
        }
        return List.of();
    }

    @Override
    protected String permission() {
        return "unstable.coreadmin";
    }
}
