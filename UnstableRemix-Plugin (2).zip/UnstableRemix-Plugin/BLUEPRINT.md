# UnstableRemix Advanced Core Blueprint

Paper 1.21.4 PvP core for Box PvP / Hardcore FFA. The current build implements economy, quests, map voting, arenas, effects, rent ranks, factions, arena events, combat tags, anti-log handling, exact-delay block sweeping, and PlaceholderAPI telemetry.

## Implemented Upgrade Pass

- `/balance`, `/pay`, and `/adminshards <give|remove|set|all>` with native tab completion and locked economy mutations.
- Combat tag manager with configurable duration, blocked menus/commands, anti-log inventory drops, and attacker reward payout.
- Progressive shard multiplier from active killstreak: +25% every 5 kills, capped at 2.0x.
- Expanded quest objectives: sword damage, player-placed cobweb breaks, and killstreak milestones.
- Quest GUI progress bars via `{progress_bar}` and `{percent}` placeholders in `quests.yml`.
- `/mapvote` holder-based 5-row GUI with configurable purple frame, gray filler, top-center Nether Star, live vote lore, click sound, and re-tally logic.
- Exact-delay block sweeper using a timestamp queue and per-tick budget instead of one large periodic clear.
- PlaceholderAPI identifiers: `unstable` and `remix`.

## Placeholder Matrix

- `%unstable_time_until_vote%`
- `%unstable_active_arena%`
- `%unstable_streak%`
- `%unstable_shards_formatted%`
- `%unstable_shard_multiplier%`
- `%unstable_combat_tag_remaining%`
- `%unstable_quests_claimable%`
- `%unstable_achievements_unlocked%`
- `%unstable_quests_completed_daily%`
- `%unstable_quests_completed_weekly%`
- `%unstable_quest_daily_1_progress%`
- `%unstable_quest_weekly_time_left%`

## Next Module Architecture

### Kits, Shop, Preview, Layout Editor

- Add `KitManager`, `KitDefinition`, `KitCommand`, `KitAdminCommand`, and `KitGuiService`.
- Store all kit display and item data in `kits.yml`.
- Use a secure `InventorySnapshot` object containing cloned contents, armor, offhand, cursor, game mode, and held slot.
- For preview/editor entry, cache snapshots by UUID only. Never store `Player` references in long-lived maps.
- On close/cancel/plugin disable, restore snapshots before clearing the session map.
- Purchases deduct coins first, then apply LuckPerms inheritance via native API. If LP fails, refund immediately.

### Cosmetics

- Add `CosmeticManager` with categories `KILL_SOUND` and `KILL_PARTICLE`.
- Gate entries by permission node and optional LuckPerms group.
- Persist unlocked/selected cosmetics as profile sets.
- Trigger effects in `CombatListener#onDeath` at victim death location.

### Bounties

- Add `/bounty <player> <amount>` and `/bounty top`.
- Store active bounties in SQL/cache by target UUID.
- Pay bounty to killer on death, using idempotency keys and per-target locks.

### Seasons

- Add `SeasonManager` with season ID, start/end timestamps, and stat snapshots.
- Add `/season`, `/season top`, `/coreadmin season start|end|reset`.
- Keep lifetime stats separate from seasonal stats so resets do not destroy permanent achievements.

### Discord Webhooks

- Use a single async queue for map-vote wins, high streaks, bounty claims, season results, and rare faction/kit unlocks.
- Never perform HTTP calls on the main server thread.
- Rate-limit duplicate event spam by event key.

### Anticheat Analytics

I can edit an anticheat if you provide the source/plugin folder. Recommended advanced checks:

- Aim-assist axis logging: record yaw/pitch deltas, acceleration, jerk, snap angle, target vector alignment, and cinematic-smoothing fingerprints.
- Trigger-bot telemetry: log time from target entering reach cone to attack packet, repeated low-variance reaction windows, and hit attempts at identical distance bands.
- Persistent hit-range analysis: bucket hits by distance, ping, velocity state, target hurt time, and line-of-sight state. Flag improbable clusters instead of one-off hits.
- Reach safety: compensate for latency, server TPS, movement interpolation, sprint state, knockback, and bounding box expansion.
- Violation design: use decay, evidence buffers, staff alerts, and replayable logs before punishments.

## Code Analysis Report

- Economy mutations use per-UUID locks; transfers lock UUIDs in stable order to avoid deadlocks.
- Quest claims remain idempotent through SQL keys.
- Combat tag state stores UUIDs and timestamps only, avoiding persistent `Player` references.
- Combat tag cleanup task is canceled on plugin disable.
- Map vote scheduled and vote-end tasks are canceled on stop/disable.
- Block sweeper processes a bounded number of blocks per tick and stores compact block keys.
- Placeholder expansion reads local manager caches and service state without script engines.
- GUI clicks use custom holders where upgraded, preventing inventory item stealing.
